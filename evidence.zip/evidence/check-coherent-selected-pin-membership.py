import ast,textwrap
from pathlib import Path
s=Path('.github/workflows/net-combined-dns-trusted-source.yml').read_text(); t=ast.parse(textwrap.dedent(s.split("          python3 -I - <<'PY'\n",1)[1].rsplit('\n          PY',1)[0])); ns={}
for n in t.body:
 if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in ('UNION_PINS','NATIVE_PINS','COHERENT_TCP_PINS') for x in n.targets): exec(compile(ast.Module(body=[n],type_ignores=[]),'pins','exec'),ns)
print({p:p in (ns['UNION_PINS']|ns['NATIVE_PINS']) for p in ns['COHERENT_TCP_PINS']})
