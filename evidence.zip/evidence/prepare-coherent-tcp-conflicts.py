from pathlib import Path
import subprocess
root=Path('C:/work/gesher-coherent-selected-tcp')
def stage(path,n):return subprocess.check_output(['git','show',f':{n}:{path}'],cwd=root).decode()
p='tools/host-pthread-authority/build-minimum-supplier.sh'; s=stage(p,3)
old='test "${GITHUB_JOB:-}" = build\ntest "${GESHER_HOST_PTHREAD_SELECTION:-}" = selected-minimum'
new='''if [[ "${GITHUB_JOB:-}" == compile ]]; then
  test "${GITHUB_REF:-}" = refs/heads/wip/tcp-minimum-selection
  test "${GITHUB_WORKFLOW:-}" = net-tcp-selected-component
  test "${TCP_SUPPLIER_ROLE:-}" = selected-minimum
else
  test "${GITHUB_JOB:-}" = build
  test "${GESHER_HOST_PTHREAD_SELECTION:-}" = selected-minimum
fi'''
assert s.count(old)==1; (root/p).write_text(s.replace(old,new),encoding='utf-8',newline='\n')
p='tools/host-pthread-authority/minimum_receipt.py'; s=stage(p,3)
old="    if os.environ.get('GESHER_HOST_PTHREAD_CALLER')=='pthread-first-link/build':"
new="""    if os.environ.get('GITHUB_JOB')=='compile':
        assert os.environ['GITHUB_REF'] == 'refs/heads/wip/tcp-minimum-selection'
        assert os.environ['GITHUB_WORKFLOW'] == 'net-tcp-selected-component'
        assert os.environ['TCP_SUPPLIER_ROLE'] == 'selected-minimum'
    elif os.environ.get('GESHER_HOST_PTHREAD_CALLER')=='pthread-first-link/build':"""
assert s.count(old)==1;s=s.replace(old,new)
old="    assert os.environ['GESHER_HOST_PTHREAD_SELECTION'] in ('publisher-control','selected-minimum')"
new="    if os.environ['GITHUB_JOB'] != 'compile':\n        assert os.environ['GESHER_HOST_PTHREAD_SELECTION'] in ('publisher-control','selected-minimum')"
assert s.count(old)==1;s=s.replace(old,new)
old="    assert os.environ['GITHUB_JOB'] == 'build'\n    target = llvm / 'x86_64-w64-mingw32'"
new="    assert os.environ['GITHUB_JOB'] in ('compile','build')\n    target = llvm / 'x86_64-w64-mingw32'"
assert s.count(old)==1;s=s.replace(old,new)
for old in ("    assert os.environ['GITHUB_JOB'] == 'build' and os.environ['GESHER_HOST_PTHREAD_SELECTION']=='selected-minimum'", "    assert os.environ['GITHUB_JOB']=='build' and os.environ['GESHER_HOST_PTHREAD_SELECTION']=='selected-minimum'"):
 assert s.count(old)==1;s=s.replace(old,"    assert os.environ['GITHUB_JOB']=='compile' or (os.environ['GITHUB_JOB']=='build' and os.environ['GESHER_HOST_PTHREAD_SELECTION']=='selected-minimum')")
(root/p).write_text(s,encoding='utf-8',newline='\n')
