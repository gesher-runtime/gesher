# PURE actual receiver-stage extraction. Native calls replaced with managed
# doubles, loop12 guard/Sleep removal explicit. No bridge import/AddType/native.
$path='C:/work/gesher-ci-graphics-processes/tests/windows/tracks/84-ci-processes.ps1'
$t=$null;$e=$null;$a=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
$loops=@($a.FindAll({param($n)$n -is [Management.Automation.Language.WhileStatementAst] -and $n.Extent.Text.Contains("'UNKNOWN_LAUNCH'")},$true))
if($loops.Count -ne 1){throw 'receiver extraction'}
$reader=$a.Find({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$graphics84ReadBounded'},$true)
. ([scriptblock]::Create($reader.Extent.Text))
$code=$loops[0].Extent.Text.Replace('while($true)','while($global:Steps++ -lt 12)').Replace('[Threading.Thread]::Sleep(5000)','$null')
$map=@{'[Graphics84]::GetProcessId($g.Slot.Handle)'='(Invoke-FakePid)';'[Graphics84]::Birth($g.Slot.Handle)'='(Invoke-FakeBirth)';'[Graphics84]::WaitForSingleObject($g.Slot.Handle,0)'='(Invoke-FakeWait 0)';'[Graphics84]::WaitForSingleObject($g.Slot.Handle,5000)'='(Invoke-FakeWait 5000)';'[Graphics84]::TerminateProcess($g.Slot.Handle,1)'='(Invoke-FakeTerminate)';'[Graphics84]::Close($g.Slot)'='Invoke-FakeClose'}
foreach($k in $map.Keys){$code=$code.Replace($k,$map[$k])}
$code=$code.Replace('[Gtest84NativeHandles]::Closed([IntPtr][long]$pair.Groups[1].Value)','$true').Replace('[Gtest84NativeHandles]::Closed([IntPtr][long]$pair.Groups[2].Value)','$true')
# Last-error observations are replaced too; never invoke the native bridge.
$code=$code.Replace('[Runtime.InteropServices.Marshal]::GetLastWin32Error()','6')
function Invoke-FakePid {if($global:Case -eq 'query_error'){throw 'injected query'};if($global:Case -eq 'wrong_identity'){return 89};return 88}
function Invoke-FakeBirth {if($global:Case -eq 'wrong_creation'){return [UInt64]3};return [UInt64]987654321}
function Invoke-FakeWait($ms){$global:WaitCalls++;if($global:Case -eq 'wait_throw'){throw 'injected wait'};if($global:Case -eq 'passive' -and $ms -ne 0 -and $global:WaitCalls -lt 4){return [uint32]258};if($global:Case -eq 'wait_failed'){return [uint32]::MaxValue};if($global:Case -eq 'wait_abandoned'){return [uint32]128};if($ms -eq 0){return [uint32]258};return [uint32]0}
function Invoke-FakeTerminate {$global:Kills++;if($global:Case -eq 'kill_unknown'){throw 'injected unreturned kill'};return $true}
function Invoke-FakeClose {if($g.Slot.State -eq 'FAILED'){throw 'unknown close no retry'};$global:Closes++;$g.Slot.State='FAILED';if($global:Case -eq 'close_unknown'){throw 'injected close/invalidity uncertainty'};$g.Slot.State='DONE'}
function Write-Host {if($global:Case -eq 'sink_error'){throw 'injected sink'}}
$env:GITHUB_SHA='a'*40;$env:GESHER_GRAPHICS84_NONCE='ab'*32;$env:GESHER_GRAPHICS84_OWNER_FILETIME='123456789';$env:GESHER_GRAPHICS84_RECEIPT='C:/work/gesher-ci-review/graphicsdex-managed-input';$graphics84Exe='OWNED/dalvikvm.exe';$mode='retained';$script:failed=0
$cases=@('normal','foreign_parent','parent_birth','nonce','source','publication','child_pid','child_birth','zero_handle','pseudo_handle','width','rights','image','fixture_pid','fixture_birth','escrow_done','release_missing','missing_key','unknown_key','duplicate_key','oversize','malformed_utf8','parent_not_done','parent_nonzero','parent_tree_kill','wrong_identity','wrong_creation','query_error','wait_failed','wait_abandoned','kill_unknown','close_unknown','sink_error','wait_throw','passive')
$results=@()
foreach($case in $cases){
 $global:Case=$case;$global:Steps=0;$global:Kills=0;$global:Closes=0;$global:WaitCalls=0
 $r=[ordered]@{schema='GRAPHICS84_HANDLE_TRANSFER_V1';source=$env:GITHUB_SHA;case='retained';nonce=$env:GESHER_GRAPHICS84_NONCE;bits=64;parent_pid=$PID;parent_creation_filetime='123456789';fixture_pid=99;fixture_creation_filetime='111111111';child_pid=88;child_creation_filetime='987654321';destination_handle_hex16='0000000012345678';duplicate_state='RETURNED_OWNED_TARGET';expected_create_application_path=$graphics84Exe;parent_access='0x1040';child_access='0x101001';inherit=$false;options=0;publication_phase='TRANSFER_PUBLISHED';source_prepublication_releases=@{thread='DONE';output='DONE';error='DONE';target='DONE'};source_child_escrow='REQUIRES_EXACT_PARENT_NATIVE_EXIT0'}
 $obs=[pscustomobject]@{Source=$env:GITHUB_SHA;Case='retained';Nonce=$env:GESHER_GRAPHICS84_NONCE;Pid=[UInt32]99;CreationFiletime=[UInt64]111111111;KernelComplete=$true;NativeExitCode=0;KillReserved=$false;Released=$true;MarkerPresent=$true;OperationExpired=$false;EofComplete=$false;TasksComplete=$true;PipesClosed=2;ObservationFailed=$true;MechanismFailure=$false;CleanupBudgetExpired=$false;ExpectedImage=$graphics84Exe}
 switch($case){foreign_parent {$r.parent_pid=$PID+1} parent_birth {$r.parent_creation_filetime='1'} nonce {$r.nonce='00'*32} source {$r.source='b'*40} publication {$r.publication_phase='PENDING'} child_pid {$r.child_pid=89} child_birth {$r.child_creation_filetime='1'} zero_handle {$r.destination_handle_hex16='0'*16} pseudo_handle {$r.destination_handle_hex16='f'*16} width {$r.bits=32} rights {$r.child_access='0x1fffff'} image {$r.expected_create_application_path='FOREIGN'} fixture_pid {$r.fixture_pid=100} fixture_birth {$r.fixture_creation_filetime='2'} escrow_done {$r.source_child_escrow='DONE'} release_missing {$r.source_prepublication_releases=@{}} missing_key {$r.Remove('source')} unknown_key {$r.extra='bad'} parent_not_done {$obs.KernelComplete=$false} parent_nonzero {$obs.NativeExitCode=23} parent_tree_kill {$obs.KillReserved=$true}}
 $json=$r|ConvertTo-Json -Depth 5 -Compress
 if($case -eq 'duplicate_key'){$json=$json.Replace('"schema":','"source":"a","schema":')}
 if($case -eq 'oversize'){$json=' '*16385}
 $bytes=[Text.Encoding]::UTF8.GetBytes($json);if($case -eq 'malformed_utf8'){$bytes=[byte[]]@(255)}
 [IO.File]::WriteAllBytes($env:GESHER_GRAPHICS84_RECEIPT+'.child',$bytes)
 $g=@{Phase='Receipt';Failed=$false;Pending=$true;Receipt='UNATTEMPTED';Query='UNATTEMPTED';Wait='UNATTEMPTED';Kill=$false;Closed=$false;Slot=[pscustomobject]@{Handle=[IntPtr]::Zero;State='UNATTEMPTED'};Obs=$obs;Text='kernel=True tasks=True pipes=2 disposed=True output=101 error=102 reader did not complete within ten seconds';Document=$null;DocClose='UNATTEMPTED';Delta=1;Before=0;ParentBound=$true;ParentReceipt='DONE';ChildNonsignaled=$false;Inputs=@{Child=@{Open='UNATTEMPTED';Stream=$null;Read='UNATTEMPTED';Close='UNATTEMPTED';Buffer=[byte[]]::new(16385);Count=0;Requested=0;Eof=$false;Text=$null}}}
 . ([scriptblock]::Create($code))
 if($case -eq 'normal'){if($g.Pending -or $g.Failed -or $global:Kills -ne 1 -or $global:Closes -ne 1){throw 'positive actual receiver failed'}}
 elseif($case -eq 'passive'){if(-not $g.Failed -or $g.Pending -or $global:Kills -ne 1 -or $global:Closes -ne 1){throw 'passive eventual settlement lost failure'}}
 elseif($case -eq 'sink_error'){if(-not $g.Failed -or $global:Closes -ne 1){throw 'sink uncertainty not retained'}}
 else{if(-not $g.Pending -or -not $g.Failed){throw "$case unknown owner escaped"}}
 if($global:Kills -gt 1 -or $global:Closes -gt 1){throw 'blind retry'}
 $results += [ordered]@{case=$case;pending=$g.Pending;failed=$g.Failed;kills=$global:Kills;closes=$global:Closes;state=$g.Slot.State;iterations=$global:Steps}
}
$out='C:/work/gesher-ci-review/graphicsdex-correction-receiver-source-results.json';[IO.File]::WriteAllText($out+'.tmp',(($results|ConvertTo-Json -Depth 5).Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false));[IO.File]::Move($out+'.tmp',$out,$true)
'35 actual receiver-source controls PASS; synthetic native/identity/close results; loop12 truncation'
