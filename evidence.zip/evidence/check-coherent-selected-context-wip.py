import importlib.util, os, subprocess
from pathlib import Path
R=Path('C:/work/gesher-coherent-selected-tcp'); os.chdir(R)
spec=importlib.util.spec_from_file_location('minimum',R/'tools/host-pthread-authority/minimum_receipt.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=dict(GITHUB_ACTIONS='true',GITHUB_REPOSITORY='gesher-runtime/gesher',GITHUB_REPOSITORY_ID='1426153186',GITHUB_SHA=source,GITHUB_WORKFLOW_SHA=source,GITHUB_RUN_ID='1',GITHUB_RUN_ATTEMPT='1',GITHUB_ACTOR='palmoni5',GITHUB_TRIGGERING_ACTOR='palmoni5',GITHUB_EVENT_NAME='push')
tcp=dict(base,GITHUB_JOB='compile',GITHUB_REF='refs/heads/wip/tcp-minimum-selection',GITHUB_WORKFLOW='net-tcp-selected-component',TCP_SUPPLIER_ROLE='selected-minimum')
off=dict(base,GITHUB_JOB='build',GITHUB_REF='refs/heads/wip/pthread-native-runtime161',GITHUB_WORKFLOW='pthread-native-off-receiver-component',GITHUB_WORKFLOW_REF='gesher-runtime/gesher/.github/workflows/pthread-native-off-receiver-component.yml@refs/heads/wip/pthread-native-runtime161',GESHER_HOST_PTHREAD_CALLER='pthread-native-off-receiver/build',GESHER_HOST_PTHREAD_SELECTION='selected-minimum',GESHER_NATIVE_OFF_RECEIVER_AUTHORIZED_SOURCE=source,GESHER_NATIVE_OFF_RECEIVER_POLICY_REF='gesher-runtime/gesher/.github/workflows/pthread-native-off-receiver-trusted-source.yml@'+'a'*40)
full=dict(base,GITHUB_JOB='build',GITHUB_REF='refs/heads/wip/coherent-selected-tcp',GITHUB_WORKFLOW='ci',GITHUB_WORKFLOW_REF='gesher-runtime/gesher/.github/workflows/ci.yml@refs/heads/wip/coherent-selected-tcp',GITHUB_EVENT_NAME='workflow_dispatch',GESHER_HOST_PTHREAD_CALLER='coherent-selected-full/build',GESHER_HOST_PTHREAD_SELECTION='selected-minimum',GESHER_COHERENT_FULL_AUTHORIZED_SOURCE=source,GESHER_COHERENT_FULL_POLICY_REF='gesher-runtime/gesher/.github/workflows/net-combined-dns-trusted-source.yml@'+'a'*40)
old=dict(os.environ)
def check(e,valid):
 os.environ.clear();os.environ.update({k:old[k] for k in ('PATH','SYSTEMROOT') if k in old});os.environ.update(e)
 try:m.context()
 except (AssertionError,KeyError):
  if valid:raise
 else:
  if not valid:raise AssertionError('wrong role admitted')
try:
 for case in (tcp,off,full):
  check(case,True)
  for key in ('GITHUB_REF','GITHUB_WORKFLOW','GITHUB_JOB','GITHUB_REPOSITORY'):
   bad=dict(case);bad[key]='foreign';check(bad,False)
 bad=dict(tcp);bad['TCP_SUPPLIER_ROLE']='publisher';check(bad,False)
 bad=dict(off);bad['GESHER_NATIVE_OFF_RECEIVER_AUTHORIZED_SOURCE']='b'*40;check(bad,False)
 bad=dict(full);bad['GESHER_COHERENT_FULL_AUTHORIZED_SOURCE']='b'*40;check(bad,False)
 bad=dict(full);bad['GITHUB_EVENT_NAME']='push';check(bad,False)
finally:os.environ.clear();os.environ.update(old)
print('WIP_CONTEXT_PASS separate TCP, OFF and full selected contexts, adverse role/source cases; authority mocked')
