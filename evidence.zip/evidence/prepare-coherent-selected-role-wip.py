from pathlib import Path
r=Path('C:/work/gesher-coherent-selected-tcp')
def replace(p,a,b):
 q=r/p;s=q.read_text(encoding='utf-8');assert s.count(a)==1,(p,a,s.count(a));q.write_text(s.replace(a,b),encoding='utf-8',newline='\n')
p='tools/host-pthread-authority/minimum_receipt.py'
replace(p,"    elif os.environ.get('GESHER_HOST_PTHREAD_CALLER')=='pthread-first-link/build':","    elif os.environ.get('GESHER_HOST_PTHREAD_CALLER')=='coherent-selected-full/build':\n        sys.path.insert(0,str(ROOT/'tools/toolchain'))\n        import coherent_selected_context as coherent\n        coherent.context(os.environ,'selected-minimum')\n    elif os.environ.get('GESHER_HOST_PTHREAD_CALLER')=='pthread-first-link/build':")
p='tools/toolchain/prepare_host_pthread.py'
replace(p,"def caller(env,selection):\n", "def caller(env,selection):\n    if env.get('GESHER_HOST_PTHREAD_CALLER') == 'coherent-selected-full/build':\n        import coherent_selected_context as coherent\n        return coherent.context(env,selection)\n")
replace(p,"    assert caller_key in ('ci/build', focused.CALLER, 'pthread-native-off-receiver/build')", "    assert caller_key in ('ci/build', focused.CALLER, 'pthread-native-off-receiver/build', 'coherent-selected-full/build')")
replace(p,"    if caller_key=='pthread-native-off-receiver/build':paths+=['tools/toolchain/native_off_receiver_context.py']", "    if caller_key=='pthread-native-off-receiver/build':paths+=['tools/toolchain/native_off_receiver_context.py']\n    if caller_key=='coherent-selected-full/build':paths+=['tools/toolchain/coherent_selected_context.py']")
replace(p,"    if caller_key == focused.CALLER:result['focused_caller']=focused.TUPLE", "    if caller_key == 'coherent-selected-full/build':\n        import coherent_selected_context as coherent\n        result['coherent_selected_caller']=coherent.TUPLE\n    if caller_key == focused.CALLER:result['focused_caller']=focused.TUPLE")
p='tools/toolchain/selected_link.cmake'
replace(p,'elseif(NOT "$ENV{GESHER_HOST_PTHREAD_CALLER}" STREQUAL "ci/build")','''elseif("$ENV{GESHER_HOST_PTHREAD_CALLER}" STREQUAL "coherent-selected-full/build")
  execute_process(COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_LIST_DIR}/coherent_selected_context.py"
                  RESULT_VARIABLE _gesher_coherent_selected_context)
  if(NOT _gesher_coherent_selected_context EQUAL 0)
    message(FATAL_ERROR "Exact coherent selected full caller authority failed")
  endif()
elseif(NOT "$ENV{GESHER_HOST_PTHREAD_CALLER}" STREQUAL "ci/build")''')
p='.github/workflows/ci.yml'
replace(p,'    needs: [artifact-preflight]\n    runs-on: ubuntu-24.04\n    env:\n      GESHER_HOST_PTHREAD_SELECTION: ${{ github.ref == \'refs/heads/wip/pthread-production-factory\' && \'selected-minimum\' || \'publisher\' }}','''    needs: [artifact-preflight, union-trusted-source]
    runs-on: ubuntu-24.04
    env:
      GESHER_HOST_PTHREAD_SELECTION: ${{ (github.ref == 'refs/heads/wip/pthread-production-factory' || github.ref == 'refs/heads/wip/coherent-selected-tcp') && 'selected-minimum' || 'publisher' }}
      GESHER_HOST_PTHREAD_CALLER: ${{ github.ref == 'refs/heads/wip/coherent-selected-tcp' && 'coherent-selected-full/build' || 'ci/build' }}
      GESHER_COHERENT_FULL_AUTHORIZED_SOURCE: ${{ needs.union-trusted-source.outputs.source }}
      GESHER_COHERENT_FULL_POLICY_REF: ${{ needs.union-trusted-source.outputs.policy_ref }}''')
replace(p,'          pthread-caller: ci/build','          pthread-caller: ${{ env.GESHER_HOST_PTHREAD_CALLER }}')
replace(p,"printf 'GESHER_SELECTED_PTHREAD_RECEIPT=%s\\nGESHER_SELECTED_PTHREAD_RECEIPT_SHA256=%s\\nGESHER_HOST_PTHREAD_CALLER=ci/build\\n' \"$SELECTED_RECEIPT\" \"$SELECTED_RECEIPT_SHA256\" >> \"$GITHUB_ENV\"", "printf 'GESHER_SELECTED_PTHREAD_RECEIPT=%s\\nGESHER_SELECTED_PTHREAD_RECEIPT_SHA256=%s\\n' \"$SELECTED_RECEIPT\" \"$SELECTED_RECEIPT_SHA256\" >> \"$GITHUB_ENV\"")
