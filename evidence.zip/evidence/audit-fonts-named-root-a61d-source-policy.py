"""Exact synthetic/immutable-Git source audit; --noop REQUIRES a separate lease."""
from pathlib import Path
import ast,contextlib,copy,hashlib,io,json,os,re,subprocess,sys,textwrap,yaml
R=Path('C:/work/gesher-fonts-resource-parser');O=Path('C:/work/gesher-ci-review');os.chdir(R)
C='a61d01adbc2de537c1b90b17944af3783cfbb3ae';BASE='2a3a485e7890619c7a756bffee6255c4a9296e00'
def git(*args):return subprocess.check_output(['git',*args])
def require(value,label):
 if not value:raise AssertionError(label)
require(git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain','--untracked-files=all').strip(),'exact clean candidate')
paths={'tools/fonts/resource-witness.py','tools/fonts/test-resource-witness.py','docs/handoff/tracks/fonts-resource-component-source.md','.github/workflows/fonts-resource-trusted-source.yml','.github/workflows/fonts-resource-component.yml'}
require(set(git('diff','--name-only',BASE,C).decode().splitlines())==paths,'exact five paths')
for commit in git('rev-list',BASE+'..'+C).decode().splitlines():require(b'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>'in git('show','-s','--format=%B',commit),'trailer')
raw=Path('.github/workflows/fonts-resource-trusted-source.yml').read_bytes()
code=textwrap.dedent(raw.decode().split("          python3 -I - <<'PY'\n",1)[1].rsplit('\n          PY',1)[0]);tree=ast.parse(code)
tree.body=[n for n in tree.body if not(isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)and isinstance(n.value.func,ast.Name)and n.value.func.id=='main')]
n={};exec(compile(tree,'disk-source-policy','exec'),n)
record=io.StringIO();noop='NOT_GRANTED_NOT_EXECUTED'
with contextlib.redirect_stdout(record):
 full=n['frozen_host']();actual=full['inventory'](C);expected=full['inventory'](n['BASE'])
 for p,b in n['EXTRA_PINS'].items():
  if not p.startswith('docs/'):expected[p]=('100644',b)
 for p in (n['CALLER'],n['TRUST']):expected[p]=actual[p]
 full['verify_tree'](actual,expected);full['verify_checkout'](expected);n['verify_documents'](C);n['verify_current_selected'](full,actual)
 full['verify_historical'](full['inventory'](full['ORIGINAL_BASE']));full['verify_selected'](full['inventory'](full['BASE']))
 for p in n['EXTRA_PINS']:
  bad=copy.deepcopy(actual);bad[p]=('100644','0'*40);n['reject']('disk_leaf_'+p,lambda:full['verify_tree'](bad,expected))
 for p in n['SELECTED_APPROVED_BASE']:
  bad=copy.deepcopy(actual);bad[p]=('100644','0'*40);n['reject']('selected_'+p,lambda:n['verify_current_selected'](full,bad))
 bad=copy.deepcopy(actual);bad['tools/fonts/unapproved-disk.py']=('100644','0'*40);n['reject']('unknown_disk_path',lambda:full['verify_tree'](bad,expected))
 approved=git('show',C+':'+n['CALLER']);refs=re.findall(rb'fonts-resource-trusted-source.yml@([0-9a-f]{40})',approved);require(len(refs)==1,'one guard');guard=refs[0].decode()
 require(git('show',guard+':'+n['TRUST'])==raw,'selfpin')
 template=git('show',n['TEMPLATE']+':'+n['CALLER']);require(approved==template.replace(b'fonts-resource-trusted-source.yml@'+b'0'*40,b'fonts-resource-trusted-source.yml@'+guard.encode()),'exact DAG template')
 if '--noop'in sys.argv:
  # Established ten caller/guard/ordinary policy paths plus two current docs.
  members=(n['CALLER'],n['TRUST'],'.github/workflows/ci.yml','.github/workflows/net-combined-dns-trusted-source.yml','.github/workflows/fonts-core-trusted-source.yml','.github/workflows/fonts-environment-trusted-source.yml','.github/workflows/fonts-owner-host-trusted-source.yml','.github/workflows/fonts-debugger-preflight-trusted-source.yml','tools/native3-locks/union_payload.py','tools/native3-locks/union_blocking_guard.py')
  original={p:Path(p).read_bytes()for p in members}
  try:
   for p in original:Path(p).write_bytes(b'pass\n')
   n['reject']('actual_noop_all_layers',lambda:full['verify_checkout'](expected))
  finally:
   for p,b in original.items():Path(p).write_bytes(b)
  for p in n['EXTRA_PINS']:
   if not p.startswith('docs/'):continue
   original=Path(p).read_bytes()
   try:Path(p).write_bytes(b'pass\n');n['reject']('actual_noop_doc_'+p,lambda:n['verify_documents'](C))
   finally:Path(p).write_bytes(original)
  full['verify_checkout'](expected);full['isolated_import_controls']();noop='CLOSED_RESTORED_CLEAN'
 require(not git('status','--porcelain','--untracked-files=all').strip(),'clean after policy')
workflows={p:b for p,(mode,b)in full['inventory'](n['BASE']).items()if p.startswith('.github/workflows/')}
require(all(actual[p][1]==b for p,b in workflows.items()),'65 original workflows unchanged')
caller=yaml.load(approved,Loader=yaml.BaseLoader)
require(set(caller['jobs'])=={'trusted-source','fixture-producer','characterization'},'DAG roles')
require(caller['jobs']['fixture-producer']['needs']=='trusted-source'and caller['jobs']['characterization']['needs']==['trusted-source','fixture-producer'],'needs')
require(caller['jobs']['characterization']['strategy']['matrix']['os']==['windows-2022','windows-2025'],'hosts')
require(caller['on']['push']['branches']==['wip/fonts-resource-parser']and caller['on']['push']['paths']==[n['CALLER']],'trigger')
require(caller['concurrency']['cancel-in-progress']=='false','no cancellation')
run={'id':9,'run_attempt':1,'head_sha':C,'name':'fonts-resource-component','path':n['CALLER'],'event':'push','head_branch':'wip/fonts-resource-parser','repository':{'full_name':n['REPO'],'id':1426153186},'head_repository':{'full_name':n['REPO'],'id':1426153186},'actor':{'login':'palmoni5'},'triggering_actor':{'login':'palmoni5'}}
n['run_identity'](run,C,'9','1','push');identity_negatives=0
for key,value in [('id',0),('run_attempt',2),('head_sha','0'*40),('name','ci'),('path','x'),('event','schedule'),('head_branch','main')]:
 bad=copy.deepcopy(run);bad[key]=value
 try:n['run_identity'](bad,C,'9','1','push')
 except RuntimeError:identity_negatives+=1
 else:raise AssertionError(key)
for key in ('repository','head_repository','actor','triggering_actor'):
 bad=copy.deepcopy(run);bad[key]['id'if 'repository'in key else 'login']=-1
 try:n['run_identity'](bad,C,'9','1','push')
 except RuntimeError:identity_negatives+=1
 else:raise AssertionError(key)
runner=Path('tools/fonts/resource-characterization.ps1').read_text(encoding='utf-8')
old=git('show',BASE+':tools/fonts/resource-characterization.ps1').decode()
predicate=next(v for v in old.splitlines()if "throw 'UNAVAILABLE: retained current ntdll profile/module mismatch'"in v)
require(predicate in runner.splitlines(),'original NTDLL predicate byte exact')
for p in ('tools/fonts/resource-code-provider.py','tools/fonts/resource-import-inventory.py','tools/fonts/resource-pe-imports.py','tests/native/font_environment_resource_characterization.cc','tools/fonts/resource-manifest.py','tools/fonts/resource-protocol.py'):
 require(Path(p).read_bytes()==git('show',BASE+':'+p),'preserved '+p)
require(len(actual)==1638 and len(n['EXTRA_PINS'])==18,'same whole/pins')
checks=[]
if '--checks'in sys.argv:
 scripts=['test-resource-pe-imports.py','test-resource-protocol.py','test-resource-source.py','test-resource-code.py','test-resource-witness.py','test-debugger-probe.py','test-core-assembly.py','test-cli-link-evidence.py','test-environment-metadata.py','test-owner-host-evidence.py','test-resource-characterization.ps1','test-debugger-preflight.ps1','test-dex-arguments.ps1','test-environment-arguments.ps1','test-owner-host-arguments.ps1']
 for name in scripts:
  args=['pwsh','-NoProfile','-File']if name.endswith('.ps1')else ['python','-B']
  result=subprocess.run(args+[str(R/'tools/fonts'/name)],capture_output=True,encoding='utf-8');require(result.returncode==0,(name,result.stdout,result.stderr))
  checks.append({'script':name,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
require(not git('status','--porcelain','--untracked-files=all').strip(),'final CLEAN')
summary={'source':C,'guard':guard,'guard_blob':git('rev-parse',guard+':'+n['TRUST']).decode().strip(),'template':n['TEMPLATE'],'paths':sorted(paths),'pins':len(n['EXTRA_PINS']),'whole_paths':len(actual),'old_workflows':len(workflows),'history':len(full['HISTORICAL_PINS']),'inner':len(full['SOURCE_PINS']),'inner_fonts':len(full['FONTS_PINS']),'policy_negative_lines':sum('=rejected'in v for v in record.getvalue().splitlines()),'identity_negatives':identity_negatives,'noop':noop,'checks':checks,'native_processes_started':0,'CI_dispatched':False}
suffix='noop'if '--noop'in sys.argv else 'readonly'
for name,payload in [(f'fonts-named-root-a61d01ad-{suffix}-source-policy.json',json.dumps(summary,indent=2,ensure_ascii=True)+'\n'),(f'fonts-named-root-a61d01ad-{suffix}-source-policy.log',record.getvalue())]:
 target=O/name;temp=target.with_suffix(target.suffix+'.tmp')
 with temp.open('w',encoding='utf-8',newline='\n')as f:f.write(payload);f.flush();os.fsync(f.fileno())
 os.replace(temp,target)
print(json.dumps({k:v for k,v in summary.items()if k!='checks'},indent=2))
