from pathlib import Path
import ast,subprocess,textwrap
r=Path('C:/work/gesher-coherent-selected-tcp');s=(r/'.github/workflows/net-combined-dns-trusted-source.yml').read_text();tree=ast.parse(textwrap.dedent(s.split("          python3 -I - <<'PY'\n",1)[1].rsplit('\n          PY',1)[0]));tree.body=[n for n in tree.body if not(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='main')];ns={};exec(compile(tree,'guard-definitions','exec'),ns)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(); t=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=r,text=True).strip();other=subprocess.check_output(['git','commit-tree',t,'-p',head],cwd=r,input='Synthetic same-tree authority negative\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\n',text=True).strip();assert other!=head
assert subprocess.check_output(['git','rev-parse',other+'^{tree}'],cwd=r,text=True).strip()==t
assert subprocess.check_output(['git','show',other+':.github/workflows/ci.yml'],cwd=r)==subprocess.check_output(['git','show',head+':.github/workflows/ci.yml'],cwd=r)
try:ns['verify_external_authority'](other,head)
except RuntimeError:print('SAME_TREE_DISTINCT_COMMIT_REJECTED approved='+other+' actual='+head)
else:raise AssertionError('same-tree different commit authorized')
