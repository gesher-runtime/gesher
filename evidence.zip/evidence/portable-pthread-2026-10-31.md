# Portable pthread checkpoint — 2026-10-31

Stop checkpoint; no CI, dispatch, publication to authority refs, or product qualification is authorized by these refs. All listed local worktrees were clean at handoff. Fetch these explicit refs on the other computer; do not use the checkpoint branches as source authority.

| Local tree | Remote ref | Exact source commit |
|---|---|---|
| C:/work/gesher-pthread-minimum-join-witness-runtime | refs/heads/checkpoint/pthread-witness-runtime-20261031 | 5e35b0dd80f627bd446c4371b5d8d691645e97f7 |
| C:/work/gesher-pthread-minimum-join-nontail-object | refs/heads/checkpoint/pthread-nontail-object-20261031 | 9e9fc4915dab742b3dbf7649432505d6f9c473bf |
| C:/work/gesher-pthread-minimum-join-cancellation | refs/heads/wip/pthread-minimum-join-cancellation | 1fe0068e417e61b9bd77078844723e11d7b7d03d |
| C:/work/gesher-pthread-native-runtime161 | refs/heads/wip/pthread-native-runtime161 | fcb41c8c3fb0796260fd672d65554d09282ba6d9 |
| C:/work/gesher-pthread-native-off-receiver | refs/heads/wip/pthread-native-off-receiver | 99743d7fb1305cc9400dd2522369716cf7a6d4eb |

The 9e9 guard 5a5c226e4c95c076c01028881fad01902f395655 is an ancestor of the pushed 9e9 checkpoint; prior 1fe guard 70d73132368f08d855dd7d3d1603da9bd7c65bce is an ancestor of the runtime checkpoint; fcb guard 6edcb921e546698e503f18ad93e3dac690487be4 is an ancestor of fcb. Checkpoint refs read back from origin exactly. Other guard identities and complete freeze conditions are in the reports.

5e35 is unfinished, unreviewed source-only WIP. Its gate pins are stale and its workflow guard pin is zero; the controller intentionally returns UNKNOWN and does not execute cancellation without a target-bound live wait proof. No compile or runtime evidence exists for it. Before any new CI, finish and review source, exact producer/static/DLL/current-source role and policy authority, independently peer, and obtain normal scheduling. Do not treat phase notification or generic OS wait as proof. The separate 9e9 non-tail compile-only candidate remains frozen and awaiting independent peer/CI; actual compiled code generation must be verified, never inferred from source.

Prior bounded evidence: run 41221763220 attempt 1, fcb, all five jobs success; independently verified both Windows hosts 161 rows/mismatch zero, 13 modes/failures zero, four stdio cycles. Run 41224370978 attempt 1, 1fe, two jobs success; actual diagnostic object tail-jumps WaitForSingleObject, so the wrapper may be absent from a live stack. Neither result establishes the live join/cancel witness or full product qualification. The 412217 build raw fetch returned 418; the separately saved gh-rendered fallback is the evidence, not the failed HTML. Existing raw-log leases and observers are closed; do not fetch or watch again without following the track rules.

Portable evidence needed from C:/work/gesher-ci-review (local files, do not upload secrets or CI artifacts):
- runtime161-412217-* including logs, receipts, leases, metadata, summaries, independent audit; audit-runtime161-412217-independent.py.
- join-collector-412243-* including logs, receipts, leases, metadata, summary and independent audit.
- pthread-minimum-join-nontail-9e9-source-freeze.md; coherent-selected-tcp-same-attempt-supplier-correlation-design.md; native-helper-b922-pthread-independent-source-peer.md; fonts-named-root-a61d-pthread-independent-source-peer.md.
- Preserve the other owners' portable handoffs and evidence lists as directed by integration; their source trees are not owned here.

Constraints persist: C/C++/Java/C# builds and native/JVM/C# fixtures only in CI; no WSL or local CI artifact downloads; logs permitted. Every GitHub write requires immediately preceding gh api user --jq .login = palmoni5; commits include Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>. Do not touch C:/work/gesher-backup-2026-10-23. Historical flagged Web4 5fac continuation is preservation-only; do not inspect or resume it. No main, tag, PR or release changes. Read docs/handoff/track-rules.md and current manager coordination before resuming.
