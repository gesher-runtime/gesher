import subprocess,json
from pathlib import Path
R=Path('C:/work/gesher-int')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],text=True).splitlines()
flagged='5facaf7025976b66be2874e68e3e8073a5ee20b7'; base='f320'; accepted='1bf8fad9ec3b423ddef8c97c1d72b25790974364'; proposed='27f1e54cbc9c026689f31dc87cecddda370e6bbb'
print('flagged_base',git('rev-parse',base)[0])
a=set(git('diff','--name-only',base,flagged)); b=set(git('diff','--name-only',accepted,proposed))
print(json.dumps({'flagged_changed_paths':sorted(a),'proposed_changed_paths_count':len(b),'overlap_paths':sorted(a&b),'accepted_ancestor_of_proposed':subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',accepted,proposed]).returncode==0,'flagged_ancestor_of_accepted':subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',flagged,accepted]).returncode==0,'flagged_ancestor_of_proposed':subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',flagged,proposed]).returncode==0},indent=2))
