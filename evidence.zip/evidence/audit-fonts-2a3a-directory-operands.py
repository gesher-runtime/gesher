"""Saved decoded groups and receipt hashes only; no real PE/tool execution."""
from pathlib import Path
import hashlib,json,struct
R=Path('C:/work/gesher-ci-review');P='fonts-2a3a-41227120830';C='2a3a485e7890619c7a756bffee6255c4a9296e00'
jobs=json.loads((R/(P+'-jobs.json')).read_bytes())['jobs'];out={}
for job in jobs:
 if not job['name'].startswith('characterization (windows-'):continue
 assert job['head_sha']==C and job['run_id']==41227120830 and job['run_attempt']==1 and job['conclusion']=='failure'
 raw=(R/f'{P}-{job["id"]}.log').read_bytes();receipt=json.loads((R/f'{P}-{job["id"]}.log.receipt.json').read_bytes())
 assert len(raw)==receipt['stdout']['bytes'] and hashlib.sha256(raw).hexdigest()==receipt['stdout']['sha256']
 rows=json.loads((R/f'{P}-{job["id"]}-decoded.json').read_bytes());imports=[r['value'] for r in rows if r['label']=='FONT_RESOURCE_RAW' and r['value'].get('role')=='imports']
 assert len(imports)==1;v=imports[0];assert v['exit']!=0 and v['stdout']==''
 marker='\nFONT_RESOURCE_RESOURCE_DIRECTORY_REJECTION ';assert v['stderr'].count(marker)==1
 prefix,encoded=v['stderr'].split(marker,1);assert 'UNAVAILABLE: resource numeric identifier/count' in prefix
 evidence=json.loads(encoded);header=bytes.fromhex(evidence['header_hex']);assert len(header)==16 and hashlib.sha256(header).hexdigest()==evidence['header_sha256']
 a,b,major,minor,named,ids=struct.unpack('<IIHHHH',header)
 assert (a,b,major,minor,named,ids)==(evidence['characteristics'],evidence['timestamp_raw'],evidence['major'],evidence['minor'],evidence['named'],evidence['ids'])
 assert (named,ids,evidence['count'],evidence['named_zero'],evidence['count_in_range'])==(1,2,3,False,True)
 p=evidence['provenance'];assert p['context']=={'source':C,'run':'41227120830','attempt':'1'} and p['imports_pid']==v['pid']
 assert evidence['level']==0 and evidence['relative_offset']==0 and evidence['key_path']==[]
 summaries=[r['value'] for r in rows if r['label']=='FONT_RESOURCE_SUMMARY'];assert len(summaries)==1
 summary=summaries[0];assert summary['phase']=='FAILED' and summary['characterization_completed'] is False
 for key in ('font_owner_qualified','private_CRT_owner_symbols_qualified','host_WCT_Windows2025_qualified','full_qualification'):assert summary[key] is False
 out[job['name']]={'pid':v['pid'],'header_hex':header.hex(),'header_sha256':evidence['header_sha256'],'named':named,'ids':ids,'count':3,'profile_sha256':p['profile']['sha256'],'resource_sha256':evidence['resource_sha256'],'summary':summary}
print(json.dumps(out,indent=2))
