from pathlib import Path, PurePosixPath
import base64, hashlib, json, re, shlex
R=Path('C:/work/gesher-ci-review'); stem='native-helper-eda8-postlink-41225681152-'; job=124609250528
p=R/(stem+str(job)+'.log'); raw=p.read_bytes(); receipt=json.loads(Path(str(p)+'.receipt.json').read_bytes())
assert receipt['state']=='CLOSED' and receipt['exit']==0 and receipt['get_count']==1 and receipt['raw_bytes']==len(raw) and receipt['raw_sha256']==hashlib.sha256(raw).hexdigest()
groups={}; current=None
for line in raw.splitlines():
    m=re.search(rb'Z FILE_MREMAP_HELPER_(\w+) part=(\d+)/(\d+) bytes=(\d+) sha256=([0-9a-f]{64}) base64=([A-Za-z0-9+/=]+)$',line)
    if not m: continue
    label,i,n,size,digest,payload=m.groups(); i=int(i); n=int(n); size=int(size)
    if i==1: assert current is None; current=[label,n,size,digest,[],0]
    assert current and (label,n,size,digest)==tuple(current[:4]) and i==current[5]+1
    current[4].append(base64.b64decode(payload,validate=True)); current[5]=i
    if i==n:
        b=b''.join(current[4]); assert len(b)==size and hashlib.sha256(b).hexdigest().encode()==digest
        groups.setdefault(label.decode(),[]).append(json.loads(b)); current=None
assert current is None

x,=groups['POST_LINK_REJECTION']; f,=groups['FAILURE']; t=x['details']['trace']['text'].encode(); assert len(t)==x['details']['trace']['bytes'] and hashlib.sha256(t).hexdigest()==x['details']['trace']['sha256']
reads=[]; loads=[]
for line in t.decode().splitlines():
 m=re.fullmatch(r'(?:ld\.lld|lld-link): Reading (.+\.a)\s*',line)
 if m: reads.append(m.group(1)); continue
 m=re.fullmatch(r'(?:ld\.lld|lld-link): Loaded ([^()]+\.a)\(([^()]+)\) for (.+)',line)
 if m: loads.append(m.groups())
assert len(reads)==11 and len(loads)==61 and set(reads)==set(x['details']['archives'])
names={PurePosixPath(v['path']).name for v in x['details']['archives'].values()}; checks={'libc++.a':'libc++.a'in names,'libunwind.a':'libunwind.a'in names,'builtins':any('builtins'in n for n in names),'ucrt':any('ucrt'in n for n in names),'libkernel32.a':'libkernel32.a'in names}
assert checks==x['details']['predicates'] and [k for k,v in checks.items() if not v]==['ucrt'] and 'libmsvcrt.a' in names
assert x['context']['source']=='eda8ed3b53ebd401e6fd5bf2b00252ff73303fcd' and x['context']['run']=='41225681152' and x['producer_id']==124609250528 and x['qualification'] is False
print(json.dumps({'reads':len(reads),'loads':len(loads),'names':sorted(names),'predicates':checks,'trace_sha256':hashlib.sha256(t).hexdigest(),'qualification':False},indent=2))