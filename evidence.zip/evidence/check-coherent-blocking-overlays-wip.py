import json,subprocess
from pathlib import Path
r=Path('C:/work/gesher-coherent-selected-tcp');m=json.loads((r/'tools/native3-locks/blocking-source.json').read_text());d={}
for p,w in m['blobs'].items():
 if p=='.github/workflows/native3-locks-blocking.yml':continue
 a=subprocess.check_output(['git','-C',str(r),'hash-object',p],text=True).strip()
 if a!=w:d[p]={'historical':w,'current':a}
print(json.dumps(d,indent=2))
