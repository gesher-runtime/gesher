from pathlib import Path
r=Path('C:/work/gesher-coherent-selected-tcp');original=(r/'.github/workflows/net-tcp-selected-component.yml').read_text(); jobs=original[original.index('  compile:\n'):]
assert jobs.count('supplier: [canonical, selected-minimum]')==2;jobs=jobs.replace('supplier: [canonical, selected-minimum]','supplier: [selected-minimum]')
jobs=jobs.replace('  compile:\n    name:', '  compile:\n    needs: [union-trusted-source]\n    name:',1)
jobs=jobs.replace('      TCP_SUPPLIER_ROLE: ${{ matrix.supplier }}', '      TCP_SUPPLIER_ROLE: ${{ matrix.supplier }}\n      GESHER_COHERENT_TCP_AUTHORIZED_SOURCE: ${{ needs.union-trusted-source.outputs.source }}\n      GESHER_COHERENT_TCP_POLICY_REF: ${{ needs.union-trusted-source.outputs.policy_ref }}')
jobs=jobs.replace('  linux-reference:\n    runs-on:', '  linux-reference:\n    needs: [union-trusted-source]\n    env:\n      GESHER_COHERENT_TCP_AUTHORIZED_SOURCE: ${{ needs.union-trusted-source.outputs.source }}\n      GESHER_COHERENT_TCP_POLICY_REF: ${{ needs.union-trusted-source.outputs.policy_ref }}\n    runs-on:',1)
jobs=jobs.replace('    needs: [compile, linux-reference]', '    needs: [union-trusted-source, compile, linux-reference]',1)
needle='      - name: Verify exact source and two-supplier preservation before native compilation';assert jobs.count(needle)==1
jobs=jobs.replace(needle,'      - name: Verify coherent selected TCP producer role\n        run: python3 tools/toolchain/coherent_tcp_context.py\n'+needle,1)
needle='      - name: Retain full independent Linux contract including inline mode';assert jobs.count(needle)==1
jobs=jobs.replace(needle,'      - name: Verify coherent TCP reference role\n        run: python3 tools/toolchain/coherent_tcp_context.py\n'+needle,1)
needle='      - name: Check exact qualified controller helper hashes and source-only pin negatives';assert jobs.count(needle)==1
jobs=jobs.replace(needle,"      - name: Verify coherent selected TCP receiver role\n        shell: pwsh\n        run: |\n          python tools/toolchain/coherent_tcp_context.py\n          if ($LASTEXITCODE -ne 0) { throw 'Coherent TCP receiver role rejected' }\n"+needle,1)
p=r/'.github/workflows/ci.yml';s=p.read_text();assert '\n  compile:\n' not in s and '\n  linux-reference:\n' not in s and '\n  windows:\n' not in s
p.write_text(s.rstrip()+'\n\n  # Current selected TCP role; historical canonical red remains separately preserved.\n'+jobs,encoding='utf-8',newline='\n')
print('TCP jobs appended; original selected source controls retained; selected-only')
