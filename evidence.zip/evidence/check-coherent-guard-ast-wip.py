import pathlib,yaml,ast
p=pathlib.Path('.github/workflows/net-combined-dns-trusted-source.yml');d=yaml.safe_load(p.read_text());s=d['jobs']['verify']['steps'][-1]['run'];assert s.startswith('python3 -I -');ast.parse(s.split("<<'PY'\n",1)[1].rsplit('\nPY',1)[0]);print('YAML + embedded Python AST PASS')
