import ast,subprocess
from pathlib import Path
r=Path('C:/work/gesher-coherent-selected-tcp')
for p in ['tools/host-pthread-authority/minimum_receipt.py','tools/toolchain/prepare_host_pthread.py']:
 ast.parse((r/p).read_text()); print('AST_PASS',p)
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
for p in ['compat/posix/src/fd.cc','compat/posix/src/socket.cc','compat/posix/src/socket_internal.h','compat/posix/src/system.cc','compat/posix/src/winsock.cc']:
 assert git('show',':'+p)==git('show','695229f0c31939ef4a95dc0cb4eef7ba5172786a:'+p);print('TCP_EXACT',p)
for p in ['compat/bionic/native_fonts.cc','compat/posix/src/path.cc','tests/windows/tracks/79-media4-muxer.ps1']:
 assert git('show',':'+p)==git('show','1bf8fad9ec3b423ddef8c97c1d72b25790974364:'+p);print('FULL_EXACT',p)
