"""Independent saved-text audit only: no network, artifact download or native execution."""
import collections,hashlib,importlib.util,json,os,re,runpy,sys,tempfile,subprocess
from pathlib import Path
R=Path('C:/work/gesher-ci-review'); W=Path('C:/work/gesher-pthread-native-runtime161')
C='fcb41c8c3fb0796260fd672d65554d09282ba6d9';G='6edcb921e546698e503f18ad93e3dac690487be4'; RUN='41221763220'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((R/'runtime161-412217-run.json').read_text());jobs=json.loads((R/'runtime161-412217-jobs.json').read_text())['jobs']
assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==C and run['run_attempt']==1 and str(run['id'])==RUN and run['event']=='push'
assert run['actor']['login']==run['triggering_actor']['login']=='palmoni5'
assert run['repository']['id']==run['head_repository']['id']==1426153186
assert len(run['referenced_workflows'])==1 and run['referenced_workflows'][0]['sha']==G
expected={124597608170:'source_authority / verify',124597636979:'native3-locks-reference',124597637025:'build',124605295943:'native3-locks-regression-windows-2022',124605295996:'native3-locks-regression-windows-2025'}
assert len(jobs)==5 and {j['id']:j['name'] for j in jobs}==expected and all(j['conclusion']=='success' and j['status']=='completed' for j in jobs)
assert run['head_branch']=='wip/pthread-native-runtime161' and run['path']=='.github/workflows/pthread-native-off-receiver-component.yml'
artifacts=json.loads((R/'runtime161-412217-artifacts.json').read_text())
assert artifacts['total_count']==len(artifacts['artifacts'])==2
for name in ('tests/windows/run-native3-locks-current.ps1','tests/native3-locks/command_oracle.py','tests/native3-locks/validate_stdio_evidence.py'):
    assert subprocess.check_output(['git','show','f9288a647298adb90bdef82302d745cf806bb7ea:'+name],cwd=W)==subprocess.check_output(['git','show',C+':'+name],cwd=W)
assert 'assert len(rows) == 161' in (W/'tests/native3-locks/command_oracle.py').read_text(encoding='utf-8')

raw={}
for jid in expected:
 suffix='-rendered-fallback' if jid==124597637025 else ''
 path=R/f'runtime161-412217-{jid}{suffix}.log'; b=path.read_bytes(); receipt=json.loads(Path(str(path)+'.receipt.json').read_bytes())
 assert receipt['state']=='CLOSED' and receipt['exit']==0 and receipt['get_count']==1 and receipt['raw_bytes']==len(b) and receipt['raw_sha256']==sha(b)
 assert receipt['source']==C and receipt['run']==int(RUN) and receipt['attempt']==1 and receipt['job']==jid
 raw[jid]=b.decode('utf-8')
failed=R/'runtime161-412217-124597637025.log';failed_receipt=json.loads(Path(str(failed)+'.receipt.json').read_bytes());failed_raw=failed.read_bytes()
assert failed_receipt['state']=='CLOSED' and failed_receipt['exit']!=0 and failed_receipt['raw_bytes']==len(failed_raw) and failed_receipt['raw_sha256']==sha(failed_raw)
assert b'418' in failed_raw or b'418' in Path(str(failed)+'.stderr').read_bytes()
policy=[json.loads(m.group(1)) for line in raw[124597608170].splitlines() if (m:=re.search(r'NATIVE_OFF_POLICY_PASS (\{.*\})$',line))]
assert len(policy)==1 and policy[0]['source']==C and policy[0]['policy_ref'].endswith('@'+G) and policy[0]['actual_jobs']==5 and policy[0]['runtime161_executed'] is False
oldspec=importlib.util.spec_from_file_location('ledger',R/'audit-native-997-saved-independent.py');old=importlib.util.module_from_spec(oldspec);oldspec.loader.exec_module(old)
prod=raw[124597637025]; records=old.reconstruct(prod);assert len(records)==38
links=[x['decoded'] for x in records if x['meta']['label']=='ACTUAL_SELECTED_TARGET_LINK'];assert len(links)==36 and all(x['exit_code']==0 for x in links)
for link in links:
 ctx=link['selected_toolchain']['context'];assert ctx['GITHUB_SHA']==C and ctx['GITHUB_RUN_ID']==RUN and ctx['GITHUB_RUN_ATTEMPT']=='1'
production=next(x['decoded'] for x in records if x['meta']['label']=='ACTUAL_WEB3_PRODUCTION_ROLE')
host=next(x['decoded'] for x in records if x['meta']['label']=='ACTUAL_NATIVE3_CURRENT_HOST')
assert production['source']==C and str(production['run'])==RUN and str(production['attempt'])=='1' and production['role']=='production' and production['test_hook_compiled'] is False
assert host['context']['source']==C and str(host['context']['run'])==RUN and str(host['context']['attempt'])=='1'
assert production['compiler']==host['compiler'] and production['executable_sha256']==host['production_runtime_sha256'] and len(host['outputs'])==19
assert len(production['selected_executables'])==33 and len(production['shared_sources'])==12
factory=json.loads(next(x.split('PRODUCTION_TOOLCHAIN_RECEIPT ',1)[1] for x in prod.splitlines() if 'PRODUCTION_TOOLCHAIN_RECEIPT ' in x))
assert factory['source']==C and str(factory['run'])==RUN and str(factory['attempt'])=='1'
for link in links:
 tool=link['selected_toolchain']

minimum=old.reconstruct(prod,'MINIMUM_RECEIPT');assert len(minimum)==1 and '[sizeof=480, align=16]' in minimum[0]['decoded']['private_record_layout']
for link in links:
 tool=link['selected_toolchain'];assert tool['receipt_sha256']==factory['receipt_sha256'] and tool['recipe_fingerprint']==factory['recipe_fingerprint'] and tool['authority_sha256']==minimum[0]['meta']['sha256']
 assert link['argv'][0]==factory['compiler_root']+'/bin/x86_64-w64-mingw32-clang++'
 assert all(v['archive_sha256'] in set(tool['aliases'].values()) for v in link['proof']['definitions'].values())
assert collections.Counter(x['proof']['status'] for x in links)=={'LINKED':35,'NOT-LINKED':1}
dalvik=next(x for x in links if x['output']['path'].endswith('/dalvikvm.exe'));assert dalvik['output']['sha256']==production['executable_sha256']
for leaf in ('uia_bridge.cc.obj','query_pool.cc.obj','uia_client.cc.obj','windows_proxy.cc.obj'):
 assert sum(x.endswith('/'+leaf) for x in dalvik['expanded_argv'])==1
assert [int(x) for x in re.findall(r'\[(\d+)/2737\]',prod)]==list(range(1,2738))
source_rows=re.findall(r'MINIMUM_SOURCE \S+ expected=([0-9a-f]{64}) actual=([0-9a-f]{64})',prod);assert len(source_rows)==36 and all(a==b for a,b in source_rows)
ref=json.loads(next(line.split('ACTUAL_NATIVE3_REFERENCE ',1)[1] for line in raw[124597636979].splitlines() if 'ACTUAL_NATIVE3_REFERENCE ' in line))
assert ref['context']['source']==C and str(ref['context']['run'])==RUN and str(ref['context']['attempt'])=='1' and set(ref['outputs'])=={'linux-reference.json'} and ref['compiler_sha256']!=host['compiler']['sha256']
summary=[]
for jid in (124605295943,124605295996):
 text=raw[jid];rows=old.reconstruct(text);assert len(rows)==13
 checked=[x['decoded'] for x in rows if x['meta']['label']=='VERIFIED_SELECTED_TARGET_LINK'];assert len(checked)==12 and all(any(x==y for y in links) for x in checked)
 current=next(x['decoded'] for x in rows if x['meta']['label']=='VERIFIED_NATIVE3_CURRENT_SUPPLIERS')
 assert current['context']['source']==C and str(current['context']['run'])==RUN and str(current['context']['attempt'])=='1'
 assert current['output_members']==20 and current['compiler']==host['compiler'] and current['production_runtime_sha256']==production['executable_sha256']
 receipts=re.findall(r'CI_ARTIFACT_RECEIPT name=(\S+) id=(\d+) digest=(sha256:[0-9a-f]{64}) producer=(\S+) producer_id=(\d+) conclusion=success source=([0-9a-f]{40}) checkout=([0-9a-f]{40}) run=(\d+) attempt=(\d+)',text)
 assert len(receipts)==2 and {r[0] for r in receipts}=={'native3-locks-host','native3-locks-reference'}
 for name,aid,digest,role,pid,source,checkout,runid,attempt in receipts:
  assert source==checkout==C and runid==RUN and attempt=='1' and {j['name']:str(j['id']) for j in jobs}[role]==pid
  artifact=next(a for a in artifacts['artifacts'] if str(a['id'])==aid); job=next(j for j in jobs if str(j['id'])==pid)
  assert artifact['name']==name and artifact['digest']==digest and artifact['expired'] is False and artifact['size_in_bytes']>0
  assert job['started_at']<=artifact['created_at']<=artifact['updated_at']<=job['completed_at']
  assert artifact['workflow_run']['id']==int(RUN) and artifact['workflow_run']['head_sha']==C
 assert 'ACTUAL_NATIVE3_PAYLOAD_NEGATIVES missing/extra/source/role rejected; exact original restored' in text
 assert sum(line.endswith(' ACTUAL_COMMAND_ORACLE rows=161 mismatches=0') for line in text.splitlines())==1
 assert sum(line.endswith(' ACTUAL_DUPLICATE_ORACLE modes=13 failures=0 semantics=bounded-resource-controls') for line in text.splitlines())==1
 dup=[json.loads(line.split('ACTUAL_DUPLICATE_ROW ',1)[1]) for line in text.splitlines() if 'ACTUAL_DUPLICATE_ROW ' in line];assert len(dup)==13 and len({x['mode'] for x in dup})==13 and all(x['failures']==0 for x in dup)
 assert 'STDIO_EVIDENCE_COMPLETE cycles=4 scope=controlled-stdio-lock-order' in text
 assert re.search(r'ACTUAL_DUPLICATE_BROKER_AUDIT client-pids=\[[0-9, ]+\] normal-exits=13 opens=2 unexpected=0',text)
 assert re.search(r'ACTUAL_DUPLICATE_BROKER_CLEANUP pid=\d+ exit=211 reaped=true intentional-owned-kill=True clients-qualified=True',text)
 assert 'ACTUAL_DUPLICATE_JOB_CLEANUP children=14 reaped=true' in text
 assert 'ACTUAL_COMMAND_ORACLE_FAILURE' not in text and 'ACTUAL_CONTENTION_FAILURE' not in text
 lines=[]
 for line in text.splitlines():
  match=re.match(r'^\d{4}-\d\d-\d\dT\S+Z (.*)$',line)
  if match:lines.append(match.group(1))
 with tempfile.TemporaryDirectory(prefix='runtime161-pure-replay-') as d:
  stderr=Path(d)/'stderr.txt';out=Path(d)/'validated.json';stderr.write_text('\n'.join(lines)+'\n',encoding='utf-8')
  oldenv={k:os.environ.get(k) for k in ('GITHUB_ACTIONS','GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT')};oldargv=sys.argv;os.environ.update(GITHUB_ACTIONS='true',GITHUB_SHA=C,GITHUB_RUN_ID=RUN,GITHUB_RUN_ATTEMPT='1');sys.argv=['validator','--stderr',str(stderr),'--output',str(out)]
  try:runpy.run_path(str(W/'tests/native3-locks/validate_stdio_evidence.py'),run_name='__main__')
  finally:
   sys.argv=oldargv
   for key,value in oldenv.items():
    if value is None:os.environ.pop(key,None)
    else:os.environ[key]=value
  assert out.exists()
 summary.append({'job':jid,'command_rows':161,'duplicate_modes':len(dup),'stdio_cycles':4,'receipts':receipts,'verified_link_rows':12})
result={'source':C,'guard':G,'run':RUN,'attempt':1,'jobs_success':5,'producer_ledger_groups':len(records),'selected_links':len(links),'runtime_sha256':production['executable_sha256'],'map_sha256':production['executable_map_sha256'],'native_host_outputs':len(host['outputs']),'consumers':summary,'archive_bytes_downloaded':False,'auditor_network_native':False,'prior_http418':'preserved'}
(R/'runtime161-412217-independent-actual-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
