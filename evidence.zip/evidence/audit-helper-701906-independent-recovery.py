from pathlib import Path, PurePosixPath
import base64, hashlib, json, re, shlex
R=Path('C:/work/gesher-ci-review'); stem='native-helper-701906-41224586536-'; job=124606012844
p=R/(stem+str(job)+'.log'); raw=p.read_bytes(); receipt=json.loads(Path(str(p)+'.receipt.json').read_bytes())
assert receipt['state']=='CLOSED' and receipt['exit']==0 and receipt['get_count']==1 and receipt['raw_bytes']==len(raw) and receipt['raw_sha256']==hashlib.sha256(raw).hexdigest()
groups={}; current=None
for line in raw.splitlines():
    m=re.search(rb'Z FILE_MREMAP_HELPER_(\w+) part=(\d+)/(\d+) bytes=(\d+) sha256=([0-9a-f]{64}) base64=([A-Za-z0-9+/=]+)$',line)
    if not m: continue
    label,i,n,size,digest,payload=m.groups(); i=int(i); n=int(n); size=int(size)
    if i==1: assert current is None; current=[label,n,size,digest,[],0]
    assert current and (label,n,size,digest)==tuple(current[:4]) and i==current[5]+1
    current[4].append(base64.b64decode(payload,validate=True)); current[5]=i
    if i==n:
        b=b''.join(current[4]); assert len(b)==size and hashlib.sha256(b).hexdigest().encode()==digest
        groups.setdefault(label.decode(),[]).append(json.loads(b)); current=None
assert current is None

failure,=groups['FAILURE']; tools=groups['TOOL']; assert failure['error'] == "Rejected('missing positive CRT/STL/unwind/builtins/system dependency')"; assert failure['qualification'] is False; print(json.dumps({'labels':{k:len(v) for k,v in groups.items()},'tool_exits':[x['exit'] for x in tools],'failure':failure},indent=2))
