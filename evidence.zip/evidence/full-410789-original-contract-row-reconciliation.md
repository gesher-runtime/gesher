# Existing full 410789: original-contract row reconciliation

The preserved full 41078972594/attempt1 at exact `1bf8fad9ec3b423ddef8c97c1d72b25790974364` contains later implementation evidence beyond several older ADR/handoff “proposed” paragraphs. This read-only reconciliation prevents historical status from being turned into a current missing-feature claim. It does not change any source, inventory, acceptance gate or release status.

Both complete saved normal Windows logs were read for the following actual anchored PASS rows. `full-410789-original-contract-row-index.json` preserves every matched row, raw-log SHA256 and exact source test Git blob from 1bf8; echoed source expressions were excluded. Each group has the same count on 2022 and 2025 and no matching actual FAIL verdict.

| Existing source group | Actual rows per host | Bounded observation |
| --- | --- | --- |
| Test73 AOT shared libraries | 98 | Actual PCL/DelegateLast and before/after-resource library contexts, code/image/stale/update and cleanup observations; 50 rows identify after-resource, 49 identify DelegateLast |
| Test77 ordered spawn | 8 | Absolute and relative driver entry, both ABIs, real ordered actions/child127/parent isolation and real no-console stdin controls |
| Test84 bounded CI processes | 43 | Actual shared helper normal/nonzero/timeout/retained-output/disposal observations; helper-specific contracts remain distinct |
| Test86 arm64 varargs | 5 | Original shallow/deep Surface logger, actual x86_64 and arm64 ELF formatting/list/overflow/thread/nested observations and final compatibility/API group |
| Test81 Locale2 | 21 | Actual API/resource/persistence/restart/negative/caller observations in both process modes |

These rows extend or supersede earlier bounded “full pending” language for the particular executed source. The already independent full audit binds both normal jobs and their current producers/artifacts, package and same-installer e2e; see `fonts-410789-independent-full-audit.md`. This report does not fetch artifacts or re-run any native/JVM/C# test locally.

Remaining AOT secondary dex, static/SDK/factory-loader contexts and wider authority constraints are not closed by the PCL/DLC/after-resource rows. Ordinary Locale2 owner negatives do not establish privileged installer/current-IME/permission authority. The varargs five-row group does not independently prove every direct variadic/HFA/binary128/JNI/APK/Surface semantic contract. Ordered spawn does not complete all attributes, descriptor inheritance, console, fork/image-replacement behavior. The process-helper group does not waive a genuine canonical supplier retirement failure in the newer component.

ADR/handoff prose remains preserved. The separate original-contract reconciliation is still a source/actual-row exercise, not a count of remaining defects. New runtime/supplier adoption must preserve and repeat the applicable current gates; no old green run is relabeled as execution of new source.
