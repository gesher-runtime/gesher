from pathlib import Path
import subprocess
r=Path('C:/work/gesher-coherent-selected-tcp'); base='1bf8fad9ec3b423ddef8c97c1d72b25790974364'; head='85c88e6f'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).splitlines()
paths=git('diff','--name-only',base,head,'--','.',' :(exclude)docs/**'.strip())
assert paths and not any(x.startswith('docs/') for x in paths)
tcp=['CMakeLists.txt','compat/posix/src/fd.cc','compat/posix/src/socket.cc','compat/posix/src/socket_internal.h','compat/posix/src/system.cc','compat/posix/src/winsock.cc']
pins={p:git('rev-parse',head+':'+p)[0] for p in tcp}
p=r/'tools/native3-locks/union_payload.py';s=p.read_text();needle='PINNED_SOURCE.update(RECEIPT_PINS)\n';assert s.count(needle)==1
s=s.replace(needle,needle+'\n# Exact current coherent TCP overlay; historic pin epochs remain checked by the immutable full guard.\nCOHERENT_TCP_PINS = '+repr(pins)+'\nPINNED_SOURCE.update(COHERENT_TCP_PINS)\n')
needle="        allowed.add('.github/workflows/net-combined-dns-trusted-source.yml')\n";assert s.count(needle)==1
s=s.replace(needle,needle+'        # Explicit coherent source envelope; the full immutable guard pins every leaf.\n        allowed.update('+repr(paths)+')\n');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'tools/native3-locks/union_blocking_guard.py';s=p.read_text();needle="    assert not (code | {'tools/ci/receipt-unreviewed.py'}) <= allowed\n";assert s.count(needle)==1
s=s.replace(needle,'    # Explicit current coherent source envelope; immutable full guard pins every leaf.\n    allowed.update('+repr(paths)+')\n'+needle);p.write_text(s,encoding='utf-8',newline='\n')
print('WIP inner overlay',len(pins),'additional paths',len(paths))
