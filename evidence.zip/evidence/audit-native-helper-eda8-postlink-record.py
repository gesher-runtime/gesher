from pathlib import Path,PurePosixPath
import hashlib,json,re
R=Path('C:/work/gesher-ci-review')
d=json.loads((R/'native-helper-eda8-postlink-41225681152-sourceowner-initial-decoded.json').read_bytes())
x=next(r['value'] for r in d['producer'] if r['label']=='POST_LINK_REJECTION');detail=x['details'];trace=detail['trace']['text'].encode()
assert len(trace)==detail['trace']['bytes'] and hashlib.sha256(trace).hexdigest()==detail['trace']['sha256']
reads=[];loads=[]
for line in trace.decode().splitlines():
    m=re.fullmatch(r'(?:ld\.lld|lld-link): Reading (.+\.a)\s*',line)
    if m:reads.append(m[1]);continue
    m=re.fullmatch(r'(?:ld\.lld|lld-link): Loaded ([^()]+\.a)\(([^()]+)\) for (.+)',line)
    if m:loads.append(m.groups())
assert reads and loads and set(reads)==set(detail['archives'])
names=sorted({PurePosixPath(v['path']).name for v in detail['archives'].values()});assert names==detail['names']
checks={'libc++.a':'libc++.a'in names,'libunwind.a':'libunwind.a'in names,'builtins':any('builtins'in n for n in names),'ucrt':any('ucrt'in n for n in names),'libkernel32.a':'libkernel32.a'in names}
assert checks==detail['predicates'] and [k for k,v in checks.items() if not v]==['ucrt']
assert x['gate']=='required_archives' and x['producer_id']==124609250528 and x['context']['source']=='eda8ed3b53ebd401e6fd5bf2b00252ff73303fcd' and x['context']['run']=='41225681152' and x['context']['attempt']=='1' and x['guard']=='5daba9a6041a02d4955782bb28476d6fad7e823c' and x['qualification'] is False
print(json.dumps({'reads':len(reads),'loads':len(loads),'names':names,'predicates':checks,'trace_bytes':len(trace),'trace_sha256':hashlib.sha256(trace).hexdigest(),'qualification':False},indent=2))
