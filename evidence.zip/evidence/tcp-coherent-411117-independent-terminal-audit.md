# Coherent TCP 411117 independent terminal audit

Run 41111736581, attempt 1, exact clean source `26526e6864fde173c4090e9d5271412657fa6ad9`, is terminal **five success / two failure**. No observer remains active. This audit qualifies the explicit retirement diagnostic role and preserves both canonical failures as hard adoption blockers. It does not qualify a new canonical compiler, inline TCP, the full product, or release bytes.

Reproducer: `audit-tcp-coherent-411117.py`; compact evidence: `tcp-coherent-411117-independent-summary.json`. It reads saved raw logs/API metadata and exact Git blobs only, with no native execution or local archive download. Initial local audit assumptions were corrected for the translator's explicit not-linked role and negative diagnostics on stderr before the final passing audit; those were audit-harness corrections, not CI or product changes.

## Exact suppliers and provenance

Both fresh producers and the independent Linux job succeeded. Canonical producer 124255157255 produced artifact 13004675628, digest `sha256:1bc71ad710d0a4f2a618ef092857525634a374a4e622b49e106cf0980c90df5b`. Retirement producer 124255157839 produced artifact 13003874718, digest `sha256:3c9916edd7ae9735b3656899a11c751f6348047b5d8ff852a977060ea1ed43de`.

The independent audit checks all seven jobs' source/run/attempt, distinct exact artifact names and source/repository IDs, positive/nonexpired digest metadata, and creation inside each producer interval. Four actual consumer receipts match the intended producer and artifact. Six actual helper Git blobs match source. All consumers reach and pass the unchanged whole-tracked-source inventory/hash comparison, exact thirteen typed output/hash comparison, NDK publisher/ABI checks, import policy and supplier checks before the fixture matrix.

Capture records independently establish 233 supplier-source entries, three explicit source records, five libraries, seven public headers and three compiler roles per producer. Canonical source and libraries are unchanged. Retirement binds the exact detached-retirement patch SHA `ebc5aac990c6ec075431d0c25a9b74ecadc0940da1bdad9503f358d4fe3431ad`; public headers, symbol inventory and DLL export inventory remain unchanged. Both use authenticated publisher archive SHA `5f9c6ed95b2d4bdb2869a488c5fd5857fbdabcf288a0aa3eb1da43f6a08d8ab4` and compiler SHA `c9b86311ade81d53235c93fafabdf98328d094de344ea9a9038e0dab6695ee9f`.

All four consumer supplier records bind the actual selected static archives for gesher-exec, the HOST TCP executable and the two guarded UDP executables. Canonical selected libpthread SHA is `dbbbb3a59f5a1077346b69d4dd8ea85eeca9574bfbd2d170eaf91b5fe5b2f88e`; retirement is `47c0fd2c9b1c0cc126880c7d23f381abda82731fbb17597b39b4de87fb5eb796`. Actual loaded member counts are 9/10/7/7 respectively. The matching arm64 translator explicitly has no pthread link input or loaded member; it is not mislabeled a static supplier consumer.

The saved producer fallback wrappers reach cleanup and contain complete audited capture records. This report does **not** infer complete raw build-step coverage from wrapper cleanup or assert that every compiler command appeared in raw build output. No further fallback was requested for this audit.

## Actual execution and retirement

Each role on each Windows host passes nine guarded controls: HOST/x86_64/arm64 ordinary matrices (200 rows), corresponding fault matrices (176 rows), and three genuine missing-MSG_TRUNC negatives returning exactly 1. All 36 structured results independently satisfy root signaled, one process, exclusive snapshot, empty job, retired writers, captured output, no controller errors and all seven owned handles closed. Negative results retain all retirement fields with only the explicitly expected exit changed to 1.

Retirement consumers 124265716213 (2025) and 124265716377 (2022) pass the isolated exact joined/detached census, then all three whole HOST/x86_64/arm64 TCP/UDP noninline contracts each. Their six structured contract processes each exit zero with all seven handles closed and the exact final noninline PASS marker. Existing error/alias/cancellation/vector/deadline and guarded-copy gates remain mandatory; Bionic's absent pthread-cancel API remains explicit, not a claimed guest pass.

Canonical consumers 124265716284 (2022) and 124265716293 (2025) fail the isolated no-TCP supplier census **before** the main TCP contracts. Joined warm-up is 115→119 and 124→128; joined repeated cycles return exactly to warm count. The first detached cycle is 119→120 and 128→129. Both executable results are genuine exit 1 with complete seven-of-seven controller retirement. The strict failure is preserved; no canonical HOST or guest main-contract acceptance is inferred from the retirement diagnostic result.

Production source remains the separately reviewed five-file coherent port: canonical whole Recv body, guarded user-copy/recvmsg metadata, MSG_TRUNC, cancellation cleanup and original errno/assertions are preserved. The minimal source supplier proposal is a separate next diagnostic dependency; no whole private branch merge is authorized.

Earlier 411015 opaque producer rejection remains unexplained. Later exact matching metadata and this successful receipt execution do not establish the earlier live cause. Earlier 411086 shallow-history failure and all previous red evidence remain preserved.
