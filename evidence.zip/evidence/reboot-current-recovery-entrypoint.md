**Current 2026-10-31 recovery:** [authoritative current coordination](C:/work/gesher-ci-review/recovery-2026-10-31-current.md) supersedes the older live ownership and run status below; retain that material as history.

# Current recovery entrypoint

Use [the authoritative coordination report](C:/work/gesher-ci-review/new-manager-union-coordination.md) for current owners, runs, work and acceptance boundaries. This file is only a stable pointer; it does not duplicate changing state.

Restoration proof verified 2026-10-30: the authoritative report is 32756 bytes; SHA256 dad8f5dc007f8ba764139d4e7774baf3b71fad5a031141a92c5711035f40c821. Root independently recorded the restored 32,756-byte report with SHA256 dad8f5dc007f8ba764139d4e7774baf3b71fad5a031141a92c5711035f40c821. No source data was lost.

Intact supporting index:

- [Current closure graph](C:/work/gesher-ci-review/reboot-current-closure-graph.md)
- [Remaining requirements](C:/work/gesher-ci-review/remaining-requirements-2026-10-29-new-manager.md)
- [Integration handover](C:/work/gesher-ci-review/reboot-2026-10-30-integration-handover.md)
- [Fonts runtime checkpoint](C:/work/gesher-ci-review/fonts-standalone-diagnostic-checkpoint.md)
- [Receipt identity evidence and current full chain](C:/work/gesher-ci-review/artifact-identity-recovery-checkpoint.md)
- [Isolated CORE comparison source and roles](C:/work/gesher-ci-review/fonts-core-component-design.md)
- [Native Windows fallback gap and plan](C:/work/gesher-ci-review/fonts-native-windows-fallback-plan.md)
- [Pthread supported entrypoint decision](C:/work/gesher-ci-review/pthread-supported-entrypoint-bootstrap-decision.md)

Consult the authoritative report and closure graph for accepted pthread410621, terminal UDP410781 raw-audit status, CORE036a and pending C++ peer state, and active full410789/1bf8/solewatch37339. These identifiers are navigation hints, not a second acceptance ledger.