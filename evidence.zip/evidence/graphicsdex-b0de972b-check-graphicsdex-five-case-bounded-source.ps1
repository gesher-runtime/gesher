# PURE managed actual-source controls. No compiler/AddType/native invocation.
$repo='C:/work/gesher-ci-graphics-processes';$path=$repo+'/tests/windows/tracks/84-ci-processes.ps1'
$new=[IO.File]::ReadAllText($path);$old=(& git -C $repo show 'fe036c12134828901693482de4186943a44a1805:tests/windows/tracks/84-ci-processes.ps1')-join "`n"
function ParseText($s){$t=$null;$e=$null;$a=[Management.Automation.Language.Parser]::ParseInput($s,[ref]$t,[ref]$e);if($e.Count){throw 'parse'};return $a}
function ReportText($s){$a=ParseText $s;$i=$a.Find({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$g.Phase -eq 'Report')")},$true);if($null -eq $i){throw 'report extraction'};return $i.Extent.Text.Replace('[Gtest84NativeHandles]::Closed([IntPtr][long]$pair.Groups[1].Value)','$true').Replace('[Gtest84NativeHandles]::Closed([IntPtr][long]$pair.Groups[2].Value)','$true')}
$oldReport=ReportText $old;$newReport=ReportText $new
function Write-Host {$global:Messages+=($args-join ' ')}
$env:GITHUB_SHA='a'*40;$env:GESHER_GRAPHICS84_NONCE='ab'*32;$graphics84Exe='OWNED/dalvikvm.exe';$script:failed=0
function NewState($mode){
 $obs=[pscustomobject]@{Source=$env:GITHUB_SHA;Case=$mode;Nonce=$env:GESHER_GRAPHICS84_NONCE;Pid=99;CreationFiletime=[UInt64]1234;KernelComplete=$true;Released=$true;TasksComplete=$true;PipesClosed=2;ExpectedImage=$graphics84Exe;NativeExitCode=0;MarkerPresent=$true;OperationExpired=$false;EofComplete=$true;KillReserved=$false;ObservationFailed=$false;MechanismFailure=$false;CleanupBudgetExpired=$false}
 if($mode -eq 'nonzero'){$obs.NativeExitCode=23};if($mode -eq 'missing-marker'){$obs.MarkerPresent=$false};if($mode -eq 'timeout'){$obs.NativeExitCode=1;$obs.MarkerPresent=$false;$obs.OperationExpired=$true;$obs.KillReserved=$true;$obs.ObservationFailed=$true};if($mode -eq 'retained'){$obs.EofComplete=$false;$obs.ObservationFailed=$true}
 return @{Phase='Report';Obs=$obs;ParentBound=$true;ParentReceipt='DONE';Failed=$false;Delta=$(if($mode -eq 'normal'){0}else{1});Text='kernel=True tasks=True pipes=2 disposed=True output=101 error=102 did not complete within ten seconds';ChildNonsignaled=$true;Closed=$true;Pending=$false}
}
function InvokeReport($code){$global:Messages=@();. ([scriptblock]::Create('while($true){'+$code+'}'));return @($global:Messages|Where-Object{$_ -like 'PASS  CI processes:*'}).Count -gt 0}
$results=@()
foreach($mode in 'nonzero','missing-marker','timeout'){
 foreach($bad in 'wrong-mode','native94','argv92','absent-parent-proof'){
  if($bad -eq 'marker' -and $mode -eq 'retained'){continue}
  $g=NewState $mode
  switch($bad){'wrong-mode'{$g.Obs.Case='foreign'}native94{$g.Obs.NativeExitCode=94}argv92{$g.Obs.NativeExitCode=92}'absent-parent-proof'{$g.Obs=$null;$g.ParentBound=$false}}
  $before=InvokeReport $oldReport
  $g.Failed=$false;$after=InvokeReport $newReport
  if(-not $before -or $after){throw '12-falsePASS regression not fixed'}
  $results+=@{case="$mode/$bad";old_false_pass=$before;new_pass=$after}
 }
}
foreach($mode in 'normal','nonzero','missing-marker','timeout','retained'){
 $g=NewState $mode;if(-not(InvokeReport $newReport)){throw "intended $mode rejected"};$results+=@{case="$mode intended";pass=$true}
 foreach($bad in '91','92','93','94','source','nonce','PID','birth','image','missingreceipt','marker','timeout-reservation','mechanism','cleanup-budget'){
  if($bad -eq 'marker' -and $mode -eq 'retained'){continue}
  $g=NewState $mode
  switch($bad){mechanism{$g.Obs.MechanismFailure=$true}'cleanup-budget'{$g.Obs.CleanupBudgetExpired=$true}source{$g.Obs.Source='b'*40}nonce{$g.Obs.Nonce='00'*32}PID{$g.Obs.Pid=0}birth{$g.Obs.CreationFiletime=0}image{$g.Obs.ExpectedImage='FOREIGN'}missingreceipt{$g.ParentBound=$false}marker{$g.Obs.MarkerPresent=-not $g.Obs.MarkerPresent}'timeout-reservation'{if($mode -eq 'timeout'){$g.Obs.KillReserved=$false}else{$g.Obs.OperationExpired=$true}}default{$g.Obs.NativeExitCode=[int]$bad}}
  if(InvokeReport $newReport){throw "$mode bad $bad passed"};$results+=@{case="$mode/$bad";pass=$false}
 }
}
# Execute the ACTUAL bounded reader block with ONLY OpenRead replaced.
$a=ParseText $new;$assign=$a.Find({param($n)$n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$graphics84ReadBounded'},$true)
. ([scriptblock]::Create($assign.Extent.Text.Replace('[IO.File]::OpenRead($path)','(Open-ManagedDouble)')))
function Open-ManagedDouble {if($global:StreamCase -eq 'open-unknown'){throw 'unknown open'};return $global:Stream}
# Actual ParentReceipt stage with bounded reader and managed MemoryStream input.
$parentIf=$aDummy
$parentAst=ParseText $new
$parentIf=$parentAst.Find({param($n)$n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text.StartsWith("if(`$g.Phase -eq 'ParentReceipt')")},$true).Extent.Text
$env:GESHER_GRAPHICS84_CWD='OWNED/cwd'
foreach($bad in 'normal','pid','birth','image','cwd','argv-env','case','source','nonce','missing','duplicate','unknown','utf8','oversize','typed-pid','typed-birth','typed-source','typed-case','typed-nonce','typed-image'){
 $mode='normal';$g=NewState $mode
 $g.Phase='ParentReceipt';$g.ParentBound=$false;$g.ParentReceipt='UNATTEMPTED';$g.ParentDocument=$null;$g.ParentDocClose='UNATTEMPTED'
 $g.Inputs=@{Parent=@{Open='UNATTEMPTED';Stream=$null;Read='UNATTEMPTED';Close='UNATTEMPTED';Buffer=[byte[]]::new(16385);Count=0;Requested=0;Eof=$false;Text=$null}}
 $r=[ordered]@{schema='GRAPHICS84_PARENT_V1';source=$env:GITHUB_SHA;case='normal';nonce=$env:GESHER_GRAPHICS84_NONCE;pid=99;creation_filetime='1234';expected_image=$graphics84Exe;cwd=$env:GESHER_GRAPHICS84_CWD;argv_env='EXACT'}
 switch($bad){pid{$r.pid=100}birth{$r.creation_filetime='1235'}image{$r.expected_image='FOREIGN'}cwd{$r.cwd='FOREIGN'}'argv-env'{$r.argv_env='UNVALIDATED'}case{$r.case='nonzero'}source{$r.source='b'*40}nonce{$r.nonce='00'*32}missing{$r.Remove('argv_env')}unknown{$r.extra='bad'}'typed-pid'{$g.Obs.Pid=100}'typed-birth'{$g.Obs.CreationFiletime=1235}'typed-source'{$g.Obs.Source='b'*40}'typed-case'{$g.Obs.Case='foreign'}'typed-nonce'{$g.Obs.Nonce='00'*32}'typed-image'{$g.Obs.ExpectedImage='FOREIGN'}}
 $json=$r|ConvertTo-Json -Compress
 if($bad -eq 'duplicate'){$json=$json.Replace('"schema":','"pid":99,"schema":')}
 if($bad -eq 'oversize'){$json=' '*16385}
 $bytes=[Text.Encoding]::UTF8.GetBytes($json);if($bad -eq 'utf8'){$bytes=[byte[]]@(255)}
 $global:StreamCase='parent';$global:Stream=[IO.MemoryStream]::new($bytes,$false)
 . ([scriptblock]::Create('for($i=0;$i -lt 3;$i++){try{'+$parentIf+';break}catch{$g.Failed=$true}}'))
 if($bad -eq 'normal'){if(-not $g.ParentBound -or $g.ParentDocClose -ne 'DONE'){throw 'normal parent binding failed'}}elseif($g.ParentBound -or -not $g.Failed){throw "parent $bad wrongly bound"}
 $results+=@{parent=$bad;bound=$g.ParentBound;failed=$g.Failed;requested=$g.Inputs.Parent.Requested;returned=$g.Inputs.Parent.Count;streamclose=$g.Inputs.Parent.Close}
}
foreach($case in 'small','partial','exact16384','overflow','changingLength','read-unknown','open-unknown','close-unknown','nonUTF8'){
 $global:StreamCase=$case;$global:Requests=0;$global:Returned=0;$global:CloseCalls=0
 $size=switch($case){exact16384{16384}overflow{16385}changingLength{16385}default{17}}
 $global:Stream=[pscustomobject]@{Remaining=$size;Length=0}
 $global:Stream|Add-Member ScriptMethod Read {param($buf,$offset,$count)$global:Requests+=$count;if($global:StreamCase -eq 'read-unknown'){throw 'unknown read'};if($global:StreamCase -eq 'changingLength' -and $global:Returned -eq 8){$this.Remaining+=1000000;$this.Length=1000000};if($this.Remaining -eq 0){return 0};$n=[Math]::Min(1,$count);$buf[$offset]=if($global:StreamCase -eq 'nonUTF8'){255}else{65};$this.Remaining-=$n;$global:Returned+=$n;return $n}
 $global:Stream|Add-Member ScriptMethod Dispose {$global:CloseCalls++;if($global:StreamCase -eq 'close-unknown'){throw 'unknown close'}}
 $slot=@{Open='UNATTEMPTED';Stream=$null;Read='UNATTEMPTED';Close='UNATTEMPTED';Buffer=[byte[]]::new(16385);Count=0;Requested=0;Eof=$false;Text=$null};$caught=$false
 try{& $graphics84ReadBounded $slot 'EXISTING_ONLY'}catch{$caught=$true}
 if($global:Requests -gt 16385 -or $global:Returned -gt 16385){throw 'acquisition budget exceeded'}
 if($case -in 'small','partial','exact16384'){if($caught -or -not $slot.Eof -or $slot.Close -ne 'DONE'){throw 'valid bounded reader'}}elseif(-not $caught){throw 'bad stream accepted'}
 if($case -eq 'read-unknown' -and ($slot.Read -ne 'UNKNOWN' -or $global:CloseCalls -ne 0 -or -not [Object]::ReferenceEquals($slot.Stream,$global:Stream))){throw 'unknown read owner lost'}
 if($case -eq 'close-unknown' -and ($slot.Close -ne 'FAILED' -or $global:CloseCalls -ne 1)){throw 'close ledger'}
 if($case -eq 'open-unknown' -and $slot.Open -ne 'UNKNOWN'){throw 'unknown open lost'}
 $results+=@{stream=$case;requested=$global:Requests;returned=$global:Returned;closecalls=$global:CloseCalls;open=$slot.Open;read=$slot.Read;close=$slot.Close;rejected=$caught}
}
$out='C:/work/gesher-ci-review/graphicsdex-five-case-bounded-source-results.json';[IO.File]::WriteAllText($out+'.tmp',(($results|ConvertTo-Json -Depth 6).Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false));[IO.File]::Move($out+'.tmp',$out,$true)
'PASS actual-source12 oldfalsePASS now rejected; five intended contrasts/adversaries; nine bounded stream doubles'
