$ErrorActionPreference='Stop'
$repo='C:/work/gesher-ci-graphics-processes'
$tokens=$null;$errors=$null
$a=[Management.Automation.Language.Parser]::ParseFile($repo+'/tests/windows/tracks/30-graphics.ps1',[ref]$tokens,[ref]$errors)
if($errors.Count){throw '30 AST'}
$f=$a.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'GraphicsDex'},$true)
$original=$f.Extent.Text
$src=$original.Replace('[Diagnostics.Process]::new()','$global:ProcessDouble').Replace('[Threading.CancellationTokenSource]::new()','$global:CancelDouble').Replace('while ($true)','while ($global:Turns++ -lt 8)').Replace('[Threading.Thread]::Sleep(5000)','$null').Replace('[GtestProcessNativeHandles]::CloseOwnedReader($q.Reader, $q.Handle)','(Close-Double $q.Reader $q.Handle)').Replace('$q.Task.IsCompleted','(Query-Double $q)')
$src=$src.Insert($src.LastIndexOf('}'),'$global:Owner=$o'+"`n")
function Test-Path($path){return -not ([string]$path).EndsWith('.map')}
function NoDrive($path){return $path}
function Write-Host {param($v) if($global:Fault -eq 'Sink'){throw 'fake sink'};$global:Messages+= [string]$v}
function Query-Double($q){$global:Queries++;if(($global:Fault -eq 'Query1' -and $global:Queries -eq 1) -or ($global:Fault -eq 'Query3' -and $global:Queries -eq 3)){throw 'fake completion query'};return $true}
function Close-Double($reader,$handle){$global:CloseCalls.Add($reader.Index);if(($global:Fault -eq 'Close1' -and $reader.Index -eq 1) -or ($global:Fault -eq 'Close2' -and $reader.Index -eq 2)){throw 'fake close'};if($global:Fault -eq 'NativeUnknown' -and $reader.Index -eq 2){return $false};return $true}
. ([scriptblock]::Create($src))
$Dir='C:/fake-no-execution';$root=$Dir;$env:GESHER_CI_PROCESS_TRACE='1'
$results=@()
foreach($fault in 'None','StartUnknown','StartFalse','ReadUnknown','Query1','Query3','Close1','Close2','NativeUnknown','Cancel','CancelDispose','ProcessDispose','ProcessUnproved','Sink'){
 $global:Fault=$fault;$global:Turns=0;$global:Queries=0;$global:Owner=$null;$global:CloseCalls=[Collections.Generic.List[int]]::new();$global:Messages=@();$global:Disposals=0;$global:KillCalls=0;$script:failed=0
 $ph=[pscustomobject]@{IsClosed=$false};$pipes=@()
 foreach($i in 1,2){
  $h=[pscustomobject]@{Bits=[IntPtr](100+$i)};$h|Add-Member ScriptMethod DangerousGetHandle {return $this.Bits}
  $task=[pscustomobject]@{Status=[Threading.Tasks.TaskStatus]::RanToCompletion;Result='GraphicsFixture all passed'};$task|Add-Member ScriptMethod Wait {param($ms)return $true}
  $r=[pscustomobject]@{Index=$i;BaseStream=[pscustomobject]@{SafeFileHandle=$h};Task=$task};$r|Add-Member ScriptMethod ReadToEndAsync {param($token)if($global:Fault -eq 'ReadUnknown'){throw 'fake read attempted'};return $this.Task};$pipes+=$r
 }
 $global:ProcessDouble=[pscustomobject]@{StartInfo=$null;SafeHandle=$ph;Id=111;StartTime=[DateTime]::UtcNow;StandardOutput=$pipes[0];StandardError=$pipes[1];ExitCode=0}
 $global:ProcessDouble|Add-Member ScriptMethod Start {if($global:Fault -eq 'StartUnknown'){throw 'fake Start uncertain'};return $global:Fault -ne 'StartFalse'}
 $global:ProcessDouble|Add-Member ScriptMethod WaitForExit {param($ms)return $true}
 $global:ProcessDouble|Add-Member ScriptMethod Kill {param($tree)$global:KillCalls++}
 $global:ProcessDouble|Add-Member ScriptMethod Dispose {$global:Disposals++;if($global:Fault -eq 'ProcessDispose'){throw 'fake Process.Dispose'};if($global:Fault -ne 'ProcessUnproved'){$this.SafeHandle.IsClosed=$true}}
 $global:CancelDouble=[pscustomobject]@{Token=$null};$global:CancelDouble|Add-Member ScriptMethod Cancel {if($global:Fault -eq 'Cancel'){throw 'fake cancellation'}};$global:CancelDouble|Add-Member ScriptMethod Dispose {if($global:Fault -eq 'CancelDispose'){throw 'fake cancel dispose'}}
 GraphicsDex independent GraphicsFixture
 $o=$global:Owner;if($null -eq $o){throw 'lost root'}
 if($fault -eq 'None'){if($o.Failed -or $global:Disposals -ne 1 -or $global:CloseCalls.Count -ne 2){throw 'normal'}}else{if(-not $o.Failed){throw 'failure cleared'}}
 if($fault -in 'StartUnknown','StartFalse','ReadUnknown','Close1','Close2','NativeUnknown','Cancel','CancelDispose','ProcessDispose','ProcessUnproved','Sink'){if($global:Turns -lt 8){throw "escaped $fault"}}
 if($global:Disposals -gt 1 -or @($global:CloseCalls|Group-Object|Where-Object Count -gt 1).Count){throw 'repeat disposal'}
 $results+=[ordered]@{kind='actual-product-extraction';fault=$fault;phase=$o.Phase;failed=$o.Failed;launch=$o.Launch;closeStates=@($o.Pipes|ForEach-Object Close);closes=@($global:CloseCalls);processDisposals=$global:Disposals;queries=$global:Queries;turns=$global:Turns;rootSame=[object]::ReferenceEquals($o.P,$global:ProcessDouble)}
}
$out='C:/work/gesher-ci-review/graphicsdex-current-prior14-product-results.json'
[IO.File]::WriteAllText($out+'.tmp',(($results|ConvertTo-Json -Depth 8).Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false));[IO.File]::Move($out+'.tmp',$out,$true)
'14 prior independent actual-product lifecycle cases replay PASS; source instrumentation/loop8 truncation'
$env:GITHUB_SHA='a'*40;$env:GESHER_GRAPHICS84_NONCE='ab'*32;$env:GESHER_GRAPHICS84_MODE='timeout'
$typed=@()
foreach($v in 'intended','postkill-late','iofault','queryfault','sinkfault'){
 $global:Variant=$v;$global:Fault='None';$global:Turns=0;$global:Queries=0;$global:WaitCalls=0;$global:Disposals=0;$global:KillCalls=0;$global:SinkCalls=0;$global:CloseCalls=[Collections.Generic.List[int]]::new();$global:Messages=@();$script:failed=0
 $global:ProcessDouble.SafeHandle.IsClosed=$false;$global:ProcessDouble.ExitCode=1
 foreach($r in @($global:ProcessDouble.StandardOutput,$global:ProcessDouble.StandardError)){
  $r.Task.Result='no marker'
  $r.Task|Add-Member -Force ScriptMethod Wait {param($ms)if($global:Variant -eq 'iofault'){throw 'injected original IO'};return $true}
 }
 $global:ProcessDouble|Add-Member -Force ScriptMethod WaitForExit {param($ms)$global:WaitCalls++;if($global:WaitCalls -eq 1){return $false};if($global:WaitCalls -eq 2 -and $global:Variant -eq 'postkill-late'){return $false};if($global:WaitCalls -eq 2 -and $global:Variant -eq 'queryfault'){throw 'injected postkill query'};return $true}
 function Write-Host {param($v)$global:SinkCalls++;if($global:Variant -eq 'sinkfault' -and $global:SinkCalls -eq 1){throw 'injected one-time sink'};$global:Messages+=[string]$v}
 GraphicsDex 'actual-typed-timeout' GraphicsFixture
 $o=$script:GraphicsDexObservation
 if($null -eq $o -or -not $o.OperationExpired -or -not $o.KillReserved -or -not $o.KernelComplete -or $script:failed -ne 1 -or $global:KillCalls -ne 1){throw 'timeout source facts/verdict'}
 if($v -eq 'intended'){if($o.MechanismFailure -or $o.CleanupBudgetExpired -or -not $o.EofComplete){throw 'intended timeout mislabeled'}}
 elseif($v -eq 'postkill-late'){if(-not $o.CleanupBudgetExpired){throw 'late kernel cleanup qualified'}}
 elseif(-not $o.MechanismFailure){throw 'unexpected mechanism failure erased'}
 if($global:Disposals -ne 1 -or $global:CloseCalls.Count -ne 2){throw 'eventual disposal repeated'}
 $typed+=@{variant=$v;mechanism_failure=$o.MechanismFailure;cleanup_expired=$o.CleanupBudgetExpired;eof=$o.EofComplete;kernel=$o.KernelComplete;native_exit=$o.NativeExitCode;kill_calls=$global:KillCalls;process_disposals=$global:Disposals;reader_close_calls=@($global:CloseCalls);product_failure_count=$script:failed;synthetic_terminal_tasks=$true}
}
$out='C:/work/gesher-ci-review/graphicsdex-typed-failure-reasons-results.json'
[IO.File]::WriteAllText($out+'.tmp',(($typed|ConvertTo-Json -Depth 6).Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false));[IO.File]::Move($out+'.tmp',$out,$true)
'5 actual-product timeout/reason branches PASS; late kernel/IO/query/sink cannot hide eventual settlement'