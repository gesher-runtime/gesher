from pathlib import Path, PurePosixPath
import base64, hashlib, json, re, shlex
R=Path('C:/work/gesher-ci-review'); stem='native-helper-012507-41222194378-'; job=124598961306
p=R/(stem+str(job)+'.log'); raw=p.read_bytes(); receipt=json.loads(Path(str(p)+'.receipt.json').read_bytes())
assert receipt['state']=='CLOSED' and receipt['exit']==0 and receipt['get_count']==1 and receipt['raw_bytes']==len(raw) and receipt['raw_sha256']==hashlib.sha256(raw).hexdigest()
groups={}; current=None
for line in raw.splitlines():
    m=re.search(rb'Z FILE_MREMAP_HELPER_(\w+) part=(\d+)/(\d+) bytes=(\d+) sha256=([0-9a-f]{64}) base64=([A-Za-z0-9+/=]+)$',line)
    if not m: continue
    label,i,n,size,digest,payload=m.groups(); i=int(i); n=int(n); size=int(size)
    if i==1: assert current is None; current=[label,n,size,digest,[],0]
    assert current and (label,n,size,digest)==tuple(current[:4]) and i==current[5]+1
    current[4].append(base64.b64decode(payload,validate=True)); current[5]=i
    if i==n:
        b=b''.join(current[4]); assert len(b)==size and hashlib.sha256(b).hexdigest().encode()==digest
        groups.setdefault(label.decode(),[]).append(json.loads(b)); current=None
assert current is None
x,=groups['DEPENDENCY_GATE']; b,=groups['EARLY_COMPILER_BASIS']; failure,=groups['FAILURE']
text=x['raw']['text']; payload=text.encode('utf-8'); assert len(payload)==x['raw']['bytes'] and hashlib.sha256(payload).hexdigest()==x['raw']['sha256']
deps=shlex.split(text.replace('\\\n',' ').split(': ',1)[1]); assert len(deps)==len(set(deps))==834
names={PurePosixPath(d).name for d in deps}; req={'array','map','memory','new','utility','vector','windows.h'}
assert set(x['required'])==req and sorted(req-names)==x['missing']==['utility'] and set(x['observed'])==names
assert x['context']==b['context'] and x['context']['source']=='012507a942bf0d4c5301f6dd34b813fd968ba391' and x['context']['run']=='41222194378' and x['context']['attempt']=='1'
assert x['guard']==b['guard']=='e9464922f4a1d28517b1402b83106152791615bb' and x['producer_id']==b['producer_id']==job and x['qualification'] is False
cfg=(json.dumps(b['controlled_config'],sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode(); assert hashlib.sha256(cfg).hexdigest()==x['controlled_config_sha256']
assert failure['error']=="Rejected('SDK/STL dependencies missing')" and failure['qualification'] is False
assert all(failure[k]==0 for k in ('retained_directory_roots','retained_native_graphs','retained_tool_graphs'))
tools=groups['TOOL']; assert len(tools)==4 and all(t['exit']==0 for t in tools)
print(json.dumps({'run':41222194378,'source':x['context']['source'],'job':job,'raw_sha256':x['raw']['sha256'],'raw_bytes':len(payload),'dependency_count':len(deps),'missing':sorted(req-names),'tool_exits':[t['exit'] for t in tools],'qualification':False},indent=2))
