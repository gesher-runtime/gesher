"""Synthetic full guard execution; source mutations are guard's finite restored controls."""
from pathlib import Path
import ast,io,json,os,subprocess,tempfile,textwrap,urllib.request
R=Path('C:/work/gesher-coherent-selected-tcp');os.chdir(R)
C='0a0f63cf39f17315a63913395c72de13d0a688ae';G='90f01cad1f3e189d30beaf4ad96fa15ae75048eb'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'])
s=(R/'.github/workflows/net-combined-dns-trusted-source.yml').read_text();code=textwrap.dedent(s.split("          python3 -I - <<'PY'\n",1)[1].rsplit('\n          PY',1)[0]);tree=ast.parse(code)
tree.body=[n for n in tree.body if not(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='main')]
scope={};exec(compile(tree,'coherent-guard-pure','exec'),scope)
run=json.loads(Path('C:/work/gesher-ci-review/fonts-qualified-410789-run.json').read_text())
run.update(id=123,run_attempt=1,head_sha=C,event='workflow_dispatch',path='.github/workflows/ci.yml',name='ci')
for key in ('repository','head_repository'):run[key]['id']=1426153186;run[key]['full_name']='gesher-runtime/gesher'
for ref in run['referenced_workflows']:
 if '/net-combined-dns-trusted-source.yml@' in ref['path']:ref['path']='gesher-runtime/gesher/.github/workflows/net-combined-dns-trusted-source.yml@'+G;ref['sha']=G
 else:ref['path']=ref['path'].rsplit('@',1)[0]+'@'+C;ref['sha']=C
env=dict(GITHUB_SHA=C,GITHUB_WORKFLOW_SHA=C,GITHUB_RUN_ID='123',GITHUB_RUN_ATTEMPT='1',GITHUB_REPOSITORY='gesher-runtime/gesher',GITHUB_REPOSITORY_ID='1426153186',GITHUB_EVENT_NAME='workflow_dispatch',GITHUB_REF='refs/heads/wip/coherent-selected-tcp',GITHUB_ACTOR='palmoni5',GITHUB_TRIGGERING_ACTOR='palmoni5',GH_TOKEN='synthetic',NET_COHERENT_SELECTED_TCP_CALLER_COMMIT=C)
old=dict(os.environ);real=urllib.request.urlopen;calls=[]
def fake(request,timeout):
 assert request.full_url=='https://api.github.com/repos/gesher-runtime/gesher/actions/runs/123' and timeout==60;calls.append(1);return io.BytesIO(json.dumps(run).encode())
try:
 with tempfile.TemporaryDirectory(prefix='coherent-guard-') as d:
  out=Path(d)/'output';os.environ.update(env,GITHUB_OUTPUT=str(out));urllib.request.urlopen=fake
  scope['main']();assert out.read_text()=='source='+C+'\npolicy_ref=gesher-runtime/gesher/.github/workflows/net-combined-dns-trusted-source.yml@'+G+'\n';assert len(calls)==1
finally:
 urllib.request.urlopen=real;os.environ.clear();os.environ.update(old)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'])
print('COHERENT_FULL_GUARD_MOCK_PASS exact_output=1 synthetic_api=1 actual_network_native=0 source_restored=1')
