"""Independent saved log audit only; no network, compiler, artifacts or fixture execution."""
import hashlib,json,re,subprocess
from pathlib import Path
R=Path('C:/work/gesher-ci-review');W=Path('C:/work/gesher-pthread-minimum-join-cancellation');C='1fe0068e417e61b9bd77078844723e11d7b7d03d';G='70d73132368f08d855dd7d3d1603da9bd7c65bce';RUN=41224370978
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((R/'join-collector-412243-run.json').read_text());jobs=json.loads((R/'join-collector-412243-jobs.json').read_text())['jobs']
assert run['id']==RUN and run['run_attempt']==1 and run['head_sha']==C and run['head_branch']=='wip/pthread-minimum-join-cancellation' and run['event']=='push' and run['status']=='completed' and run['conclusion']=='success'
assert run['actor']['login']==run['triggering_actor']['login']=='palmoni5' and run['repository']['id']==run['head_repository']['id']==1426153186
assert len(run['referenced_workflows'])==1 and run['referenced_workflows'][0]['sha']==G
assert {j['id']:j['name'] for j in jobs}=={124605332418:'source-authority / verify',124605364612:'diagnostic-producer'} and all(j['status']=='completed' and j['conclusion']=='success' and j['head_sha']==C and j['run_attempt']==1 for j in jobs)
logs={}
for j in jobs:
 path=R/f"join-collector-412243-{j['id']}.log";raw=path.read_bytes();rc=json.loads(Path(str(path)+'.receipt.json').read_bytes())
 assert rc['state']=='CLOSED' and rc['exit']==0 and rc['get_count']==1 and rc['raw_bytes']==len(raw) and rc['raw_sha256']==sha(raw) and rc['source']==C and rc['run']==RUN and rc['attempt']==1
 logs[j['id']]=raw.decode('utf-8')
producer=logs[124605364612];guard=logs[124605332418]
assert f'JOIN_OBJECT_SOURCE_PASS source={C} guard={G} files=1831 runtime=false qualification=false' in guard
assert 'JOIN_DIAG_OBJECT_COLLECTION_ONLY runtime_executed=false target_wait_proved=false product_qualification=false' in producer
assert 'checking whether we are cross compiling... yes' in producer and 'diagnostic-thread.obj:\tfile format coff-x86-64' in producer
manifest=json.loads(subprocess.check_output(['git','show',C+':tools/host-pthread-authority/minimum-inputs.json'],cwd=W))
rows=re.findall(r'JOIN_DIAG_UPSTREAM_SOURCE (\S+) ([0-9a-f]{64})',producer);assert dict(rows)==manifest['source_sha256'] and len(rows)==12
for name in ('minimum-detached-retirement.patch','minimum-noattach-join.patch','minimum-join-wait-diagnostic.patch'):
 data=subprocess.check_output(['git','show',C+':tools/host-pthread-authority/'+name],cwd=W);assert re.search(r'\b'+sha(data)+r'  \S*/'+re.escape(name)+r'$',producer,re.M)
assert re.search(r'thread.c: OK',producer) and 'llvm-mingw-diagnostic.tar.xz: OK' in producer
assert 'c9b86311ade81d53235c93fafabdf98328d094de344ea9a9038e0dab6695ee9f' in producer and 'Target: x86_64-w64-windows-gnu' in producer
obj=re.search(r'([0-9a-f]{64})  diagnostic-thread\.obj',producer);assert obj
# Actual exact object disassembly and COFF relocations, not linked/live bytes.
lines=[]
for line in producer.splitlines():
 match=re.match(r'^\d{4}-\d\d-\d\dT\S+Z (.*)$',line)
 if match:lines.append(match.group(1))
text='\n'.join(lines)
a=text.index('0000000000002540 <gesher_minimum_join_diag_wait>:');b=text.index('0000000000002580 <_pthread_tryjoin>:',a);wrapper=text[a:b]
for fragment in ('2545: 48 89 ce','2548: 48 89 0d','IMAGE_REL_AMD64_REL32\tgesher_diag_handle','IMAGE_REL_AMD64_REL32\t__imp_GetCurrentThreadId','2560: 87 05','IMAGE_REL_AMD64_REL32\tgesher_diag_phase','2566: 48 89 f1','2569: ba ff ff ff ff','2573: 48 ff 25','IMAGE_REL_AMD64_REL32\t__imp_WaitForSingleObject'):
 assert fragment in wrapper,fragment
assert 'jmpq' in next(x for x in wrapper.splitlines() if '2573:' in x)
for fragment in ('230f: 48 8b 4b 28','IMAGE_REL_AMD64_REL32\tgesher_diag_target','231c: e8 00 00 00 00','IMAGE_REL_AMD64_REL32\tgesher_minimum_join_diag_wait','2321: eb 38'):
 assert fragment in text,fragment
out={'source':C,'guard':G,'run':RUN,'attempt':1,'jobs_success':2,'object_sha256':obj.group(1),'upstream_files':12,'wrapper_start':'0x2540','wait_tail_jump':'0x2573','wait_relocation':'0x2576','caller_call':'0x231c','caller_return':'0x2321','live_wait_proved':False,'linked_binary_proved':False,'product_qualification':False,'auditor_network_native':False}
(R/'join-collector-412243-independent-actual-summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,indent=2))
