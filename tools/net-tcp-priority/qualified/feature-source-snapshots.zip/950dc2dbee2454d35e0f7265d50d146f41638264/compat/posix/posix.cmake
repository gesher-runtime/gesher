# gesher-base: the Linux/POSIX interfaces AOSP code expects, on Win32.
# Headers in include/ shadow or extend mingw's; implementations in src/.
add_library(gesher_posix STATIC
  ${CMAKE_CURRENT_LIST_DIR}/src/binder.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/crash.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/dirent.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/dlfcn.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/epoll.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/environment.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/errno.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/fault_signals.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/fd.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/filesystem_capacity.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/fnmatch.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/font_environment.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/fsops.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/ftw.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/inotify.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/internal.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/libcap.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/links.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/logging.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/memalign.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/mman_alias_prepare.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/mman.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/memfd_seals.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/native_fence.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/misc.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/netdb.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/network_dns.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/ofd.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/path.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/pipe_io.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/process.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_descriptors.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_duplicate.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_liveness.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_operation.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_registry.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/record_lock_wait.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/procfs.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/resume.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/revocable_file.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/rooted_storage.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/rooted_storage_client.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/drop_mount.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/pthread.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/select.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/signal.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/sleep.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/socket.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/unix_rights.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/stat.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/stdio_output.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/syscall.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/sysv_shims.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/system.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/system_properties.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/thread_register.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/timerfd.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/unistd.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/users.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/windows_zones.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/winsock.cc
  ${CMAKE_CURRENT_LIST_DIR}/src/xattr.cc)
# Windows time zone ids to IANA ids (src/windows_zones.cc), from the pinned
# ICU's CLDR windowsZones (ADR 0045).
set(_gesher_posix_gen "${CMAKE_BINARY_DIR}/gen/gesher_posix")
set(_windows_zones_txt "${AOSP_DIR}/external/icu/icu4c/source/data/misc/windowsZones.txt")
add_custom_command(
  OUTPUT "${_gesher_posix_gen}/windows_zones_table.inc"
  COMMAND ${CMAKE_COMMAND} -E make_directory "${_gesher_posix_gen}"
  COMMAND ${Python3_EXECUTABLE} "${CMAKE_CURRENT_LIST_DIR}/gen_windows_zones.py"
          "${_windows_zones_txt}" "${_gesher_posix_gen}/windows_zones_table.inc"
  DEPENDS "${CMAKE_CURRENT_LIST_DIR}/gen_windows_zones.py" "${_windows_zones_txt}"
  VERBATIM)
target_sources(gesher_posix PRIVATE "${_gesher_posix_gen}/windows_zones_table.inc")
target_include_directories(gesher_posix PRIVATE "${_gesher_posix_gen}")
# Resolve ordinary Win32 symbols before mincore, whose umbrella import library
# also exports them through API sets. Only the precise interrupt clocks need
# mincore; the pinned LLVM-MinGW does not ship their standalone import library.
target_link_libraries(gesher_posix PUBLIC powrprof synchronization psapi ws2_32 iphlpapi bcrypt shell32 advapi32 ole32 uuid
  pthread kernel32 mincore)
# Pull in the crash reporter (src/crash.cc), which nothing calls.
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_crash_reporter_anchor)
# Every process keeps a signal mailbox for kill() from other processes
# (src/process.cc), which nothing calls either.
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_signal_mailbox_anchor)
# DLL callers resolve the futex queue in the executable. Force a private anchor:
# an import library can satisfy the public owner symbol without extracting it.
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_futex_owner_anchor_v1)
# One OFD registry for the executable and every linked AOSP DLL. Import the
# child's shared descriptions before application code can recycle its fds.
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_ofd_owner_anchor_v1)
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_descriptor_transaction_anchor_v1)
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_stdio_output_anchor_v1)
target_link_options(gesher_posix INTERFACE -Wl,-u,gesher_environment_anchor_v1)
# GNU scanf's parser uses public getc/ungetc; retain one stream lock around
# its complete conversion sequence, including ANSI-mode assembly aliases.
target_link_options(gesher_posix INTERFACE -Wl,--wrap=__mingw_vfscanf -Wl,--wrap=__mingw_vfwscanf)
# The __real_ calls alone do not extract the original parser members from the
# pinned MinGW archive with lld's COFF --wrap handling. Retain both actual
# parsers; otherwise a successful link can leave a call to its next instruction.
target_link_options(gesher_posix INTERFACE -Wl,-u,__mingw_vfscanf -Wl,-u,__mingw_vfwscanf)
# posix_memalign() memory goes to free()/realloc() (src/memalign.cc).
target_link_options(gesher_posix INTERFACE -Wl,--wrap=free -Wl,--wrap=realloc)
target_include_directories(gesher_posix BEFORE PUBLIC ${CMAKE_CURRENT_LIST_DIR}/include)
# Every AOSP module sees the Linux-like environment, and links its implementation.
include_directories(BEFORE ${CMAKE_CURRENT_LIST_DIR}/include)
link_libraries(gesher_posix)
target_compile_options(gesher_posix PRIVATE -Wall -Wextra -Werror)
# Fence factories convert allocation failure to ENOMEM while retaining pending
# GPU-event lifetime. Descriptor publication itself uses preallocated slots.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/native_fence.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
# /dev/binder (src/binder.cc) speaks the kernel driver's ABI, from bionic's
# uapi header; searched last, so gesher-base's <linux/*.h> come first.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/binder.cc PROPERTIES
  COMPILE_OPTIONS "-idirafter;${AOSP_DIR}/bionic/libc/kernel/uapi")

# Only detached alias bookkeeping may throw; same pinned STL/CRT/allocator ABI.
# Actual compile_commands effective ordering and throwing runtime require CI proof.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/mman_alias_prepare.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
# Stream/map allocation failures are reported as ENOMEM before fdopen takes
# descriptor ownership. Exceptions do not cross the stdio ABI boundary.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/stdio_output.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
# Exec snapshot visitors may allocate in the calling module. Preserve owner
# lock cleanup when such a caller reports allocation failure by unwinding.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/environment.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
# OFD/control-block allocations also report ENOMEM at their owner boundary.
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/ofd.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
set_source_files_properties(${CMAKE_CURRENT_LIST_DIR}/src/revocable_file.cc PROPERTIES
  COMPILE_OPTIONS "-fexceptions")
