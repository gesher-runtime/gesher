// gesher-base: /dev/binder, over binderd (compat/binder/binderd.cc).
//
// $GESHER_BINDER names a binder device served by a binderd; without it, or
// with no binderd serving it, /dev/binder does not exist (ENOENT), so
// libbinder runs in-process only, as before. open() connects the process to
// the broker; each thread's first ioctl connects that thread
// (binder_wire.h). BINDER_WRITE_READ sends the command stream with the
// transaction data the commands point to, and copies each transaction the
// broker returns into the process's binder mapping (the fd's mmap), as the
// kernel driver does, so libbinder sees the same pointers and the same
// BC_FREE_BUFFER protocol. See docs/decisions/0015-services-binder-ipc.md.
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <windows.h>

#include <iterator>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include <linux/android/binder.h>
#include <gesher/binder_endpoint.h>
#include <gesher/file_description.h>
#include <gesher/rooted_storage_wire.h>

#include "binder_internal.h"
#include "binder_file_descriptions.h"
#include "binder_sg.h"
#include "binder_wire.h"
#include "record_lock_operation.h"
#include "internal.h"
#include "native_fence_internal.h"
#include "record_lock_descriptors.h"

namespace gesher {
namespace {

namespace wire = binder_wire;

// --- pipes -------------------------------------------------------------------

bool ReadExact(HANDLE pipe, void* buf, size_t n) {
  uint8_t* p = static_cast<uint8_t*>(buf);
  while (n > 0) {
    DWORD got = 0;
    DWORD want = n > 0x10000000 ? 0x10000000 : static_cast<DWORD>(n);
    if (!ReadFile(pipe, p, want, &got, nullptr) || got == 0) return false;
    p += got;
    n -= got;
  }
  return true;
}

bool WriteExact(HANDLE pipe, const void* buf, size_t n) {
  const uint8_t* p = static_cast<const uint8_t*>(buf);
  while (n > 0) {
    DWORD put = 0;
    DWORD want = n > 0x10000000 ? 0x10000000 : static_cast<DWORD>(n);
    if (!WriteFile(pipe, p, want, &put, nullptr) || put == 0) return false;
    p += put;
    n -= put;
  }
  return true;
}

struct Message {
  std::vector<uint8_t> bytes = std::vector<uint8_t>(4);  // the length, filled in by Send
  void Write(const void* data, size_t n) {
    if (n == 0) return;
    const uint8_t* b = static_cast<const uint8_t*>(data);
    bytes.insert(bytes.end(), b, b + n);
  }
  template <typename T>
  void Put(const T& v) {
    Write(&v, sizeof(T));
  }
};

bool Send(HANDLE pipe, Message& m) {
  uint32_t len = static_cast<uint32_t>(m.bytes.size() - 4);
  memcpy(m.bytes.data(), &len, 4);
  return WriteExact(pipe, m.bytes.data(), m.bytes.size());
}

bool Receive(HANDLE pipe, std::vector<uint8_t>* out) {
  uint32_t len;
  if (!ReadExact(pipe, &len, sizeof(len)) || len > (64u << 20)) return false;
  out->resize(len);
  return ReadExact(pipe, out->data(), len);
}

struct Reader {
  const uint8_t* p;
  const uint8_t* end;
  bool Read(void* out, size_t n) {
    if (static_cast<size_t>(end - p) < n) return false;
    memcpy(out, p, n);
    p += n;
    return true;
  }
  template <typename T>
  bool Get(T* out) {
    return Read(out, sizeof(T));
  }
};

std::wstring PipeName() {
  if (binder_endpoint::Current().IsStandalone()) return {};
  const char* device = getenv("GESHER_BINDER");
  if (device == nullptr || device[0] == '\0') return {};
  return std::wstring(wire::kPipePrefix) + Widen(device);
}

std::wstring RecordPipeName() {
  if (!binder_endpoint::Current().IsStandalone()) return PipeName();
  const DWORD pid = binder_endpoint::Current().StandaloneRecordBrokerPid();
  return pid != 0 ? wire::kStandaloneRecordPipe + std::to_wstring(pid) : std::wstring{};
}

HANDLE ConnectPipe(const std::wstring& name) {
  for (int attempt = 0; attempt < 50; ++attempt) {
    HANDLE h = CreateFileW(name.c_str(), wire::kPipeClientAccess, 0, nullptr, OPEN_EXISTING,
                           SECURITY_SQOS_PRESENT | SECURITY_IDENTIFICATION, nullptr);
    if (h != INVALID_HANDLE_VALUE) {
      if (binder_endpoint::Current().VerifyPipe(h)) return h;
      CloseHandle(h);
      SetLastError(ERROR_ACCESS_DENIED);
      return INVALID_HANDLE_VALUE;
    }
    if (GetLastError() != ERROR_PIPE_BUSY) return INVALID_HANDLE_VALUE;
    WaitNamedPipeW(name.c_str(), 100);
  }
  SetLastError(ERROR_PIPE_BUSY);
  return INVALID_HANDLE_VALUE;
}

// --- the open device ------------------------------------------------------------

struct Allocation {
  uint64_t id;          // the broker's buffer
  size_t offset;        // in the mapping, or kMalloced
  size_t size;
};
constexpr size_t kMalloced = SIZE_MAX;

struct BinderFile {
  std::wstring pipe_name;
  HANDLE proc_pipe = INVALID_HANDLE_VALUE;
  uint32_t proc_id = 0;
  uint64_t key = 0;
  bool non_block = false;

  std::mutex mutex;  // guards what follows
  uint8_t* map = nullptr;
  size_t map_size = 0;
  std::map<size_t, size_t> free_blocks;  // offset -> size, in the mapping
  std::unordered_map<uintptr_t, Allocation> allocations;

  ~BinderFile() {
    // Closing the process's connection releases it in the broker.
    if (proc_pipe != INVALID_HANDLE_VALUE) CloseHandle(proc_pipe);
    std::lock_guard<std::mutex> lock(mutex);
    for (auto& [ptr, a] : allocations) {
      if (a.offset == kMalloced) free(reinterpret_cast<void*>(ptr));
    }
  }

  // A block for a transaction the broker delivers: in the mapping when it
  // fits (as the kernel allocates it), else on the heap.
  uint8_t* Allocate(size_t size, uint64_t id, bool require_mapping = false) {
    size = (size + 7) & ~size_t{7};
    if (size == 0) size = 8;
    std::lock_guard<std::mutex> lock(mutex);
    for (auto it = free_blocks.begin(); it != free_blocks.end(); ++it) {
      if (it->second < size) continue;
      size_t offset = it->first;
      size_t rest = it->second - size;
      free_blocks.erase(it);
      if (rest > 0) free_blocks[offset + size] = rest;
      uint8_t* p = map + offset;
      allocations[reinterpret_cast<uintptr_t>(p)] = {id, offset, size};
      return p;
    }
    // New PTR payloads obey the actual receiver mapping capacity. Legacy
    // plain transactions retain their existing heap fallback as open scope.
    if (require_mapping) return nullptr;
    uint8_t* p = static_cast<uint8_t*>(malloc(size));
    if (p != nullptr) allocations[reinterpret_cast<uintptr_t>(p)] = {id, kMalloced, size};
    return p;
  }

  // BC_FREE_BUFFER: the broker's id for the block at ptr, which is freed.
  uint64_t Free(uintptr_t ptr) {
    std::lock_guard<std::mutex> lock(mutex);
    auto it = allocations.find(ptr);
    if (it == allocations.end()) return 0;
    Allocation a = it->second;
    allocations.erase(it);
    if (a.offset == kMalloced) {
      free(reinterpret_cast<void*>(ptr));
      return a.id;
    }
    // Coalesce with the neighbouring free blocks.
    size_t offset = a.offset;
    size_t size = a.size;
    auto next = free_blocks.lower_bound(offset);
    if (next != free_blocks.end() && next->first == offset + size) {
      size += next->second;
      next = free_blocks.erase(next);
    }
    if (next != free_blocks.begin()) {
      auto prev = std::prev(next);
      if (prev->first + prev->second == offset) {
        prev->second += size;
        return a.id;
      }
    }
    free_blocks[offset] = size;
    return a.id;
  }
};

std::mutex files_mutex;
std::unordered_map<int, std::shared_ptr<BinderFile>> files;

std::shared_ptr<BinderFile> Lookup(int fd) {
  std::lock_guard<std::mutex> lock(files_mutex);
  if (files.empty()) return nullptr;
  auto it = files.find(fd);
  return it == files.end() ? nullptr : it->second;
}

// --- per-thread connections -----------------------------------------------------

struct ThreadConnection {
  std::weak_ptr<BinderFile> file;
  BinderFile* key;
  HANDLE pipe;
};

struct ThreadConnections {
  std::vector<ThreadConnection> list;
  ~ThreadConnections() {
    for (ThreadConnection& c : list) CloseHandle(c.pipe);
  }
};

// Fiber-local storage, whose callback runs when any thread exits, closes the
// thread's connections: the broker then releases the binder thread
// (binder_thread_release), as the kernel does when a thread exits.
DWORD fls_index = FLS_OUT_OF_INDEXES;
std::once_flag fls_once;

void NTAPI FreeThreadConnections(void* data) { delete static_cast<ThreadConnections*>(data); }

ThreadConnections* Connections() {
  std::call_once(fls_once, [] { fls_index = FlsAlloc(FreeThreadConnections); });
  if (fls_index == FLS_OUT_OF_INDEXES) return nullptr;
  auto* conns = static_cast<ThreadConnections*>(FlsGetValue(fls_index));
  if (conns == nullptr) {
    conns = new ThreadConnections;
    FlsSetValue(fls_index, conns);
  }
  return conns;
}

// The calling thread's connection for `file`, opened on first use. Returns
// INVALID_HANDLE_VALUE with errno set on failure.
HANDLE ThreadPipe(const std::shared_ptr<BinderFile>& file) {
  ThreadConnections* conns = Connections();
  if (conns == nullptr) return errno = ENOMEM, INVALID_HANDLE_VALUE;
  for (auto it = conns->list.begin(); it != conns->list.end();) {
    if (it->file.expired()) {  // a closed fd's
      CloseHandle(it->pipe);
      it = conns->list.erase(it);
      continue;
    }
    if (it->key == file.get()) return it->pipe;
    ++it;
  }
  HANDLE pipe = ConnectPipe(file->pipe_name);
  if (pipe == INVALID_HANDLE_VALUE) return errno = EBADF, INVALID_HANDLE_VALUE;
  Message hello;
  hello.Put<uint32_t>(wire::kHelloThread);
  hello.Put<uint32_t>(wire::kMagic);
  hello.Put<uint32_t>(wire::kVersion);
  hello.Put<uint32_t>(file->proc_id);
  hello.Put<uint64_t>(file->key);
  hello.Put<uint32_t>(GetCurrentThreadId());
  std::vector<uint8_t> reply;
  int32_t status = -EBADF;
  if (!Send(pipe, hello) || !Receive(pipe, &reply) || reply.size() < 4) {
    CloseHandle(pipe);
    return errno = EBADF, INVALID_HANDLE_VALUE;
  }
  memcpy(&status, reply.data(), 4);
  if (status != 0) {
    CloseHandle(pipe);
    return errno = -status, INVALID_HANDLE_VALUE;
  }
  conns->list.push_back({file, file.get(), pipe});
  return pipe;
}

void CloseThreadPipe(BinderFile* file) {
  ThreadConnections* conns = Connections();
  if (conns == nullptr) return;
  for (auto it = conns->list.begin(); it != conns->list.end(); ++it) {
    if (it->key == file) {
      CloseHandle(it->pipe);
      conns->list.erase(it);
      return;
    }
  }
}

// --- ioctls ---------------------------------------------------------------------------

// File descriptors in transactions (BINDER_TYPE_FD). The kernel installs a
// new fd for the same open file in the receiver. Here the sender puts the
// fd's Windows handle in the object (its 64-bit pad_binder, which shares the
// fd's union), binderd duplicates it into the receiving process
// (DuplicateHandle). That staging handle remains broker-owned; the receiver
// duplicates it again and adopts only its distinct local copy. A socket's fd
// (open on NUL) travels as its SOCKET handle, and its description's state in
// pad_flags and the high 32 bits of the object's cookie (TransferSocket's low
// and high 32 bits, ADR 0088 phase 3). binderd copies an fd object's cookie
// unchanged; its low 32 bits keep libbinder's value (the sender's ownership
// flag), which the receiver gets back as sent. A completed native fence
// travels as its read-only completion event (kNativeFenceFileDescription), with
// its type in pad_flags and no shared description. Ordinary files retain their
// full cookie and carry shared descriptions in the separate side table.
// Only fds backed by a Windows handle (files, memfds, pipes, sockets) travel;
// any other goes as handle 0,
// which binderd refuses (BR_FAILED_REPLY).
template <typename F>
void ForEachFdObject(uint8_t* data, size_t data_size, const void* offsets, size_t offsets_size,
                     F f) {
  const uint8_t* offs = static_cast<const uint8_t*>(offsets);
  for (size_t i = 0; i + sizeof(binder_size_t) <= offsets_size; i += sizeof(binder_size_t)) {
    binder_size_t off;
    memcpy(&off, offs + i, sizeof(off));
    if (off > data_size || data_size - off < sizeof(binder_fd_object)) continue;
    binder_fd_object obj;
    memcpy(&obj, data + off, sizeof(obj));
    if (obj.hdr.type != BINDER_TYPE_FD) continue;
    f(off, obj);
    memcpy(data + off, &obj, sizeof(obj));
  }
}

bool SendFds(uint8_t* data, size_t data_size, const void* offsets, size_t offsets_size,
             std::vector<wire::FileDescription>* descriptions,
             std::vector<DescriptorSnapshotPtr>* pins) {
  bool ok = true;
  ForEachFdObject(data, data_size, offsets, offsets_size, [&](uint64_t offset, binder_fd_object& obj) {
    if (!ok) { obj.pad_binder = 0; return; }
    const int fd = static_cast<int>(obj.fd);
    uintptr_t socket = 0;
    uint64_t metadata = 0;
    DescriptorSnapshotPtr snapshot;
    {
      record_locks::DescriptorGuard guard;
      uintptr_t fence_event = 0;
      uint64_t fence_metadata = 0;
      if (TransferNativeFence(fd, &fence_event, &fence_metadata)) {
        // A completed native fence is its typed read-only event, not the NUL
        // reservation behind the descriptor. Pin a duplicate until the broker
        // consumes this stream, even if the sender closes its last fd.
        auto pin = std::make_shared<DescriptorSnapshot>();
        if (!DuplicateHandle(GetCurrentProcess(), reinterpret_cast<HANDLE>(fence_event),
                             GetCurrentProcess(), &pin->handle, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
          ok = false; obj.pad_binder = 0; return;
        }
        obj.pad_flags = static_cast<__u32>(fence_metadata);
        obj.pad_binder = reinterpret_cast<uintptr_t>(pin->handle);
        descriptions->push_back({offset, 0, wire::kNativeFenceFileDescription, 0});
        pins->push_back(std::move(pin));
        return;
      }
      if (TransferSocket(fd, &socket, &metadata)) {
        // Keep the actual socket alive until the broker consumes this stream.
        auto pin = std::make_shared<DescriptorSnapshot>();
        if (!DuplicateHandle(GetCurrentProcess(), reinterpret_cast<HANDLE>(socket),
                             GetCurrentProcess(), &pin->handle, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
          ok = false; obj.pad_binder = 0; return;
        }
        obj.pad_flags = static_cast<__u32>(metadata);
        obj.cookie = (obj.cookie & 0xffffffffu) | (metadata & 0xffffffff00000000ull);
        obj.pad_binder = reinterpret_cast<uintptr_t>(pin->handle);
        descriptions->push_back({offset, 0, wire::kSocketFileDescription, 0});
        pins->push_back(std::move(pin));
        return;
      }
      snapshot = CaptureDescriptor(fd);
    }
    HANDLE shared = snapshot && snapshot->kind != DescriptorKind::kUnshareable
        ? ShareFileDescription(snapshot) : nullptr;
    if (!shared) { ok = false; obj.pad_binder = 0; return; }
    obj.pad_flags = 0;
    obj.pad_binder = reinterpret_cast<uintptr_t>(snapshot->handle);
    descriptions->push_back({offset, reinterpret_cast<uintptr_t>(shared),
                             static_cast<uint32_t>(snapshot->kind), 0});
    pins->push_back(std::move(snapshot));
  });
  return ok;
}

bool ReceiveFds(uint8_t* data, size_t data_size, const void* offsets, size_t offsets_size,
                const std::vector<wire::FileDescription>& descriptions) {
  bool ok = true;
  size_t next = 0;
  ForEachFdObject(data, data_size, offsets, offsets_size, [&](uint64_t, binder_fd_object& obj) {
    const auto& description = descriptions[next++];  // validated before allocation/claim
    HANDLE staging = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(obj.pad_binder));
    HANDLE owned = nullptr, shared = nullptr;
    int fd = -1;
    if (DuplicateHandle(GetCurrentProcess(), staging, GetCurrentProcess(), &owned,
                         0, FALSE, DUPLICATE_SAME_ACCESS)) {
      if (description.kind == wire::kSocketFileDescription) {
        fd = AdoptSocket(reinterpret_cast<uintptr_t>(owned),
                         uint64_t{obj.pad_flags} | (obj.cookie & 0xffffffff00000000ull));
      } else if (description.kind == wire::kNativeFenceFileDescription) {
        // Consumes the handle; admits only an immutable signaled completion event.
        fd = AdoptNativeFence(owned, obj.pad_flags);
      } else {
        HANDLE shared_staging = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(description.shared_handle));
        if (DuplicateHandle(GetCurrentProcess(), shared_staging, GetCurrentProcess(), &shared,
                            0, FALSE, DUPLICATE_SAME_ACCESS)) {
          fd = AdoptFileDescription(owned, shared, static_cast<DescriptorKind>(description.kind), true);
        } else {
          CloseHandle(owned);
        }
      }
    }
    if (fd < 0) ok = false;
    obj.pad_flags = 0;
    if (description.kind == wire::kSocketFileDescription) obj.cookie &= 0xffffffffu;
    obj.pad_binder = 0;
    obj.fd = static_cast<__u32>(fd);
  });
  return ok;
}

void CloseReceivedFds(uint8_t* data, size_t data_size, const void* offsets, size_t offsets_size) {
  ForEachFdObject(data, data_size, offsets, offsets_size, [](uint64_t, binder_fd_object& obj) {
    if (obj.fd != static_cast<__u32>(-1)) close(static_cast<int>(obj.fd));
    obj.fd = static_cast<__u32>(-1);
  });
}

// The uid the driver gives this process's transactions (Binder.getCallingUid
// in the receiver): getuid(), or $GESHER_BINDER_UID. Every gesher-base process
// is uid 10000; the system server sets GESHER_BINDER_UID=1000 (SYSTEM_UID)
// before it opens the driver, so that apps see their calls come from the
// system, as ApplicationThread checks.
uint32_t BinderUid() {
  const char* uid = getenv("GESHER_BINDER_UID");
  if (uid != nullptr && uid[0] != '\0') return static_cast<uint32_t>(strtoul(uid, nullptr, 10));
  return getuid();
}

bool IsTransactionCommand(uint32_t cmd) {
  return cmd == BC_TRANSACTION || cmd == BC_REPLY || cmd == BC_TRANSACTION_SG ||
         cmd == BC_REPLY_SG;
}

// Equivalent to a guarded user copy: bad/unmapped/changing caller pointers
// become transaction failures instead of faults in the shim or broker.
bool CopyUser(void* destination, const void* source, size_t size) {
  if (size == 0) return true;
  SIZE_T copied = 0;
  return ReadProcessMemory(GetCurrentProcess(), source, destination, size, &copied) && copied == size;
}

bool CopyToUser(void* destination, const void* source, size_t size) {
  if (size == 0) return true;
  // WriteProcessMemory can temporarily make read-only pages writable. Reject
  // stable nonwritable output before using that API; this is not a guarantee
  // against concurrent protection changes/unmapping or partial-copy races.
  const uintptr_t begin = reinterpret_cast<uintptr_t>(destination);
  if (begin == 0 || size > UINTPTR_MAX - begin) return false;
  const uintptr_t end = begin + size;
  for (uintptr_t at = begin; at < end;) {
    MEMORY_BASIC_INFORMATION region{};
    if (VirtualQuery(reinterpret_cast<const void*>(at), &region, sizeof(region)) != sizeof(region) ||
        region.State != MEM_COMMIT || (region.Protect & PAGE_GUARD) != 0) return false;
    const DWORD protection = region.Protect & 0xff;
    if (protection != PAGE_READWRITE && protection != PAGE_WRITECOPY &&
        protection != PAGE_EXECUTE_READWRITE && protection != PAGE_EXECUTE_WRITECOPY) return false;
    const uintptr_t base = reinterpret_cast<uintptr_t>(region.BaseAddress);
    if (base > at || region.RegionSize > UINTPTR_MAX - base) return false;
    const uintptr_t next = base + region.RegionSize;
    if (next <= at) return false;
    at = next;
  }
  SIZE_T copied = 0;
  return WriteProcessMemory(GetCurrentProcess(), destination, source, size, &copied) && copied == size;
}

bool BufferResult(HANDLE pipe, uint32_t operation, uint64_t id, bool accepted = false) {
  Message message;
  message.Put<uint32_t>(operation);
  message.Put(id);
  if (operation == wire::kFinishBuffer) message.Put<uint32_t>(accepted ? 1 : 0);
  std::vector<uint8_t> reply;
  int32_t status = -EBADF;
  return Send(pipe, message) && Receive(pipe, &reply) && reply.size() == sizeof(status) &&
      (memcpy(&status, reply.data(), sizeof(status)), status == 0);
}

int WriteRead(const std::shared_ptr<BinderFile>& file, binder_write_read* bwr) {
  HANDLE pipe = ThreadPipe(file);
  if (pipe == INVALID_HANDLE_VALUE) return -1;

  Message m;
  std::vector<DescriptorSnapshotPtr> outbound_fds;
  m.Put<uint32_t>(wire::kWriteRead);
  uint64_t read_size = bwr->read_size > bwr->read_consumed ? bwr->read_size - bwr->read_consumed : 0;
  m.Put<uint64_t>(read_size);
  m.Put<uint32_t>(bwr->read_consumed == 0 ? 1 : 0);
  m.Put<uint32_t>(file->non_block ? 1 : 0);

  // The command stream, with the data each transaction points to.
  std::vector<size_t> starts;  // each command's offset in the write buffer
  if (bwr->write_consumed > bwr->write_size || bwr->write_size > binder_sg::kMaxBytes ||
      bwr->read_consumed > bwr->read_size || bwr->read_size > binder_sg::kMaxBytes) {
    return errno = EINVAL, -1;
  }
  std::vector<uint8_t> command_bytes(static_cast<size_t>(bwr->write_size));
  if (!CopyUser(command_bytes.data(), reinterpret_cast<const void*>(bwr->write_buffer), command_bytes.size())) {
    return errno = EFAULT, -1;
  }
  const uint8_t* wbase = command_bytes.data();
  size_t wpos = bwr->write_consumed;
  while (wpos < bwr->write_size) {
    if (bwr->write_size - wpos < 4) return errno = EINVAL, -1;
    starts.push_back(wpos);
    uint32_t cmd;
    memcpy(&cmd, wbase + wpos, 4);
    size_t size = _IOC_SIZE(cmd);
    if (bwr->write_size - wpos - 4 < size) return errno = EINVAL, -1;
    const uint8_t* arg = wbase + wpos + 4;
    if (!binder_sg::Range(m.bytes.size() - 4, 4 + size +
        (IsTransactionCommand(cmd) ? sizeof(int32_t) : 0), binder_sg::kMaxBytes)) return errno = EINVAL, -1;
    m.Put(cmd);
    if (IsTransactionCommand(cmd)) {
      binder_transaction_data tr;
      memcpy(&tr, arg, sizeof(tr));
      const void* data = reinterpret_cast<const void*>(tr.data.ptr.buffer);
      const void* offsets = reinterpret_cast<const void*>(tr.data.ptr.offsets);
      uint64_t extra_size = 0;
      if (cmd == BC_TRANSACTION_SG || cmd == BC_REPLY_SG) {
        memcpy(&extra_size, arg + sizeof(tr), sizeof(extra_size));
      }
      std::vector<uint8_t> snapshot;
      std::vector<uint64_t> snapshot_offsets;
      std::vector<uint8_t> extra;
      std::vector<wire::FileDescription> descriptions;
      int32_t copy_error = 0;
      if (!binder_sg::Dimensions(tr.data_size, tr.offsets_size, extra_size)) {
        copy_error = EINVAL;
      } else {
        const uint64_t header_end = m.bytes.size() - 4 + size + sizeof(int32_t);
        const uint64_t body_size = tr.data_size + tr.offsets_size + extra_size;
        // Aggregate wire budget is checked before snapshots/extra allocations,
        // including every prior command in this same ioctl message.
        if (!binder_sg::Range(header_end, body_size, binder_sg::kMaxBytes)) {
          copy_error = EINVAL;
        } else {
        snapshot.resize(static_cast<size_t>(tr.data_size));
        snapshot_offsets.resize(static_cast<size_t>(tr.offsets_size / sizeof(uint64_t)));
        if (!CopyUser(snapshot.data(), data, snapshot.size()) ||
            !CopyUser(snapshot_offsets.data(), offsets, static_cast<size_t>(tr.offsets_size))) {
          copy_error = EFAULT;
        } else {
          bool user_fault = false;
          if (!binder_sg::Capture(&snapshot, snapshot_offsets, static_cast<size_t>(extra_size), &extra,
              [&](void* to, const void* from, size_t bytes) {
                if (CopyUser(to, from, bytes)) return true;
                user_fault = true;
                return false;
              })) copy_error = user_fault ? EFAULT : EINVAL;
        }
        }
      }
      tr.data.ptr.buffer = 0;
      tr.data.ptr.offsets = 0;
      if (copy_error == 0) {
        size_t count = 0;
        ForEachFdObject(snapshot.data(), snapshot.size(), snapshot_offsets.data(),
                       snapshot_offsets.size() * sizeof(uint64_t), [&](uint64_t, binder_fd_object&) { ++count; });
        if (count > wire::kMaxFileDescriptions ||
            !binder_sg::Range(m.bytes.size() - 4 + size + sizeof(int32_t) + sizeof(uint32_t),
                    snapshot.size() + snapshot_offsets.size() * sizeof(uint64_t) + extra.size() +
                    count * sizeof(wire::FileDescription), binder_sg::kMaxBytes)) {
          copy_error = EINVAL;
        } else {
          const size_t previous_pins = outbound_fds.size();
          if (!SendFds(snapshot.data(), snapshot.size(), snapshot_offsets.data(),
                       snapshot_offsets.size() * sizeof(uint64_t), &descriptions, &outbound_fds)) {
            copy_error = EBADF;
            outbound_fds.resize(previous_pins);
          }
        }
      }
      m.Put(tr);
      if (size > sizeof(tr)) m.Write(arg + sizeof(tr), size - sizeof(tr));  // buffers_size
      m.Put(copy_error);
      if (copy_error == 0) {
        m.Put<uint32_t>(static_cast<uint32_t>(descriptions.size()));
        m.Write(snapshot.data(), snapshot.size());
        m.Write(snapshot_offsets.data(), snapshot_offsets.size() * sizeof(uint64_t));
        m.Write(extra.data(), extra.size());
        m.Write(descriptions.data(), descriptions.size() * sizeof(wire::FileDescription));
      }
    } else if (cmd == BC_FREE_BUFFER) {
      binder_uintptr_t ptr;
      memcpy(&ptr, arg, sizeof(ptr));
      m.Put<uint64_t>(file->Free(ptr));
    } else {
      m.Write(arg, size);
    }
    wpos += 4 + size;
  }

  if (m.bytes.size() - 4 > binder_sg::kMaxBytes) return errno = EINVAL, -1;

  std::vector<uint8_t> reply;
  if (!Send(pipe, m) || !Receive(pipe, &reply)) {
    CloseThreadPipe(file.get());
    return errno = EBADF, -1;
  }
  Reader r{reply.data(), reply.data() + reply.size()};
  int32_t status;
  uint32_t consumed;
  if (!r.Get(&status) || !r.Get(&consumed)) {
    CloseThreadPipe(file.get());
    return errno = EBADF, -1;
  }
  bwr->write_consumed = consumed >= starts.size() ? bwr->write_size : starts[consumed];
  if (status < 0) {
    if (status == -EBADF) CloseThreadPipe(file.get());
    bwr->read_consumed = 0;
    return errno = -status, -1;
  }

  // The return stream, each transaction's data copied into the mapping.
  size_t rpos = bwr->read_consumed;
  auto publish = [&](const void* bytes, size_t length) {
    if (!binder_sg::Range(rpos, length, bwr->read_size) ||
        bwr->read_buffer > UINTPTR_MAX - rpos) return false;
    return CopyToUser(reinterpret_cast<void*>(static_cast<uintptr_t>(bwr->read_buffer + rpos)), bytes, length);
  };
  while (r.p < r.end) {
    uint32_t cmd;
    if (!r.Get(&cmd)) { CloseThreadPipe(file.get()); return errno = EBADF, -1; }
    size_t size = _IOC_SIZE(cmd);
    if (!binder_sg::Range(rpos, 4 + size, bwr->read_size)) {
      CloseThreadPipe(file.get());  // rolls back any not-yet-claimed delivery
      return errno = EFAULT, -1;
    }
    std::vector<uint8_t> command(4 + size);
    memcpy(command.data(), &cmd, 4);
    if (cmd == BR_TRANSACTION || cmd == BR_REPLY) {
      binder_transaction_data tr;
      uint64_t id;
      if (!r.Get(&tr) || !r.Get(&id)) { CloseThreadPipe(file.get()); return errno = EBADF, -1; }
      auto abandon = [&](uint8_t* block, bool claimed, int error) {
        if (block != nullptr) {
          if (claimed) CloseReceivedFds(block, static_cast<size_t>(tr.data_size),
              block + ((tr.data_size + 7) & ~uint64_t{7}), static_cast<size_t>(tr.offsets_size));
          file->Free(reinterpret_cast<uintptr_t>(block));
        }
        if (!BufferResult(pipe, wire::kFinishBuffer, id, false)) CloseThreadPipe(file.get());
        bwr->read_consumed = rpos;
        errno = error;
        return -1;
      };
      uint64_t extra_size;
      uint32_t description_count;
      if (!r.Get(&extra_size) || !r.Get(&description_count) ||
          !binder_sg::Dimensions(tr.data_size, tr.offsets_size, extra_size) ||
          description_count > tr.offsets_size / sizeof(uint64_t) ||
          description_count > wire::kMaxFileDescriptions) {
        return abandon(nullptr, false, EBADF);
      }
      size_t data_size = static_cast<size_t>(tr.data_size);
      size_t aligned = (data_size + 7) & ~size_t{7};
      const size_t offsets_size = static_cast<size_t>(tr.offsets_size);
      const size_t extra_offset = aligned + offsets_size;
      const uint64_t wire_bytes = tr.data_size + tr.offsets_size + extra_size +
          static_cast<uint64_t>(description_count) * sizeof(wire::FileDescription);
      if (wire_bytes > static_cast<uint64_t>(r.end - r.p)) return abandon(nullptr, false, EBADF);
      // Receive owns this immutable reply until WriteRead returns. Validate its
      // byte ranges directly, then copy once into the receiver-owned allocation.
      // Wire offsets and the descriptor table can follow an odd-sized payload.
      const uint8_t* data = r.p;
      const uint8_t* offsets = data + data_size;
      const uint8_t* extra = offsets + offsets_size;
      std::vector<wire::FileDescription> descriptions(description_count);
      if (!descriptions.empty()) {
        memcpy(descriptions.data(), extra + static_cast<size_t>(extra_size),
               descriptions.size() * sizeof(wire::FileDescription));
      }
      r.p += static_cast<size_t>(wire_bytes);
      binder_sg::Layout layout;
      if (!binder_sg::WireLayout(data, data_size, offsets, offsets_size,
                                static_cast<size_t>(extra_size), &layout) ||
          !wire::ValidFileDescriptions(data, data_size, offsets, offsets_size, descriptions))
        return abandon(nullptr, false, EBADF);
      uint8_t* block = file->Allocate(extra_offset + static_cast<size_t>(extra_size), id, !layout.pointers.empty());
      if (block == nullptr) return abandon(nullptr, false, ENOMEM);
      if (data_size != 0) memcpy(block, data, data_size);
      if (offsets_size != 0) memcpy(block + aligned, offsets, offsets_size);
      if (extra_size != 0) memcpy(block + extra_offset, extra, static_cast<size_t>(extra_size));
      binder_sg::Rebase(block, block + extra_offset, layout);
      if (!BufferResult(pipe, wire::kClaimBuffer, id)) return abandon(block, false, EBADF);
      if (!ReceiveFds(block, data_size, block + aligned, tr.offsets_size, descriptions))
        return abandon(block, true, EMFILE);
      tr.data.ptr.buffer = reinterpret_cast<binder_uintptr_t>(block);
      tr.data.ptr.offsets = reinterpret_cast<binder_uintptr_t>(block + aligned);
      memcpy(command.data() + 4, &tr, sizeof(tr));
      if (!publish(command.data(), command.size())) return abandon(block, true, EFAULT);
      rpos += command.size();
      bwr->read_consumed = rpos;  // A published command remains caller-owned.
      if (!BufferResult(pipe, wire::kFinishBuffer, id, true)) {
        CloseThreadPipe(file.get());
        return errno = EBADF, -1;
      }
      continue;
    } else if (!r.Read(command.data() + 4, size)) {
      CloseThreadPipe(file.get());
      return errno = EBADF, -1;
    }
    if (!publish(command.data(), command.size())) {
      // A preceding NOOP/reference command can fault before we parse the
      // transaction later in this same broker reply. Closing the connection
      // aborts that pending delivery and wakes its synchronous sender too.
      CloseThreadPipe(file.get());
      return errno = EFAULT, -1;
    }
    rpos += 4 + size;
    bwr->read_consumed = rpos;
  }
  bwr->read_consumed = rpos;
  return 0;
}

// An ioctl the broker answers: `in` bytes of the argument go, `out` come back.
int Forward(const std::shared_ptr<BinderFile>& file, uint32_t request, void* arg, size_t in,
            size_t out) {
  HANDLE pipe = ThreadPipe(file);
  if (pipe == INVALID_HANDLE_VALUE) return -1;
  Message m;
  m.Put<uint32_t>(wire::kIoctl);
  m.Put<uint32_t>(request);
  if (in > 0) m.Write(arg, in);
  std::vector<uint8_t> reply;
  if (!Send(pipe, m) || !Receive(pipe, &reply) || reply.size() < 4) return errno = EBADF, -1;
  int32_t status;
  memcpy(&status, reply.data(), 4);
  if (status < 0) return errno = -status, -1;
  if (out > 0 && reply.size() >= 4 + out) memcpy(arg, reply.data() + 4, out);
  return 0;
}

}  // namespace

bool binder_endpoint::EnrollChild(HANDLE process) {
  const ULONGLONG deadline = GetTickCount64() + 5000;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return false;
  HANDLE pipe = ConnectPipe(name);
  if (pipe == INVALID_HANDLE_VALUE) return false;
  struct OwnedPipe {
    HANDLE handle;
    ~OwnedPipe() { CloseHandle(handle); }
  } close_on_return{pipe};
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (!SetNamedPipeHandleState(pipe, &mode, nullptr, nullptr)) return false;
  struct Request {
    uint32_t length, op, magic, version;
    uint64_t child;
  } request{20, wire::kEnrollChild, wire::kMagic, wire::kVersion,
            binder_bootstrap::EncodeHandle(process)};
  static_assert(sizeof(Request) == 24);
  uint32_t reply[2] = {};
  return binder_bootstrap::Transfer(pipe, &request, sizeof(request), true, deadline) &&
         binder_bootstrap::Transfer(pipe, reply, sizeof(reply), false, deadline) &&
         reply[0] == sizeof(reply[1]) && reply[1] == 0;
}

namespace {
struct RecordPipe {
  HANDLE handle = INVALID_HANDLE_VALUE;
  ~RecordPipe() { if (handle != INVALID_HANDLE_VALUE) CloseHandle(handle); }
};

bool AudioPlaybackRequest(wire::Op op, uint32_t stream, uint32_t in_past_ms, uint64_t* result) {
  if (!binder_endpoint::Current().UsesProtectedAudio()) return false;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return false;
  RecordPipe pipe{ConnectPipe(name)};
  if (pipe.handle == INVALID_HANDLE_VALUE) return false;
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (!SetNamedPipeHandleState(pipe.handle, &mode, nullptr, nullptr)) return false;
  uint32_t request[] = {5 * sizeof(uint32_t), op, wire::kMagic, wire::kVersion, stream, in_past_ms};
  uint32_t reply[4]{};
  const ULONGLONG deadline = GetTickCount64() + 5000;
  if (!binder_bootstrap::Transfer(pipe.handle, request, sizeof(request), true, deadline) ||
      !binder_bootstrap::Transfer(pipe.handle, reply, sizeof(reply), false, deadline) ||
      reply[0] != 3 * sizeof(uint32_t) || reply[1] != 0) return false;
  *result = static_cast<uint64_t>(reply[2]) | static_cast<uint64_t>(reply[3]) << 32;
  return true;
}

int ReceiveRecordStatus(HANDLE pipe, std::vector<uint8_t>* reply) {
  if (!Receive(pipe, reply) || reply->size() < sizeof(int32_t)) return EIO;
  int32_t status;
  std::memcpy(&status, reply->data(), sizeof(status));
  if (status > 0 || status < -4095 || (status != 0 && reply->size() != sizeof(status))) return EPROTO;
  return -status;
}
}  // namespace

audio_state::Activity* binder_endpoint::OpenAudioPlaybackActivity() {
  uint64_t handle = 0;
  if (!AudioPlaybackRequest(wire::kAudioPlaybackPublish, 0, 0, &handle) ||
      !handle || handle > UINTPTR_MAX) return nullptr;
  auto section = binder_bootstrap::DecodeHandle(handle);
  auto* state = static_cast<audio_state::Activity*>(
      MapViewOfFile(section, FILE_MAP_WRITE, 0, 0, sizeof(audio_state::Activity)));
  CloseHandle(section);
  return state;
}

bool binder_endpoint::IsAudioPlaybackActive(int stream, int in_past_ms) {
  uint64_t active = 0;
  return AudioPlaybackRequest(wire::kAudioPlaybackQuery, stream, std::max(0, in_past_ms), &active) &&
      active == 1;
}

int binder_endpoint::NewProtectedAudioSession() {
  uint64_t session = 0;
  return AudioPlaybackRequest(wire::kAudioPlaybackSession, 0, 0, &session) && session <= INT_MAX
      ? static_cast<int>(session) : 0;
}

audio_state::DeviceState* binder_endpoint::OpenAudioDeviceControls(bool writable) {
  uint64_t handle = 0;
  if (!AudioPlaybackRequest(wire::kAudioDeviceControls, writable ? 1 : 0, 0, &handle) ||
      !handle || handle > UINTPTR_MAX) return nullptr;
  auto section = binder_bootstrap::DecodeHandle(handle);
  auto* state = static_cast<audio_state::DeviceState*>(MapViewOfFile(
      section, writable ? FILE_MAP_WRITE : FILE_MAP_READ, 0, 0, sizeof(audio_state::DeviceState)));
  CloseHandle(section);
  return state;
}

HANDLE binder_endpoint::OpenAudioRender(const std::u16string& label) {
  if (!binder_endpoint::Current().IsGuest()) return INVALID_HANDLE_VALUE;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return INVALID_HANDLE_VALUE;
  RecordPipe pipe{ConnectPipe(name)};
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (pipe.handle == INVALID_HANDLE_VALUE ||
      !SetNamedPipeHandleState(pipe.handle, &mode, nullptr, nullptr)) return INVALID_HANDLE_VALUE;
  const auto size = static_cast<uint32_t>(std::min<size_t>(label.size(), 120));
  Message request;
  request.Put<uint32_t>(wire::kAudioRender);
  request.Put<uint32_t>(wire::kMagic);
  request.Put<uint32_t>(wire::kVersion);
  request.Put<uint32_t>(size);
  request.Write(label.data(), size * sizeof(char16_t));
  if (!Send(pipe.handle, request)) return INVALID_HANDLE_VALUE;
  const HANDLE connected = pipe.handle;
  pipe.handle = INVALID_HANDLE_VALUE;
  return connected;
}

static HANDLE OpenRecordDevice(uint32_t op, bool info_only) {
  if (!binder_endpoint::Current().IsGuest()) return INVALID_HANDLE_VALUE;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return INVALID_HANDLE_VALUE;
  RecordPipe pipe{ConnectPipe(name)};
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (pipe.handle == INVALID_HANDLE_VALUE ||
      !SetNamedPipeHandleState(pipe.handle, &mode, nullptr, nullptr)) return INVALID_HANDLE_VALUE;
  uint32_t request[] = {4 * sizeof(uint32_t), op, wire::kMagic, wire::kVersion,
                        static_cast<uint32_t>(info_only)};
  if (!binder_bootstrap::Transfer(pipe.handle, request, sizeof(request), true,
                                  GetTickCount64() + 5000)) return INVALID_HANDLE_VALUE;
  const HANDLE connected = pipe.handle;
  pipe.handle = INVALID_HANDLE_VALUE;
  return connected;
}

HANDLE binder_endpoint::OpenAudioCapture(bool info_only) {
  return OpenRecordDevice(wire::kAudioCapture, info_only);
}

HANDLE binder_endpoint::OpenCamera(bool info_only) {
  return OpenRecordDevice(wire::kCamera, info_only);
}

HANDLE binder_endpoint::OpenDropWorker() {
  if (!binder_endpoint::Current().IsGuest()) return INVALID_HANDLE_VALUE;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return INVALID_HANDLE_VALUE;
  RecordPipe pipe{ConnectPipe(name)};
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (pipe.handle == INVALID_HANDLE_VALUE ||
      !SetNamedPipeHandleState(pipe.handle, &mode, nullptr, nullptr)) return INVALID_HANDLE_VALUE;
  uint32_t request[] = {3 * sizeof(uint32_t), wire::kDropWorker, wire::kMagic, wire::kVersion};
  if (!binder_bootstrap::Transfer(pipe.handle, request, sizeof(request), true, GetTickCount64() + 2500)) {
    return INVALID_HANDLE_VALUE;
  }
  const HANDLE connected = pipe.handle;
  pipe.handle = INVALID_HANDLE_VALUE;
  return connected;
}

int binder_endpoint::QueryAndroidDataCapacity(rooted_storage_wire::Filesystem* capacity) {
  if (capacity == nullptr) return EFAULT;
  auto& binding = binder_endpoint::Current();
  if (!binding.IsGuest() || binding.IsStandalone()) return EACCES;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return EACCES;
  RecordPipe pipe{ConnectPipe(name)};
  if (pipe.handle == INVALID_HANDLE_VALUE) return ErrnoFromWin32(GetLastError());
  DWORD mode = PIPE_READMODE_BYTE | PIPE_NOWAIT;
  if (!SetNamedPipeHandleState(pipe.handle, &mode, nullptr, nullptr)) return EIO;
  uint32_t request[] = {3 * sizeof(uint32_t), wire::kAndroidDataCapacity, wire::kMagic, wire::kVersion};
  struct {
    uint32_t length;
    int32_t status;
  } header{};
  const ULONGLONG deadline = GetTickCount64() + 5000;
  if (!binder_bootstrap::Transfer(pipe.handle, request, sizeof(request), true, deadline) ||
      !binder_bootstrap::Transfer(pipe.handle, &header, sizeof(header), false, deadline)) return EIO;
  if (header.status != 0) {
    return header.length == sizeof(header.status) && header.status < 0 && header.status >= -4095
        ? -header.status : EPROTO;
  }
  rooted_storage_wire::Filesystem result{};
  if (header.length != sizeof(header.status) + sizeof(result)) return EPROTO;
  if (!binder_bootstrap::Transfer(pipe.handle, &result, sizeof(result), false, deadline)) return EIO;
  if (!binding.VerifyPipe(pipe.handle)) return EACCES;
  *capacity = result;
  return 0;
}

int binder_endpoint::FileRecordLock(HANDLE file, int command, record_locks::LinuxFlock* flock) {
  if (!binder_endpoint::Current().IsGuest() || !flock) return EACCES;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return EACCES;
  RecordPipe pipe{ConnectPipe(name)};
  if (pipe.handle == INVALID_HANDLE_VALUE) return gesher::ErrnoFromWin32(GetLastError());
  Message request;
  request.Put<uint32_t>(wire::kFileRecordLock);
  request.Put<uint32_t>(wire::kMagic);
  request.Put<uint32_t>(wire::kVersion);
  request.Put<uint64_t>(binder_bootstrap::EncodeHandle(file));
  request.Put<int32_t>(command);
  request.Put<int16_t>(flock->type);
  request.Put<int16_t>(flock->whence);
  request.Put<int64_t>(flock->start);
  request.Put<int64_t>(flock->length);
  request.Put<int32_t>(flock->pid);
  std::vector<uint8_t> reply;
  if (!Send(pipe.handle, request)) return EIO;
  int error = ReceiveRecordStatus(pipe.handle, &reply);
  if (error) return error;
  if (command != 5 && command != 36) return reply.size() == sizeof(int32_t) ? 0 : EPROTO;
  Reader in{reply.data() + sizeof(int32_t), reply.data() + reply.size()};
  return in.Get(&flock->type) && in.Get(&flock->whence) && in.Get(&flock->start) &&
      in.Get(&flock->length) && in.Get(&flock->pid) && in.p == in.end ? 0 : EPROTO;
}

int binder_endpoint::FileRecordClosed(HANDLE* pin) {
  if (!binder_endpoint::Current().IsGuest() || !pin || !*pin) return EACCES;
  const std::wstring name = RecordPipeName();
  if (name.empty()) return EACCES;
  RecordPipe pipe{ConnectPipe(name)};
  if (pipe.handle == INVALID_HANDLE_VALUE) return gesher::ErrnoFromWin32(GetLastError());
  Message request;
  request.Put<uint32_t>(wire::kFileRecordClose);
  request.Put<uint32_t>(wire::kMagic);
  request.Put<uint32_t>(wire::kVersion);
  request.Put<uint64_t>(binder_bootstrap::EncodeHandle(*pin));
  std::vector<uint8_t> reply;
  if (!Send(pipe.handle, request)) return EIO;
  int error = ReceiveRecordStatus(pipe.handle, &reply);
  if (error) return error;
  if (reply.size() != sizeof(int32_t)) return EPROTO;
  if (!CloseHandle(*pin)) return gesher::ErrnoFromWin32(GetLastError());
  *pin = nullptr;
  Message acknowledge;
  acknowledge.Put<uint32_t>(1);
  if (!Send(pipe.handle, acknowledge)) return EIO;
  error = ReceiveRecordStatus(pipe.handle, &reply);
  return !error && reply.size() != sizeof(int32_t) ? EPROTO : error;
}

bool BinderDeviceExists() {
  std::wstring name = PipeName();
  if (name.empty()) return false;
  // WaitNamedPipe fails at once with ERROR_FILE_NOT_FOUND when no server
  // has the pipe; any other answer means one does.
  if (WaitNamedPipeW(name.c_str(), 1)) return true;
  return GetLastError() != ERROR_FILE_NOT_FOUND;
}

int OpenBinder(int flags) {
  std::wstring name = PipeName();
  if (name.empty()) return errno = ENOENT, -1;
  HANDLE pipe = ConnectPipe(name);
  if (pipe == INVALID_HANDLE_VALUE) return errno = ENOENT, -1;
  auto file = std::make_shared<BinderFile>();
  file->pipe_name = name;
  file->proc_pipe = pipe;
  file->non_block = (flags & O_NONBLOCK) != 0;
  Message hello;
  hello.Put<uint32_t>(binder_endpoint::Current().IsOperator() ? wire::kHelloOperator : wire::kHelloProc);
  hello.Put<uint32_t>(wire::kMagic);
  hello.Put<uint32_t>(wire::kVersion);
  hello.Put<uint32_t>(GetCurrentProcessId());
  hello.Put<uint32_t>(BinderUid());
  std::vector<uint8_t> reply;
  if (!Send(pipe, hello) || !Receive(pipe, &reply)) return errno = EIO, -1;
  Reader r{reply.data(), reply.data() + reply.size()};
  int32_t status;
  if (!r.Get(&status) || status != 0 || !r.Get(&file->proc_id) || !r.Get(&file->key)) {
    return errno = EIO, -1;
  }
  int fd = ReserveFd();
  if (fd < 0) return -1;
  std::lock_guard<std::mutex> lock(files_mutex);
  files[fd] = std::move(file);
  return fd;
}

bool IsBinderFd(int fd) { return Lookup(fd) != nullptr; }

void SetBinderMapping(int fd, void* addr, size_t size) {
  std::shared_ptr<BinderFile> file = Lookup(fd);
  if (file == nullptr) return;
  std::lock_guard<std::mutex> lock(file->mutex);
  if (file->map != nullptr) return;  // the first mapping is the receive buffer
  file->map = static_cast<uint8_t*>(addr);
  file->map_size = size;
  file->free_blocks.clear();
  file->free_blocks[0] = size;
}

bool BinderIoctl(int fd, unsigned long request, void* arg, int* result) {
  std::shared_ptr<BinderFile> file = Lookup(fd);
  if (file == nullptr) return false;
  uint32_t req = static_cast<uint32_t>(request);
  switch (req) {
    case BINDER_WRITE_READ:
      *result = WriteRead(file, static_cast<binder_write_read*>(arg));
      break;
    case BINDER_VERSION:
      static_cast<binder_version*>(arg)->protocol_version = BINDER_CURRENT_PROTOCOL_VERSION;
      *result = 0;
      break;
    case BINDER_SET_MAX_THREADS:
      *result = Forward(file, req, arg, sizeof(uint32_t), 0);
      break;
    case BINDER_SET_CONTEXT_MGR:
      *result = Forward(file, req, arg, 0, 0);
      break;
    case BINDER_SET_CONTEXT_MGR_EXT:
      *result = Forward(file, req, arg, sizeof(flat_binder_object), 0);
      break;
    case BINDER_GET_NODE_INFO_FOR_REF:
      *result = Forward(file, req, arg, sizeof(binder_node_info_for_ref),
                        sizeof(binder_node_info_for_ref));
      break;
    case BINDER_THREAD_EXIT:
      *result = Forward(file, req, arg, 0, 0);
      CloseThreadPipe(file.get());
      break;
    case BINDER_ENABLE_ONEWAY_SPAM_DETECTION:
    case BINDER_SET_IDLE_TIMEOUT:
    case BINDER_SET_IDLE_PRIORITY:
      *result = 0;
      break;
    case BINDER_GET_EXTENDED_ERROR: {
      binder_extended_error* ee = static_cast<binder_extended_error*>(arg);
      ee->id = 0;
      ee->command = BR_OK;
      ee->param = 0;
      *result = 0;
      break;
    }
    default:
      errno = EINVAL;
      *result = -1;
      break;
  }
  return true;
}

bool ForgetBinder(int fd) {
  std::shared_ptr<BinderFile> file;
  {
    std::lock_guard<std::mutex> lock(files_mutex);
    if (files.empty()) return false;
    auto it = files.find(fd);
    if (it == files.end()) return false;
    file = std::move(it->second);
    files.erase(it);
  }
  return true;  // the last reference closes the process's connection
}

void DupBinder(int fd, int fd2) {
  std::shared_ptr<BinderFile> file = Lookup(fd);
  if (file == nullptr) return;
  std::lock_guard<std::mutex> lock(files_mutex);
  files[fd2] = std::move(file);
}

}  // namespace gesher
