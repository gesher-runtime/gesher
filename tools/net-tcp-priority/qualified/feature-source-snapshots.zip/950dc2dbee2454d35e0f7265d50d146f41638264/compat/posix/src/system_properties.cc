// Copyright (C) 2026 The Gesher Authors
// SPDX-License-Identifier: Apache-2.0
// The property area used by Java/libbase, ELF bionic and getprop/setprop.
// Device boot names isolate volatile properties; persist.* survive a new boot.

#include <gesher/system_properties.h>
#include <gesher/environment.h>
#include <gesher/cohost_bootstrap.h>

#include <windows.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cwchar>
#include <memory>
#include <mutex>
#include <string_view>
#include <utility>
#include <vector>

#include "rooted_storage_client.h"

namespace gesher::properties {
namespace {

constexpr DWORD kCapacity = 4 * 1024 * 1024;
constexpr uint32_t kMagic = 0x47535052; // GSPR
constexpr uint32_t kVersion = 3;
uint32_t Serial(const std::string& name, const std::string& text, uint32_t previous = 0,
                bool update = false) {
  if (name.rfind("ro.", 0) == 0 && text.size() >= 92) {
    return (static_cast<uint32_t>(sizeof(kLongLegacyError) - 1) << 24) | (1U << 16);
  }
  return (static_cast<uint32_t>(text.size()) << 24) |
         (update ? (previous + 2) & 0x00fffffeU : 0);
}
struct Header {
  uint32_t magic;
  uint32_t version;
  uint32_t generation;
  uint32_t used[2];
};
constexpr DWORD kMappingSize = sizeof(Header) + 2 * kCapacity;

char* Payload(void* view, uint32_t slot) {
  return static_cast<char*>(view) + sizeof(Header) + slot * kCapacity;
}

struct Handle {
  HANDLE value = nullptr;
  ~Handle() { if (value && value != INVALID_HANDLE_VALUE) CloseHandle(value); }
};
struct MutexLock {
  HANDLE mutex;
  bool held = false;
  explicit MutexLock(HANDLE handle) : mutex(handle) {
    if (mutex) {
      DWORD result = WaitForSingleObject(mutex, INFINITE);
      held = result == WAIT_OBJECT_0 || result == WAIT_ABANDONED;
    }
  }
  ~MutexLock() { if (held) ReleaseMutex(mutex); }
};
struct Area {
  Handle mutex, file, mapping;
  void* view = nullptr;
  uint32_t cached_generation = 0;
  Snapshot values;
  Snapshot overrides;
  std::wstring root, path, persistent;
  bool writable = false;
  ~Area() { if (view) UnmapViewOfFile(view); }
};
bool Valid(const std::string& name, const std::string& value);

bool WritableProcess() {
  // Use the primary Windows token even when a thread is impersonating a client.
  static const bool writable = [] {
    Handle token;
    DWORD contained = 0, size = 0;
    return OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token.value) &&
           GetTokenInformation(token.value, TokenIsAppContainer, &contained,
                               sizeof(contained), &size) && !contained;
  }();
  return writable;
}

// Deliberately leaked: property callbacks can run during static destruction.
std::mutex& LocalMutex() { static auto* mutex = new std::mutex; return *mutex; }
std::map<std::wstring, std::unique_ptr<Area>>& Areas() {
  static auto* areas = new std::map<std::wstring, std::unique_ptr<Area>>;
  return *areas;
}

std::wstring Environment(const wchar_t* name) {
  DWORD size = GetEnvironmentVariableW(name, nullptr, 0);
  if (!size) return {};
  std::wstring result(size, 0);
  DWORD count = GetEnvironmentVariableW(name, result.data(), size);
  if (!count || count >= size) return {};
  result.resize(count);
  return result;
}
// The ordinary device/session and inherited root fit in this stack buffer.
// Longer supported values retain the general environment reader. Read the
// actual environment every time: callers may change device boots in-process.
bool EnvironmentEquals(const wchar_t* name, std::wstring_view expected) {
  wchar_t buffer[1024];
  DWORD count = GetEnvironmentVariableW(name, buffer, 1024);
  if (count >= 1024) return Environment(name) == expected;
  return count == expected.size() && (!count || std::wmemcmp(buffer, expected.data(), count) == 0);
}
std::wstring FullPath(std::wstring path) {
  std::replace(path.begin(), path.end(), L'/', L'\\');
  DWORD size = GetFullPathNameW(path.c_str(), 0, nullptr, nullptr);
  if (!size) return {};
  std::wstring result(size, 0);
  DWORD count = GetFullPathNameW(path.c_str(), size, result.data(), nullptr);
  if (!count || count >= size) return {};
  result.resize(count);
  return result;
}
bool Directories(const std::wstring& path) {
  for (size_t i = 3; i <= path.size(); ++i) {
    if (i != path.size() && path[i] != L'\\') continue;
    std::wstring part = path.substr(0, i);
    if (!CreateDirectoryW(part.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) return false;
  }
  return true;
}
std::wstring Key(const std::wstring& path) {
  uint64_t hash = 14695981039346656037ULL;
  for (wchar_t ch : path) {
    if (ch >= L'A' && ch <= L'Z') ch += L'a' - L'A';
    hash = (hash ^ static_cast<uint16_t>(ch)) * 1099511628211ULL;
  }
  wchar_t text[24];
  std::swprintf(text, sizeof(text) / sizeof(text[0]), L"%016llx", static_cast<unsigned long long>(hash));
  return text;
}
std::wstring Session() {
  std::wstring session = Environment(L"GESHER_BINDER");
  if (!session.empty()) return L"device-" + session;
  session = Environment(L"GESHER_PROPERTY_SESSION");
  if (session.empty()) {
    FILETIME time;
    GetSystemTimePreciseAsFileTime(&time);
    uint64_t ticks = (static_cast<uint64_t>(time.dwHighDateTime) << 32) | time.dwLowDateTime;
    session = std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(ticks);
    if (SetWideEnvironment(L"GESHER_PROPERTY_SESSION", session.c_str()) != 0) return {};
  }
  return L"single-" + session;
}
bool InheritRoot(const std::wstring& session, const std::wstring& root) {
  if (Environment(L"GESHER_PROPERTY_ROOT_SESSION") == session &&
      Environment(L"GESHER_PROPERTY_ROOT") == root) return true;
  return SetWideEnvironment(L"GESHER_PROPERTY_ROOT", root.c_str()) == 0 &&
         SetWideEnvironment(L"GESHER_PROPERTY_ROOT_SESSION", session.c_str()) == 0;
}

void Put32(std::string* data, uint32_t value) {
  data->append(reinterpret_cast<const char*>(&value), sizeof(value));
}
bool Take32(const std::string& data, size_t* at, uint32_t* value) {
  if (data.size() - *at < sizeof(*value)) return false;
  std::memcpy(value, data.data() + *at, sizeof(*value));
  *at += sizeof(*value);
  return true;
}
std::string Encode(const Snapshot& values) {
  std::string data;
  Put32(&data, static_cast<uint32_t>(values.size()));
  for (const auto& [name, value] : values) {
    Put32(&data, static_cast<uint32_t>(name.size()));
    Put32(&data, static_cast<uint32_t>(value.text.size()));
    Put32(&data, value.serial);
    data += name;
    data += value.text;
  }
  return data;
}
bool Decode(const std::string& data, Snapshot* values) {
  size_t at = 0;
  uint32_t count;
  if (!Take32(data, &at, &count) || count > kCapacity / 12) return false;
  Snapshot parsed;
  for (uint32_t i = 0; i < count; ++i) {
    uint32_t name_size, value_size, serial;
    if (!Take32(data, &at, &name_size) || !Take32(data, &at, &value_size) ||
        !Take32(data, &at, &serial) || name_size > data.size() - at) return false;
    std::string name = data.substr(at, name_size);
    at += name_size;
    if (value_size > data.size() - at) return false;
    parsed.emplace(std::move(name), Value{data.substr(at, value_size), serial});
    at += value_size;
  }
  if (at != data.size()) return false;
  *values = std::move(parsed);
  return true;
}
bool ReadContents(HANDLE file, std::string* data) {
  LARGE_INTEGER size;
  if (!GetFileSizeEx(file, &size) || size.QuadPart > kCapacity || size.QuadPart < 0) return false;
  data->resize(static_cast<size_t>(size.QuadPart));
  DWORD count = 0;
  return ReadFile(file, data->data(), static_cast<DWORD>(data->size()), &count, nullptr) &&
         count == data->size();
}
bool Read(const std::wstring& path, std::string* data, bool optional) {
  Handle file;
  file.value = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                          nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (file.value == INVALID_HANDLE_VALUE) return optional && GetLastError() == ERROR_FILE_NOT_FOUND;
  return ReadContents(file.value, data);
}
bool WritePersistent(const std::wstring& path, const Snapshot& values) {
  std::string data = Encode(values);
  if (data.size() > kCapacity) return false;
  std::wstring temp = path + L"." + std::to_wstring(GetCurrentProcessId()) + L".tmp";
  Handle file;
  file.value = CreateFileW(temp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (file.value == INVALID_HANDLE_VALUE) return false;
  DWORD count = 0;
  bool ok = WriteFile(file.value, data.data(), static_cast<DWORD>(data.size()), &count, nullptr) &&
            count == data.size() && FlushFileBuffers(file.value);
  CloseHandle(file.value);
  file.value = nullptr;
  if (ok) ok = MoveFileExW(temp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
  if (!ok) DeleteFileW(temp.c_str());
  return ok;
}
bool Persist(const std::wstring& path, const std::string* name, const Value* value, Snapshot* initial) {
  Handle mutex;
  mutex.value = CreateMutexW(nullptr, FALSE, (L"Local\\gesher-properties-persist-" + Key(path)).c_str());
  MutexLock lock(mutex.value);
  if (!lock.held) return false;
  std::string data;
  Snapshot values;
  if (!Read(path, &data, true) || (!data.empty() && !Decode(data, &values))) return false;
  if (initial) {
    for (const auto& [key, entry] : values) {
      if (key.rfind("persist.", 0) == 0 && Valid(key, entry.text)) (*initial)[key] = entry;
    }
  }
  if (!name) return true;
  values[*name] = *value;
  return WritePersistent(path, values);
}

std::string Trim(const std::string& text) {
  size_t start = text.find_first_not_of(" \t\r\n");
  if (start == std::string::npos) return {};
  return text.substr(start, text.find_last_not_of(" \t\r\n") - start + 1);
}
Snapshot Initial() {
  Snapshot values;
  for (const auto& pair : {
         std::pair{"ro.build.version.sdk", "36"}, {"ro.build.version.release", "16"},
         {"ro.build.version.codename", "REL"}, {"ro.product.cpu.abi", "x86_64"},
         {"ro.product.cpu.abilist", "x86_64,arm64-v8a"}, {"ro.product.cpu.abilist64", "x86_64,arm64-v8a"},
         {"ro.product.manufacturer", "gesher"}, {"ro.product.model", "Gesher"},
         {"ro.product.brand", "gesher"}, {"ro.hardware", "gesher"}, {"ro.debuggable", "0"},
         // The DisplayEventReceiver stand-in has no vsync source.
         {"debug.choreographer.vsync", "false"}}) {
    values[pair.first] = {pair.second, 1};
  }
  std::wstring root = Environment(L"ANDROID_ROOT");
  if (root.empty()) return values;
  std::string data;
  if (!Read(FullPath(root + L"/build.prop"), &data, true)) return values;
  size_t at = 0;
  while (at < data.size()) {
    size_t end = data.find('\n', at);
    std::string line = Trim(data.substr(at, end == std::string::npos ? std::string::npos : end - at));
    at = end == std::string::npos ? data.size() : end + 1;
    if (line.empty() || line[0] == '#') continue;
    size_t equal = line.find('=');
    if (equal == std::string::npos || equal == 0) continue;
    std::string key = Trim(line.substr(0, equal));
    bool optional = !key.empty() && key.back() == '?';
    if (optional) key = Trim(key.substr(0, key.size() - 1));
    std::string value = Trim(line.substr(equal + 1));
    if (Valid(key, value) && (!optional || !values.count(key))) values[key] = {std::move(value), 1};
  }
  return values;
}

bool LoadBootstrapOverrides(Area* area) {
  if (area->writable) return true;
  const auto& scope = cohost_bootstrap::Current();
  if (!scope || scope.build_prop.empty()) return true;
  Handle file;
  if (storage_root::OpenBootstrap(rooted_storage_wire::Op::kOpenBuildProp, &file.value) != 0) return false;
  std::string data;
  if (!ReadContents(file.value, &data)) return false;
  for (size_t start = 0; start < data.size();) {
    const size_t end = data.find('\n', start);
    const std::string line = Trim(data.substr(start, end == std::string::npos ? end : end - start));
    start = end == std::string::npos ? data.size() : end + 1;
    if (line.empty() || line.front() == '#') continue;
    const size_t equal = line.find('=');
    if (equal == 0 || equal == std::string::npos) continue;
    std::string name = Trim(line.substr(0, equal));
    if (!name.empty() && name.back() == '?') name = Trim(name.substr(0, name.size() - 1));
    std::string text = Trim(line.substr(equal + 1));
    if (!Valid(name, text)) continue;
    const auto existing = area->values.find(name);
    const bool present = existing != area->values.end();
    // Match the standalone Java loader. Existing ro.* properties stay
    // immutable, and an assignment of the existing value changes no serial.
    if (present && (name.starts_with("ro.") || existing->second.text == text)) continue;
    Value update{text, Serial(name, text, present ? existing->second.serial : 0, present)};
    area->values[name] = update;
    area->overrides[name] = std::move(update);
  }
  return true;
}

bool Refresh(Area* area) {
  const auto* header = static_cast<const Header*>(area->view);
  for (int attempt = 0; attempt < 8; ++attempt) {
    uint32_t generation = __atomic_load_n(&header->generation, __ATOMIC_ACQUIRE);
    if (!generation || header->magic != kMagic || header->version != kVersion) return false;
    if (generation == area->cached_generation) return true;
    uint32_t slot = generation & 1;
    uint32_t used = __atomic_load_n(&header->used[slot], __ATOMIC_RELAXED);
    std::string data;
    if (used <= kCapacity) data.assign(Payload(area->view, slot), used);
    // The writer publishes the other slot first. If it has published again
    // while we copied, this slot might have been reused and must be discarded.
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    if (generation != __atomic_load_n(&header->generation, __ATOMIC_ACQUIRE)) continue;
    if (used > kCapacity || !Decode(data, &area->values)) return false;
    for (const auto& [name, value] : area->overrides) area->values[name] = value;
    area->cached_generation = generation;
    return true;
  }
  // During sustained writes, keep the last coherent snapshot. Wait callers
  // will poll again until the property changes or their timeout expires.
  return area->cached_generation != 0;
}
bool Publish(Area* area, Snapshot values) {
  if (!area->writable) return false;
  std::string data = Encode(values);
  if (data.size() > kCapacity) return false;
  auto* header = static_cast<Header*>(area->view);
  uint32_t previous = __atomic_load_n(&header->generation, __ATOMIC_RELAXED);
  uint32_t generation = previous + 1;
  if (!generation) generation = 1;
  // Zero means uninitialized. Skip directly to an even generation on wrap
  // so a writer always leaves the currently published slot intact.
  if (previous && (previous & 1) == (generation & 1)) ++generation;
  uint32_t slot = generation & 1;
  std::memcpy(Payload(area->view, slot), data.data(), data.size());
  __atomic_store_n(&header->used[slot], static_cast<uint32_t>(data.size()), __ATOMIC_RELAXED);
  // The unlocked fast path reads this field atomically. Publish it last,
  // without a whole-header store overlapping the independently read word.
  __atomic_store_n(&header->generation, generation, __ATOMIC_RELEASE);
  area->values = std::move(values);
  area->cached_generation = generation;
  return true;
}
void RemoveOldAreas(const std::wstring& directory, const std::wstring& current) {
  // Open areas deny FILE_SHARE_DELETE. Stale boot files can be removed, while
  // another live device's mapping stays usable. Only our exact generated
  // filename shape is eligible; persistent_properties is in another directory.
  WIN32_FIND_DATAW entry;
  HANDLE find = FindFirstFileW((directory + L"\\*.area").c_str(), &entry);
  if (find == INVALID_HANDLE_VALUE) return;
  do {
    std::wstring name = entry.cFileName;
    if (name.size() != 21 || name.substr(16) != L".area") continue;
    bool generated = true;
    for (size_t i = 0; i < 16; ++i) {
      if (!((name[i] >= L'0' && name[i] <= L'9') || (name[i] >= L'a' && name[i] <= L'f'))) generated = false;
    }
    std::wstring path = directory + L"\\" + name;
    if (generated && path != current) DeleteFileW(path.c_str());
  } while (FindNextFileW(find, &entry));
  FindClose(find);
}
Area* Current() { // LocalMutex is held by every caller.
  // Map keys and Areas have process lifetime. Avoid rebuilding session/root
  // strings on every property/log read, but preserve all environment changes
  // and the existing root inheritance repair on the slow path.
  static const std::wstring* last_session = nullptr;
  static Area* last_area = nullptr;
  if (last_session) {
    std::wstring_view session(*last_session);
    bool same = session.starts_with(L"device-")
        ? EnvironmentEquals(L"GESHER_BINDER", session.substr(7))
        : EnvironmentEquals(L"GESHER_BINDER", {}) &&
          EnvironmentEquals(L"GESHER_PROPERTY_SESSION", session.substr(7));
    if (same && EnvironmentEquals(L"GESHER_PROPERTY_ROOT_SESSION", session) &&
        EnvironmentEquals(L"GESHER_PROPERTY_ROOT", last_area->root)) return last_area;
  }
  std::wstring session = Session();
  if (session.empty()) return nullptr;
  auto& cached = Areas();
  auto existing = cached.find(session);
  if (existing != cached.end()) {
    Area* area = existing->second.get();
    if (!InheritRoot(session, area->root)) return nullptr;
    last_session = &existing->first;
    last_area = area;
    return area;
  }
  // A boot's mapping keeps its original data root, as Android's property area
  // does. ART tests temporarily replace ANDROID_DATA for scratch directories;
  // ordinary log/property reads must not create a new service in each scratch.
  // Children must inherit this same boot root even when ART has temporarily
  // changed ANDROID_DATA before spawning them. A different session starts a
  // new boot and deliberately ignores the previous root's inherited binding.
  std::wstring data = Environment(L"GESHER_PROPERTY_ROOT_SESSION") == session
                          ? Environment(L"GESHER_PROPERTY_ROOT") : std::wstring{};
  if (data.empty()) data = Environment(L"ANDROID_DATA");
  if (data.empty()) {
    data = Environment(L"LOCALAPPDATA");
    if (data.empty()) data = Environment(L"TEMP");
    if (data.empty()) return nullptr;
    data += L"\\Gesher\\data";
  }
  data = FullPath(data);
  if (data.empty()) return nullptr;
  std::wstring dir = data + L"\\system\\gesher-properties";
  std::wstring path = dir + L"\\" + Key(L"property-v3-" + session) + L".area";
  auto area = std::make_unique<Area>();
  area->root = data;
  area->path = path;
  area->writable = WritableProcess();
  if (area->writable) {
    if (!Directories(dir) || !Directories(data + L"\\property")) return nullptr;
    area->persistent = data + L"\\property\\persistent_properties";
    area->mutex.value = CreateMutexW(nullptr, FALSE, (L"Local\\gesher-properties-" + Key(path)).c_str());
    if (!area->mutex.value) return nullptr;
  }
  MutexLock lock(area->mutex.value);
  if (area->writable && !lock.held) return nullptr;
  area->file.value = CreateFileW(path.c_str(), area->writable ? GENERIC_READ | GENERIC_WRITE : GENERIC_READ,
                                 FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                                 area->writable ? OPEN_ALWAYS : OPEN_EXISTING,
                                 FILE_ATTRIBUTE_NORMAL, nullptr);
  if (area->file.value == INVALID_HANDLE_VALUE) return nullptr;
  area->mapping.value = CreateFileMappingW(area->file.value, nullptr, area->writable ? PAGE_READWRITE : PAGE_READONLY,
                                           0, area->writable ? kMappingSize : 0, nullptr);
  if (!area->mapping.value) return nullptr;
  area->view = MapViewOfFile(area->mapping.value, area->writable ? FILE_MAP_WRITE : FILE_MAP_READ, 0, 0, kMappingSize);
  if (!area->view) return nullptr;
  auto* header = static_cast<Header*>(area->view);
  if (area->writable && !__atomic_load_n(&header->generation, __ATOMIC_RELAXED)) {
    Snapshot initial = Initial();
    if (!Persist(area->persistent, nullptr, nullptr, &initial)) return nullptr;
    for (auto& [name, value] : initial) value.serial = Serial(name, value.text);
    header->magic = kMagic;
    header->version = kVersion;
    if (!Publish(area.get(), std::move(initial))) return nullptr;
  }
  if (!Refresh(area.get()) || !LoadBootstrapOverrides(area.get()) || !InheritRoot(session, data)) return nullptr;
  Area* result = area.get();
  auto inserted = cached.emplace(session, std::move(area));
  last_session = &inserted.first->first;
  last_area = result;
  if (result->writable) RemoveOldAreas(dir, path);
  return result;
}
bool Utf8(const std::string& value) {
  for (size_t at = 0; at < value.size();) {
    unsigned char lead = static_cast<unsigned char>(value[at++]);
    if (lead < 0x80) continue;
    unsigned trailing;
    uint32_t code, minimum;
    if (lead >= 0xc2 && lead <= 0xdf) { trailing = 1; code = lead & 0x1f; minimum = 0x80; }
    else if (lead >= 0xe0 && lead <= 0xef) { trailing = 2; code = lead & 0x0f; minimum = 0x800; }
    else if (lead >= 0xf0 && lead <= 0xf4) { trailing = 3; code = lead & 7; minimum = 0x10000; }
    else return false;
    if (trailing > value.size() - at) return false;
    while (trailing--) {
      unsigned char next = static_cast<unsigned char>(value[at++]);
      if ((next & 0xc0) != 0x80) return false;
      code = (code << 6) | (next & 0x3f);
    }
    if (code < minimum || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return false;
  }
  return true;
}
bool Valid(const std::string& name, const std::string& value) {
  if (name.empty() || name.size() > 255 || name.front() == '.' || name.back() == '.' ||
      name.find("..") != std::string::npos || value.find('\0') != std::string::npos || !Utf8(value)) return false;
  for (unsigned char c : name) {
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
          c == '.' || c == '_' || c == '-' || c == '@' || c == ':')) return false;
  }
  return value.size() < (name.rfind("ro.", 0) == 0 ? 65536U : 92U);
}

} // namespace

bool Initialize() {
  std::lock_guard lock(LocalMutex());
  return Current() != nullptr;
}

std::wstring ReadOnlyAreaPath() {
  if (!WritableProcess()) return {};
  std::lock_guard lock(LocalMutex());
  Area* area = Current();
  return area ? area->path : std::wstring{};
}

namespace {
// The area, its values current (LocalMutex is held). Every log line reads a
// few properties (log.tag.*). Refresh returns the process's decoded copy
// when the published generation has not changed.
Area* Refreshed() {
  Area* area = Current();
  return area && Refresh(area) ? area : nullptr;
}
}  // namespace

Revision CurrentRevision() {
  std::lock_guard local(LocalMutex());
  Area* area = Current();
  if (!area) return {};
  const auto* header = static_cast<const Header*>(area->view);
  return {area, __atomic_load_n(&header->generation, __ATOMIC_ACQUIRE)};
}
void GetAll(const std::string* names, std::string* values, size_t count, Revision* revision) {
  std::lock_guard local(LocalMutex());
  Area* area = Refreshed();
  if (revision) *revision = area ? Revision{area, area->cached_generation} : Revision{};
  for (size_t i = 0; i < count; ++i) {
    auto found = area ? area->values.find(names[i]) : Snapshot::iterator{};
    values[i] = area && found != area->values.end() ? found->second.text : std::string();
  }
}
bool Get(const std::string& name, std::string* value, uint32_t* serial) {
  std::lock_guard local(LocalMutex());
  Area* area = Refreshed();
  if (!area) return false;
  auto found = area->values.find(name);
  if (found == area->values.end()) return false;
  if (value) *value = found->second.text;
  if (serial) *serial = found->second.serial;
  return true;
}
bool Set(const std::string& name, const std::string& value) {
  if (!WritableProcess() || !Valid(name, value)) return false;
  std::lock_guard local(LocalMutex());
  Area* area = Current();
  if (!area) return false;
  MutexLock lock(area->mutex.value);
  if (!lock.held || !Refresh(area)) return false;
  auto found = area->values.find(name);
  if (name.rfind("ro.", 0) == 0 && found != area->values.end()) return false;
  Value next{value, Serial(name, value, found == area->values.end() ? 0 : found->second.serial,
                           found != area->values.end())};
  Snapshot values = area->values;
  values[name] = next;
  if (Encode(values).size() > kCapacity) return false;
  if (name.rfind("persist.", 0) == 0 && !Persist(area->persistent, &name, &next, nullptr)) return false;
  return Publish(area, std::move(values));
}
Snapshot List() {
  std::lock_guard local(LocalMutex());
  Area* area = Refreshed();
  return area ? area->values : Snapshot{};
}
uint32_t AreaSerial() {
  std::lock_guard local(LocalMutex());
  Area* area = Refreshed();
  return area ? area->cached_generation : 0;
}
bool Wait(const std::string* name, uint32_t old_serial, uint32_t* new_serial,
          const WaitTimeout* timeout) {
  using Clock = std::chrono::steady_clock;
  if (timeout && (timeout->seconds < 0 || timeout->nanoseconds < 0 || timeout->nanoseconds >= 1000000000)) {
    return false;
  }
  auto deadline = Clock::time_point::max();
  if (timeout) {
    auto now = Clock::now();
    auto maximum = std::chrono::duration_cast<std::chrono::nanoseconds>(deadline - now).count();
    int64_t requested = maximum;
    if (timeout->seconds <= (maximum - timeout->nanoseconds) / 1000000000) {
      requested = timeout->seconds * 1000000000 + timeout->nanoseconds;
    }
    deadline = now + std::chrono::nanoseconds(requested);
  }
  Area* area;
  {
    std::lock_guard local(LocalMutex());
    area = Current();
  }
  if (!area) return false;
  for (;;) {
    {
      std::lock_guard local(LocalMutex());
      if (!Refresh(area)) return false;
      uint32_t current = area->cached_generation;
      if (name) {
        auto found = area->values.find(*name);
        if (found == area->values.end()) return false;
        current = found->second.serial;
      }
      if (current != old_serial) {
        if (new_serial) *new_serial = current;
        return true;
      }
    }
    auto now = Clock::now();
    if (now >= deadline) return false;
    auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - now).count();
    Sleep(static_cast<DWORD>(std::min<int64_t>(10, std::max<int64_t>(1, remaining))));
  }
}

} // namespace gesher::properties
