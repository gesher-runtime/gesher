// gesher-base: smaller POSIX/Linux interfaces — uname, statvfs, resource
// limits and priorities, scheduling, ioctl, wait, fcntl, uio, extra
// stat calls, memfd, strsignal, and link.h.

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <pthread.h>
#include <link.h>
#include <sched.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/uio.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>
#include <windows.h>
#include <psapi.h>
#include <gesher/file_description.h>
#include <gesher/filesystem_capacity.h>

#include <array>
#include <memory>
#include <new>
#include <string>
#include <limits>
#include <vector>

#include "binder_internal.h"
#include "event_internal.h"
#include "internal.h"
#include "pipe_io.h"
#include "revocable_internal.h"
#include "linux_socket.h"
#include "record_lock_descriptors.h"
#include "record_lock_duplicate.h"
#include "rooted_storage_client.h"
#include "socket_internal.h"

namespace {

HANDLE OpenThreadForPriority(id_t who, DWORD access) {
  if (who == 0 || who == GetCurrentThreadId()) return GetCurrentThread();
  return OpenThread(access, FALSE, who);
}

void CloseThreadHandle(HANDLE h) {
  if (h != GetCurrentThread()) CloseHandle(h);
}

// Linux nice values (-20 highest .. 19 lowest) onto Windows thread priorities.
int PriorityFromNice(int nice) {
  if (nice <= -16) return THREAD_PRIORITY_HIGHEST;
  if (nice <= -6) return THREAD_PRIORITY_ABOVE_NORMAL;
  if (nice <= 4) return THREAD_PRIORITY_NORMAL;
  if (nice <= 14) return THREAD_PRIORITY_BELOW_NORMAL;
  return THREAD_PRIORITY_LOWEST;
}

int NiceFromPriority(int priority) {
  if (priority >= THREAD_PRIORITY_HIGHEST) return -20;
  if (priority >= THREAD_PRIORITY_ABOVE_NORMAL) return -10;
  if (priority >= THREAD_PRIORITY_NORMAL) return 0;
  if (priority >= THREAD_PRIORITY_BELOW_NORMAL) return 10;
  return 19;
}

void FillStatvfs(uint64_t avail, uint64_t total, uint64_t free, struct statvfs* buf) {
  const unsigned long long block = 4096;
  memset(buf, 0, sizeof(*buf));
  buf->f_bsize = block;
  buf->f_frsize = block;
  buf->f_blocks = total / block;
  buf->f_bfree = free / block;
  buf->f_bavail = avail / block;
  buf->f_namemax = 255;
}

}  // namespace

extern "C" {

// --- uname -------------------------------------------------------------------

int uname(struct utsname* buf) {
  memset(buf, 0, sizeof(*buf));
  // Android's kernel is Linux, and Android code takes it as given: libcore turns
  // sysname into os.name (JNA, for one, selects its native platform from it), and
  // ART's IsKernelVersionAtLeast CHECKs that sysname is "Linux". The release names
  // no real kernel version, so "kernel >= X" checks still fail: callers take their
  // oldest-kernel path instead of assuming features Gesher may not provide.
  snprintf(buf->sysname, sizeof(buf->sysname), "Linux");
  snprintf(buf->release, sizeof(buf->release), "0.0.0-gesher");
  OSVERSIONINFOEXW v{};
  v.dwOSVersionInfoSize = sizeof(v);
  using RtlGetVersionFn = LONG(WINAPI*)(OSVERSIONINFOEXW*);
  auto rtl_get_version = reinterpret_cast<RtlGetVersionFn>(
      reinterpret_cast<void*>(GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion")));
  if (rtl_get_version != nullptr && rtl_get_version(&v) == 0) {
    snprintf(buf->version, sizeof(buf->version), "Windows %lu.%lu.%lu", v.dwMajorVersion,
             v.dwMinorVersion, v.dwBuildNumber);
  }
  snprintf(buf->machine, sizeof(buf->machine), "x86_64");
  DWORD size = sizeof(buf->nodename);
  GetComputerNameA(buf->nodename, &size);
  return 0;
}

// --- statvfs -----------------------------------------------------------------

namespace {

int RootedStatvfs(HANDLE file, struct statvfs* buf) {
  gesher::rooted_storage_wire::Filesystem capacity;
  const int error = gesher::QueryFilesystemCapacity(file, &capacity);
  if (error != 0) return errno = error, -1;
  FillStatvfs(capacity.available_bytes, capacity.total_bytes, capacity.free_bytes, buf);
  return 0;
}

// Keep the final Win32 namespace intact: in particular, \\?\UNC\ is not a
// drive prefix that can be removed. A handle also follows a file symlink or
// directory junction to the volume containing the actual file.
int StatvfsHandle(HANDLE h, struct statvfs* buf) {
  constexpr DWORD flags = FILE_NAME_NORMALIZED | VOLUME_NAME_DOS;
  DWORD needed = GetFinalPathNameByHandleW(h, nullptr, 0, flags);
  if (needed == 0) return gesher::FailWithLastError();
  std::wstring path;
  for (;;) {
    if (needed > 32768) return errno = ENAMETOOLONG, -1;
    path.resize(needed);
    DWORD length = GetFinalPathNameByHandleW(h, path.data(), needed, flags);
    if (length == 0) return gesher::FailWithLastError();
    if (length < needed) {
      path.resize(length);
      break;
    }
    // A rename between the size query and the read can lengthen the path.
    needed = length == needed ? needed + 1 : length;
  }
  // A root is no longer than the full path plus a trailing separator.
  std::wstring root(path.size() + 2, L'\0');
  if (!GetVolumePathNameW(path.c_str(), root.data(), static_cast<DWORD>(root.size())))
    return gesher::FailWithLastError();
  ULARGE_INTEGER avail, total, free;
  if (!GetDiskFreeSpaceExW(root.c_str(), &avail, &total, &free))
    return gesher::FailWithLastError();
  FillStatvfs(avail.QuadPart, total.QuadPart, free.QuadPart, buf);
  return 0;
}

bool FullFilesystemPath(const std::wstring& input, std::wstring* path) {
  DWORD needed = GetFullPathNameW(input.c_str(), 0, nullptr, nullptr);
  if (needed == 0) return gesher::FailWithLastError(), false;
  for (;;) {
    if (needed > 32768) return errno = ENAMETOOLONG, false;
    path->resize(needed);
    DWORD length = GetFullPathNameW(input.c_str(), needed, path->data(), nullptr);
    if (length == 0) return gesher::FailWithLastError(), false;
    if (length < needed) {
      path->resize(length);
      return true;
    }
    needed = length == needed ? needed + 1 : length;
  }
}

// The nearest-existing-ancestor fallback must stop at the drive/share root;
// turning D:\ into D: would select that drive's current directory instead.
bool ParentFilesystemPath(std::wstring* path) {
  size_t root;
  bool extended_unc = path->size() >= 8 && path->rfind(L"\\\\?\\", 0) == 0 &&
                      ((*path)[4] == L'U' || (*path)[4] == L'u') &&
                      ((*path)[5] == L'N' || (*path)[5] == L'n') &&
                      ((*path)[6] == L'C' || (*path)[6] == L'c') && (*path)[7] == L'\\';
  size_t network = extended_unc ? 8 :
                   path->rfind(L"\\\\", 0) == 0 &&
                   path->rfind(L"\\\\?\\", 0) != 0 &&
                   path->rfind(L"\\\\.\\", 0) != 0 ? 2 : 0;
  if (network != 0) {
    size_t server = path->find(L'\\', network);
    size_t share = server == std::wstring::npos ? server : path->find(L'\\', server + 1);
    root = share == std::wstring::npos ? path->size() : share + 1;
  } else {
    size_t prefix = path->rfind(L"\\\\?\\", 0) == 0 ||
                    path->rfind(L"\\\\.\\", 0) == 0 ? 4 : 0;
    size_t slash = path->find(L'\\', prefix);
    root = slash == std::wstring::npos ? path->size() : slash + 1;
  }
  size_t end = path->size();
  while (end > root && (*path)[end - 1] == L'\\') --end;
  if (end <= root) return false;
  if (end < path->size()) {
    path->resize(end);
  } else {
    size_t slash = path->rfind(L'\\', end - 1);
    path->resize(slash < root ? root : slash);
  }
  return true;
}

}  // namespace

// Android's own directories (`/data`: SQLiteGlobal's default page size is
// StatFs("/data")'s block size; `/system`) are not on the disk (ADR 0010): an
// absolute path that does not exist answers for the volume it would be on, its
// nearest existing ancestor's.
int statvfs(const char* path, struct statvfs* buf) {
  if (path == nullptr || buf == nullptr) return errno = EFAULT, -1;
  if (*path == '\0') return errno = ENOENT, -1;
  if (strcmp(path, "/data") == 0 && gesher::storage_root::HasBroker()) {
    gesher::rooted_storage_wire::Filesystem capacity;
    const int error = gesher::storage_root::StatAndroidData(&capacity);
    if (error != 0) return errno = error, -1;
    FillStatvfs(capacity.available_bytes, capacity.total_bytes, capacity.free_bytes, buf);
    return 0;
  }
  std::wstring mapped;
  gesher::PathKind kind = gesher::MapPath(path, &mapped);
  if (kind == gesher::PathKind::kMissing) return errno = ENOENT, -1;
  if (kind == gesher::PathKind::kFile) {
    if (const auto rooted = gesher::storage_root::Lookup(mapped)) {
      HANDLE h;
      const int error = gesher::storage_root::Open(rooted, gesher::rooted_storage_wire::kMetadata, &h);
      if (error != 0) return errno = error, -1;
      const int result = RootedStatvfs(h, buf);
      const int saved_errno = errno;
      CloseHandle(h);
      errno = saved_errno;
      return result;
    }
  }
  if (kind != gesher::PathKind::kFile) {
    // Retain the existing backing-volume approximation for virtual paths.
    // This repair does not supply procfs/device filesystem statistics.
    mapped = gesher::Widen(path);
  }
  for (wchar_t& c : mapped) if (c == L'/') c = L'\\';
  std::wstring windows;
  if (!FullFilesystemPath(mapped, &windows)) return -1;
  const bool allow_ancestor = path[0] == '/' || path[0] == '\\';
  bool ancestor = false;
  for (;;) {
    HANDLE h = CreateFileW(windows.c_str(), 0,
                           FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
                           OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, nullptr);
    if (h != INVALID_HANDLE_VALUE) {
      int result;
      BY_HANDLE_FILE_INFORMATION info;
      if (ancestor && !GetFileInformationByHandle(h, &info)) {
        result = gesher::FailWithLastError();
      } else if (ancestor && (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0) {
        errno = ENOTDIR;
        result = -1;
      } else {
        result = StatvfsHandle(h, buf);
      }
      int saved_errno = errno;
      CloseHandle(h);
      errno = saved_errno;
      return result;
    }
    DWORD error = GetLastError();
    bool missing = error == ERROR_PATH_NOT_FOUND || error == ERROR_FILE_NOT_FOUND;
    if (!missing || !allow_ancestor || !ParentFilesystemPath(&windows)) {
      SetLastError(error);
      return gesher::FailWithLastError();
    }
    ancestor = true;
  }
}

int fstatvfs(int fd, struct statvfs* buf) {
  if (buf == nullptr) return errno = EFAULT, -1;
  HANDLE h = gesher::HandleFromFd(fd);
  if (h == INVALID_HANDLE_VALUE) return errno = EBADF, -1;
  if (!gesher::storage_root::DescriptorPath(h).empty()) return RootedStatvfs(h, buf);
  return StatvfsHandle(h, buf);
}

// --- mount -------------------------------------------------------------------

int mount(const char*, const char*, const char*, unsigned long, const void*) {
  return errno = ENOSYS, -1;
}
int umount2(const char*, int) { return errno = ENOSYS, -1; }

// --- resources and priorities -------------------------------------------------

// getrlimit, setrlimit and getrusage are in process.cc.

int getpriority(int which, id_t who) {
  if (which != PRIO_PROCESS) return errno = EINVAL, -1;
  HANDLE h = OpenThreadForPriority(who, THREAD_QUERY_LIMITED_INFORMATION);
  if (h == nullptr) return errno = ESRCH, -1;
  int priority = GetThreadPriority(h);
  CloseThreadHandle(h);
  errno = 0;
  return NiceFromPriority(priority);
}

int setpriority(int which, id_t who, int prio) {
  if (which != PRIO_PROCESS) return errno = EINVAL, -1;
  HANDLE h = OpenThreadForPriority(who, THREAD_SET_LIMITED_INFORMATION);
  if (h == nullptr) return errno = ESRCH, -1;
  BOOL ok = SetThreadPriority(h, PriorityFromNice(prio));
  CloseThreadHandle(h);
  return ok ? 0 : gesher::FailWithLastError();
}

// --- scheduling ----------------------------------------------------------------

int gesher_cpu_count(const cpu_set_t* set) {
  int n = 0;
  for (unsigned long long word : set->__bits) n += __builtin_popcountll(word);
  return n;
}

int sched_getcpu(void) { return static_cast<int>(GetCurrentProcessorNumber()); }

int sched_setaffinity(pid_t, size_t, const cpu_set_t*) { return 0; }

int sched_getaffinity(pid_t, size_t size, cpu_set_t* set) {
  // The Linux kernel accepts whole-word masks only, and a short mask must
  // fail before it is modified. CPU_SET would write a full word even when
  // the caller supplied only one byte (or only room for an earlier word).
  constexpr size_t word = sizeof(set->__bits[0]);
  if (size == 0 || size % word != 0) return errno = EINVAL, -1;
  DWORD cpus = GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
  if (cpus == 0) return gesher::FailWithLastError();
  size_t required = ((static_cast<size_t>(cpus) + 63) / 64) * word;
  if (size < required) return errno = EINVAL, -1;
  if (set == nullptr) return errno = EFAULT, -1;
  memset(set, 0, size);
  auto* bytes = reinterpret_cast<unsigned char*>(set);
  for (DWORD i = 0; i < cpus; ++i) bytes[i / 8] |= static_cast<unsigned char>(1u << (i % 8));
  return 0;
}

int unshare(int) { return errno = ENOSYS, -1; }

int sched_getparam(pid_t, struct sched_param* param) {
  param->sched_priority = 0;
  return 0;
}

int sched_setparam(pid_t, const struct sched_param*) { return 0; }

// --- ioctl, wait --------------------------------------------------------------

// FIONREAD and FIONBIO, the ioctls Android's Java libraries use on files,
// pipes and sockets; the only device ioctls are /dev/binder's (binder.cc),
// others fail with ENOTTY.
int ioctl(int fd, unsigned long request, ...) {
  va_list args;
  va_start(args, request);
  int* argp = va_arg(args, int*);
  va_end(args);
  int binder_result;
  if (gesher::BinderIoctl(fd, request, argp, &binder_result)) return binder_result;
  gesher::SocketFd state;
  if (gesher::LookupSocket(fd, &state)) {
    if (!argp && (request == FIONREAD || request == FIONBIO)) return errno = EFAULT, -1;
    if (request == FIONREAD) {
      if (gesher::ws::Available(state.socket, argp) != 0) return -1;
      // An AF_UNIX datagram pair's payload, without its framing (ADR 0088).
      if (state.description->unix_datagram_pair.load()) *argp = gesher::ws::UnixDatagramPayload(*argp);
      return 0;
    }
    int result;
    if (gesher::sock::InterfaceIoctl(request, argp, &result)) return result;
    if (request == FIONBIO) {
      gesher::record_locks::DescriptorGuard descriptor_guard;
      gesher::SocketFd current;
      if (!gesher::LookupSocket(fd, &current) || current.description != state.description) return errno = EBADF, -1;
      std::lock_guard<std::mutex> lock(state.description->status_mutex);
      const bool on = *argp != 0;
      if (!state.description->native_nonblocking_datagram &&
          gesher::ws::SetNonBlocking(state.socket, on) < 0) return -1;
      state.description->nonblocking.store(on);
      return 0;
    }
    return errno = ENOTTY, -1;
  }
  auto snapshot = gesher::CaptureDescriptor(fd);
  if (!snapshot) return -1;
  HANDLE h = snapshot->handle;
  if (!argp && (request == FIONREAD || request == FIONBIO)) return errno = EFAULT, -1;
  if (request == FIONBIO && GetFileType(h) == FILE_TYPE_PIPE) {
    int flags = gesher::FileDescriptionFlags(snapshot);
    if (flags < 0) return -1;
    return gesher::SetFileDescriptionFlags(snapshot, *argp ? flags | O_NONBLOCK : flags & ~O_NONBLOCK);
  }
  if (request != FIONREAD) return errno = ENOTTY, -1;
  gesher::FileOperationLease operation(snapshot);
  if (operation.Error()) return errno = operation.Error(), -1;
  switch (GetFileType(h)) {
    case FILE_TYPE_PIPE: {
      return gesher::PipeBytesAvailable(snapshot, argp);
    }
    case FILE_TYPE_DISK: {
      // Bytes from the current position to the end, as Linux reports.
      LARGE_INTEGER size, pos, zero = {};
      if (!GetFileSizeEx(h, &size) || !SetFilePointerEx(h, zero, &pos, FILE_CURRENT)) {
        return gesher::FailWithLastError();
      }
      long long remaining = size.QuadPart > pos.QuadPart ? size.QuadPart - pos.QuadPart : 0;
      *argp = static_cast<int>(remaining > 0x7FFFFFFF ? 0x7FFFFFFF : remaining);
      return 0;
    }
    default:
      *argp = 0;
      return 0;
  }
}

pid_t waitpid(pid_t, int*, int) { return errno = ECHILD, -1; }
pid_t wait(int*) { return errno = ECHILD, -1; }
int waitid(idtype_t, id_t, siginfo_t*, int) { return errno = ECHILD, -1; }

// --- fcntl and friends --------------------------------------------------------

int fcntl(int fd, int cmd, ...) {
  static_assert(sizeof(struct flock) == sizeof(gesher::record_locks::LinuxFlock));
  static_assert(offsetof(struct flock, l_start) == 8 && offsetof(struct flock, l_pid) == 24);
  // Win64 integer operands are 32 bits; lock operands retain pointer width.
  // Consume lock pointers before the integer-command varargs path.
  if (cmd == F_GETLK || cmd == F_SETLK || cmd == F_OFD_GETLK || cmd == F_OFD_SETLK) {
    va_list pointers;
    va_start(pointers, cmd);
    struct flock* argument = va_arg(pointers, struct flock*);
    va_end(pointers);
    return gesher::record_locks::DescriptorFcntl(fd, cmd, argument);
  }
  int arg = 0;
  // Getter commands have no third argument; other supported commands take an int.
  if (cmd == F_SETFD || cmd == F_SETFL || cmd == F_DUPFD ||
      cmd == F_DUPFD_CLOEXEC || cmd == F_ADD_SEALS) {
    va_list args;
    va_start(args, cmd);
    arg = va_arg(args, int);
    va_end(args);
  }
  gesher::DescriptorSnapshotPtr status_snapshot;
  {
    gesher::record_locks::DescriptorGuard descriptor_guard;
    HANDLE h = gesher::HandleFromFd(fd);
    if (h == INVALID_HANDLE_VALUE) return errno = EBADF, -1;
    gesher::SocketFd state;
    if (gesher::LookupSocket(fd, &state)) {
      switch (cmd) {
        case F_GETFL:
          return O_RDWR | (state.description->nonblocking.load() ? O_NONBLOCK : 0);
        case F_SETFL:
          {
            gesher::record_locks::DescriptorGuard descriptor_guard;
            gesher::SocketFd current;
            if (!gesher::LookupSocket(fd, &current) || current.description != state.description) return errno = EBADF, -1;
            std::lock_guard<std::mutex> lock(state.description->status_mutex);
            const bool on = (arg & O_NONBLOCK) != 0;
            if (on != state.description->nonblocking.load()) {
              if (!state.description->native_nonblocking_datagram &&
                  gesher::ws::SetNonBlocking(state.socket, on) < 0) return -1;
              state.description->nonblocking.store(on);
            }
          }
          return 0;
        case F_GETFD:
          return FD_CLOEXEC;  // sockets are never inherited (winsock.cc)
        case F_SETFD:
          return 0;
        default:
          break;  // F_DUPFD and the rest below
      }
    }
    if (std::shared_ptr<gesher::EventFd> e = gesher::LookupEventFd(fd)) {
      if (cmd == F_GETFL) return O_RDWR | (gesher::IsNonBlocking(*e) ? O_NONBLOCK : 0);
      if (cmd == F_SETFL) {
        gesher::SetNonBlocking(*e, (arg & O_NONBLOCK) != 0);
        return 0;
      }
    }
    switch (cmd) {
      case F_GETFD: {
        DWORD flags = 0;
        if (!GetHandleInformation(h, &flags)) return gesher::FailWithLastError();
        return (flags & HANDLE_FLAG_INHERIT) != 0 ? 0 : FD_CLOEXEC;
      }
      case F_SETFD:
        if (!SetHandleInformation(h, HANDLE_FLAG_INHERIT,
                                  (arg & FD_CLOEXEC) != 0 ? 0 : HANDLE_FLAG_INHERIT)) {
          return gesher::FailWithLastError();
        }
        return 0;
      case F_GETFL:
      case F_SETFL:
        status_snapshot = gesher::CaptureDescriptor(fd);
        if (!status_snapshot) return -1;
        break;
      case F_DUPFD:
      case F_DUPFD_CLOEXEC: {
        const int duplicate = gesher::record_locks::DuplicateAtLeast(fd, static_cast<int>(arg), cmd == F_DUPFD_CLOEXEC);
        if (duplicate >= 0) gesher::CopyMemfdRegistration(fd, duplicate);
        return duplicate;
      }
      case F_ADD_SEALS:
        return gesher::AddMemfdSeals(fd, static_cast<unsigned>(arg));
      case F_GET_SEALS:
        return gesher::GetMemfdSeals(fd);
      default:
        return errno = EINVAL, -1;
    }
  }
  // The snapshot retains the selected object and description across concurrent
  // close/dup2. Native mode operations must not hold the publication lock.
  return cmd == F_GETFL ? gesher::FileDescriptionFlags(status_snapshot)
                       : gesher::SetFileDescriptionFlags(status_snapshot, arg);
}

// flock: a lock on one byte far beyond any file's data (LockFileEx locks
// are mandatory on Windows, so a range over the data would block reads and
// writes through other handles; this one blocks nothing but other locks).
// Windows keeps a lock per open file object, as Linux keeps flock's per open
// file description: dup()s share it, and it goes when the last handle closes.
// A lock is converted by dropping it first, as Linux may.
int flock(int fd, int operation) {
  HANDLE h = gesher::HandleFromFd(fd);
  if (h == INVALID_HANDLE_VALUE) return errno = EBADF, -1;
  int kind = operation & ~LOCK_NB;
  if (kind != LOCK_SH && kind != LOCK_EX && kind != LOCK_UN) return errno = EINVAL, -1;
  if (GetFileType(h) != FILE_TYPE_DISK) return 0;  // pipes, sockets, devices
  OVERLAPPED ov = {};
  ov.Offset = 0xfffffffe;
  ov.OffsetHigh = 0x7fffffff;
  // Drop what this open file holds (none: ERROR_NOT_LOCKED).
  UnlockFileEx(h, 0, 1, 0, &ov);
  if (kind == LOCK_UN) return 0;
  DWORD flags = (kind == LOCK_EX ? LOCKFILE_EXCLUSIVE_LOCK : 0) |
                ((operation & LOCK_NB) != 0 ? LOCKFILE_FAIL_IMMEDIATELY : 0);
  memset(&ov, 0, sizeof(ov));
  ov.Offset = 0xfffffffe;
  ov.OffsetHigh = 0x7fffffff;
  if (!LockFileEx(h, flags, 0, 1, 0, &ov)) {
    DWORD error = GetLastError();
    if (error == ERROR_IO_PENDING) {  // an overlapped handle: wait for the lock
      DWORD n;
      if (GetOverlappedResult(h, &ov, &n, TRUE)) return 0;
      error = GetLastError();
    }
    if (error == ERROR_LOCK_VIOLATION) return errno = EWOULDBLOCK, -1;
    SetLastError(error);
    return gesher::FailWithLastError();
  }
  return 0;
}

int posix_fadvise(int fd, off_t, off_t len, int advice) {
  if (fd < 0) return EBADF;
  const int saved_errno = errno;
  const int result = [&]() -> int {
    // Keep the CRT descriptor stable while inspecting its Win32 object.
    gesher::record_locks::DescriptorGuard descriptor_guard;
    HANDLE handle = gesher::HandleFromFd(fd);
    // UCRT uses -2 for unbound standard streams. Do not inspect it as a
    // Win32 handle, where the same value denotes the current thread.
    if (handle == INVALID_HANDLE_VALUE || handle == reinterpret_cast<HANDLE>(intptr_t{-2})) return EBADF;
    uint32_t access = 0;
    const int access_error = gesher::record_locks::HandleAccess(handle, &access);
    if (access_error) return access_error;
    // O_PATH requests no data access for every object type, including NUL-backed
    // character devices. Linux excludes these descriptors before type/range
    // validation, so do not limit this check to ordinary disk files.
    if ((access & (FILE_READ_DATA | FILE_WRITE_DATA | FILE_APPEND_DATA)) == 0) return EBADF;
    SetLastError(ERROR_SUCCESS);
    const DWORD kind = GetFileType(handle);
    if (kind == FILE_TYPE_UNKNOWN) {
      const DWORD error = GetLastError();
      if (error != ERROR_SUCCESS) return gesher::ErrnoFromWin32(error);
    }
    if (kind == FILE_TYPE_PIPE) return ESPIPE;
    if (len < 0 || advice < POSIX_FADV_NORMAL || advice > POSIX_FADV_NOREUSE) return EINVAL;
    // Linux accepts signed offsets and even ranges whose end would overflow.
    // Hints are nonbinding. Leave caching to Windows without touching data or
    // the shared file offset, or issuing blocking I/O for a read-ahead hint.
    return 0;
  }();
  errno = saved_errno;
  return result;
}

int posix_fallocate(int fd, off_t offset, off_t len) {
  // Unlike fallocate, POSIX returns the error number and leaves errno alone.
  const int saved_errno = errno;
  const int result = [&]() -> int {
    if (offset < 0 || len <= 0) return EINVAL;
    if (len > std::numeric_limits<off_t>::max() - offset) return EFBIG;
    const off_t end = offset + len;

    // Revocable files serialize growth with all writes in the same session.
    // Do not hold the process descriptor lock while entering that barrier.
    auto snapshot = gesher::CaptureDescriptor(fd);
    if (!snapshot) return errno;
    gesher::FileOperationLease operation(snapshot);
    if (operation.Error()) return operation.Error();
    if (gesher::FileDescriptionIsMemfd(snapshot)) {
      if (int error = gesher::MemfdGrowHandleError(snapshot->handle, static_cast<uint64_t>(end))) return error;
    }
    if (gesher::FileDescriptionIsRevocable(snapshot)) {
      const int flags = gesher::FileDescriptionFlags(snapshot);
      if (flags < 0) return errno;
      if ((flags & O_PATH) != 0 || (flags & O_ACCMODE) == O_RDONLY) return EBADF;
      LARGE_INTEGER size{};
      if (!GetFileSizeEx(snapshot->handle, &size)) return gesher::ErrnoFromWin32(GetLastError());
      if (end > size.QuadPart) {
        FILE_END_OF_FILE_INFO info{};
        info.EndOfFile.QuadPart = end;
        if (!SetFileInformationByHandle(snapshot->handle, FileEndOfFileInfo, &info, sizeof(info)))
          return gesher::ErrnoFromWin32(GetLastError());
      }
      return 0;
    }
    const HANDLE handle = snapshot->handle;
    uint32_t access = 0;
    int error = gesher::record_locks::HandleAccess(handle, &access);
    if (error) return error;
    if ((access & FILE_WRITE_DATA) == 0) return EBADF;
    const DWORD kind = GetFileType(handle);
    if (kind == FILE_TYPE_PIPE) return ESPIPE;
    if (kind != FILE_TYPE_DISK) return ENODEV;

    // Preserve CRT zero-filled growth on the object captured above. The
    // caller's fd may already have been closed or replaced with another file
    // whose seals or revocation group were never admitted by this operation.
    HANDLE duplicate = INVALID_HANDLE_VALUE;
    if (!DuplicateHandle(GetCurrentProcess(), handle, GetCurrentProcess(), &duplicate,
                         0, FALSE, DUPLICATE_SAME_ACCESS)) return gesher::ErrnoFromWin32(GetLastError());
    gesher::record_locks::DescriptorGuard descriptor_guard;
    const int pinned_fd = _open_osfhandle(reinterpret_cast<intptr_t>(duplicate), _O_RDWR | _O_BINARY | _O_NOINHERIT);
    if (pinned_fd < 0) {
      const int error = gesher_errno_from_crt(errno);
      CloseHandle(duplicate);
      return error;
    }
    // This internal slot is never published or registered as an Android fd.
    // Its close must not release the app's process-wide record locks.
    struct CrtSlot { int fd; ~CrtSlot() { _close(fd); } } pinned{pinned_fd};
    const long long size = _filelengthi64(pinned_fd);
    if (size < 0) return gesher_errno_from_crt(errno);
    if (end > size) {
      // Retain the existing CRT zero-filled extension path. This is not a
      // range-preallocation backend for sparse files. In particular, replacing
      // it with absolute FileAllocationInfo/EOF assignments would also risk
      // truncating concurrent writers after a stale size query.
      error = _chsize_s(pinned_fd, end);
      if (error) return gesher_errno_from_crt(error);
    }
    return 0;
  }();
  errno = saved_errno;
  return result;
}

int fallocate(int fd, int mode, off_t offset, off_t len) {
  if (mode != 0) return errno = EOPNOTSUPP, -1;
  int result = posix_fallocate(fd, offset, len);
  return result == 0 ? 0 : (errno = result, -1);
}

// --- uio ---------------------------------------------------------------------

namespace {

// readv/writev on a socket fd: one gather/scatter call.
void ReleaseCanceledIoVector(void* raw) {
  std::vector<gesher::ws::Buffer> empty;
  empty.swap(*static_cast<std::vector<gesher::ws::Buffer>*>(raw));
}

bool SocketIo(int fd, const struct iovec* iov, int iovcnt, bool write, ssize_t* result) {
  gesher::SocketFd state;
  if (!gesher::LookupSocket(fd, &state)) return false;
  if (iovcnt < 0) {
    errno = EINVAL;
    *result = -1;
    return true;
  }
  std::vector<gesher::ws::Buffer> buffers;
  for (int i = 0; i < iovcnt; ++i) buffers.push_back({iov[i].iov_base, iov[i].iov_len});
  pthread_cleanup_push(ReleaseCanceledIoVector, &buffers);
  *result = write ? gesher::ws::SendOwned(state.socket, buffers.data(), buffers.size(), 0, nullptr, state.description)
                  : gesher::ws::RecvOwned(state.socket, buffers.data(), buffers.size(), 0, nullptr, state.description);
  pthread_cleanup_pop(0);
  return true;
}

// Linux checks the fd and the count before transferring anything, so a bad
// fd fails even with no buffers.
bool BadVector(int fd, int iovcnt) {
  if (gesher::HandleFromFd(fd) == INVALID_HANDLE_VALUE) return errno = EBADF, true;
  if (iovcnt < 0 || iovcnt > IOV_MAX) return errno = EINVAL, true;
  return false;
}

struct FileVectorTransfer {
  gesher::DescriptorSnapshotPtr snapshot;
  std::unique_ptr<unsigned char[]> allocated;
  unsigned char small[4096];
};
void ReleaseCanceledFileVector(void* raw) {
  auto* state = static_cast<FileVectorTransfer*>(raw);
  state->snapshot.reset();
  state->allocated.reset();
}

bool FileWriteVector(int fd, const iovec* iov, int iovcnt, bool positioned,
                     off_t offset, ssize_t* result) {
  pthread_testcancel();
  FileVectorTransfer state;
  {
    gesher::record_locks::DescriptorGuard guard;
    HANDLE handle = gesher::HandleFromFd(fd);
    if (handle == INVALID_HANDLE_VALUE) { *result = -1; errno = EBADF; return true; }
    const DWORD type = GetFileType(handle);
    if (type != FILE_TYPE_DISK && type != FILE_TYPE_PIPE) return false;
    state.snapshot = gesher::CaptureDescriptor(fd);
  }
  if (!state.snapshot) { *result = -1; return true; }
  std::array<iovec, IOV_MAX> copied{};
  if (!gesher::ws::CopyFromUser(copied.data(), iov, static_cast<size_t>(iovcnt) * sizeof(iovec))) {
    *result = -1; errno = EFAULT; return true;
  }
  // A file or pipe writev is one write, including append placement and the
  // PIPE_BUF guarantee. The native ordinary-file API accepts one span, so
  // gather multiple nonempty spans before submitting the single operation.
  // A single span has no copy or allocation; small vectors use stack storage.
  constexpr size_t maximum = 0x7ffff000;
  size_t total = 0, requested = 0, spans = 0;
  const void* single = nullptr;
  for (int i = 0; i < iovcnt; ++i) {
    if (copied[i].iov_len > static_cast<size_t>(std::numeric_limits<ssize_t>::max()) - requested) {
      *result = -1; errno = EINVAL; return true;
    }
    requested += copied[i].iov_len;
    copied[i].iov_len = std::min(copied[i].iov_len, maximum - total);
    total += copied[i].iov_len;
    if (copied[i].iov_len) { ++spans; single = copied[i].iov_base; }
  }
  const void* data = single;
  if (spans > 1) {
    if (total > sizeof(state.small)) {
      state.allocated.reset(new (std::nothrow) unsigned char[total]);
      if (!state.allocated) { *result = -1; errno = ENOMEM; return true; }
    }
    unsigned char* to = state.allocated ? state.allocated.get() : state.small;
    data = to;
    for (int i = 0; i < iovcnt; ++i) {
      if (!gesher::ws::CopyFromUser(to, copied[i].iov_base, copied[i].iov_len)) {
        *result = -1; errno = EFAULT; return true;
      }
      to += copied[i].iov_len;
    }
  }
  pthread_cleanup_push(ReleaseCanceledFileVector, &state);
  *result = positioned ? gesher::WriteFileDescriptionAt(state.snapshot, data, static_cast<unsigned>(total), offset)
                       : gesher::WriteFileDescription(state.snapshot, data, static_cast<unsigned>(total));
  pthread_cleanup_pop(0);
  return true;
}

}  // namespace

ssize_t readv(int fd, const struct iovec* iov, int iovcnt) {
  if (BadVector(fd, iovcnt)) return -1;
  ssize_t total = 0;
  if (SocketIo(fd, iov, iovcnt, false, &total)) return total;
  for (int i = 0; i < iovcnt; ++i) {
    int n = read(fd, iov[i].iov_base, static_cast<unsigned>(iov[i].iov_len));  // fd.cc
    if (n < 0) return total > 0 ? total : -1;
    total += n;
    if (static_cast<size_t>(n) < iov[i].iov_len) break;
  }
  return total;
}

ssize_t writev(int fd, const struct iovec* iov, int iovcnt) {
  if (BadVector(fd, iovcnt)) return -1;
  if (int error = gesher::EventObjectWriteError(fd)) return errno = error, -1;
  ssize_t transferred = 0;
  if (FileWriteVector(fd, iov, iovcnt, false, 0, &transferred)) return transferred;
  // A zero-total vector performs no device operation (eventfd rejects a
  // zero-byte scalar write). Preserve each vector boundary otherwise: Linux's
  // legacy .write fallback, including eventfd, writes one element at a time.
  bool empty = true;
  for (int i = 0; i < iovcnt; ++i) empty = empty && iov[i].iov_len == 0;
  if (empty) {
    // Preserve the socket path's cancellation point without issuing I/O.
    // Cancellation must not retain a descriptor guard or any owning object.
    pthread_testcancel();
    // Linux checks write access even when no bytes will be transferred. The
    // generic F_GETFL fallback reports O_RDWR, so inspect the held handle's
    // actual access without issuing an artificial zero-byte write (which can
    // create a socket datagram or fail on an otherwise writable eventfd).
    gesher::record_locks::DescriptorGuard descriptor_guard;
    HANDLE handle = gesher::HandleFromFd(fd);
    if (handle == INVALID_HANDLE_VALUE) return errno = EBADF, -1;
    uint32_t access = 0;
    if (int error = gesher::record_locks::HandleAccess(handle, &access)) {
      return errno = error, -1;
    }
    if ((access & FILE_WRITE_DATA) == 0) return errno = EBADF, -1;
    return 0;
  }
  ssize_t total = 0;
  if (SocketIo(fd, iov, iovcnt, true, &total)) return total;
  for (int i = 0; i < iovcnt; ++i) {
    // fd.cc owns virtual event descriptors and file/pipe notification. Their
    // reserved CRT descriptor may be NUL and cannot perform the actual write.
    int n = write(fd, iov[i].iov_base, static_cast<unsigned>(iov[i].iov_len));
    if (n < 0) return total > 0 ? total : -1;
    total += n;
    if (static_cast<size_t>(n) < iov[i].iov_len) break;
  }
  return total;
}

ssize_t preadv(int fd, const struct iovec* iov, int iovcnt, off_t offset) {
  if (BadVector(fd, iovcnt)) return -1;
  ssize_t total = 0;
  for (int i = 0; i < iovcnt; ++i) {
    ssize_t n = pread(fd, iov[i].iov_base, iov[i].iov_len, offset + total);
    if (n < 0) return total > 0 ? total : -1;
    total += n;
    if (static_cast<size_t>(n) < iov[i].iov_len) break;
  }
  return total;
}

ssize_t pwritev(int fd, const struct iovec* iov, int iovcnt, off_t offset) {
  if (BadVector(fd, iovcnt)) return -1;
  ssize_t total = 0;
  if (FileWriteVector(fd, iov, iovcnt, true, offset, &total)) return total;
  for (int i = 0; i < iovcnt; ++i) {
    ssize_t n = pwrite(fd, iov[i].iov_base, iov[i].iov_len, offset + total);
    if (n < 0) return total > 0 ? total : -1;
    total += n;
    if (static_cast<size_t>(n) < iov[i].iov_len) break;
  }
  return total;
}

ssize_t process_vm_readv(pid_t, const struct iovec*, unsigned long, const struct iovec*,
                         unsigned long, unsigned long) {
  return errno = ENOSYS, -1;
}

// --- extra stat calls (lstat, fstatat, mkdirat: path.cc) ----------------------

// fchown is in unistd.cc, with chown.
int mkfifo(const char*, mode_t) { return errno = ENOSYS, -1; }

int mknod(const char* path, mode_t mode, dev_t) {
  switch (mode & S_IFMT) {
    case 0:
    case S_IFREG: {
      int fd = open(path, O_CREAT | O_EXCL | O_WRONLY, mode & 07777);
      return fd < 0 ? -1 : close(fd);
    }
    case S_IFIFO:
      return mkfifo(path, mode);
    default:
      return errno = EPERM, -1;  // device nodes need CAP_MKNOD
  }
}

ssize_t splice(int, off_t*, int, off_t*, size_t, unsigned int) { return errno = EINVAL, -1; }


// --- memfd -------------------------------------------------------------------

int memfd_create(const char* name, unsigned int flags) {
  constexpr unsigned known = MFD_CLOEXEC | MFD_ALLOW_SEALING | MFD_HUGETLB |
                             MFD_NOEXEC_SEAL | MFD_EXEC;
  // Huge-page size encodings are valid only with HUGETLB, even though this
  // backend cannot supply huge pages. Reject invalid flags before the name.
  const unsigned huge_size = (flags & MFD_HUGETLB) ? (0x3fu << 26) : 0;
  if ((flags & ~(known | huge_size)) != 0 ||
      ((flags & MFD_NOEXEC_SEAL) != 0 && (flags & MFD_EXEC) != 0))
    return errno = EINVAL, -1;
  // Linux permits at most 249 name bytes (NAME_MAX minus "memfd:"). Probe
  // bounded bytes without dereferencing an untrusted native caller pointer.
  if (name == nullptr) return errno = EFAULT, -1;
  const uintptr_t address = reinterpret_cast<uintptr_t>(name);
  for (size_t i = 0; i < 250; ++i) {
    char byte;
    SIZE_T copied = 0;
    if (address > UINTPTR_MAX - i ||
        !ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<const void*>(address + i),
                           &byte, 1, &copied) || copied != 1)
      return errno = EFAULT, -1;
    if (byte == '\0') break;
    if (i == 249) return errno = EINVAL, -1;
  }
  // A delete-on-close file supplies storage, not enforceable Linux seals or
  // huge pages. Do not report those capabilities merely because a file opens.
  // Seals are stored on the file and enforced by gesher-base (memfd_seals.cc).
  if ((flags & (MFD_HUGETLB | MFD_NOEXEC_SEAL)) != 0) return errno = EOPNOTSUPP, -1;
  wchar_t dir[MAX_PATH], path[MAX_PATH];
  DWORD length = GetTempPathW(MAX_PATH, dir);
  if (length == 0) return gesher::FailWithLastError();
  if (length >= MAX_PATH) return errno = ENAMETOOLONG, -1;
  if (GetTempFileNameW(dir, L"mfd", 0, path) == 0) return gesher::FailWithLastError();
  SECURITY_ATTRIBUTES inherit = {sizeof(inherit), nullptr, (flags & MFD_CLOEXEC) == 0};
  // The supported default policy is executable, as is explicit MFD_EXEC.
  HANDLE h = CreateFileW(path, GENERIC_READ | GENERIC_WRITE | GENERIC_EXECUTE,
                         FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, &inherit,
                         CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE,
                         nullptr);
  if (h == INVALID_HANDLE_VALUE) {
    // GetTempFileNameW already created a file. A failed open owns no handle
    // whose close could remove it, so clean up that real file explicitly.
    DWORD error = GetLastError();
    DeleteFileW(path);
    return errno = gesher::ErrnoFromWin32(error), -1;
  }
  // Every memfd carries its seals (F_SEAL_SEAL alone without MFD_ALLOW_SEALING,
  // as on Linux). A file system that cannot store them cannot seal: refuse
  // MFD_ALLOW_SEALING rather than accept seals nothing would keep.
  if (!gesher::InitMemfdSeals(h, (flags & MFD_ALLOW_SEALING) != 0) &&
      (flags & MFD_ALLOW_SEALING) != 0) {
    CloseHandle(h);
    return errno = EOPNOTSUPP, -1;
  }
  gesher::record_locks::DescriptorGuard descriptor_guard;
  int fd = gesher::CrtResult(_open_osfhandle(reinterpret_cast<intptr_t>(h),
                           _O_RDWR | _O_BINARY | ((flags & MFD_CLOEXEC) != 0 ? _O_NOINHERIT : 0)));
  if (fd < 0) CloseHandle(h);
  else if (gesher::RegisterOfd(fd, O_RDWR | O_LARGEFILE) < 0) {
    int saved = errno;
    _close(fd);
    return errno = saved, -1;
  }
  if (fd >= 0) gesher::RegisterMemfd(fd);
  return fd;
}

// --- strsignal, link.h ------------------------------------------------------------

char* strsignal(int sig) {
  static thread_local char buf[32];
  switch (sig) {
    case SIGSEGV: return const_cast<char*>("Segmentation fault");
    case SIGBUS: return const_cast<char*>("Bus error");
    case SIGILL: return const_cast<char*>("Illegal instruction");
    case SIGFPE: return const_cast<char*>("Floating point exception");
    case SIGABRT: return const_cast<char*>("Aborted");
    case SIGTRAP: return const_cast<char*>("Trace/breakpoint trap");
    case SIGQUIT: return const_cast<char*>("Quit");
    case SIGKILL: return const_cast<char*>("Killed");
    case SIGTERM: return const_cast<char*>("Terminated");
    case SIGINT: return const_cast<char*>("Interrupt");
    default:
      snprintf(buf, sizeof(buf), "Unknown signal %d", sig);
      return buf;
  }
}

// dl_iterate_phdr reports every loaded Windows module (the main executable
// first, where libart is statically linked) with one synthetic PT_LOAD
// program header spanning the module's image. ART uses this to find the
// range of libart's own code (OatQuickMethodHeader::IsStub, which the stack
// walker calls for every quick/nterp frame) and to symbolize addresses. ELF
// objects the gesher loader mapped report their real headers through
// <link.h>'s loader-side iteration (compat/bionic/shim.cc); they are not
// Windows modules and do not appear here.
int dl_iterate_phdr(int (*callback)(struct dl_phdr_info*, size_t, void*), void* data) {
  HMODULE mods[512];
  DWORD needed = 0;
  HANDLE proc = GetCurrentProcess();
  if (!EnumProcessModules(proc, mods, sizeof(mods), &needed)) return 0;
  size_t count = needed / sizeof(HMODULE);
  if (count > 512) count = 512;
  // One persistent PT_LOAD phdr per module (the callback keeps no copy, but
  // the pointer must stay valid for the call).
  static thread_local Elf64_Phdr phdr;
  for (size_t i = 0; i < count; ++i) {
    auto base = reinterpret_cast<uintptr_t>(mods[i]);
    auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) continue;
    auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) continue;
    phdr = {};
    phdr.p_type = PT_LOAD;
    phdr.p_flags = PF_R | PF_X | PF_W;
    phdr.p_vaddr = 0;
    phdr.p_memsz = nt->OptionalHeader.SizeOfImage;
    char name[MAX_PATH] = "";
    GetModuleFileNameA(mods[i], name, sizeof(name));
    struct dl_phdr_info info = {};
    info.dlpi_addr = base;
    info.dlpi_name = name;
    info.dlpi_phdr = &phdr;
    info.dlpi_phnum = 1;
    int r = callback(&info, sizeof(info), data);
    if (r != 0) return r;
  }
  return 0;
}

}  // extern "C"
