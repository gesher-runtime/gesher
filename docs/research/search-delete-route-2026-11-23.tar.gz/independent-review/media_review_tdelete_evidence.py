#!/usr/bin/env python3
"""Independent arithmetic and retained-input verification; no timed replay."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import math
import statistics

BASE = Path(__file__).resolve().parent
WORK = BASE / 'tdelete-final-measure-v1'
checks = 0


def check(value, label):
    global checks
    checks += 1
    assert value, label


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def same(actual, expected, label):
    check(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10), label)


build = json.loads((WORK / 'build.json').read_text())
raw = json.loads((WORK / 'measurement.json').read_text())
summary = json.loads((WORK / 'summary.json').read_text())
check(raw['complete'] and build['complete'], 'complete fixed campaign/build')
check(raw['build_sha256'] == sha(WORK / 'build.json'), 'actual build receipt binding')
check(raw['blocks'] == 6 and len(raw['cases']) == 27 and len(raw['processes']) == 648, 'predeclared full count')
check(raw['order'] == ['baseline', 'candidate', 'candidate', 'baseline'], 'fixed ABBA order')
for name, expected in build['hashes'].items():
    check(sha(WORK / name) == expected, 'build/source/binary/log ' + name)
seen = set()
previous = datetime.fromisoformat(raw['started_utc'])
for process in raw['processes']:
    key = process['block'], tuple(process['case']), process['position']
    check(key not in seen, 'each process retained once')
    seen.add(key)
    check(process['variant'] == raw['order'][process['position']], 'position variant')
    check(process['case'] in raw['cases'], 'declared case')
    check(process['exit'] == 0 and process['stderr'] == '', 'complete correct process')
    measurement = json.loads(process['stdout'])
    check(measurement == process['measurement'], 'unmodified actual stdout')
    mode, size, kind = process['case']
    check([measurement['mode'], measurement['size'], measurement['kind']] == process['case'], 'case output binding')
    rounds = max(4, 524288 // size)
    check(measurement['operations'] == rounds * size, 'whole reported operation count')
    check(measurement['first_operations'] == size, 'first-lifecycle denominator')
    check(measurement['checksum'] == measurement['expected'] == (rounds + 1) * size * size, 'complete output checksum')
    start, end = map(datetime.fromisoformat, (process['started_utc'], process['ended_utc']))
    check(previous <= start < end, 'sequential real process intervals')
    previous = end
check(previous <= datetime.fromisoformat(raw['ended_utc']), 'complete declared interval')
for block in range(6):
    for case in raw['cases']:
        for position in range(4):
            check((block, tuple(case), position) in seen, 'no filtered process or workload')
check(len(summary) == 27, 'all summary cases')
for row in summary:
    case = row['case']
    selected = [p for p in raw['processes'] if p['case'] == case]
    for field in ('cpu_ns', 'wall_ns', 'first_cpu_ns', 'first_wall_ns'):
        denominator = 'first_operations' if field.startswith('first_') else 'operations'
        values = {variant: [p['measurement'][field] / p['measurement'][denominator]
                  for p in selected if p['variant'] == variant] for variant in ('baseline', 'candidate')}
        for variant in values:
            check(len(values[variant]) == 12, 'twelve fresh processes per variant/case')
            check(values[variant] == row[field]['raw_ns_per_operation'][variant], 'all raw normalized observations')
            same(row[field][variant], statistics.median(values[variant]), 'independent median')
        same(row[field]['percent'], 100 * (statistics.median(values['candidate']) /
             statistics.median(values['baseline']) - 1), 'independent median percentage')
        for block in range(6):
            means = {variant: statistics.mean(p['measurement'][field] / p['measurement'][denominator]
                      for p in selected if p['block'] == block and p['variant'] == variant)
                      for variant in ('baseline', 'candidate')}
            same(row[field]['paired_block_percent'][block],
                 100 * (means['candidate'] / means['baseline'] - 1), 'independent paired block ratio')
proof = {'checks': checks, 'timed_processes': 648, 'cases': 27, 'blocks': 6,
         'build_sha256': sha(WORK / 'build.json'), 'measurement_sha256': sha(WORK / 'measurement.json'),
         'summary_sha256': sha(WORK / 'summary.json'),
         'source_sha256': sha(BASE / 'gesher-tdelete/compat/bionic/search_bionic.cc'),
         'limits': ['No new timed replay, runtime execution or performance-budget acceptance.',
                    'Caller CPU brackets wall-clock reads; tiny per-operation CPU includes that overhead.',
                    'Final report/archive and current-head source composition remain separate review steps.']}
(BASE / 'media-review-tdelete-evidence.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
