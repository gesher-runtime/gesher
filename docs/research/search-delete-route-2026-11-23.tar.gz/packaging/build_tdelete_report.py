#!/usr/bin/env python3
"""Package the fixed completed experiment; never run or select timing samples."""
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

WORK = Path(__file__).resolve().parent
ROOT = WORK / "gesher-tdelete"
OUT = ROOT / "docs/research"
STEM = "search-delete-route-2026-11-23"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((WORK / name).read_text())


def p95(values):
    values = sorted(values)
    position = .95 * (len(values) - 1)
    left = int(position)
    return values[left] + (values[min(left + 1, len(values) - 1)] - values[left]) * (position - left)


def main():
    blobs = {}
    directories = ["tdelete-pilot", "tdelete-route-pilot", "tdelete-final-measure-v1",
                   "tdelete-qualification-gcc-v1", "tdelete-qualification-llvm-v1",
                   "tdelete-qualification-llvm-v2", "tdelete-c17-proof", "tdelete-reference"]
    for directory in directories:
        for path in sorted((WORK / directory).rglob("*")):
            if path.is_file():
                assert not path.is_symlink(), path
                blobs["evidence/" + str(path.relative_to(WORK))] = path.read_bytes()
    for name in ["compat/bionic/search_bionic.cc", "compat/bionic/search_bionic.h", "compat/bionic/abi_types.h",
                 "tests/native/search_test.inc", "tests/native/search_delete_contract.inc",
                 "tests/native/search_delete_contract_host.cc", "tests/native/search_delete_measure.cc",
                 "tools/test_search_delete_contracts.py", "tools/test_search_delete_report.py", "tools/measure_search_delete.py"]:
        blobs["source/" + name] = (ROOT / name).read_bytes()
    for path in sorted((ROOT / "tests/native/reference/search").iterdir()):
        if path.is_file():
            blobs["source/" + str(path.relative_to(ROOT))] = path.read_bytes()
    for name in ("media_review_tdelete_evidence.py", "media-review-tdelete-evidence.json"):
        blobs["independent-review/" + name] = (WORK / name).read_bytes()
    blobs["packaging/build_tdelete_report.py"] = Path(__file__).read_bytes()
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as archive:
            for name, data in sorted(blobs.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                item.uid = item.gid = 0
                item.uname = item.gname = ""
                archive.addfile(item, io.BytesIO(data))
    packed = output.getvalue()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / (STEM + ".tar.gz")).write_bytes(packed)
    build = read("tdelete-final-measure-v1/build.json")
    measured = read("tdelete-final-measure-v1/measurement.json")
    results = copy.deepcopy(read("tdelete-final-measure-v1/summary.json"))
    for row in results:
        for metric in ("cpu_ns", "wall_ns", "first_cpu_ns", "first_wall_ns"):
            values = row[metric]
            values["delta_ns"] = values["candidate"] - values["baseline"]
            values["p95"] = {variant: p95(values["raw_ns_per_operation"][variant]) for variant in ("baseline", "candidate")}
            values["p95"]["percent"] = 100 * (values["p95"]["candidate"] / values["p95"]["baseline"] - 1)
    qualification = read("tdelete-qualification-gcc-v1/qualification.json")
    index = {
        "schema": 1, "scope": "historical-host-component-evidence", "issue": 56,
        "source": {"baseline_commit": "08146b1ea150229313ef14a8fcd99df217a57fb9",
                   "baseline_sha256": build["hashes"]["baseline.cc"], "candidate_sha256": build["hashes"]["candidate.cc"],
                   "caller_object_sha256": build["hashes"]["caller.o"], "caller_source_sha256": build["hashes"]["caller.cc"]},
        "measurement": {"started_utc": measured["started_utc"], "ended_utc": measured["ended_utc"],
                        "quiet_confirmed_utc": measured["quiet_confirmed_utc"], "quiet_lanes": measured["quiet_lanes"],
                        "processes": 648, "first_plus_steady_records": 1296, "cases": 27, "blocks": 6,
                        "order": measured["order"], "flags": build["flags"], "compiler": build["compiler"],
                        "host": build["host"], "cpu_count": build["cpu_count"],
                        "summary": "Median of 12 independent fresh-process observations per variant/case; ratio of medians, plus each of six paired-block ratios.",
                        "p95": "R7 linear-interpolated descriptive sample p95 of 12 values; not a population tail guarantee.",
                        "clock_scope": "Process CPU surrounds both monotonic wall reads; for tiny per-round batches the CPU interval includes substantial timer-boundary cost.",
                        "first_scope": "First complete workload batch after tree setup in a fresh process, not application startup or an isolated cold Tdelete call."},
        "results": results, "counted": build["counted"], "android_reference": qualification["reference"],
        "qualification": {name: {key: read(name + "/qualification.json").get(key) for key in ("complete", "positive", "negative", "error")}
                          for name in ("tdelete-qualification-gcc-v1", "tdelete-qualification-llvm-v1", "tdelete-qualification-llvm-v2")},
        "static_frames_bytes": {"native": {"baseline": 40, "candidate": 1096},
                                "windows-x86_64": {"baseline": 72, "candidate": 1128},
                                "windows-aarch64": {"baseline": 64, "candidate": 1136}},
        "independent_review": read("media-review-tdelete-evidence.json"),
        "first_llvm_driver_failure_annotation": read("tdelete-qualification-llvm-v1/failure-annotation.json"),
        "limits": ["Static function frames are not complete recursive peak stack usage.",
                   "No whole-application speedup or universal performance-budget acceptance is established.",
                   "Local Linux host execution and Windows cross-compilation do not establish Windows runtime or Android-device parity.",
                   "The supplier implementation has valid different unbalanced tree shapes; equality is asserted for public semantics, not shape.",
                   "The reduced-capacity two-slot source exercises the exact overflow/fallback branch; a physically realizable 128-level valid AVL tree was not built.",
                   "All old pilots and the first LLVM driver error are retained separately; no observations are dropped or pooled across changed callers/flags."],
        "archive": {"file": STEM + ".tar.gz", "sha256": sha(packed), "bytes": len(packed),
                    "members": {name: {"sha256": sha(data), "bytes": len(data)} for name, data in sorted(blobs.items())}},
    }
    (OUT / (STEM + ".json")).write_text(json.dumps(index, indent=2) + "\n")
    lines = ["# Search deletion: retain the lookup route for rebalancing", "",
             "This is scoped host evidence for issue #56. The complete 4,096-key deletion workloads reduce median process CPU by **37.49% for integer keys and 36.31% for common-prefix strings**. Successful delete/reinsert churn improves **30.37% / 23.32%**, and complete build/drain lifecycles improve **26.47% / 19.44%**. The same measured candidate costs **10.040 ns / 15.40%** on a missing integer key, with all six blocks adverse, and adds approximately 1 KiB to the static `Tdelete` frame. These costs are part of the proposal.", "",
             "## Production change and ownership", "",
             "The prior public `Tdelete` first searches iteratively to retain its required parent result, then searches the same route again recursively while removing and balancing. The candidate records pointers to the ancestor links during the first search in a bounded 128-slot local array. It removes the found node with the same successor routine, consumes those links in reverse order to rebalance, and publishes the final root. The original recursive removal remains the overflow fallback. No allocation, global state, cache, comparator adapter, or changed node representation is introduced.", "",
             "The captured links are in strict ancestors, not the freed target/successor. Each lower link is consumed before any parent rotation can move its context. Non-root return values preserve the original parent address; the unspecified non-null root result is not dereferenced. Missing deletion preserves the tree. `Tsearch`, `Tfind`, `Twalk`, insertion, balancing, minimum removal and destruction retain their implementation. The successful path intentionally invokes the comparator fewer times; comparator side-effect counts are not claimed identical. Stable comparison order remains the required input contract. Same-tree read-only comparator reentrance and independent-tree deletion are tested; mutating the active tree from its comparator is not newly supported.", "",
             "## Exact sources and ordinary build", "",
             f"- Baseline commit: `{index['source']['baseline_commit']}`; complete source SHA-256 `{index['source']['baseline_sha256']}`.",
             f"- Candidate complete source SHA-256: `{index['source']['candidate_sha256']}`.",
             f"- One separately compiled ordinary caller object SHA-256: `{index['source']['caller_object_sha256']}`; the same object is linked with each complete production translation unit.",
             "- Actual compiler: LLVM 23.1.3, commit `0d261d1ca552c95a8f007e061c787ac7132fbcbc`, Linux x86-64 host. Flags: `-std=gnu++20 -O3 -DNDEBUG -Wall -Wextra -Werror -fno-exceptions -fsized-deallocation -mno-ms-bitfields`. Timed objects have no sanitizer, LTO, allocation wrapper or comparison counter. The project `BIONIC_SYSV` declarations are retained.",
             "- The archive retains full sources, headers, objects, executables, compiler/dependency/frame outputs, command arguments and actual stdout/stderr. A separately compiled counted caller links the same ordinary production objects; its durations are not used as performance evidence.", "",
             "## Fixed measurement protocol", "",
             f"The final campaign ran **{measured['started_utc']}–{measured['ended_utc']}**, after all four lanes explicitly stopped CPU work. It contains **648 fresh processes: 27 cases × six ABBA blocks × four processes**, with 1,296 first/steady records. Every case has 12 observations per implementation. No run was replaced or omitted. Medians below are ratios of the separately computed medians; all six paired-block ratios and all raw per-operation values are in the JSON.", "",
             "Each workload verifies actual public results, key identity, its checksum and final tree state. Drain removes every key; churn removes and reinserts each key; lifecycle includes all insertions and deletion of the resulting tree. Mixed cases contain 25% or 75% successful deletion plus reinsertion and the remaining absent-key deletions. Integer and 72-byte-common-prefix string comparators are real callbacks. Setup is outside timing except in lifecycle; result checks and checksums are inside, while final exact-key validation and cleanup are outside. The denominator is workload key operations, so churn/lifecycle/mixed hits can contain multiple public function calls per operation.", "",
             "Steady work uses `max(4, 524288 / size)` complete rounds; the first complete round is retained separately. First means the first workload batch after tree setup in a fresh process, not whole-application startup or an isolated cold deletion. The process CPU interval surrounds both monotonic wall-clock reads. With tiny trees each round is correspondingly tiny, so CPU includes substantial timer-boundary cost that the wall interval excludes. The two clocks must not be conflated or overhead-subtracted after the fact.", "",
             "### All final cases", "",
             "Negative percentages are improvements. CPU values are ns per workload key operation. First p95 is the R7 linearly interpolated sample p95 of only 12 fresh processes per variant, a descriptive observation rather than a tail guarantee.", "",
             "| Workload | Keys | Kind | CPU before → after (ns/op) | CPU Δ | Wall Δ | First CPU Δ | First CPU p95 Δ |",
             "| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |"]
    for row in results:
        mode, size, kind = row["case"]
        cpu = row["cpu_ns"]
        lines.append(f"| {mode} | {size:,} | {kind} | {cpu['baseline']:.3f} → {cpu['candidate']:.3f} | {cpu['percent']:+.2f}% | {row['wall_ns']['percent']:+.2f}% | {row['first_cpu_ns']['percent']:+.2f}% | {row['first_cpu_ns']['p95']['percent']:+.2f}% |")
    lines += ["", "Large 4,096/65,536-key drains, both churn cases and both hit/miss mixtures improve in all six paired blocks. Integer lifecycle has one +0.65% adverse block among five improvements; its median gain is not a claim that every run improved. The 4,096 integer missing-key regression occurs in all six blocks (+1.31% to +29.71%). String misses have mixed-sign paired results despite their median −2.61%; their first CPU/wall medians worsen +15.05%/+19.43%.", "",
              "Other retained adverse controls include one-key integer drain CPU +1.67%, 16-key integer drain +2.73%, empty deletion +0.368 ns/+12.38%, and unchanged duplicate string insertion +9.431 ns/+3.93% (five of six paired blocks adverse). Unchanged integer find first CPU/wall worsens +16.43%/+17.04%. `Tfind` and duplicate insertion are unchanged control implementations: neither their favorable nor adverse shifts are attributed to removal of the second comparator pass. All first p95 observations, including unfavorable ones, are present above and in the JSON.", "",
              "## Comparison and resource accounting", "",
              "The 54 separate counted processes cover all 27 cases and both implementations. Each counts its first and steady whole batch, twice the stated key count. Both production objects are identical to the ordinary timed build; only the separate caller adds comparator/allocation counters. The following integer results count complete actual public work:", "",
              "| Workload (4,096 keys × two batches) | Comparisons before → after | malloc calls / bytes, both | frees, both |",
              "| --- | ---: | ---: | ---: |"]
    for mode in ("drain", "churn", "missing", "lifecycle", "mixed25", "mixed75", "empty"):
        pair = {row["variant"]: row["measurement"] for row in build["counted"] if row["case"] == [mode, 4096, "int"]}
        before, after = pair["baseline"], pair["candidate"]
        lines.append(f"| {mode} | {before['comparisons']:,} → {after['comparisons']:,} | {after['allocations']:,} / {after['allocated_bytes']:,} | {after['frees']:,} |")
    lines += ["", "Successful deletion allocates nothing and frees exactly one node; an absent key allocates/frees nothing. Caller-owned key pointers retain ownership. Full drain halves comparator calls exactly; churn and mixed modes also include unchanged insertion comparisons. No dynamic-memory saving or complete-application gain is inferred from those call counts.", "",
              "| `Tdelete` static function frame | Before | After |",
              "| --- | ---: | ---: |",
              "| Linux x86-64 / LLVM 23 | 40 B | 1,096 B |",
              "| Windows x86-64, project SysV ABI | 72 B | 1,128 B |",
              "| Windows ARM64 | 64 B | 1,136 B |", "",
              "These are actual compiler `.su` static function frames, not the complete recursive peak stack or a runtime stack measurement. The additional local route also affects misses, tiny trees and nested calls. The candidate uses no retained heap buffer. A full 128-level valid AVL tree is not physically realizable with available address space; the fixture reduces only the route capacity to two in the same full production source to execute overflow and fallback on valid trees. That exact fallback preserves the complete baseline/candidate public traversal trace, and a compiled off-by-one mutant is rejected by ASan. This is not a claim that an actual 128/129-depth valid tree was constructed.", "",
              "## Public semantics, actual Android source and negative controls", "",
              "The shared public-API corpus runs 3,654,000 checks per implementation: sorted/reversed/shuffled insertions, root/extreme/shuffled deletion, parent return, duplicate identity, missing keys, callback errno, remaining keys, complete VISIT/order/depth/balance and exact remaining-key destruction. Baseline, candidate and two-slot fallback produce the identical complete trace `cb5909ac8b767a1e`. The fixture is included by the existing native guest test and is also valid strict C17.", "",
              "The complete actual production translation unit is linked without extracting or recreating the algorithm. Additional host tests exercise comparator reentrance with read-only access to the active tree, deletion in another tree, eight independent concurrent trees, and allocation denial around the actual deletion call. Host counts are 101,442 candidate, 102,019 baseline, 101,968 two-slot fallback and 100,992 supplier checks. All have the same 3,654,000 shared checks.", "",
              "The test-only supplier is the unmodified Android Bionic `tsearch.c`, `tfind.c` and `tdestroy.cpp` family selected by `libc/Android.bp` at [android-16.0.0_r4](https://android.googlesource.com/platform/bionic/+/refs/tags/android-16.0.0_r4/), tag object `2ae67d60dd95c0f0c8fe12c30907be36f2ac17ff`, peeled commit `f22516cbc67e81c13cf943ce02f01b8929a98726`. Sources, exact Gitiles receipts, SHA-256 pins and original Public Domain/Apache-2.0 notices are retained under `tests/native/reference/search` and in the archive. Public semantics are compared against the actual supplier; its valid unbalanced shape is not forced to match the AVL implementation. Its distinct complete trace is `317c81fece2db47e`. This is the Bionic repository, separate from the external LLVM libc supplier used in the earlier Memrchr report.", "",
              "GCC 14 ASan/UBSan passes baseline/candidate/supplier/fallback and six genuinely compiled negative controls: omitted ancestor balancing, wrong parent result, missing-key false success, lost successor key, omitted overflow fallback, and route off-by-one. Every negative binary compiles and fails its relevant runtime contract. Ordinary LLVM 23 independently passes all four positives and the five semantic negatives; the out-of-bounds negative is restricted to the sanitizer run. A separate strict C17 caller passes the supplier's complete shared corpus. The first LLVM driver attempt failed after its two production positives because a compiler-name parser constructed `clangcc`; that error and all outputs remain archived, followed by the corrected complete attempt. No source predicate was weakened.", "",
              "Local ASan runs set `ASAN_OPTIONS=detect_leaks=0` only because this workspace's ptrace environment cannot run LeakSanitizer. The committed CI command does not disable LeakSanitizer. Explicit allocator ownership checks remain active locally. Complete production TUs cross-compile with strict ordinary flags for Windows x86-64 and ARM64. Those object builds and Linux host/supplier execution do not establish Windows runtime, an Android-device result or the complete issue budget. No Android NDK/sysroot was installed locally; the existing full CI builds and runs its guest/runtime surfaces.", "",
              "## Earlier experiments are retained", "",
              "The first recursive one-pass removal prototype ran a fixed 64-process pilot and was rejected: despite large successful-deletion gains, integer misses worsened +79.22%. A separately retained longer 96-process ABCCBA comparison of baseline, rejected recursive candidate and this bounded-route candidate found the recursive miss +102.20%; the route miss was +9.60% integer/+12.38% string. Both pilots retain complete raw first/steady observations, binaries, caller/source identities and their noisy unchanged controls. The final campaign keeps the route production source unchanged, uses the common enum-dispatch caller and ordinary project flags, and broadens to 27 cases. Measurements across different callers/flags are not pooled. This final fixed campaign was not repeated to select favorable results.", "",
              "Independent review checks all 648 actual process outputs, fixed block order, build/binary/source hashes, 27 × four metrics and paired ratios: 8,706 checks. The final historical report validator independently verifies the archive and recomputes the public summary. Current production semantics remain a separate executable CI gate; the historical evidence gate does not freeze unrelated future tree implementation changes or label them as the old measured source.", "",
              "## Reproduce qualification and inspect evidence", "",
              "```sh", "python3 tools/test_search_delete_contracts.py --sanitize --negative-controls",
              "python3 tools/test_search_delete_report.py", "```", "",
              "For a new experiment, `tools/measure_search_delete.py --prepare --output-dir NEW_DIRECTORY --baseline COMPLETE_BASELINE.cc --compiler clang++ --cross-bin LLVM_MINGW_BIN` freezes all ordinary inputs. After qualification and explicit idle coordination, `--run --output-dir NEW_DIRECTORY --quiet-confirmed UTC_TIMESTAMP` runs exactly six ABBA blocks. The driver refuses to overwrite an existing measurement. New measurements are separate evidence, not edits to this historical result.", "",
              f"Machine-readable complete results and member manifest: `{STEM}.json`. All raw observations, both pilots, source/supplier files, full positive/negative binaries, failed driver attempt and independent review: `{STEM}.tar.gz`, **{len(blobs):,} regular members**, **{len(packed):,} bytes**, SHA-256 `{sha(packed)}`.", ""]
    (OUT / (STEM + ".md")).write_text("\n".join(lines))
    print(json.dumps({"members": len(blobs), "archive_bytes": len(packed), "archive_sha256": sha(packed),
                      "json_bytes": (OUT / (STEM + ".json")).stat().st_size, "markdown_bytes": (OUT / (STEM + ".md")).stat().st_size}))


if __name__ == "__main__":
    main()
