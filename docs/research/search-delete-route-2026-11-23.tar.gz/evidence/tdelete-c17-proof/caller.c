#define _GNU_SOURCE 1
#include <errno.h>
#include <search.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned long long checks;
static void check(const char* what, int ok) { ++checks; if (!ok) { fprintf(stderr,"C_REFERENCE_FAILURE: %s\n",what); exit(1); } }
static int compare_ints(const void* a, const void* b) { int x=*(const int*)a,y=*(const int*)b; return (x>y)-(x<y); }
#define TREE_DELETE_EXTENDED 1
#define TREE_DELETE_CHECK_BALANCE 0
#include "search_test.inc"
int main(void) { test_search(); printf("C17_REFERENCE_PASS host_checks=%llu shared_checks=%llu trace=%016llx\n",checks,tree_delete_checks,tree_delete_digest); }
