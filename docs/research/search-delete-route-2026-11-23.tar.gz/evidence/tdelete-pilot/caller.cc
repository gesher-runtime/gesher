#include "search_bionic.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <numeric>
#include <string>
#include <vector>
namespace tree = gesher::bionic::search;
struct Key { int value; char text[96]; };
__attribute__((noinline)) int BIONIC_SYSV ints(const void* a, const void* b) {
  int x = static_cast<const Key*>(a)->value, y = static_cast<const Key*>(b)->value;
  return (x > y) - (x < y);
}
__attribute__((noinline)) int BIONIC_SYSV strings(const void* a, const void* b) {
  return std::strcmp(static_cast<const Key*>(a)->text, static_cast<const Key*>(b)->text);
}
void BIONIC_SYSV keep(void*) {}
static unsigned checks;
static void require(bool ok) { ++checks; if (!ok) { std::fprintf(stderr,"FAIL check %u\n",checks); std::exit(1); } }
static Key key(int value) {
  Key k{}; k.value=value;
  std::memset(k.text,'p',72);
  std::snprintf(k.text+72,24,"%010d",value);
  return k;
}
static void contracts() {
  for (auto cmp : {ints, strings}) {
    for (int n : {1,2,3,7,16,127,128,257}) {
      std::vector<Key> keys; for(int i=0;i<n;++i)keys.push_back(key(i));
      void* root=nullptr;
      for(int i=0;i<n;++i) {
        auto p=static_cast<const Key* const*>(tree::Tsearch(&keys[i],&root,cmp));
        require(p && *p==&keys[i]);
      }
      Key absent=key(n+1); void* original=root;
      require(!tree::Tdelete(&absent,&root,cmp) && root==original);
      std::vector<bool> live(n,true);
      std::vector<int> order(n); std::iota(order.begin(),order.end(),0);
      unsigned seed=0x57ab19;
      for(int i=n-1;i>0;--i){seed=seed*1664525u+1013904223u;std::swap(order[i],order[seed%(i+1)]);}
      for(int i:order) {
        require(tree::Tdelete(&keys[i],&root,cmp)!=nullptr); live[i]=false;
        require(tree::Tdelete(&keys[i],&root,cmp)==nullptr);
        for(int j=0;j<n;++j){auto p=static_cast<const Key* const*>(tree::Tfind(&keys[j],&root,cmp));require(live[j] ? p&&*p==&keys[j] : !p);}
      }
      require(root==nullptr && !tree::Tdelete(&absent,&root,cmp));
      require(!tree::Tdelete(&absent,nullptr,cmp));
    }
  }
  std::printf("%u actual tree contract checks passed\n",checks);
}
static long long cpu() { timespec t{}; require(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t)==0);return t.tv_sec*1000000000LL+t.tv_nsec; }
static long long wall() {return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
int main(int argc,char**argv) {
  if(argc==2 && !std::strcmp(argv[1],"contracts")){contracts();return 0;}
  if(argc!=4)return 2;
  const std::string mode=argv[1]; const int n=std::atoi(argv[2]);
  if(n<1 || n>65536)return 2;
  auto cmp=!std::strcmp(argv[3],"string")?strings:ints;
  std::vector<Key> keys,missing;keys.reserve(n);missing.reserve(n);
  for(int i=0;i<n;++i){keys.push_back(key(2*i));missing.push_back(key(2*i+1));}
  const int rounds=std::max(4,32768/n);
  long long total_cpu=0,total_wall=0,first_cpu=0,first_wall=0;
  unsigned long long calls=0,checksum=0;
  for(int round=-1;round<rounds;++round) {
    void* root=nullptr;
    auto build=[&](){for(int i=0;i<n;++i)require(tree::Tsearch(&keys[i],&root,cmp)!=nullptr);};
    if(mode!="lifecycle")build();
    auto c0=cpu(),w0=wall();
    if(mode=="lifecycle")build();
    for(int j=0;j<n;++j) {
      const int i=(j*197)%n;
      if(mode=="drain" || mode=="lifecycle") {
        require(tree::Tdelete(&keys[i],&root,cmp)!=nullptr);
      } else if(mode=="churn") {
        require(tree::Tdelete(&keys[i],&root,cmp)!=nullptr);
        auto p=static_cast<const Key* const*>(tree::Tsearch(&keys[i],&root,cmp));
        require(p && *p==&keys[i]);
      } else if(mode=="missing") {
        require(tree::Tdelete(&missing[i],&root,cmp)==nullptr);
      } else if(mode=="find") {
        auto p=static_cast<const Key* const*>(tree::Tfind(&keys[i],&root,cmp));
        require(p && *p==&keys[i]);
      } else if(mode=="duplicate") {
        auto p=static_cast<const Key* const*>(tree::Tsearch(&keys[i],&root,cmp));
        require(p && *p==&keys[i]);
      } else return 2;
      checksum+=static_cast<unsigned>(keys[i].value)+1;
    }
    auto w1=wall(),c1=cpu();
    if(round<0){first_cpu=c1-c0;first_wall=w1-w0;}else{total_cpu+=c1-c0;total_wall+=w1-w0;calls+=n;}
    if(mode=="drain" || mode=="lifecycle")require(root==nullptr);
    else {for(int i=0;i<n;++i)require(tree::Tfind(&keys[i],&root,cmp)!=nullptr);tree::Tdestroy(root,keep);}
  }
  const auto expected=static_cast<unsigned long long>(rounds+1)*n*n;
  require(checksum==expected);
  std::printf("{\"mode\":\"%s\",\"size\":%d,\"kind\":\"%s\",\"calls\":%llu,\"cpu_ns\":%lld,\"wall_ns\":%lld,\"first_cpu_ns\":%lld,\"first_wall_ns\":%lld,\"checksum\":%llu,\"expected\":%llu}\n",mode.c_str(),n,argv[3],calls,total_cpu,total_wall,first_cpu,first_wall,checksum,expected);
}
