from datetime import datetime, timezone
import hashlib,json,statistics,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
build=json.loads((root/'build.json').read_text())
for name,digest in build['hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
cases=[('drain',n,kind) for kind in ('int','string') for n in (16,256,4096)]
cases += [(mode,4096,kind) for mode in ('churn','missing','find','lifecycle','duplicate') for kind in ('int','string')]
assert len(cases)==16
def utc(): return datetime.now(timezone.utc).isoformat()
data={'started_utc':utc(),'build':build,'cases':cases,'quiet_lanes':['java','media','native'],
      'rounds':1,'order':['baseline','candidate','candidate','baseline'],'processes':[],'complete':False}
out=root/'pilot.json'
assert not out.exists()
try:
    for case in cases:
        for position,variant in enumerate(data['order']):
            cmd=[str(root/(variant+'.bin')),*map(str,case)]
            start=utc()
            run=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
            row={'case':case,'variant':variant,'position':position,'command':cmd,'started_utc':start,
                 'ended_utc':utc(),'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
            data['processes'].append(row)
            assert run.returncode==0 and not run.stderr,row
            row['measurement']=json.loads(run.stdout)
            assert row['measurement']['checksum']==row['measurement']['expected']
    data['complete']=True
finally:
    data['ended_utc']=utc()
    out.write_text(json.dumps(data,indent=2)+'\n')
summary=[]
for case in cases:
    rows=[r for r in data['processes'] if tuple(r['case'])==case]
    metrics={}
    for metric in ('cpu_ns','wall_ns'):
        m={v:statistics.median(r['measurement'][metric]/r['measurement']['calls'] for r in rows if r['variant']==v)
           for v in ('baseline','candidate')}
        metrics[metric]={**m,'percent':100*(m['candidate']/m['baseline']-1)}
    summary.append({'case':case,**metrics})
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'started':data['started_utc'],'ended':data['ended_utc'],'processes':len(data['processes']),'summary':summary}))
