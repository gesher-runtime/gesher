from pathlib import Path
import sys,subprocess,hashlib,json,os
p=Path(__file__).resolve().parent;repo=p/'gesher-media-resample-channels';sys.path.insert(0,str(repo/'tools'))
from test_audio_state_contracts import generate
out=p/'media-audio-refill-reproducer';out.mkdir(exist_ok=True)
fixture=r'''
using namespace gesher::media;
using namespace std::chrono_literals;
int main() {
 Engine engine; TrackParams params;params.channels=1;params.sample_rate=48000;params.capacity_frames=960;
 Track track(&engine,params);std::vector<int16_t> pcm(14400);
 for(size_t i=0;i<pcm.size();++i)pcm[i]=static_cast<int16_t>(16383.5*std::sin(2*3.14159265358979323846*750*i/48000));
 track.Start();auto writer=std::async(std::launch::async,[&]{return track.Write(pcm.data(),pcm.size()*sizeof(int16_t),true);});
 const auto deadline=std::chrono::steady_clock::now()+2s;
 while(track.room_.waits.load()==0 && std::chrono::steady_clock::now()<deadline)std::this_thread::yield();
 if(track.room_.waits.load()==0){track.Release();writer.wait();return 2;}
 {std::lock_guard<std::mutex> lock(track.mu_);if(track.written_!=960||track.read_!=0){track.released_=true;track.room_.notify_all();return 3;}}
 // One actual MixInto request below ClockedSink's unmodified4,800-frame cap.
 // Writer is already in actual blocking Write with all14,400 source frames.
 std::vector<float> mixed(1406*2);bool played=track.MixInto(mixed.data(),1406,48000,2);
 size_t different=0;
 for(size_t i=0;i<960;++i)for(size_t c=0;c<2;++c)if(mixed[i*2+c]!=pcm[i]/32768.0f)++different;
 size_t nonzero_tail=0;for(size_t i=960*2;i<mixed.size();++i)if(mixed[i]!=0)++nonzero_tail;
 uint32_t underrun;uint64_t position;{std::lock_guard<std::mutex> lock(track.mu_);underrun=track.underrun_frames_;position=track.played_;}
 track.Release();if(writer.wait_for(2s)!=std::future_status::ready)return 4;auto transferred=writer.get();
 std::printf("{\"actual_request_frames\":1406,\"actual_ring_frames\":960,\"source_ready_frames\":14400,\"real_pcm_mismatches\":%zu,\"zero_tail_frames\":446,\"tail_nonzero_samples\":%zu,\"underrun_frames\":%u,\"source_position\":%llu,\"writer_transferred_bytes_before_release\":%lld,\"played\":%s}\n",different,nonzero_tail,underrun,(unsigned long long)position,(long long)transferred,played?"true":"false");
 return !played || different || nonzero_tail || underrun!=446 || position!=960;
}
'''
receipts=[]
for label,ref in [('actual_failed_merge','498ed2a9fa8c9d63f0bb093f779463697d3a5715'),('current_main','8f53b6045e26f0bb4a482c69099d084db3e94963'),('pending_334','3e7afab2c5a88128e08a41e7273257d3a5f323ce')]:
 production=generate('audio',ref);marker='namespace {\nusing namespace gesher::media;';assert production.count(marker)==1;source=production[:production.index(marker)]+fixture
 cpp=out/(label+'.cc');cpp.write_text(source);binary=out/label
 cmd=['c++','-std=c++20','-O1','-g','-Wall','-Wextra','-Werror','-pthread','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer',str(cpp),'-o',str(binary)]
 subprocess.run(cmd,check=True);r=subprocess.run([str(binary)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'),timeout=20);(out/(label+'.log')).write_text(r.stdout);r.check_returncode();print(label,r.stdout.strip(),flush=True)
 receipts.append({'label':label,'ref':ref,'generated_sha256':hashlib.sha256(source.encode()).hexdigest(),'compile':cmd,'returncode':r.returncode,'result':json.loads(r.stdout)})
(out/'proof.json').write_text(json.dumps({'scope':'Complete actual Track methods/header with existing Engine/clock and observed real-condition-variable boundaries; no hooked waits. Explicit oversized request models one permitted ClockedSink catch-up. Demonstrates a sufficient mechanism, not unrecorded scheduling history of original Windows failure.','receipts':receipts},indent=2)+'\n')
