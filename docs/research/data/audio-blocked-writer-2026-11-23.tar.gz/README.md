# Audio blocking-writer repair evidence

Original CI WAVs and the full failed-job log are unmodified. The in-memory
comparison does not edit either WAV. A separate actual Track/CaptureSink
fixture gives its own deterministic 727.3 versus 750.0 Hz comparison; the
original Windows capture is 727.4 Hz. No original scheduling trace is inferred.
Source snapshots, generated source, mutants, commands/logs and header hashes
identify exact boundaries. Binaries are represented by hashes/rebuild commands.

AudioTrack.cpp/.h are the pinned Android Open Source Project contract reference
under Apache-2.0; original copyright/license headers and LICENSE are retained.
Other source snapshots retain their project/dependency notices.
MANIFEST.json hashes every payload member. Full Windows CI remains pending.
