#include <algorithm>
#include <vector>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
int Analyze(const char* path) {
  FILE* f = fopen(path, "rb");
  if (f == nullptr) {
    printf("cannot open %s\n", path);
    return 2;
  }
  std::vector<uint8_t> file;
  uint8_t buf[65536];
  size_t n;
  while ((n = fread(buf, 1, sizeof(buf), f)) > 0) file.insert(file.end(), buf, buf + n);
  fclose(f);
  if (file.size() < 44 || memcmp(file.data(), "RIFF", 4) != 0) {
    printf("not a WAV file\n");
    return 2;
  }
  uint16_t channels = 0, bits = 0;
  uint32_t rate = 0;
  size_t data_off = 0, data_len = 0;
  for (size_t off = 12; off + 8 <= file.size();) {
    uint32_t len;
    memcpy(&len, file.data() + off + 4, 4);
    if (memcmp(file.data() + off, "fmt ", 4) == 0) {
      memcpy(&channels, file.data() + off + 10, 2);
      memcpy(&rate, file.data() + off + 12, 4);
      memcpy(&bits, file.data() + off + 22, 2);
    } else if (memcmp(file.data() + off, "data", 4) == 0) {
      data_off = off + 8;
      data_len = std::min<size_t>(len, file.size() - data_off);
      break;
    }
    off += 8 + len + (len & 1);
  }
  if (bits != 16 || channels == 0 || rate == 0) {
    printf("unsupported WAV (%u bits)\n", bits);
    return 2;
  }
  size_t frames = data_len / (2 * channels);
  std::vector<float> left(frames), right(frames);
  for (size_t i = 0; i < frames; i++) {
    int16_t l, r;
    memcpy(&l, file.data() + data_off + i * 2 * channels, 2);
    memcpy(&r, file.data() + data_off + i * 2 * channels + (channels > 1 ? 2 : 0), 2);
    left[i] = l / 32768.0f;
    right[i] = r / 32768.0f;
  }
  printf("wav: %u Hz, %u channels, %.3f s\n", rate, channels, static_cast<double>(frames) / rate);
  // Sounding blocks of 5 ms; sounds are runs of them, apart by 50 ms or more.
  const size_t block = rate / 200;
  std::vector<bool> loud(frames / block + 1, false);
  for (size_t b = 0; b * block < frames; b++) {
    double e = 0;
    size_t end = std::min(frames, (b + 1) * block);
    for (size_t i = b * block; i < end; i++) e += left[i] * left[i] + right[i] * right[i];
    loud[b] = std::sqrt(e / (2.0 * (end - b * block))) > 0.003;
  }
  int index = 0;
  for (size_t b = 0; b < loud.size();) {
    if (!loud[b]) {
      b++;
      continue;
    }
    size_t e = b;
    size_t quiet = 0;
    for (size_t k = b; k < loud.size(); k++) {
      if (loud[k]) {
        e = k;
        quiet = 0;
      } else if (++quiet >= 10) {
        break;
      }
    }
    size_t s0 = b * block, s1 = std::min(frames, (e + 1) * block);
    // Zero crossings (upward) of the louder channel, interpolated. A crossing
    // counts only after the signal went below -30% of its rms (hysteresis):
    // the low-level noise lossy codecs leave around a tone's start and end
    // would otherwise add crossings (an MP3 tone of 523 Hz measured 540).
    double el = 0, er = 0;
    for (size_t i = s0; i < s1; i++) {
      el += left[i] * left[i];
      er += right[i] * right[i];
    }
    const std::vector<float>& x = el >= er ? left : right;
    const double threshold = -0.3 * std::sqrt(std::max(el, er) / (s1 - s0));
    double first = -1, last = -1;
    int crossings = 0;
    bool armed = false;
    for (size_t i = s0 + 1; i < s1; i++) {
      if (x[i] < threshold) armed = true;
      if (armed && x[i - 1] < 0 && x[i] >= 0) {
        armed = false;
        double t = (i - 1) + x[i - 1] / (x[i - 1] - x[i]);
        if (first < 0) first = t;
        last = t;
        crossings++;
      }
    }
    double hz = crossings > 1 ? (crossings - 1) * rate / (last - first) : 0;
    double rms_l = std::sqrt(el / (s1 - s0)), rms_r = std::sqrt(er / (s1 - s0));
    printf("sound %d: start %.3f s, duration %.3f s, %.1f Hz, rms %.3f %.3f\n", ++index,
           static_cast<double>(s0) / rate, static_cast<double>(s1 - s0) / rate, hz, rms_l, rms_r);
    b = e + 1;
  }
  printf("sounds: %d\n", index);
  return 0;
}

int main(int argc,char**argv){return argc==2?Analyze(argv[1]):2;}
