// Production source SHA256: 044db8f21b351ba3db2b73548ff5fa9bfd5a87d54c46ecc8e4f8fe628bf36302
// Engine attachment/output clock and CV scheduling boundaries; all Track methods are production.
#include <sys/types.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <time.h>

// Clock transport for the Linux lifecycle fixture. Suspend semantics are
// exercised with the actual adapter in tools/test_clock_domains.py.
namespace gesher {
inline int AndroidClockGettime(clockid_t clock, timespec* value) {
  return clock_gettime(clock, value);
}
inline int64_t MonotonicNanos() {
  timespec value;
  clock_gettime(CLOCK_MONOTONIC, &value);
  return static_cast<int64_t>(value.tv_sec) * 1000000000 + value.tv_nsec;
}
}

class ObservedConditionVariable {
 public:
  std::atomic<unsigned> waits{0};
  std::function<void()> before_reacquire;
  void notify_all() { cv_.notify_all(); }
  void wait(std::unique_lock<std::mutex>& lock) {
    ++waits;
    if (Hook(lock)) return;
    cv_.wait(lock);
  }
  template<class Rep, class Period>
  std::cv_status wait_for(std::unique_lock<std::mutex>& lock,
                          const std::chrono::duration<Rep, Period>& duration) {
    ++waits;
    if (Hook(lock)) return std::cv_status::no_timeout;
    return cv_.wait_for(lock, duration);
  }
  template<class Rep, class Period, class Predicate>
  bool wait_for(std::unique_lock<std::mutex>& lock,
                const std::chrono::duration<Rep, Period>& duration, Predicate predicate) {
    return cv_.wait_for(lock, duration, predicate);
  }
 private:
  bool Hook(std::unique_lock<std::mutex>& lock) {
    if (!before_reacquire) return false;
    auto hook = std::move(before_reacquire);
    lock.unlock();
    hook();
    lock.lock();
    return true;
  }
  std::condition_variable cv_;
};

// Gesher: the audio output of an app process (docs/media.md, ADR 0042).
//
// Every sound an app makes (AudioTrack, MediaPlayer, SoundPool, AAudio,
// OpenSL ES) is a Track of this process's Engine. The engine's thread mixes
// the tracks at the output's rate, one mix per Android stream volume group
// (media, ring, alarm, notification, call), and hands the mixes to the sink:
//
//  - WASAPI, shared mode: one render stream per group in use, each its own
//    Windows audio session ("<app> (Alarm)"), whose volume is the Android
//    stream volume of the group (shared_state.h; the Windows volume mixer
//    changes it back);
//  - a capture file (GESHER_AUDIO_CAPTURE): the groups mixed into one WAV,
//    paced by the clock as a device would be, with the stream volumes
//    applied in software (what the volume mixer would do), for tests on
//    machines without an audio endpoint;
//  - nothing, paced by the clock, when no endpoint opens (or GESHER_AUDIO=null).
//
// Tracks are format-converted (8/16/24/32-bit PCM, float), resampled from any
// rate (windowed sinc), channel-mapped to the output and mixed in float.
// Nothing here knows Java: the JNI layers sit on top (compat/media/jni).


#include <sys/types.h>

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace gesher::media {

// AudioDeviceInfo and the native routing getters use the same process-local IDs.
constexpr int kOutputDeviceId = 2;
constexpr int kInputDeviceId = 3;

enum class PcmFormat : int { kU8, kS16, kS24Packed, kS32, kFloat };

size_t BytesPerSample(PcmFormat f);

// Android's stream types (AudioSystem.STREAM_*) and their volume groups:
// a stream plays at the volume of its alias (AudioService's
// STREAM_VOLUME_ALIAS_DEFAULT on a phone).
constexpr int kNumStreamTypes = 12;  // STREAM_VOICE_CALL (0) .. STREAM_ASSISTANT (11)
int StreamAlias(int stream);
// The volume groups, by alias: the streams that alias to themselves.
constexpr int kNumGroups = 5;
int GroupOfStream(int stream);       // 0..kNumGroups-1
int StreamOfGroup(int group);        // the alias stream of a group
const char* GroupName(int group);    // "Media", "Ringtone", ...

// Status codes, as Android's (AudioSystem.SUCCESS, ERROR, BAD_VALUE, ...).
constexpr int kOk = 0;
constexpr int kError = -1;
constexpr int kBadValue = -2;
constexpr int kInvalidOperation = -3;
constexpr int kWouldBlock = -7;

struct TrackParams {
  uint32_t sample_rate = 48000;
  uint32_t channels = 2;
  PcmFormat format = PcmFormat::kS16;
  int stream_type = 3;          // STREAM_MUSIC
  size_t capacity_frames = 0;   // the stream's buffer, or the static buffer's size
  bool is_static = false;
  int session_id = 0;
  std::string name;             // for logs
};

// What a track tells its owner; called on the engine's event thread (never
// the mixing thread), in order.
struct TrackEvents {
  std::function<void(uint32_t position)> marker;        // the marker was played
  std::function<void(uint32_t position)> new_position;  // one more update period
  std::function<void()> end;                            // the data ran out (static end, stop drained)
  std::function<void()> underrun;                       // streaming, playing, no data
};

class Engine;

class Track : public std::enable_shared_from_this<Track> {
 public:
  enum class State { kStopped, kPlaying, kStopping, kPaused };

  ~Track();

  const TrackParams& params() const { return params_; }
  size_t frame_size() const { return frame_size_; }

  void SetEvents(TrackEvents events);

  // Playback control, as android::AudioTrack's.
  int Start();
  void Pause();
  // Streaming: drains the data present at stop; later writes prime the next start.
  // Static: stops at once and rewinds.
  void Stop();
  // Streaming, stopped or paused: drops what was not played; position 0.
  void Flush();
  State state() const;
  bool stopped() const;  // stopped, or stopping and drained

  // Streaming: copies up to `bytes` (whole frames) into the buffer; with
  // `blocking`, waits for room until everything is written or the track is
  // stopped, paused or released. Returns the bytes written or an error.
  // Static: writes at the start of the static buffer (data loaded so far).
  ssize_t Write(const void* data, size_t bytes, bool blocking);

  // Static tracks.
  int SetLoop(uint32_t start, uint32_t end, int count);  // count -1: forever
  int Reload();                                          // rewind to 0
  int SetPosition(uint32_t frame);                       // stopped or paused only
  size_t static_frames() const;

  // Position: frames played since the start (uint32 wraps, as Android's).
  uint32_t Position() const;
  // Frames presented and the CLOCK_MONOTONIC time of that, for getTimestamp.
  bool Timestamp(int64_t* frames, int64_t* time_ns) const;
  int SetMarker(uint32_t frame);
  uint32_t marker() const;
  int SetUpdatePeriod(uint32_t frames);
  uint32_t update_period() const;

  void SetVolume(float left, float right);
  // The playback rate in Hz (setPlaybackRate) and speed (PlaybackParams);
  // pitch follows the speed (no time stretching).
  int SetSampleRate(uint32_t rate);
  uint32_t sample_rate() const;
  void SetSpeed(float speed);
  float speed() const;

  uint32_t buffer_capacity_frames() const { return static_cast<uint32_t>(params_.capacity_frames); }
  uint32_t buffer_size_frames() const;
  int SetBufferSizeFrames(uint32_t frames);
  uint32_t underrun_frames() const;
  // Cumulative transitions into underrun, distinct from the frames missing.
  uint32_t underrun_count() const;
  uint32_t LatencyMs() const;

  // Streaming: frames written and not yet played.
  size_t Queued() const;
  // Waits until rames frames fit in the buffer (signalled by the mixer as it
  // plays, not polled), at most timeout_ms; true if they fit. A feeder that
  // sleeps instead wakes late under load (Windows' 15.6 ms timer ticks) and lets
  // a small buffer run dry.
  bool WaitForRoom(size_t frames, int timeout_ms);

  // Detaches the track from the engine; blocked writers return.
  void Release();

 public:
  friend class Engine;
  friend std::shared_ptr<Track> CreateTrack(const TrackParams&, std::string*);
  Track(Engine* engine, const TrackParams& params);

  // Mixing thread: adds up to `frames` output frames at `out_rate` with
  // `out_channels` into `mix` (already scaled by the track's volume).
  // Returns false when the track has nothing to play.
  bool MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels);
  // Reads up to `frames` source frames as float (the track's channels).
  size_t ReadSource(float* dst, size_t frames, bool* ended);
  void QueueEvents(uint64_t before, uint64_t after);

  Engine* engine_;
  TrackParams params_;
  size_t frame_size_;

  mutable std::mutex mu_;
  ObservedConditionVariable room_;  // signalled as frames are played, and on state changes
  State state_ = State::kStopped;
  bool released_ = false;
  bool drained_ = false;  // kStopping: all played
  // A writer must observe pause/stop even if start() runs before it reacquires mu_.
  uint64_t write_interrupt_ = 0;

  // Streaming ring, or static data.
  std::vector<uint8_t> data_;
  uint64_t written_ = 0;      // streaming: frames ever written
  uint64_t read_ = 0;         // streaming: frames ever taken by the resampler
  uint64_t stop_end_ = 0;     // kStopping: frozen source limit for this drain
  size_t buffer_frames_ = 0;  // streaming: setBufferSizeInFrames' limit
  size_t static_frames_ = 0;  // static: frames loaded
  size_t static_pos_ = 0;     // static: next frame to take
  uint32_t loop_start_ = 0, loop_end_ = 0;
  int loop_count_ = 0;

  // Played position (source frames), as the resampler passes them.
  uint64_t played_ = 0;
  uint64_t position_base_ = 0;  // subtracted from played_ for Position()
  int64_t played_time_ns_ = 0;
  uint32_t marker_ = 0;
  bool marker_reached_ = false;
  uint32_t update_period_ = 0;
  uint64_t next_update_ = 0;
  uint32_t underrun_frames_ = 0;
  uint32_t underrun_count_ = 0;
  bool was_underrun_ = false;
  bool end_signalled_ = false;
  int64_t starved_since_ns_ = -1;

  float vol_left_ = 1.0f, vol_right_ = 1.0f;
  float applied_left_ = 1.0f, applied_right_ = 1.0f;  // ramps toward vol_*
  uint32_t rate_;
  float speed_ = 1.0f;

  TrackEvents events_;
  struct Resampler;
  std::unique_ptr<Resampler> rs_;
};

std::shared_ptr<Track> CreateTrack(const TrackParams& params, std::string* error);

// The engine's output, for AudioSystem's answers.
struct OutputInfo {
  uint32_t sample_rate;
  uint32_t channels;
  uint32_t period_frames;   // the mixer's period
  uint32_t latency_frames;  // what the sink holds
  std::string description;  // "WASAPI shared mode, ...", "capture to ...", "none: ..."
  std::string device_name;  // the endpoint's friendly name
  int device_type;          // AUDIO_DEVICE_OUT_* of the endpoint's form factor
  uint32_t generation;      // changes when the output does
};
OutputInfo GetOutputInfo();

// Raises the calling thread's priority for audio work that feeds the engine
// (Android runs such threads at ANDROID_PRIORITY_AUDIO or SCHED_FIFO):
// `urgent` (an app's callback, a buffer queue's feeder) is
// THREAD_PRIORITY_HIGHEST, else (a player's decoder) ABOVE_NORMAL. Under load
// a normal-priority feeder may not run before the engine's time-critical
// mixer has played what the track holds.
void RaiseAudioThreadPriority(bool urgent);

// Runs `fn` on the engine's event thread (after earlier events).
void PostEvent(std::function<void()> fn);

// Streams with a track playing now (or within the last `in_past_ms`), on this
// device (every process; shared_state.h).
bool IsStreamActive(int stream, int in_past_ms);

// The process's application name for the Windows audio sessions
// ("<label> (Media)"); set by the JNI layer when it knows it.
void SetAppName(const std::u16string& name);

}  // namespace gesher::media

namespace gesher::media {

size_t BytesPerSample(PcmFormat f) {
  switch (f) {
    case PcmFormat::kU8: return 1;
    case PcmFormat::kS16: return 2;
    case PcmFormat::kS24Packed: return 3;
    case PcmFormat::kS32: return 4;
    case PcmFormat::kFloat: return 4;
  }
  return 2;
}

// --- Stream volume groups ----------------------------------------------------------------

namespace {

// STREAM_VOICE_CALL 0, SYSTEM 1, RING 2, MUSIC 3, ALARM 4, NOTIFICATION 5,
// BLUETOOTH_SCO 6, SYSTEM_ENFORCED 7, DTMF 8, TTS 9, ACCESSIBILITY 10, ASSISTANT 11:
// AudioService's STREAM_VOLUME_ALIAS_DEFAULT.
constexpr int kAlias[kNumStreamTypes] = {0, 2, 2, 3, 4, 5, 0, 2, 2, 3, 3, 3};
constexpr int kGroupStream[kNumGroups] = {3, 2, 4, 5, 0};
constexpr const char* kGroupName[kNumGroups] = {"Media", "Ringtone", "Alarm", "Notifications",
                                                "Calls"};

int64_t MonotonicNs() {
  timespec ts;
  gesher::AndroidClockGettime(CLOCK_MONOTONIC, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000000000 + ts.tv_nsec;
}

}  // namespace

int StreamAlias(int stream) {
  return stream >= 0 && stream < kNumStreamTypes ? kAlias[stream] : 3;
}

int GroupOfStream(int stream) {
  int a = StreamAlias(stream);
  for (int g = 0; g < kNumGroups; g++) {
    if (kGroupStream[g] == a) return g;
  }
  return 0;
}

int StreamOfGroup(int group) { return group >= 0 && group < kNumGroups ? kGroupStream[group] : 3; }

const char* GroupName(int group) {
  return group >= 0 && group < kNumGroups ? kGroupName[group] : "Media";
}

// --- The resampler -----------------------------------------------------------------------

namespace {

// A windowed sinc (Blackman-Harris) of kHalfTaps zero crossings each side,
// tabulated at kTableRes points per zero crossing.
constexpr int kHalfTaps = 12;
constexpr int kTableRes = 512;

const float* KernelTable() {
  static const std::vector<float> table = [] {
    std::vector<float> t(kHalfTaps * kTableRes + 2);
    for (size_t i = 0; i < t.size(); i++) {
      double x = static_cast<double>(i) / kTableRes;
      if (x >= kHalfTaps) {
        t[i] = 0;
        continue;
      }
      double sinc = x == 0 ? 1.0 : std::sin(M_PI * x) / (M_PI * x);
      double n = 0.5 + x / (2.0 * kHalfTaps);  // window over [-H, H] mapped to [0, 1]
      double w = 0.35875 - 0.48829 * std::cos(2 * M_PI * n) + 0.14128 * std::cos(4 * M_PI * n) -
                 0.01168 * std::cos(6 * M_PI * n);
      t[i] = static_cast<float>(sinc * w);
    }
    return t;
  }();
  return table.data();
}

inline float Kernel(const float* table, double x) {
  x = std::fabs(x);
  if (x >= kHalfTaps) return 0;
  double p = x * kTableRes;
  size_t i = static_cast<size_t>(p);
  float f = static_cast<float>(p - static_cast<double>(i));
  return table[i] + (table[i + 1] - table[i]) * f;
}

// Converts `frames` frames of `fmt` to float.
void ToFloat(const uint8_t* src, PcmFormat fmt, size_t samples, float* dst) {
  switch (fmt) {
    case PcmFormat::kU8:
      for (size_t i = 0; i < samples; i++) dst[i] = (static_cast<int>(src[i]) - 128) / 128.0f;
      break;
    case PcmFormat::kS16: {
      for (size_t i = 0; i < samples; i++) {
        int16_t v;
        memcpy(&v, src + 2 * i, 2);
        dst[i] = v / 32768.0f;
      }
      break;
    }
    case PcmFormat::kS24Packed:
      for (size_t i = 0; i < samples; i++) {
        const uint8_t* p = src + 3 * i;
        int32_t v = static_cast<int32_t>((static_cast<uint32_t>(p[0]) << 8) |
                                         (static_cast<uint32_t>(p[1]) << 16) |
                                         (static_cast<uint32_t>(p[2]) << 24)) >> 8;
        dst[i] = v / 8388608.0f;
      }
      break;
    case PcmFormat::kS32:
      for (size_t i = 0; i < samples; i++) {
        int32_t v;
        memcpy(&v, src + 4 * i, 4);
        dst[i] = static_cast<float>(v / 2147483648.0);
      }
      break;
    case PcmFormat::kFloat:
      memcpy(dst, src, samples * 4);
      break;
  }
}

}  // namespace

// Source frames (float, the track's channels) in, output frames out. The
// history starts with kHalfTaps-ish zeros, so the first output frame is
// centered on the first source frame.
struct Track::Resampler {
  explicit Resampler(uint32_t ch) : channels(ch) { Reset(); }

  void Reset() {
    hist.clear();
    width = 0;
    t = 0;
    start_index = 0;
    primed = false;
    real_end = -1;
    played_index = 0;
  }

  uint32_t channels;
  std::vector<float> hist;  // interleaved; hist frame 0 is source frame start_index
  // Mixing scratch belongs to this track and is protected by Track::mu_. Keep
  // its capacity through Reset() so each 10 ms block does not allocate again.
  std::vector<float> frame;
  std::vector<float> source;
  size_t width;             // half-width in source frames of the current filter
  double t;                 // the next output frame's center, in hist frames
  int64_t start_index;      // source index of hist frame 0 (negative while primed zeros)
  bool primed;
  int64_t real_end = -1;    // source index one past the last real frame, once ended
  int64_t played_index = 0; // source frames passed since the last Reset
  size_t frames() const { return hist.size() / channels; }
};


// The mixer is driven explicitly by the test, with no OS endpoint or background thread.
class Engine {
 public:
  void Remove(Track*) {}
  uint32_t out_rate() const { return 48000; }
  uint32_t latency_frames() const { return 0; }
};
void PostEvent(std::function<void()> event) { event(); }
Track::Track(Engine* engine, const TrackParams& params)
    : engine_(engine),
      params_(params),
      frame_size_(BytesPerSample(params.format) * params.channels),
      rate_(params.sample_rate),
      rs_(std::make_unique<Resampler>(params.channels)) {
  data_.resize(params.capacity_frames * frame_size_);
  buffer_frames_ = params.capacity_frames;
}

Track::~Track() = default;

void Track::SetEvents(TrackEvents events) {
  std::lock_guard<std::mutex> lock(mu_);
  events_ = std::move(events);
}

int Track::Start() {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (state_ == State::kPlaying) return kOk;
  if (state_ == State::kStopped || (state_ == State::kStopping && drained_)) {
    // As android::AudioTrack::start: from stopped, the position starts at 0.
    position_base_ = played_;
    next_update_ = update_period_;
    marker_reached_ = false;
    if (params_.is_static && state_ == State::kStopped) {
      // A stopped static track was rewound by stop().
    }
    rs_->Reset();
  }
  if (!params_.is_static && rs_->real_end >= 0) {
    // A draining resampler may have padded its right edge with silence. Resume
    // from its real history and phase, allowing newly primed frames past that
    // edge, including when pause() interrupted the drain before this start().
    size_t real_frames = static_cast<size_t>(
        std::max<int64_t>(0, rs_->real_end - rs_->start_index));
    rs_->hist.resize(std::min(real_frames, rs_->frames()) * rs_->channels);
    rs_->real_end = -1;
  }
  state_ = State::kPlaying;
  drained_ = false;
  was_underrun_ = false;
  end_signalled_ = false;
  room_.notify_all();
  return kOk;
}

void Track::Pause() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ == State::kPlaying || state_ == State::kStopping) {
    state_ = State::kPaused;
    ++write_interrupt_;
  }
  room_.notify_all();
}

void Track::Stop() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ != State::kPlaying && state_ != State::kPaused) return;
  ++write_interrupt_;
  if (params_.is_static) {
    state_ = State::kStopped;
    static_pos_ = 0;
    loop_start_ = loop_end_ = 0;
    loop_count_ = 0;
    position_base_ = played_;  // position 0
    rs_->Reset();
  } else if (state_ == State::kPlaying) {
    state_ = State::kStopping;
    stop_end_ = written_;
    drained_ = stop_end_ == read_ && rs_->frames() == 0;
    if (drained_) state_ = State::kStopped;
  } else if (state_ == State::kPaused) {
    // Paused data is dropped at stop (android::AudioTrack: stop from paused
    // flushes what was not played).
    state_ = State::kStopped;
    read_ = written_;
    stop_end_ = read_;
    rs_->Reset();
  }
  room_.notify_all();
}

void Track::Flush() {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static || state_ == State::kPlaying) return;
  read_ = written_;
  stop_end_ = read_;
  rs_->Reset();
  position_base_ = played_;
  marker_ = 0;
  marker_reached_ = false;
  update_period_ = 0;
  next_update_ = 0;
  if (state_ == State::kStopping) state_ = State::kStopped;
  room_.notify_all();
}

Track::State Track::state() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_;
}

bool Track::stopped() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_ == State::kStopped || (state_ == State::kStopping && drained_);
}

ssize_t Track::Write(const void* data, size_t bytes, bool blocking) {
  const uint8_t* src = static_cast<const uint8_t*>(data);
  size_t frames = bytes / frame_size_;
  std::unique_lock<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (params_.is_static) {
    size_t n = std::min(frames, params_.capacity_frames);
    memcpy(data_.data(), src, n * frame_size_);
    static_frames_ = n;
    static_pos_ = 0;
    return static_cast<ssize_t>(n * frame_size_);
  }
  size_t done = 0;
  const uint64_t interrupt = write_interrupt_;
  while (done < frames) {
    if (released_ || write_interrupt_ != interrupt) break;
    size_t limit = std::min(buffer_frames_, params_.capacity_frames);
    size_t queued = static_cast<size_t>(written_ - read_);
    size_t room = queued < limit ? limit - queued : 0;
    if (room == 0) {
      // Android makes writes nonblocking while stopped/paused. Priming before
      // play() may fill the buffer, but must not wait for a mixer that is idle.
      if (!blocking || state_ != State::kPlaying) break;
      room_.wait(lock);
      continue;
    }
    size_t n = std::min(room, frames - done);
    // Copy into the ring, in up to two pieces.
    size_t cap = params_.capacity_frames;
    size_t pos = static_cast<size_t>(written_ % cap);
    size_t first = std::min(n, cap - pos);
    memcpy(data_.data() + pos * frame_size_, src + done * frame_size_, first * frame_size_);
    if (n > first) {
      memcpy(data_.data(), src + (done + first) * frame_size_, (n - first) * frame_size_);
    }
    written_ += n;
    done += n;
  }
  return static_cast<ssize_t>(done * frame_size_);
}

int Track::SetLoop(uint32_t start, uint32_t end, int count) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (count == 0) {
    loop_count_ = 0;
    loop_start_ = loop_end_ = 0;
    return kOk;
  }
  if (start >= end || end > params_.capacity_frames) return kBadValue;
  loop_start_ = start;
  loop_end_ = end;
  loop_count_ = count;
  return kOk;
}

int Track::Reload() {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (state_ == State::kPlaying) return kInvalidOperation;
  static_pos_ = 0;
  position_base_ = played_;
  rs_->Reset();
  return kOk;
}

int Track::SetPosition(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static || state_ == State::kPlaying) return kInvalidOperation;
  if (frame > static_frames_) return kBadValue;
  static_pos_ = frame;
  position_base_ = played_ - frame;
  rs_->Reset();
  return kOk;
}

size_t Track::static_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_frames_;
}

uint32_t Track::Position() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(played_ - position_base_);
}

bool Track::Timestamp(int64_t* frames, int64_t* time_ns) const {
  std::lock_guard<std::mutex> lock(mu_);
  if (played_time_ns_ == 0) return false;
  *frames = static_cast<int64_t>(played_ - position_base_);
  // What was mixed last is heard after the sink's latency.
  uint32_t out_rate = engine_->out_rate();
  *time_ns = played_time_ns_ +
             (out_rate != 0 ? static_cast<int64_t>(engine_->latency_frames()) * 1000000000 / out_rate
                            : 0);
  return true;
}

int Track::SetMarker(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  marker_ = frame;
  marker_reached_ = frame == 0;
  return kOk;
}

uint32_t Track::marker() const {
  std::lock_guard<std::mutex> lock(mu_);
  return marker_;
}

int Track::SetUpdatePeriod(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  update_period_ = frames;
  uint64_t pos = played_ - position_base_;
  next_update_ = frames == 0 ? 0 : (pos / frames + 1) * frames;
  return kOk;
}

uint32_t Track::update_period() const {
  std::lock_guard<std::mutex> lock(mu_);
  return update_period_;
}

void Track::SetVolume(float left, float right) {
  std::lock_guard<std::mutex> lock(mu_);
  vol_left_ = std::clamp(left, 0.0f, 1.0f);
  vol_right_ = std::clamp(right, 0.0f, 1.0f);
}

int Track::SetSampleRate(uint32_t rate) {
  std::lock_guard<std::mutex> lock(mu_);
  if (rate == 0 || rate > params_.sample_rate * 2 * 8) return kBadValue;
  rate_ = rate;
  return kOk;
}

uint32_t Track::sample_rate() const {
  std::lock_guard<std::mutex> lock(mu_);
  return rate_;
}

void Track::SetSpeed(float speed) {
  std::lock_guard<std::mutex> lock(mu_);
  speed_ = std::clamp(speed, 0.01f, 16.0f);
}

float Track::speed() const {
  std::lock_guard<std::mutex> lock(mu_);
  return speed_;
}

uint32_t Track::buffer_size_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(params_.is_static ? params_.capacity_frames : buffer_frames_);
}

int Track::SetBufferSizeFrames(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static) return kInvalidOperation;
  buffer_frames_ = std::clamp<size_t>(frames, 1, params_.capacity_frames);
  room_.notify_all();
  return static_cast<int>(buffer_frames_);
}

uint32_t Track::underrun_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_frames_;
}

uint32_t Track::underrun_count() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_count_;
}

uint32_t Track::LatencyMs() const {
  uint32_t out_rate = engine_->out_rate();
  uint32_t sink_ms = out_rate != 0 ? engine_->latency_frames() * 1000 / out_rate : 0;
  std::lock_guard<std::mutex> lock(mu_);
  uint32_t buffer_ms =
      params_.is_static ? 0 : static_cast<uint32_t>(buffer_frames_ * 1000 / std::max(rate_, 1u));
  return sink_ms + buffer_ms;
}

bool Track::WaitForRoom(size_t frames, int timeout_ms) {
  std::unique_lock<std::mutex> lock(mu_);
  auto fits = [&] {
    if (released_ || params_.is_static) return true;
    size_t limit = std::min(buffer_frames_, params_.capacity_frames);
    size_t queued = static_cast<size_t>(written_ - read_);
    return queued + std::min(frames, limit) <= limit;
  };
  room_.wait_for(lock, std::chrono::milliseconds(timeout_ms), fits);
  return fits();
}

size_t Track::Queued() const {
  std::lock_guard<std::mutex> lock(mu_);
  return params_.is_static ? 0 : static_cast<size_t>(written_ - read_);
}

void Track::Release() {
  {
    std::lock_guard<std::mutex> lock(mu_);
    released_ = true;
    ++write_interrupt_;
    state_ = State::kStopped;
    room_.notify_all();
  }
  engine_->Remove(this);
}

// Mixing thread, with mu_ held.
size_t Track::ReadSource(float* dst, size_t frames, bool* ended) {
  *ended = false;
  size_t ch = params_.channels;
  size_t bps = BytesPerSample(params_.format);
  size_t done = 0;
  if (!params_.is_static) {
    const uint64_t end = state_ == State::kStopping ? stop_end_ : written_;
    size_t avail = static_cast<size_t>(end - read_);
    size_t n = std::min(avail, frames);
    size_t cap = params_.capacity_frames;
    while (done < n) {
      size_t pos = static_cast<size_t>(read_ % cap);
      size_t piece = std::min(n - done, cap - pos);
      ToFloat(data_.data() + pos * frame_size_, params_.format, piece * ch, dst + done * ch);
      read_ += piece;
      done += piece;
    }
    room_.notify_all();
    if (done == 0 && state_ == State::kStopping) *ended = true;
    return done;
  }
  while (done < frames) {
    bool looping = loop_count_ != 0 && loop_end_ > loop_start_ && static_pos_ <= loop_end_;
    size_t end = looping ? loop_end_ : static_frames_;
    if (static_pos_ >= end) {
      if (looping) {
        static_pos_ = loop_start_;
        if (loop_count_ > 0) loop_count_--;
        continue;
      }
      *ended = true;
      break;
    }
    size_t piece = std::min(frames - done, end - static_pos_);
    ToFloat(data_.data() + static_pos_ * frame_size_, params_.format, piece * ch, dst + done * ch);
    static_pos_ += piece;
    done += piece;
  }
  (void)bps;
  return done;
}

bool Track::MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels) {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_ || (state_ != State::kPlaying && state_ != State::kStopping) ||
      (state_ == State::kStopping && drained_)) {
    return false;
  }
  Resampler& rs = *rs_;
  const size_t ch = params_.channels;
  const double step = static_cast<double>(rate_) * speed_ / out_rate;
  const bool passthrough = step == 1.0;
  const double cutoff = step > 1.0 ? 1.0 / step * 0.97 : 1.0;
  const size_t width = passthrough ? 0 : static_cast<size_t>(std::ceil(kHalfTaps / cutoff));
  const float* table = KernelTable();

  if (!rs.primed || rs.width != width) {
    if (!rs.primed) {
      // Zeros before the first frame, so the filter has history.
      rs.hist.assign(width * ch, 0.0f);
      rs.start_index = -static_cast<int64_t>(width);
      rs.t = static_cast<double>(width);
      rs.real_end = -1;
      rs.primed = true;
    } else if (width > rs.width) {
      // A rate change can widen the filter beyond retained left-hand history
      // (especially just after startup or compaction). Preserve every real
      // sample and the absolute timeline, padding only unavailable past taps.
      const int64_t first = static_cast<int64_t>(std::floor(rs.t)) -
                            static_cast<int64_t>(width) + 1;
      if (first < 0) {
        const size_t missing = static_cast<size_t>(-first);
        rs.hist.insert(rs.hist.begin(), missing * ch, 0.0f);
        rs.t += static_cast<double>(missing);
        rs.start_index -= static_cast<int64_t>(missing);
      }
    }
    rs.width = width;
  }

  uint64_t played_before = played_;
  std::vector<float>& frame = rs.frame;
  frame.resize(ch);
  std::vector<float>& tmp = rs.source;
  size_t out_done = 0;
  bool ended = false;
  bool starved = false;
  // Volume changes ramp linearly over the block (no clicks).
  const float gl = vol_left_, gr = vol_right_;
  float al = applied_left_, ar = applied_right_;
  const float dl = (gl - al) / static_cast<float>(std::max<size_t>(frames, 1));
  const float dr = (gr - ar) / static_cast<float>(std::max<size_t>(frames, 1));

  auto mix_frame = [&](const float* samples) {
    al += dl;
    ar += dr;
    float* o = mix + out_done * out_channels;
    float l, r;
    if (ch == 1) {
      l = r = samples[0];
    } else if (ch == 2) {
      l = samples[0];
      r = samples[1];
    } else {
      // FL FR FC LFE BL BR SL SR ...: the center and the surrounds at -3 dB.
      constexpr float k = 0.7071f;
      l = samples[0];
      r = samples[1];
      if (ch > 2) { l += k * samples[2]; r += k * samples[2]; }
      for (size_t c = 4; c + 1 < ch && c < 8; c += 2) { l += k * samples[c]; r += k * samples[c + 1]; }
    }
    l *= al;
    r *= ar;
    if (out_channels == 1) {
      o[0] += 0.5f * (l + r);
    } else {
      o[0] += l;
      o[1] += r;
    }
    ++out_done;
  };

  while (out_done < frames) {
    int64_t center = static_cast<int64_t>(std::floor(rs.t));
    size_t need = static_cast<size_t>(center + static_cast<int64_t>(width) + 1);
    while (rs.frames() < need) {
      if (rs.real_end >= 0) {
        // Ended: zeros flush the filter.
        rs.hist.insert(rs.hist.end(), (need - rs.frames()) * ch, 0.0f);
        break;
      }
      size_t want = std::max<size_t>(need - rs.frames(), 256);
      tmp.resize(want * ch);
      bool src_ended = false;
      size_t got = ReadSource(tmp.data(), want, &src_ended);
      rs.hist.insert(rs.hist.end(), tmp.begin(), tmp.begin() + got * ch);
      if (got == 0) {
        if (src_ended) {
          rs.real_end = rs.start_index + static_cast<int64_t>(rs.frames());
          continue;
        }
        starved = true;
        break;
      }
    }
    if (starved) break;
    if (rs.real_end >= 0 && rs.start_index + center >= rs.real_end) {
      ended = true;
      break;
    }
    if (passthrough) {
      // Unity-rate output already has contiguous source frames. Keep the
      // existing read-ahead and history, but check availability once per span
      // instead of once per output frame. A fractional phase left by a rate
      // change keeps the single-frame path: rounding when adding 1 near an
      // integer boundary can otherwise skip a source frame. The bounded
      // integral span advances exactly, including in floating-point arithmetic.
      size_t count = 1;
      if (rs.t == static_cast<double>(center) && rs.t < 0x1p52) {
        count = std::min({frames - out_done, rs.frames() - static_cast<size_t>(center), size_t{256}});
      }
      if (rs.real_end >= 0) {
        count = std::min(count, static_cast<size_t>(rs.real_end - rs.start_index - center));
      }
      const float* samples = rs.hist.data() + static_cast<size_t>(center) * ch;
      for (size_t i = 0; i < count; ++i) {
        mix_frame(samples);
        samples += ch;
        rs.t += 1.0;
      }
    } else {
      std::fill(frame.begin(), frame.end(), 0.0f);
      for (int64_t k = center - static_cast<int64_t>(width) + 1;
           k <= center + static_cast<int64_t>(width); k++) {
        float w = Kernel(table, (rs.t - static_cast<double>(k)) * cutoff) * static_cast<float>(cutoff);
        if (w == 0) continue;
        const float* s = &rs.hist[static_cast<size_t>(k) * ch];
        for (size_t c = 0; c < ch; c++) frame[c] += s[c] * w;
      }
      mix_frame(frame.data());
      rs.t += step;
    }
  }
  applied_left_ = gl;
  applied_right_ = gr;

  // Played: source frames whose center the filter passed.
  int64_t center_index = rs.start_index + static_cast<int64_t>(std::floor(rs.t));
  if (rs.real_end >= 0) center_index = std::min(center_index, rs.real_end);
  // played_ counts frames since the track was created; the resampler's index
  // restarts at each Reset, so advance by the difference.
  if (center_index > rs.played_index) {
    played_ += static_cast<uint64_t>(center_index - rs.played_index);
    rs.played_index = center_index;
  }
  played_time_ns_ = MonotonicNs();

  // Starved for a while (an underrun, or a writer that stopped writing without
  // stop()): the frames the filter still holds back count as played, and the
  // resampler starts over with the next data. Otherwise the last few frames
  // would wait for data that may never come (AAudio's getFramesRead, a
  // position that must reach what was written).
  if (starved && out_done == 0 && rs.primed) {
    if (starved_since_ns_ < 0) starved_since_ns_ = played_time_ns_;
    // Preserve the 10 ms grace between empty mixes when the device asks
    // for frames more often than the engine's periodic timer.
    if (played_time_ns_ - starved_since_ns_ >= 10'000'000) {
      int64_t end = rs.start_index + static_cast<int64_t>(rs.frames());
      if (end > rs.played_index) played_ += static_cast<uint64_t>(end - rs.played_index);
      rs.Reset();
      starved_since_ns_ = -1;
    }
  } else if (!starved) {
    starved_since_ns_ = -1;
  }

  // Drop history the filter no longer needs.
  int64_t keep_from = static_cast<int64_t>(std::floor(rs.t)) - static_cast<int64_t>(width) - 1;
  if (keep_from > 4096) {
    rs.hist.erase(rs.hist.begin(), rs.hist.begin() + keep_from * static_cast<int64_t>(ch));
    rs.t -= static_cast<double>(keep_from);
    rs.start_index += keep_from;
  }

  if (starved && out_done < frames && state_ == State::kPlaying && played_ > position_base_) {
    underrun_frames_ += static_cast<uint32_t>((frames - out_done) * rate_ / out_rate);
    if (!was_underrun_) {
      was_underrun_ = true;
      ++underrun_count_;
      if (events_.underrun) PostEvent(events_.underrun);
    }
  } else if (out_done == frames) {
    was_underrun_ = false;
  }

  bool was_ended = end_signalled_;
  if (ended) {
    if (state_ == State::kStopping) {
      drained_ = true;
      state_ = State::kStopped;
    } else {
      // A static track at its end stays "playing" (as Android's), silent.
      state_ = params_.is_static ? State::kPlaying : state_;
    }
    room_.notify_all();
    if (events_.end && !end_signalled_) {
      end_signalled_ = true;
      PostEvent(events_.end);
    }
  } else {
    end_signalled_ = false;
  }
  QueueEvents(played_before - position_base_, played_ - position_base_);
  return out_done > 0 || (ended && !was_ended);
}

void Track::QueueEvents(uint64_t before, uint64_t after) {
  if (after <= before) return;
  if (!marker_reached_ && marker_ != 0 && before < marker_ && after >= marker_) {
    marker_reached_ = true;
    if (events_.marker) {
      auto fn = events_.marker;
      uint32_t m = marker_;
      PostEvent([fn, m] { fn(m); });
    }
  }
  if (update_period_ != 0 && next_update_ != 0) {
    while (after >= next_update_) {
      if (events_.new_position) {
        auto fn = events_.new_position;
        uint32_t p = static_cast<uint32_t>(next_update_);
        PostEvent([fn, p] { fn(p); });
      }
      next_update_ += update_period_;
    }
  }
}

}  // namespace gesher::media



using namespace gesher::media;
using namespace std::chrono_literals;
int main() {
 Engine engine; TrackParams params;params.channels=1;params.sample_rate=48000;params.capacity_frames=960;
 Track track(&engine,params);std::vector<int16_t> pcm(14400);
 for(size_t i=0;i<pcm.size();++i)pcm[i]=static_cast<int16_t>(16383.5*std::sin(2*3.14159265358979323846*750*i/48000));
 track.Start();auto writer=std::async(std::launch::async,[&]{return track.Write(pcm.data(),pcm.size()*sizeof(int16_t),true);});
 const auto deadline=std::chrono::steady_clock::now()+2s;
 while(track.room_.waits.load()==0 && std::chrono::steady_clock::now()<deadline)std::this_thread::yield();
 if(track.room_.waits.load()==0){track.Release();writer.wait();return 2;}
 {std::lock_guard<std::mutex> lock(track.mu_);if(track.written_!=960||track.read_!=0){track.released_=true;track.room_.notify_all();return 3;}}
 // One actual MixInto request below ClockedSink's unmodified4,800-frame cap.
 // Writer is already in actual blocking Write with all14,400 source frames.
 std::vector<float> mixed(1406*2);bool played=track.MixInto(mixed.data(),1406,48000,2);
 size_t different=0;
 for(size_t i=0;i<960;++i)for(size_t c=0;c<2;++c)if(mixed[i*2+c]!=pcm[i]/32768.0f)++different;
 size_t nonzero_tail=0;for(size_t i=960*2;i<mixed.size();++i)if(mixed[i]!=0)++nonzero_tail;
 uint32_t underrun;uint64_t position;{std::lock_guard<std::mutex> lock(track.mu_);underrun=track.underrun_frames_;position=track.played_;}
 track.Release();if(writer.wait_for(2s)!=std::future_status::ready)return 4;auto transferred=writer.get();
 std::printf("{\"actual_request_frames\":1406,\"actual_ring_frames\":960,\"source_ready_frames\":14400,\"real_pcm_mismatches\":%zu,\"zero_tail_frames\":446,\"tail_nonzero_samples\":%zu,\"underrun_frames\":%u,\"source_position\":%llu,\"writer_transferred_bytes_before_release\":%lld,\"played\":%s}\n",different,nonzero_tail,underrun,(unsigned long long)position,(long long)transferred,played?"true":"false");
 return !played || different || nonzero_tail || underrun!=446 || position!=960;
}
