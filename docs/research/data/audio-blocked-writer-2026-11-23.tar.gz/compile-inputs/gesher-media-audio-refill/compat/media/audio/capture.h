// Gesher: the audio input of an app process (docs/media.md "Recording", ADR 0059).
//
// Every recorder an app opens (AudioRecord, AAudio and OpenSL ES input,
// MediaRecorder's audio) is a CaptureStream of this process's capture engine.
// The engine's thread takes what the input source gives, every 10 ms, and
// hands it to each started stream, converted to the stream's rate (linear
// interpolation), channels and PCM format. Normal builds use the actual
// default WASAPI capture endpoint. Initialization/start failure is reported;
// device loss becomes a terminal error, without substituting another input.
//
// Only the separately built GESHER_CAPTURE_TEST_SOURCES fixture role accepts
// GESHER_AUDIO_SOURCE=<file.wav>, loopback or null. Its explicitly selected
// synthetic inputs are unavailable to ordinary applications and releases.
//
// Nothing here knows Java: the JNI and NDK layers sit on top.
#pragma once

#include <sys/types.h>

#include <atomic>
#include <condition_variable>
#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

#include "engine.h"

namespace gesher::media {

struct CaptureParams {
  uint32_t sample_rate = 48000;
  uint32_t channels = 1;
  PcmFormat format = PcmFormat::kS16;
  size_t capacity_frames = 0;  // the stream's buffer (0: half a second)
  int source = 1;              // MediaRecorder.AudioSource (MIC), for logs
  std::string name;            // for logs
};

// What a stream tells its owner; called on the capture thread, in order.
struct CaptureEvents {
  std::function<void(uint32_t position)> marker;
  std::function<void(uint32_t position)> new_position;
  // Data arrived (frames now available), for callback-driven readers.
  std::function<void()> data;
};

inline constexpr int kCaptureUnavailable = -19; // Android native NO_INIT (-ENODEV).
inline constexpr int kCaptureDeadObject = -32; // Android native DEAD_OBJECT (-EPIPE).

class CaptureEngine;

struct CaptureStats {
  uint64_t captured_frames = 0, read_frames = 0;
  uint32_t lost_frames = 0, overruns = 0;
  int64_t timestamp_ns = 0;
};

class CaptureStream {
 public:
  ~CaptureStream();

  const CaptureParams& params() const { return params_; }
  size_t frame_size() const { return frame_size_; }

  void SetEvents(CaptureEvents events);

  int Start();
  void Stop();
  bool started() const;
  int error() const;

  // Lifecycle/error observers snapshot this sequence before checking their
  // predicates, then wait without holding either the API or capture mutex.
  // A change between the check and wait cannot lose its notification. API
  // lifecycle changes can use the same wake without a callback into the API.
  uint64_t StateWakeSequence() const;
  void WaitForStateWake(uint64_t observed) const;
  void NotifyStateWake();

  // Copies up to `bytes` (whole frames) of what was captured; with `blocking`,
  // waits until that much is there or the stream stops. Returns the bytes
  // read (0 when stopped and empty) or an error.
  ssize_t Read(void* dst, size_t bytes, bool blocking);
  // Frames captured and not read yet.
  size_t Available() const;
  // Waits until `frames` are there (or the stream stops), at most timeout_ms.
  bool WaitForData(size_t frames, int timeout_ms);

  // Frames ever read (the record position) and captured.
  uint64_t frames_read() const;
  uint64_t frames_captured() const;
  // The frame captured last and the CLOCK_MONOTONIC time it was captured at.
  bool Timestamp(int64_t* frames, int64_t* time_ns) const;
  uint32_t overrun_frames() const;
  // Cumulative transitions into overrun, distinct from the frames discarded.
  uint32_t overrun_count() const;
  // A coherent diagnostic snapshot; collection and buffering are unchanged.
  CaptureStats stats() const;
  size_t capacity_frames() const { return params_.capacity_frames; }

  int SetMarker(uint32_t frame);
  uint32_t marker() const;
  int SetUpdatePeriod(uint32_t frames);
  uint32_t update_period() const;

  // Detaches the stream from the engine; blocked readers return.
  void Release();

 private:
  friend class CaptureEngine;
  friend std::shared_ptr<CaptureStream> OpenCapture(const CaptureParams&, std::string*);
  CaptureStream(CaptureEngine* engine, const CaptureParams& params);

  // Capture thread: `frames` frames of the source (float, src_channels
  // interleaved, at src_rate) arrive.
  void Push(const float* src, size_t frames, uint32_t src_rate, uint32_t src_channels,
            int64_t now_ns, std::optional<uint64_t> generation = std::nullopt);

  int Activate(uint64_t generation);
  void Fail(int error);

  CaptureEngine* engine_;
  CaptureParams params_;
  size_t frame_size_;

  mutable std::mutex mu_;
  std::condition_variable cv_;
  std::atomic<uint64_t> state_wake_sequence_{0};
  bool started_ = false, released_ = false;
  int error_ = kOk;
  uint64_t generation_ = 0;
  std::vector<uint8_t> ring_;
  uint64_t written_ = 0, read_ = 0;  // frames
  uint32_t overruns_ = 0;
  uint32_t overrun_count_ = 0;
  bool was_overrun_ = false;
  int64_t last_ns_ = 0;
  // The resampler's state: the fractional source position and the last frame.
  double phase_ = 0;
  std::vector<float> last_;
  // Protected by mu_; at most the ring's capacity of converted frames.
  std::vector<float> converted_;
  std::array<float, 8> current_frame_{}, previous_frame_{};
  bool primed_ = false;
  uint32_t marker_ = 0;
  bool marker_reached_ = false;
  uint32_t update_period_ = 0;
  uint64_t next_update_ = 0;
  CaptureEvents events_;
};

std::shared_ptr<CaptureStream> OpenCapture(const CaptureParams& params, std::string* error);

// The input, for AudioManager and AudioSystem's answers.
struct InputInfo {
  bool device = false;      // a real input device (a microphone, loopback or the file)
  uint32_t sample_rate = 48000;
  uint32_t channels = 1;
  std::string description;  // "WASAPI shared mode capture on ...", "file ...", "none: ..."
  std::string device_name;
  int device_type = 0x80000004;  // AUDIO_DEVICE_IN_BUILTIN_MIC
};
InputInfo GetInputInfo();

// The minimum buffer a recorder needs at a rate (frames): two capture periods.
size_t MinCaptureFrames(uint32_t rate);

// Converts float samples to `format` (interleaved), `count` samples.
void FloatToPcm(const float* src, size_t count, PcmFormat format, void* dst);

// --- Sources (capture_wasapi.cc, capture.cc) -----------------------------------------

class CaptureSource {
 public:
  virtual ~CaptureSource() = default;
  virtual uint32_t rate() const = 0;
  virtual uint32_t channels() const = 0;
  virtual std::string Describe() const = 0;
  virtual std::string DeviceName() const = 0;
  // Starts (or restarts) capturing; false when it cannot.
  virtual bool Start() = 0;
  virtual void Stop() = 0;
  // What arrived since the last call, as float frames, appended to `out`.
  // False when the source is gone.
  virtual bool Pull(std::vector<float>* out) = 0;
};

// WASAPI shared mode on the default capture endpoint, or (loopback) the
// default render endpoint's loopback; null with `error` when there is none.
std::unique_ptr<CaptureSource> OpenWasapiCapture(bool loopback, std::string* error);
// Whether the default capture endpoint exists (without opening it).
bool HasWasapiCaptureEndpoint(std::string* name);
// COM for the calling thread (the multithreaded apartment).
void CaptureComInit();

}  // namespace gesher::media
