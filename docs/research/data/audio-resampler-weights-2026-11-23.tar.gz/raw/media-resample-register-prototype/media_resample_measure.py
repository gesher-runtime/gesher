#!/usr/bin/env python3
"""Retain every ordinary process/phase and validate full-transfer identities."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics
import subprocess

BASE = Path('/workspace/scratch/aa09b1a0dc1f')
BIN = BASE / 'media-resample-pilot'
CASES = [
    ('mono_44100_stream', ['1', '44100', '48000', '14400', '1', '1']),
    ('stereo_44100_stream', ['2', '44100', '48000', '14400', '1', '1']),
    ('stereo_96000_stream', ['2', '96000', '48000', '14400', '1', '1']),
    ('stereo_half_speed_stream', ['2', '48000', '48000', '14400', '.5', '1']),
    ('stereo_fast_static', ['2', '48000', '48000', '14400', '1.5', '0']),
    ('stereo_unity_stream', ['2', '48000', '48000', '14400', '1', '1']),
    ('eight_44100_stream', ['8', '44100', '48000', '14400', '1', '1']),
    ('stereo_short_stream', ['2', '44100', '48000', '64', '1', '1']),
    ('mono_one_static', ['1', '44100', '48000', '1', '1', '0']),
]


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--blocks', type=int, default=1)
    p.add_argument('--cycles', type=int, default=8)
    p.add_argument('--smoke', action='store_true')
    args = p.parse_args()
    payload = {'start_utc': timestamp(), 'scope': 'actual Track construction/input/complete mix/end/Release/destruction plus all-output hash; input and output buffer preparation excluded',
               'mode': 'smoke-under-uncontrolled-load' if args.smoke else 'ordinary-ABBA',
               'build': json.loads((BIN / 'build.json').read_text()), 'processes': []}
    identities = {}
    for block in range(args.blocks):
        for name, case in CASES[block % len(CASES):] + CASES[:block % len(CASES)]:
            order = ['baseline', 'candidate'] if args.smoke else ['baseline', 'candidate', 'candidate', 'baseline']
            for slot, variant in enumerate(order):
                command = [str(BIN / variant), *case, str(args.cycles), '128']
                started = timestamp()
                result = subprocess.run(command, text=True, capture_output=True, timeout=60)
                record = {'block': block, 'slot': slot, 'case': name, 'variant': variant,
                          'start_utc': started, 'end_utc': timestamp(), 'command': command,
                          'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
                payload['processes'].append(record)
                args.output.write_text(json.dumps(payload, indent=2) + '\n')
                assert result.returncode == 0 and not result.stderr, record
                rows = [json.loads(line) for line in result.stdout.splitlines()]
                assert [x['phase'] for x in rows] == ['first', 'steady'], record
                record['rows'] = rows
                for row in rows:
                    key = (name, row['phase'])
                    identity = {k: v for k, v in row.items() if k not in ['cpu_ns', 'wall_ns']}
                    if key in identities:
                        assert identities[key] == identity, (key, identity, identities[key])
                    else:
                        identities[key] = identity
                print(block, name, slot, variant, 'PASS', flush=True)
    payload['end_utc'] = timestamp()
    payload['binary_hashes'] = {label: hashlib.sha256((BIN / label).read_bytes()).hexdigest()
                                for label in ['baseline', 'candidate']}
    summaries = []
    for name, _ in CASES:
        for phase in ['first', 'steady']:
            row = {'case': name, 'phase': phase}
            for metric in ['cpu_ns', 'wall_ns']:
                values = {variant: [r[metric] / r['cycles'] for proc in payload['processes']
                                    if proc['variant'] == variant and proc['case'] == name
                                    for r in proc['rows'] if r['phase'] == phase]
                          for variant in ['baseline', 'candidate']}
                medians = {k: statistics.median(v) for k, v in values.items()}
                row[metric] = {'median': medians, 'change_percent': (medians['candidate'] / medians['baseline'] - 1) * 100}
            summaries.append(row)
    payload['summaries'] = summaries
    args.output.write_text(json.dumps(payload, indent=2) + '\n')
    for row in summaries:
        print(row['case'], row['phase'], 'CPU', round(row['cpu_ns']['change_percent'], 3),
              'wall', round(row['wall_ns']['change_percent'], 3), flush=True)


if __name__ == '__main__':
    main()
