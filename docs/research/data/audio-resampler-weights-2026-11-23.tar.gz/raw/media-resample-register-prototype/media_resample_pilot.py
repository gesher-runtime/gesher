#!/usr/bin/env python3
"""Build ordinary complete-Track pilot variants; no allocation overrides."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

BASE = Path('/workspace/scratch/aa09b1a0dc1f')
ROOT = BASE / 'gesher-media-resample-channels'
OUT = BASE / 'media-resample-pilot'
REF = 'bcfb5044029d486e17138dc417f3ced81524cf3f'


def build():
    OUT.mkdir(exist_ok=True)
    sys.path.insert(0, str(ROOT / 'tools'))
    from test_audio_state_contracts import generate
    wrappers = (BASE / 'media_resample_pilot_wrappers.cc').read_text()
    driver = BASE / 'media_resample_pilot_driver.cc'
    common = BASE / 'media_resample_pilot.h'
    metadata = {'baseline': REF, 'commands': [], 'inputs': {}}
    for label, ref in [('baseline', REF), ('candidate', None)]:
        source = generate('audio', ref)
        boundary = 'namespace {\nusing namespace gesher::media;'
        assert source.count(boundary) == 1
        source = source[:source.index(boundary)]
        assert source.count('ObservedConditionVariable room_;') == 1
        # The ordinary workload has no scheduling hooks. Restore the exact
        # production CV type instead of carrying the contract fixture counters.
        source = source.replace('ObservedConditionVariable room_;', 'std::condition_variable room_;')
        cpp = OUT / (label + '.cc')
        cpp.write_text(source + wrappers)
        obj = OUT / (label + '.o')
        binary = OUT / label
        compile_command = ['c++', '-std=c++20', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
                           '-fno-exceptions', '-pthread', '-I' + str(BASE), '-c', str(cpp), '-o', str(obj)]
        link_command = ['c++', '-std=c++20', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
                        '-fno-exceptions', '-pthread', '-I' + str(BASE), str(driver), str(obj), '-o', str(binary)]
        for command in [compile_command, link_command]:
            subprocess.run(command, check=True, timeout=120)
            metadata['commands'].append(command)
        metadata['inputs'][label] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in [cpp, obj, binary, driver, common]}
    (OUT / 'build.json').write_text(json.dumps(metadata, indent=2) + '\n')


if __name__ == '__main__':
    build()
