// Complete production Track methods and the maintained Engine/clock boundary.
// The scalar oracle uses the unchanged sinc table; the second executable runs
// the complete original source and compares every output/state transcript byte.
#include <array>
#include <bit>
#include <cfenv>
#include <cstdlib>
#include <limits>

namespace { thread_local size_t resampler_kernel_calls = 0; }
// Production source SHA256: 4cf8e5614bce9aa4bfda7a324f4ed7c0f39e7c47a0dba0914063ecf6518875be
// Engine attachment/output clock and CV scheduling boundaries; all Track methods are production.
#include <sys/types.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <time.h>

// Clock transport for the Linux lifecycle fixture. Suspend semantics are
// exercised with the actual adapter in tools/test_clock_domains.py.
namespace gesher {
// The unity-rate transcript advances this by one nominal period per mix.
// Lifecycle checks leave it disabled and use the host clock.
inline thread_local int64_t fixture_playback_ns = -1;
inline int AndroidClockGettime(clockid_t clock, timespec* value) {
  if (clock == CLOCK_MONOTONIC && fixture_playback_ns >= 0) {
    value->tv_sec = fixture_playback_ns / 1000000000;
    value->tv_nsec = fixture_playback_ns % 1000000000;
    return 0;
  }
  return clock_gettime(clock, value);
}
inline int64_t MonotonicNanos() {
  timespec value;
  clock_gettime(CLOCK_MONOTONIC, &value);
  return static_cast<int64_t>(value.tv_sec) * 1000000000 + value.tv_nsec;
}
}

class ObservedConditionVariable {
 public:
  std::atomic<unsigned> waits{0};
  std::function<void()> before_reacquire;
  void notify_all() { cv_.notify_all(); }
  void wait(std::unique_lock<std::mutex>& lock) {
    ++waits;
    if (Hook(lock)) return;
    cv_.wait(lock);
  }
  template<class Rep, class Period>
  std::cv_status wait_for(std::unique_lock<std::mutex>& lock,
                          const std::chrono::duration<Rep, Period>& duration) {
    ++waits;
    if (Hook(lock)) return std::cv_status::no_timeout;
    return cv_.wait_for(lock, duration);
  }
  template<class Rep, class Period, class Predicate>
  bool wait_for(std::unique_lock<std::mutex>& lock,
                const std::chrono::duration<Rep, Period>& duration, Predicate predicate) {
    return cv_.wait_for(lock, duration, predicate);
  }
 private:
  bool Hook(std::unique_lock<std::mutex>& lock) {
    if (!before_reacquire) return false;
    auto hook = std::move(before_reacquire);
    lock.unlock();
    hook();
    lock.lock();
    return true;
  }
  std::condition_variable cv_;
};

// Gesher: the audio output of an app process (docs/media.md, ADR 0042).
//
// Every sound an app makes (AudioTrack, MediaPlayer, SoundPool, AAudio,
// OpenSL ES) is a Track of this process's Engine. The engine's thread mixes
// the tracks at the output's rate, one mix per Android stream volume group
// (media, ring, alarm, notification, call), and hands the mixes to the sink:
//
//  - WASAPI, shared mode: one render stream per group in use, each its own
//    Windows audio session ("<app> (Alarm)"), whose volume is the Android
//    stream volume of the group (shared_state.h; the Windows volume mixer
//    changes it back);
//  - a capture file (GESHER_AUDIO_CAPTURE): the groups mixed into one WAV,
//    paced by the clock as a device would be, with the stream volumes
//    applied in software (what the volume mixer would do), for tests on
//    machines without an audio endpoint;
//  - nothing, paced by the clock, when no endpoint opens (or GESHER_AUDIO=null).
//
// Tracks are format-converted (8/16/24/32-bit PCM, float), resampled from any
// rate (windowed sinc), channel-mapped to the output and mixed in float.
// Nothing here knows Java: the JNI layers sit on top (compat/media/jni).


#include <sys/types.h>

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace gesher::media {

// AudioDeviceInfo and the native routing getters use the same process-local IDs.
constexpr int kOutputDeviceId = 2;
constexpr int kInputDeviceId = 3;

enum class PcmFormat : int { kU8, kS16, kS24Packed, kS32, kFloat };

size_t BytesPerSample(PcmFormat f);

// Android's stream types (AudioSystem.STREAM_*) and their volume groups:
// a stream plays at the volume of its alias (AudioService's
// STREAM_VOLUME_ALIAS_DEFAULT on a phone).
constexpr int kNumStreamTypes = 12;  // STREAM_VOICE_CALL (0) .. STREAM_ASSISTANT (11)
int StreamAlias(int stream);
// The volume groups, by alias: the streams that alias to themselves.
constexpr int kNumGroups = 5;
int GroupOfStream(int stream);       // 0..kNumGroups-1
int StreamOfGroup(int group);        // the alias stream of a group
const char* GroupName(int group);    // "Media", "Ringtone", ...

// Status codes, as Android's (AudioSystem.SUCCESS, ERROR, BAD_VALUE, ...).
constexpr int kOk = 0;
constexpr int kError = -1;
constexpr int kBadValue = -2;
constexpr int kInvalidOperation = -3;
constexpr int kWouldBlock = -7;

struct TrackParams {
  uint32_t sample_rate = 48000;
  uint32_t channels = 2;
  PcmFormat format = PcmFormat::kS16;
  int stream_type = 3;          // STREAM_MUSIC
  size_t capacity_frames = 0;   // the stream's buffer, or the static buffer's size
  bool is_static = false;
  int session_id = 0;
  std::string name;             // for logs
};

// What a track tells its owner; called on the engine's event thread (never
// the mixing thread), in order.
struct TrackEvents {
  std::function<void(uint32_t position)> marker;        // the marker was played
  std::function<void(uint32_t position)> new_position;  // one more update period
  std::function<void()> end;                            // the data ran out (static end, stop drained)
  std::function<void()> underrun;                       // streaming, playing, no data
};

class Engine;

class Track : public std::enable_shared_from_this<Track> {
 public:
  enum class State { kStopped, kPlaying, kStopping, kPaused };

  ~Track();

  const TrackParams& params() const { return params_; }
  size_t frame_size() const { return frame_size_; }

  void SetEvents(TrackEvents events);

  // Playback control, as android::AudioTrack's.
  int Start();
  void Pause();
  // Streaming: drains the data present at stop; later writes prime the next start.
  // Static: stops at once and rewinds.
  void Stop();
  // Streaming, stopped or paused: drops what was not played; position 0.
  void Flush();
  State state() const;
  bool stopped() const;  // stopped, or stopping and drained

  // Streaming: copies up to `bytes` (whole frames) into the buffer; with
  // `blocking`, waits for room until everything is written or the track is
  // stopped, paused or released. Returns the bytes written or an error.
  // Static: writes at the start of the static buffer (data loaded so far).
  ssize_t Write(const void* data, size_t bytes, bool blocking);

  // Static tracks.
  int SetLoop(uint32_t start, uint32_t end, int count);  // count -1: forever
  int Reload();                                          // rewind to 0
  int SetPosition(uint32_t frame);                       // stopped or paused only
  size_t static_frames() const;

  // Position: frames played since the start (uint32 wraps, as Android's).
  uint32_t Position() const;
  // Frames presented and the CLOCK_MONOTONIC time of that, for getTimestamp.
  bool Timestamp(int64_t* frames, int64_t* time_ns) const;
  int SetMarker(uint32_t frame);
  uint32_t marker() const;
  int SetUpdatePeriod(uint32_t frames);
  uint32_t update_period() const;

  void SetVolume(float left, float right);
  // The playback rate in Hz (setPlaybackRate) and speed (PlaybackParams);
  // pitch follows the speed (no time stretching).
  int SetSampleRate(uint32_t rate);
  uint32_t sample_rate() const;
  void SetSpeed(float speed);
  float speed() const;

  uint32_t buffer_capacity_frames() const { return static_cast<uint32_t>(params_.capacity_frames); }
  uint32_t buffer_size_frames() const;
  int SetBufferSizeFrames(uint32_t frames);
  uint32_t underrun_frames() const;
  // Cumulative transitions into underrun, distinct from the frames missing.
  uint32_t underrun_count() const;
  uint32_t LatencyMs() const;

  // Streaming: frames written and not yet played.
  size_t Queued() const;
  // Waits until rames frames fit in the buffer (signalled by the mixer as it
  // plays, not polled), at most timeout_ms; true if they fit. A feeder that
  // sleeps instead wakes late under load (Windows' 15.6 ms timer ticks) and lets
  // a small buffer run dry.
  bool WaitForRoom(size_t frames, int timeout_ms);

  // Detaches the track from the engine; blocked writers return.
  void Release();

 public:
  friend class Engine;
  friend std::shared_ptr<Track> CreateTrack(const TrackParams&, std::string*);
  Track(Engine* engine, const TrackParams& params);

  // Mixing thread: adds up to `frames` output frames at `out_rate` with
  // `out_channels` into `mix` (already scaled by the track's volume).
  // Returns false when the track has nothing to play.
  bool MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels);
  // Reads up to `frames` source frames as float (the track's channels).
  size_t ReadSource(float* dst, size_t frames, bool* ended);
  void QueueEvents(uint64_t before, uint64_t after);

  Engine* engine_;
  TrackParams params_;
  size_t frame_size_;

  mutable std::mutex mu_;
  std::condition_variable room_;  // signalled as frames are played, and on state changes
  State state_ = State::kStopped;
  bool released_ = false;
  bool drained_ = false;  // kStopping: all played
  // A writer must observe pause/stop even if start() runs before it reacquires mu_.
  uint64_t write_interrupt_ = 0;

  // Streaming ring, or static data.
  std::vector<uint8_t> data_;
  uint64_t written_ = 0;      // streaming: frames ever written
  uint64_t read_ = 0;         // streaming: frames ever taken by the resampler
  uint64_t stop_end_ = 0;     // kStopping: frozen source limit for this drain
  size_t buffer_frames_ = 0;  // streaming: setBufferSizeInFrames' limit
  size_t static_frames_ = 0;  // static: frames loaded
  size_t static_pos_ = 0;     // static: next frame to take
  uint32_t loop_start_ = 0, loop_end_ = 0;
  int loop_count_ = 0;

  // Played position (source frames), as the resampler passes them.
  uint64_t played_ = 0;
  uint64_t position_base_ = 0;  // subtracted from played_ for Position()
  int64_t played_time_ns_ = 0;
  uint32_t marker_ = 0;
  bool marker_reached_ = false;
  uint32_t update_period_ = 0;
  uint64_t next_update_ = 0;
  uint32_t underrun_frames_ = 0;
  uint32_t underrun_count_ = 0;
  bool was_underrun_ = false;
  bool end_signalled_ = false;
  int64_t starved_since_ns_ = -1;

  float vol_left_ = 1.0f, vol_right_ = 1.0f;
  float applied_left_ = 1.0f, applied_right_ = 1.0f;  // ramps toward vol_*
  uint32_t rate_;
  float speed_ = 1.0f;

  TrackEvents events_;
  struct Resampler;
  std::unique_ptr<Resampler> rs_;
};

std::shared_ptr<Track> CreateTrack(const TrackParams& params, std::string* error);

// The engine's output, for AudioSystem's answers.
struct OutputInfo {
  uint32_t sample_rate;
  uint32_t channels;
  uint32_t period_frames;   // the mixer's period
  uint32_t latency_frames;  // what the sink holds
  std::string description;  // "WASAPI shared mode, ...", "capture to ...", "none: ..."
  std::string device_name;  // the endpoint's friendly name
  int device_type;          // AUDIO_DEVICE_OUT_* of the endpoint's form factor
  uint32_t generation;      // changes when the output does
};
OutputInfo GetOutputInfo();

// Raises the calling thread's priority for audio work that feeds the engine
// (Android runs such threads at ANDROID_PRIORITY_AUDIO or SCHED_FIFO):
// `urgent` (an app's callback, a buffer queue's feeder) is
// THREAD_PRIORITY_HIGHEST, else (a player's decoder) ABOVE_NORMAL. Under load
// a normal-priority feeder may not run before the engine's time-critical
// mixer has played what the track holds.
void RaiseAudioThreadPriority(bool urgent);

// Runs `fn` on the engine's event thread (after earlier events).
void PostEvent(std::function<void()> fn);

// Streams with a track playing now (or within the last `in_past_ms`), on this
// device (every process; shared_state.h).
bool IsStreamActive(int stream, int in_past_ms);

// The process's application name for the Windows audio sessions
// ("<label> (Media)"); set by the JNI layer when it knows it.
void SetAppName(const std::u16string& name);

}  // namespace gesher::media

namespace gesher::media {

size_t BytesPerSample(PcmFormat f) {
  switch (f) {
    case PcmFormat::kU8: return 1;
    case PcmFormat::kS16: return 2;
    case PcmFormat::kS24Packed: return 3;
    case PcmFormat::kS32: return 4;
    case PcmFormat::kFloat: return 4;
  }
  return 2;
}

// --- Stream volume groups ----------------------------------------------------------------

namespace {

// STREAM_VOICE_CALL 0, SYSTEM 1, RING 2, MUSIC 3, ALARM 4, NOTIFICATION 5,
// BLUETOOTH_SCO 6, SYSTEM_ENFORCED 7, DTMF 8, TTS 9, ACCESSIBILITY 10, ASSISTANT 11:
// AudioService's STREAM_VOLUME_ALIAS_DEFAULT.
constexpr int kAlias[kNumStreamTypes] = {0, 2, 2, 3, 4, 5, 0, 2, 2, 3, 3, 3};
constexpr int kGroupStream[kNumGroups] = {3, 2, 4, 5, 0};
constexpr const char* kGroupName[kNumGroups] = {"Media", "Ringtone", "Alarm", "Notifications",
                                                "Calls"};

int64_t MonotonicNs() {
  timespec ts;
  gesher::AndroidClockGettime(CLOCK_MONOTONIC, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000000000 + ts.tv_nsec;
}

}  // namespace

int StreamAlias(int stream) {
  return stream >= 0 && stream < kNumStreamTypes ? kAlias[stream] : 3;
}

int GroupOfStream(int stream) {
  int a = StreamAlias(stream);
  for (int g = 0; g < kNumGroups; g++) {
    if (kGroupStream[g] == a) return g;
  }
  return 0;
}

int StreamOfGroup(int group) { return group >= 0 && group < kNumGroups ? kGroupStream[group] : 3; }

const char* GroupName(int group) {
  return group >= 0 && group < kNumGroups ? kGroupName[group] : "Media";
}

// --- The resampler -----------------------------------------------------------------------

namespace {

// A windowed sinc (Blackman-Harris) of kHalfTaps zero crossings each side,
// tabulated at kTableRes points per zero crossing.
constexpr int kHalfTaps = 12;
constexpr int kTableRes = 512;

const float* KernelTable() {
  static const std::vector<float> table = [] {
    std::vector<float> t(kHalfTaps * kTableRes + 2);
    for (size_t i = 0; i < t.size(); i++) {
      double x = static_cast<double>(i) / kTableRes;
      if (x >= kHalfTaps) {
        t[i] = 0;
        continue;
      }
      double sinc = x == 0 ? 1.0 : std::sin(M_PI * x) / (M_PI * x);
      double n = 0.5 + x / (2.0 * kHalfTaps);  // window over [-H, H] mapped to [0, 1]
      double w = 0.35875 - 0.48829 * std::cos(2 * M_PI * n) + 0.14128 * std::cos(4 * M_PI * n) -
                 0.01168 * std::cos(6 * M_PI * n);
      t[i] = static_cast<float>(sinc * w);
    }
    return t;
  }();
  return table.data();
}

inline float Kernel(const float* table, double x) {
  ++resampler_kernel_calls;
  x = std::fabs(x);
  if (x >= kHalfTaps) return 0;
  double p = x * kTableRes;
  size_t i = static_cast<size_t>(p);
  float f = static_cast<float>(p - static_cast<double>(i));
  return table[i] + (table[i + 1] - table[i]) * f;
}

int ExactHalfPhase(double position, int64_t center) {
  // Leave ample range for the bounded integral taps and an exact half-step.
  if (!(position >= 0 && position < 0x1p51)) return -1;
  const double fraction = position - static_cast<double>(center);
  return fraction == 0 ? 0 : fraction == 0.5 ? 1 : -1;
}

// Converts `frames` frames of `fmt` to float.
void ToFloat(const uint8_t* src, PcmFormat fmt, size_t samples, float* dst) {
  switch (fmt) {
    case PcmFormat::kU8:
      for (size_t i = 0; i < samples; i++) dst[i] = (static_cast<int>(src[i]) - 128) / 128.0f;
      break;
    case PcmFormat::kS16: {
      for (size_t i = 0; i < samples; i++) {
        int16_t v;
        memcpy(&v, src + 2 * i, 2);
        dst[i] = v / 32768.0f;
      }
      break;
    }
    case PcmFormat::kS24Packed:
      for (size_t i = 0; i < samples; i++) {
        const uint8_t* p = src + 3 * i;
        int32_t v = static_cast<int32_t>((static_cast<uint32_t>(p[0]) << 8) |
                                         (static_cast<uint32_t>(p[1]) << 16) |
                                         (static_cast<uint32_t>(p[2]) << 24)) >> 8;
        dst[i] = v / 8388608.0f;
      }
      break;
    case PcmFormat::kS32:
      for (size_t i = 0; i < samples; i++) {
        int32_t v;
        memcpy(&v, src + 4 * i, 4);
        dst[i] = static_cast<float>(v / 2147483648.0);
      }
      break;
    case PcmFormat::kFloat:
      memcpy(dst, src, samples * 4);
      break;
  }
}

}  // namespace

// Source frames (float, the track's channels) in, output frames out. The
// history starts with kHalfTaps-ish zeros, so the first output frame is
// centered on the first source frame.
struct Track::Resampler {
  explicit Resampler(uint32_t ch) : channels(ch) { Reset(); }

  void Reset() {
    hist.clear();
    width = 0;
    t = 0;
    start_index = 0;
    primed = false;
    real_end = -1;
    played_index = 0;
  }

  uint32_t channels;
  std::vector<float> hist;  // interleaved; hist frame 0 is source frame start_index
  // Mixing scratch belongs to this track and is protected by Track::mu_. Keep
  // its capacity through Reset() so each 10 ms block does not allocate again.
  std::vector<float> frame;
  std::vector<float> source;
  size_t width;             // half-width in source frames of the current filter
  double t;                 // the next output frame's center, in hist frames
  int64_t start_index;      // source index of hist frame 0 (negative while primed zeros)
  bool primed;
  int64_t real_end = -1;    // source index one past the last real frame, once ended
  int64_t played_index = 0; // source frames passed since the last Reset
  size_t frames() const { return hist.size() / channels; }
};


// The mixer is driven explicitly by the test, with no OS endpoint or background thread.
class Engine {
 public:
  void Remove(Track*) {}
  uint32_t out_rate() const { return 48000; }
  uint32_t latency_frames() const { return 0; }
};
void PostEvent(std::function<void()> event) { event(); }
Track::Track(Engine* engine, const TrackParams& params)
    : engine_(engine),
      params_(params),
      frame_size_(BytesPerSample(params.format) * params.channels),
      rate_(params.sample_rate),
      rs_(std::make_unique<Resampler>(params.channels)) {
  data_.resize(params.capacity_frames * frame_size_);
  buffer_frames_ = params.capacity_frames;
}

Track::~Track() = default;

void Track::SetEvents(TrackEvents events) {
  std::lock_guard<std::mutex> lock(mu_);
  events_ = std::move(events);
}

int Track::Start() {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (state_ == State::kPlaying) return kOk;
  if (state_ == State::kStopped || (state_ == State::kStopping && drained_)) {
    // As android::AudioTrack::start: from stopped, the position starts at 0.
    position_base_ = played_;
    next_update_ = update_period_;
    marker_reached_ = false;
    if (params_.is_static && state_ == State::kStopped) {
      // A stopped static track was rewound by stop().
    }
    rs_->Reset();
  }
  if (!params_.is_static && rs_->real_end >= 0) {
    // A draining resampler may have padded its right edge with silence. Resume
    // from its real history and phase, allowing newly primed frames past that
    // edge, including when pause() interrupted the drain before this start().
    size_t real_frames = static_cast<size_t>(
        std::max<int64_t>(0, rs_->real_end - rs_->start_index));
    rs_->hist.resize(std::min(real_frames, rs_->frames()) * rs_->channels);
    rs_->real_end = -1;
  }
  state_ = State::kPlaying;
  drained_ = false;
  was_underrun_ = false;
  end_signalled_ = false;
  room_.notify_all();
  return kOk;
}

void Track::Pause() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ == State::kPlaying || state_ == State::kStopping) {
    state_ = State::kPaused;
    ++write_interrupt_;
  }
  room_.notify_all();
}

void Track::Stop() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ != State::kPlaying && state_ != State::kPaused) return;
  ++write_interrupt_;
  if (params_.is_static) {
    state_ = State::kStopped;
    static_pos_ = 0;
    loop_start_ = loop_end_ = 0;
    loop_count_ = 0;
    position_base_ = played_;  // position 0
    rs_->Reset();
  } else if (state_ == State::kPlaying) {
    state_ = State::kStopping;
    stop_end_ = written_;
    drained_ = stop_end_ == read_ && rs_->frames() == 0;
    if (drained_) state_ = State::kStopped;
  } else if (state_ == State::kPaused) {
    // Paused data is dropped at stop (android::AudioTrack: stop from paused
    // flushes what was not played).
    state_ = State::kStopped;
    read_ = written_;
    stop_end_ = read_;
    rs_->Reset();
  }
  room_.notify_all();
}

void Track::Flush() {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static || state_ == State::kPlaying) return;
  read_ = written_;
  stop_end_ = read_;
  rs_->Reset();
  position_base_ = played_;
  marker_ = 0;
  marker_reached_ = false;
  update_period_ = 0;
  next_update_ = 0;
  if (state_ == State::kStopping) state_ = State::kStopped;
  room_.notify_all();
}

Track::State Track::state() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_;
}

bool Track::stopped() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_ == State::kStopped || (state_ == State::kStopping && drained_);
}

ssize_t Track::Write(const void* data, size_t bytes, bool blocking) {
  const uint8_t* src = static_cast<const uint8_t*>(data);
  size_t frames = bytes / frame_size_;
  std::unique_lock<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (params_.is_static) {
    size_t n = std::min(frames, params_.capacity_frames);
    memcpy(data_.data(), src, n * frame_size_);
    static_frames_ = n;
    static_pos_ = 0;
    return static_cast<ssize_t>(n * frame_size_);
  }
  size_t done = 0;
  const uint64_t interrupt = write_interrupt_;
  while (done < frames) {
    if (released_ || write_interrupt_ != interrupt) break;
    size_t limit = std::min(buffer_frames_, params_.capacity_frames);
    size_t queued = static_cast<size_t>(written_ - read_);
    size_t room = queued < limit ? limit - queued : 0;
    if (room == 0) {
      // Android makes writes nonblocking while stopped/paused. Priming before
      // play() may fill the buffer, but must not wait for a mixer that is idle.
      if (!blocking || state_ != State::kPlaying) break;
      room_.wait(lock);
      continue;
    }
    size_t n = std::min(room, frames - done);
    // Copy into the ring, in up to two pieces.
    size_t cap = params_.capacity_frames;
    size_t pos = static_cast<size_t>(written_ % cap);
    size_t first = std::min(n, cap - pos);
    memcpy(data_.data() + pos * frame_size_, src + done * frame_size_, first * frame_size_);
    if (n > first) {
      memcpy(data_.data(), src + (done + first) * frame_size_, (n - first) * frame_size_);
    }
    written_ += n;
    done += n;
  }
  return static_cast<ssize_t>(done * frame_size_);
}

int Track::SetLoop(uint32_t start, uint32_t end, int count) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (count == 0) {
    loop_count_ = 0;
    loop_start_ = loop_end_ = 0;
    return kOk;
  }
  if (start >= end || end > params_.capacity_frames) return kBadValue;
  loop_start_ = start;
  loop_end_ = end;
  loop_count_ = count;
  return kOk;
}

int Track::Reload() {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (state_ == State::kPlaying) return kInvalidOperation;
  static_pos_ = 0;
  position_base_ = played_;
  rs_->Reset();
  return kOk;
}

int Track::SetPosition(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static || state_ == State::kPlaying) return kInvalidOperation;
  if (frame > static_frames_) return kBadValue;
  static_pos_ = frame;
  position_base_ = played_ - frame;
  rs_->Reset();
  return kOk;
}

size_t Track::static_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_frames_;
}

uint32_t Track::Position() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(played_ - position_base_);
}

bool Track::Timestamp(int64_t* frames, int64_t* time_ns) const {
  std::lock_guard<std::mutex> lock(mu_);
  if (played_time_ns_ == 0) return false;
  *frames = static_cast<int64_t>(played_ - position_base_);
  // What was mixed last is heard after the sink's latency.
  uint32_t out_rate = engine_->out_rate();
  *time_ns = played_time_ns_ +
             (out_rate != 0 ? static_cast<int64_t>(engine_->latency_frames()) * 1000000000 / out_rate
                            : 0);
  return true;
}

int Track::SetMarker(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  marker_ = frame;
  marker_reached_ = frame == 0;
  return kOk;
}

uint32_t Track::marker() const {
  std::lock_guard<std::mutex> lock(mu_);
  return marker_;
}

int Track::SetUpdatePeriod(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  update_period_ = frames;
  uint64_t pos = played_ - position_base_;
  next_update_ = frames == 0 ? 0 : (pos / frames + 1) * frames;
  return kOk;
}

uint32_t Track::update_period() const {
  std::lock_guard<std::mutex> lock(mu_);
  return update_period_;
}

void Track::SetVolume(float left, float right) {
  std::lock_guard<std::mutex> lock(mu_);
  vol_left_ = std::clamp(left, 0.0f, 1.0f);
  vol_right_ = std::clamp(right, 0.0f, 1.0f);
}

int Track::SetSampleRate(uint32_t rate) {
  std::lock_guard<std::mutex> lock(mu_);
  if (rate == 0 || rate > params_.sample_rate * 2 * 8) return kBadValue;
  rate_ = rate;
  return kOk;
}

uint32_t Track::sample_rate() const {
  std::lock_guard<std::mutex> lock(mu_);
  return rate_;
}

void Track::SetSpeed(float speed) {
  std::lock_guard<std::mutex> lock(mu_);
  speed_ = std::clamp(speed, 0.01f, 16.0f);
}

float Track::speed() const {
  std::lock_guard<std::mutex> lock(mu_);
  return speed_;
}

uint32_t Track::buffer_size_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(params_.is_static ? params_.capacity_frames : buffer_frames_);
}

int Track::SetBufferSizeFrames(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static) return kInvalidOperation;
  buffer_frames_ = std::clamp<size_t>(frames, 1, params_.capacity_frames);
  room_.notify_all();
  return static_cast<int>(buffer_frames_);
}

uint32_t Track::underrun_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_frames_;
}

uint32_t Track::underrun_count() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_count_;
}

uint32_t Track::LatencyMs() const {
  uint32_t out_rate = engine_->out_rate();
  uint32_t sink_ms = out_rate != 0 ? engine_->latency_frames() * 1000 / out_rate : 0;
  std::lock_guard<std::mutex> lock(mu_);
  uint32_t buffer_ms =
      params_.is_static ? 0 : static_cast<uint32_t>(buffer_frames_ * 1000 / std::max(rate_, 1u));
  return sink_ms + buffer_ms;
}

bool Track::WaitForRoom(size_t frames, int timeout_ms) {
  std::unique_lock<std::mutex> lock(mu_);
  auto fits = [&] {
    if (released_ || params_.is_static) return true;
    size_t limit = std::min(buffer_frames_, params_.capacity_frames);
    size_t queued = static_cast<size_t>(written_ - read_);
    return queued + std::min(frames, limit) <= limit;
  };
  room_.wait_for(lock, std::chrono::milliseconds(timeout_ms), fits);
  return fits();
}

size_t Track::Queued() const {
  std::lock_guard<std::mutex> lock(mu_);
  return params_.is_static ? 0 : static_cast<size_t>(written_ - read_);
}

void Track::Release() {
  {
    std::lock_guard<std::mutex> lock(mu_);
    released_ = true;
    ++write_interrupt_;
    state_ = State::kStopped;
    room_.notify_all();
  }
  engine_->Remove(this);
}

// Mixing thread, with mu_ held.
size_t Track::ReadSource(float* dst, size_t frames, bool* ended) {
  *ended = false;
  size_t ch = params_.channels;
  size_t bps = BytesPerSample(params_.format);
  size_t done = 0;
  if (!params_.is_static) {
    const uint64_t end = state_ == State::kStopping ? stop_end_ : written_;
    size_t avail = static_cast<size_t>(end - read_);
    size_t n = std::min(avail, frames);
    size_t cap = params_.capacity_frames;
    while (done < n) {
      size_t pos = static_cast<size_t>(read_ % cap);
      size_t piece = std::min(n - done, cap - pos);
      ToFloat(data_.data() + pos * frame_size_, params_.format, piece * ch, dst + done * ch);
      read_ += piece;
      done += piece;
    }
    room_.notify_all();
    if (done == 0 && state_ == State::kStopping) *ended = true;
    return done;
  }
  while (done < frames) {
    bool looping = loop_count_ != 0 && loop_end_ > loop_start_ && static_pos_ <= loop_end_;
    size_t end = looping ? loop_end_ : static_frames_;
    if (static_pos_ >= end) {
      if (looping) {
        static_pos_ = loop_start_;
        if (loop_count_ > 0) loop_count_--;
        continue;
      }
      *ended = true;
      break;
    }
    size_t piece = std::min(frames - done, end - static_pos_);
    ToFloat(data_.data() + static_pos_ * frame_size_, params_.format, piece * ch, dst + done * ch);
    static_pos_ += piece;
    done += piece;
  }
  (void)bps;
  return done;
}

bool Track::MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels) {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_ || (state_ != State::kPlaying && state_ != State::kStopping) ||
      (state_ == State::kStopping && drained_)) {
    return false;
  }
  Resampler& rs = *rs_;
  const size_t ch = params_.channels;
  const double step = static_cast<double>(rate_) * speed_ / out_rate;
  const bool passthrough = step == 1.0;
  const double cutoff = step > 1.0 ? 1.0 / step * 0.97 : 1.0;
  const size_t width = passthrough ? 0 : static_cast<size_t>(std::ceil(kHalfTaps / cutoff));
  const float* table = KernelTable();
  // Integer and half-integer steps repeat at most two exact phases. Reuse only
  // those actual coefficients within this mix; no phase quantization or state
  // survives a rate change. Wider filters keep the original per-frame path.
  constexpr size_t kReusableWidth = 64;
  float weights[2][2 * kReusableWidth];
  bool weights_ready[2] = {};
  double integral_step;
  const bool reusable_step = !passthrough && width <= kReusableWidth &&
                             std::modf(step * 2, &integral_step) == 0;

  if (!rs.primed || rs.width != width) {
    if (!rs.primed) {
      // Zeros before the first frame, so the filter has history.
      rs.hist.assign(width * ch, 0.0f);
      rs.start_index = -static_cast<int64_t>(width);
      rs.t = static_cast<double>(width);
      rs.real_end = -1;
      rs.primed = true;
    } else if (width > rs.width) {
      // A rate change can widen the filter beyond retained left-hand history
      // (especially just after startup or compaction). Preserve every real
      // sample and the absolute timeline, padding only unavailable past taps.
      const int64_t first = static_cast<int64_t>(std::floor(rs.t)) -
                            static_cast<int64_t>(width) + 1;
      if (first < 0) {
        const size_t missing = static_cast<size_t>(-first);
        rs.hist.insert(rs.hist.begin(), missing * ch, 0.0f);
        rs.t += static_cast<double>(missing);
        rs.start_index -= static_cast<int64_t>(missing);
      }
    }
    rs.width = width;
  }

  uint64_t played_before = played_;
  std::vector<float>& frame = rs.frame;
  frame.resize(ch);
  std::vector<float>& tmp = rs.source;
  size_t out_done = 0;
  bool ended = false;
  bool starved = false;
  // Volume changes ramp linearly over the block (no clicks).
  const float gl = vol_left_, gr = vol_right_;
  float al = applied_left_, ar = applied_right_;
  const float dl = (gl - al) / static_cast<float>(std::max<size_t>(frames, 1));
  const float dr = (gr - ar) / static_cast<float>(std::max<size_t>(frames, 1));

  auto mix_frame = [&](const float* samples) {
    al += dl;
    ar += dr;
    float* o = mix + out_done * out_channels;
    float l, r;
    if (ch == 1) {
      l = r = samples[0];
    } else if (ch == 2) {
      l = samples[0];
      r = samples[1];
    } else {
      // FL FR FC LFE BL BR SL SR ...: the center and the surrounds at -3 dB.
      constexpr float k = 0.7071f;
      l = samples[0];
      r = samples[1];
      if (ch > 2) { l += k * samples[2]; r += k * samples[2]; }
      for (size_t c = 4; c + 1 < ch && c < 8; c += 2) { l += k * samples[c]; r += k * samples[c + 1]; }
    }
    l *= al;
    r *= ar;
    if (out_channels == 1) {
      o[0] += 0.5f * (l + r);
    } else {
      o[0] += l;
      o[1] += r;
    }
    ++out_done;
  };

  while (out_done < frames) {
    int64_t center = static_cast<int64_t>(std::floor(rs.t));
    size_t need = static_cast<size_t>(center + static_cast<int64_t>(width) + 1);
    while (rs.frames() < need) {
      if (rs.real_end >= 0) {
        // Ended: zeros flush the filter.
        rs.hist.insert(rs.hist.end(), (need - rs.frames()) * ch, 0.0f);
        break;
      }
      size_t want = std::max<size_t>(need - rs.frames(), 256);
      tmp.resize(want * ch);
      bool src_ended = false;
      size_t got = ReadSource(tmp.data(), want, &src_ended);
      rs.hist.insert(rs.hist.end(), tmp.begin(), tmp.begin() + got * ch);
      if (got == 0) {
        if (src_ended) {
          rs.real_end = rs.start_index + static_cast<int64_t>(rs.frames());
          continue;
        }
        starved = true;
        break;
      }
    }
    if (starved) break;
    if (rs.real_end >= 0 && rs.start_index + center >= rs.real_end) {
      ended = true;
      break;
    }
    if (passthrough) {
      // Unity-rate output already has contiguous source frames. Keep the
      // existing read-ahead and history, but check availability once per span
      // instead of once per output frame. A fractional phase left by a rate
      // change keeps the single-frame path: rounding when adding 1 near an
      // integer boundary can otherwise skip a source frame. The bounded
      // integral span advances exactly, including in floating-point arithmetic.
      size_t count = 1;
      if (rs.t == static_cast<double>(center) && rs.t < 0x1p52) {
        count = std::min({frames - out_done, rs.frames() - static_cast<size_t>(center), size_t{256}});
      }
      if (rs.real_end >= 0) {
        count = std::min(count, static_cast<size_t>(rs.real_end - rs.start_index - center));
      }
      const float* samples = rs.hist.data() + static_cast<size_t>(center) * ch;
      for (size_t i = 0; i < count; ++i) {
        mix_frame(samples);
        samples += ch;
        rs.t += 1.0;
      }
    } else {
      const int64_t first = center - static_cast<int64_t>(width) + 1;
      const float* repeated = nullptr;
      if (reusable_step) {
        // In this range both an integer and its half-step are represented
        // exactly. Subtracting each integral tap gives the same coefficient
        // argument whenever the exact phase repeats, including after history
        // compaction. A fractional phase left by another rate falls back.
        const int phase = ExactHalfPhase(rs.t, center);
        if (phase >= 0) {
          if (!weights_ready[phase]) {
            for (size_t tap = 0; tap < 2 * width; ++tap) {
              const int64_t k = first + static_cast<int64_t>(tap) + 1;
              weights[phase][tap] = Kernel(table, (rs.t - static_cast<double>(k)) * cutoff) *
                                    static_cast<float>(cutoff);
            }
            weights_ready[phase] = true;
          }
          repeated = weights[phase];
        }
      }
      std::fill(frame.begin(), frame.end(), 0.0f);
      if (repeated) {
        for (int64_t k = first; k <= center + static_cast<int64_t>(width); k++) {
          const float w = repeated[static_cast<size_t>(k - first)];
          if (w == 0) continue;
          const float* s = &rs.hist[static_cast<size_t>(k) * ch];
          for (size_t c = 0; c < ch; c++) frame[c] += s[c] * w;
        }
      } else {
        for (int64_t k = center - static_cast<int64_t>(width) + 1;
             k <= center + static_cast<int64_t>(width); k++) {
          float w = Kernel(table, (rs.t - static_cast<double>(k)) * cutoff) * static_cast<float>(cutoff);
          if (w == 0) continue;
          const float* s = &rs.hist[static_cast<size_t>(k) * ch];
          for (size_t c = 0; c < ch; c++) frame[c] += s[c] * w;
        }
      }
      mix_frame(frame.data());
      rs.t += step;
    }
  }
  applied_left_ = gl;
  applied_right_ = gr;

  // Played: source frames whose center the filter passed.
  int64_t center_index = rs.start_index + static_cast<int64_t>(std::floor(rs.t));
  if (rs.real_end >= 0) center_index = std::min(center_index, rs.real_end);
  // played_ counts frames since the track was created; the resampler's index
  // restarts at each Reset, so advance by the difference.
  if (center_index > rs.played_index) {
    played_ += static_cast<uint64_t>(center_index - rs.played_index);
    rs.played_index = center_index;
  }
  played_time_ns_ = MonotonicNs();

  // Starved for a while (an underrun, or a writer that stopped writing without
  // stop()): the frames the filter still holds back count as played, and the
  // resampler starts over with the next data. Otherwise the last few frames
  // would wait for data that may never come (AAudio's getFramesRead, a
  // position that must reach what was written).
  if (starved && out_done == 0 && rs.primed) {
    if (starved_since_ns_ < 0) starved_since_ns_ = played_time_ns_;
    // Preserve the 10 ms grace between empty mixes when the device asks
    // for frames more often than the engine's periodic timer.
    if (played_time_ns_ - starved_since_ns_ >= 10'000'000) {
      int64_t end = rs.start_index + static_cast<int64_t>(rs.frames());
      if (end > rs.played_index) played_ += static_cast<uint64_t>(end - rs.played_index);
      rs.Reset();
      starved_since_ns_ = -1;
    }
  } else if (!starved) {
    starved_since_ns_ = -1;
  }

  // Drop history the filter no longer needs.
  int64_t keep_from = static_cast<int64_t>(std::floor(rs.t)) - static_cast<int64_t>(width) - 1;
  if (keep_from > 4096) {
    rs.hist.erase(rs.hist.begin(), rs.hist.begin() + keep_from * static_cast<int64_t>(ch));
    rs.t -= static_cast<double>(keep_from);
    rs.start_index += keep_from;
  }

  if (starved && out_done < frames && state_ == State::kPlaying && played_ > position_base_) {
    underrun_frames_ += static_cast<uint32_t>((frames - out_done) * rate_ / out_rate);
    if (!was_underrun_) {
      was_underrun_ = true;
      ++underrun_count_;
      if (events_.underrun) PostEvent(events_.underrun);
    }
  } else if (out_done == frames) {
    was_underrun_ = false;
  }

  bool was_ended = end_signalled_;
  if (ended) {
    if (state_ == State::kStopping) {
      drained_ = true;
      state_ = State::kStopped;
    } else {
      // A static track at its end stays "playing" (as Android's), silent.
      state_ = params_.is_static ? State::kPlaying : state_;
    }
    room_.notify_all();
    if (events_.end && !end_signalled_) {
      end_signalled_ = true;
      PostEvent(events_.end);
    }
  } else {
    end_signalled_ = false;
  }
  QueueEvents(played_before - position_base_, played_ - position_base_);
  return out_done > 0 || (ended && !was_ended);
}

void Track::QueueEvents(uint64_t before, uint64_t after) {
  if (after <= before) return;
  if (!marker_reached_ && marker_ != 0 && before < marker_ && after >= marker_) {
    marker_reached_ = true;
    if (events_.marker) {
      auto fn = events_.marker;
      uint32_t m = marker_;
      PostEvent([fn, m] { fn(m); });
    }
  }
  if (update_period_ != 0 && next_update_ != 0) {
    while (after >= next_update_) {
      if (events_.new_position) {
        auto fn = events_.new_position;
        uint32_t p = static_cast<uint32_t>(next_update_);
        PostEvent([fn, p] { fn(p); });
      }
      next_update_ += update_period_;
    }
  }
}

}  // namespace gesher::media



namespace {
using namespace gesher::media;
Engine engine;
size_t checks = 0, failures = 0;
void Check(bool okay, const char* reason) {
  ++checks;
  if (!okay) { ++failures; if (failures <= 12) std::fprintf(stderr, "FAIL unity mixer: %s\n", reason); }
}
void Write(FILE* output, const void* data, size_t size) {
  if (size && std::fwrite(data, 1, size, output) != size) std::abort();
}
template<class T> void Write(FILE* output, const T& value) { Write(output, &value, sizeof(value)); }
float Sample(size_t frame, size_t channel) {
  return (static_cast<int>((frame * 13 + channel * 29) % 201) - 100) / 128.0f;
}
std::vector<uint8_t> Payload(PcmFormat format, uint32_t channels, size_t frames) {
  const size_t bytes = BytesPerSample(format);
  std::vector<uint8_t> result(frames * channels * bytes);
  for (size_t frame = 0; frame < frames; ++frame) for (size_t ch = 0; ch < channels; ++ch) {
    const int level = static_cast<int>(Sample(frame, ch) * 128);
    uint8_t* out = result.data() + (frame * channels + ch) * bytes;
    switch (format) {
      case PcmFormat::kU8: *out = static_cast<uint8_t>(128 + level); break;
      case PcmFormat::kS16: { int16_t v = static_cast<int16_t>(level * 256); std::memcpy(out, &v, 2); break; }
      case PcmFormat::kS24Packed: {
        uint32_t v = static_cast<uint32_t>(level * 65536);
        out[0] = v; out[1] = v >> 8; out[2] = v >> 16; break;
      }
      case PcmFormat::kS32: { int32_t v = level * 16777216; std::memcpy(out, &v, 4); break; }
      case PcmFormat::kFloat: { float v = Sample(frame, ch); std::memcpy(out, &v, 4); break; }
    }
  }
  return result;
}
std::array<float, 2> Channels(size_t frame, size_t channels) {
  float l = Sample(frame, 0), r = Sample(frame, channels == 1 ? 0 : 1);
  if (channels > 2) {
    l += 0.7071f * Sample(frame, 2); r += 0.7071f * Sample(frame, 2);
    for (size_t ch = 4; ch + 1 < channels && ch < 8; ch += 2) {
      l += 0.7071f * Sample(frame, ch); r += 0.7071f * Sample(frame, ch + 1);
    }
  }
  return {l, r};
}

template <typename T>
bool AwaitingStarvationGrace(const T& track) {
  if constexpr (requires { track.starved_since_ns_; }) {
    return track.starved_since_ns_ >= 0;
  } else {
    return track.starved_ticks_ != 0;
  }
}

// Serialize individual values, not struct padding or nondeterministic clock
// readings. Includes all ownership/timeline state that a batching change could
// accidentally advance early, and all callback types in delivery order.
void Observe(FILE* output, Track& t, const std::vector<uint64_t>& events) {
  Write(output, t.state_); Write(output, t.drained_); Write(output, t.released_);
  Write(output, t.read_); Write(output, t.written_); Write(output, t.stop_end_);
  Write(output, t.buffer_frames_); Write(output, t.static_pos_); Write(output, t.static_frames_);
  Write(output, t.loop_start_); Write(output, t.loop_end_); Write(output, t.loop_count_);
  Write(output, t.played_); Write(output, t.position_base_); Write(output, t.write_interrupt_);
  Write(output, t.marker_); Write(output, t.marker_reached_); Write(output, t.next_update_);
  Write(output, t.update_period_); Write(output, t.underrun_count_); Write(output, t.underrun_frames_);
  Write(output, t.was_underrun_); Write(output, t.end_signalled_); Write(output, AwaitingStarvationGrace(t));
  Write(output, t.vol_left_); Write(output, t.vol_right_);
  Write(output, t.applied_left_); Write(output, t.applied_right_);
  Write(output, t.rate_); Write(output, t.speed_);
  Write(output, t.rs_->t); Write(output, t.rs_->width); Write(output, t.rs_->start_index);
  Write(output, t.rs_->real_end); Write(output, t.rs_->primed); Write(output, t.rs_->played_index);
  Write(output, t.rs_->hist.size()); Write(output, t.rs_->hist.data(), t.rs_->hist.size() * sizeof(float));
  Write(output, events.size()); Write(output, events.data(), events.size() * sizeof(uint64_t));
}
void Record(FILE* output, Track& t, size_t frames, uint32_t out_rate, uint32_t channels,
            const std::vector<uint64_t>& events) {
  gesher::fixture_playback_ns += 10'000'000;
  std::vector<float> data(frames * channels);
  for (size_t i = 0; i < data.size(); ++i) data[i] = (i & 1) ? -0.125f : 0.25f;
  const bool active = t.MixInto(data.data(), frames, out_rate, channels);
  Check(std::all_of(data.begin(), data.end(), [](float v) { return std::isfinite(v); }),
        "finite supplied PCM remains finite");
  Write(output, active); Write(output, frames); Write(output, channels);
  Write(output, data.data(), data.size() * sizeof(float));
  Observe(output, t, events);
}
void InstallEvents(Track& t, std::vector<uint64_t>* events) {
  TrackEvents e;
  e.marker = [events](uint32_t p) { events->push_back((uint64_t{1} << 32) | p); };
  e.new_position = [events](uint32_t p) { events->push_back((uint64_t{2} << 32) | p); };
  e.end = [events] { events->push_back(uint64_t{3} << 32); };
  e.underrun = [events] { events->push_back(uint64_t{4} << 32); };
  t.SetEvents(std::move(e)); t.SetMarker(17); t.SetUpdatePeriod(97);
}

void Oracle(PcmFormat format, uint32_t channels, uint32_t out_channels) {
  TrackParams p; p.format = format; p.channels = channels; p.capacity_frames = 777; p.is_static = true;
  Track t(&engine, p); const auto source = Payload(format, channels, p.capacity_frames);
  Check(t.Write(source.data(), source.size(), false) == static_cast<ssize_t>(source.size()), "oracle writes full input");
  std::vector<uint64_t> events; InstallEvents(t, &events); t.Start();
  size_t at = 0;
  for (size_t frames : {0u, 1u, 17u, 255u, 256u, 257u, 480u}) {
    std::vector<float> actual(frames * out_channels, 0.25f), expected = actual;
    const size_t n = std::min(frames, p.capacity_frames - at);
    for (size_t i = 0; i < n; ++i) {
      const auto value = Channels(at + i, channels);
      if (out_channels == 1) expected[i] += 0.5f * (value[0] + value[1]);
      else { expected[i * out_channels] += value[0]; expected[i * out_channels + 1] += value[1]; }
    }
    t.MixInto(actual.data(), frames, 48000, out_channels); at += n;
    Check(actual == expected, "every sample follows independent source/channel oracle");
    Check(t.Position() == at, "position advances only by real source frames");
  }
  Check(std::count(events.begin(), events.end(), uint64_t{3} << 32) == 1, "static end is delivered once");
  Check(t.state() == Track::State::kPlaying, "completed static track retains playing state");
}



bool SameSample(float a, float b) {
  return std::bit_cast<uint32_t>(a) == std::bit_cast<uint32_t>(b) ||
         (std::isnan(a) && std::isnan(b));
}

void PhaseOracle(FILE* output, uint32_t channels, float speed, double fraction,
                 size_t offset, int rounding, bool gate, bool special = false) {
  TrackParams p;
  p.channels = channels; p.format = PcmFormat::kFloat;
  p.capacity_frames = 32768; p.is_static = true;
  Track t(&engine, p);
  std::vector<float> source(p.capacity_frames * channels);
  const uint32_t values[] = {0, 0x80000000u, 0x00000001u, 0x80000001u,
                            0x7f800000u, 0xff800000u, 0x7fc00071u, 0xffc00037u};
  for (size_t i = 0; i < source.size(); ++i)
    source[i] = special ? std::bit_cast<float>(values[(i * 7 + i / channels) % std::size(values)]) :
                         Sample(i / channels, i % channels);
  const auto retained_source = source;
  Check(t.Write(source.data(), source.size() * sizeof(float), false) ==
            static_cast<ssize_t>(source.size() * sizeof(float)), "phase oracle owns actual source frames");
  Check(std::fesetround(rounding) == 0, "requested floating rounding mode is available");
  t.SetSpeed(speed); t.Start();
  float dummy = 0;
  t.MixInto(&dummy, 0, 48000, 1);
  const size_t width = t.rs_->width;
  t.rs_->hist.resize((width + p.capacity_frames) * channels);
  bool ended = false;
  Check(t.ReadSource(t.rs_->hist.data() + width * channels, p.capacity_frames, &ended) == p.capacity_frames,
        "phase oracle uses real ReadSource conversion and ownership");
  t.rs_->t = static_cast<double>(width + offset) + fraction;
  // A rate transition can leave one representable value below an integer.
  if (fraction == -1) t.rs_->t = std::nextafter(static_cast<double>(width + offset), 0.0);
  const auto original_history = t.rs_->hist;
  const int64_t original_start = t.rs_->start_index;
  double phase = t.rs_->t;
  const double step = static_cast<double>(t.sample_rate()) * t.speed() / 48000;
  const double cutoff = step > 1 ? 1.0 / step * 0.97 : 1.0;
  constexpr size_t frames = 67;
  const bool reusable_step = step != 1 && width <= 64 && std::fmod(step, 0.5) == 0;
  bool observed_phase[2] = {};
  size_t expected_evaluations = 0;
  std::array<float, frames * 2> expected{}, actual{};
  for (size_t i = 0; i < expected.size(); ++i) expected[i] = actual[i] = (i & 1) ? -0.125f : 0.25f;
  // Frozen scalar tap order, independently of the repeated-weight branch.
  // Nonfinite classification is checked here; the full original-source
  // transcript additionally compares actual NaN payloads and all signed zeros.
  for (size_t out = 0; out < frames; ++out) {
    std::array<float, 24> sums{};
    const int64_t center = static_cast<int64_t>(std::floor(phase));
    const double actual_fraction = phase - static_cast<double>(center);
    const int half = phase >= 0 && phase < 0x1p51 && actual_fraction == 0 ? 0 :
                     phase >= 0 && phase < 0x1p51 && actual_fraction == 0.5 ? 1 : -1;
    // A noncanonical starting phase may round onto an exact phase at a later
    // addition. Account for each actual scalar phase, not its initial label.
    if (reusable_step && half >= 0) {
      if (!observed_phase[half]) { expected_evaluations += 2 * width; observed_phase[half] = true; }
    } else expected_evaluations += 2 * width;
    for (int64_t k = center - static_cast<int64_t>(width) + 1;
         k <= center + static_cast<int64_t>(width); ++k) {
      float coefficient = Kernel(KernelTable(), (phase - static_cast<double>(k)) * cutoff) *
                          static_cast<float>(cutoff);
      if (coefficient == 0) continue;
      for (size_t c = 0; c < channels; ++c)
        sums[c] += original_history[static_cast<size_t>(k) * channels + c] * coefficient;
    }
    float left = sums[0], right = channels == 1 ? sums[0] : sums[1];
    if (channels > 2) {
      left += 0.7071f * sums[2]; right += 0.7071f * sums[2];
      for (size_t c = 4; c + 1 < channels && c < 8; c += 2) {
        left += 0.7071f * sums[c]; right += 0.7071f * sums[c + 1];
      }
    }
    expected[out * 2] += left; expected[out * 2 + 1] += right;
    phase += step;
  }
  std::feclearexcept(FE_ALL_EXCEPT);
  resampler_kernel_calls = 0;
  gesher::fixture_playback_ns += 10'000'000;
  Check(t.MixInto(actual.data(), frames, 48000, 2), "phase oracle actually mixes every requested frame");
  const int exceptions = std::fetestexcept(FE_ALL_EXCEPT);
  const size_t evaluated = resampler_kernel_calls;
  Check(std::fegetround() == rounding, "mix retains the calling thread rounding mode");
  bool matching = true;
  for (size_t i = 0; i < actual.size(); ++i) matching &= SameSample(actual[i], expected[i]);
  Check(matching, "uncached scalar tap oracle matches complete PCM");
  Check(original_start + phase == t.rs_->start_index + t.rs_->t,
        "phase advances by the original repeated floating additions");
  Check(t.Position() == static_cast<uint32_t>(original_start + std::floor(phase)),
        "resampler position retains the original source centers");
  Check(std::memcmp(source.data(), retained_source.data(), source.size() * sizeof(float)) == 0,
        "mix does not modify caller-owned source storage");
  if (gate)
    Check(evaluated == expected_evaluations, "repeated-phase coefficient work is bounded by two actual phases per mix");
  else
    Check(evaluated == frames * 2 * width, "original scalar coefficient work covers every actual output frame");
  // Only actual outputs/state enter the baseline comparison; the intended
  // coefficient count reduction is a separate observation.
  Write(output, actual); Write(output, exceptions); Observe(output, t, {});
  std::fesetround(FE_TONEAREST);
  t.Release();
  auto released = actual;
  Check(!t.MixInto(actual.data(), frames, 48000, 2) &&
        std::memcmp(actual.data(), released.data(), sizeof(actual)) == 0,
        "release prevents all further mixing and output access");
}

void ExactPhaseBounds() {
  // Execute the production classifier at otherwise impractically large
  // history indices. This is scalar classification/arithmetic evidence, not
  // a claim to allocate or mix 2^51 real frames on the host.
  for (double value : {0.0, 0.5, 12.0, 12.5, 4096.0, 4096.5, 0x1p51 - 1, 0x1p51 - 0.5}) {
    const int64_t center = static_cast<int64_t>(std::floor(value));
    const int expected = value == static_cast<double>(center) ? 0 : 1;
    Check(ExactHalfPhase(value, center) == expected, "exact finite half-phase classifier accepts represented values");
    if (center >= 64) for (int tap = -63; tap <= 64; ++tap) {
      const double original = value - static_cast<double>(center + tap);
      const double canonical = expected * 0.5 - static_cast<double>(tap);
      Check(original == canonical, "bounded integer-tap subtraction retains the exact original argument");
    }
  }
  for (double value : {0.25, 12.25, std::nextafter(256.0, 0.0), -1.0, 0x1p51, 0x1p52,
                       std::numeric_limits<double>::infinity(), std::numeric_limits<double>::quiet_NaN()}) {
    const int64_t center = std::isfinite(value) ? static_cast<int64_t>(std::floor(value)) : 0;
    Check(ExactHalfPhase(value, center) == -1, "fractional or out-of-range phase cannot enter coefficient reuse");
  }
}

void ZeroWeightNonfinite(FILE* output) {
  TrackParams p; p.channels = 1; p.format = PcmFormat::kFloat;
  p.capacity_frames = 128; p.is_static = true;
  Track t(&engine, p);
  std::array<float, 128> values{};
  values[12] = std::numeric_limits<float>::quiet_NaN();
  t.Write(values.data(), sizeof(values), false); t.SetSpeed(0.5f); t.Start();
  std::array<float, 2> actual{};
  t.MixInto(actual.data(), 1, 48000, 2);
  Check(std::isfinite(actual[0]) && std::isfinite(actual[1]),
        "zero-weight tap does not introduce a nonfinite source sample");
  Write(output, actual); Observe(output, t, {});
  t.Release();
}

void EmptyAndSilent(FILE* output) {
  // The eligibility check must not introduce an extra inexact exception on
  // an empty or silent first frame at a nonbinary rate.
  for (size_t frames : {0u, 1u}) {
    TrackParams p; p.channels = 1; p.sample_rate = 44100;
    p.format = PcmFormat::kFloat; p.capacity_frames = 512; p.is_static = true;
    Track t(&engine, p); std::array<float, 512> input{};
    t.Write(input.data(), sizeof(input), false); t.Start();
    std::array<float, 2> result{};
    std::feclearexcept(FE_ALL_EXCEPT);
    t.MixInto(result.data(), frames, 48000, 2);
    const int exceptions = std::fetestexcept(FE_ALL_EXCEPT);
    Write(output, exceptions); Write(output, result); Observe(output, t, {});
    t.Release();
  }
}

void Lifecycle(FILE* output, PcmFormat format, uint32_t channels, bool is_static) {
  TrackParams p; p.format = format; p.channels = channels;
  p.capacity_frames = is_static ? 4096 : 311; p.is_static = is_static;
  Track t(&engine, p); auto source = Payload(format, channels, p.capacity_frames);
  std::vector<uint64_t> events; InstallEvents(t, &events);
  t.Write(source.data(), source.size(), false);
  if (is_static) t.SetLoop(3, 997, -1);
  t.Start(); t.SetVolume(0.3f, 0.9f);
  const std::array<float, 10> rates{0.5f, 1.5f, 2, 2.5f, 3, 3.5f, 4, 4.5f, 5, 6};
  const std::array<size_t, 8> spans{0, 1, 2, 17, 127, 256, 257, 513};
  for (size_t step = 0; step < 104; ++step) {
    t.SetSpeed(rates[(step / 3) % rates.size()]);
    if (step == 9) t.SetSampleRate(44100);
    if (step == 16) t.SetSampleRate(48000);
    if (step == 29) { t.Pause(); Record(output, t, 17, 48000, 2, events); t.Start(); }
    if (step == 41) t.Stop();
    if (step == 48) t.Start();
    if (step == 55) { t.Pause(); t.Flush(); if (is_static) t.SetPosition(31); t.Start(); }
    if (step == 63) { t.SetVolume(0.75f, 0.25f); t.SetMarker(t.Position() + 23); t.SetUpdatePeriod(83); }
    if (step == 72 && is_static) { t.Pause(); t.Reload(); t.SetLoop(11, 267, 3); t.Start(); }
    if (step == 77 && !is_static) t.SetBufferSizeFrames(73);
    if (step == 83 && !is_static) t.SetBufferSizeFrames(311);
    if (!is_static && step % 7 != 0) {
      const size_t bytes = ((step * 137) % 312) * t.frame_size();
      Write(output, t.Write(source.data(), bytes, false));
    }
    const uint32_t output_rate = step % 11 == 0 ? 44100 : step % 13 == 0 ? 96000 : 48000;
    Record(output, t, spans[step % spans.size()], output_rate, step % 3 == 0 ? 1 : 2, events);
  }
  t.Stop();
  for (unsigned i = 0; i < 8; ++i) Record(output, t, 257, 48000, 2, events);
  if (is_static) { t.Reload(); t.SetLoop(0, 4096, -1); }
  else t.Write(source.data(), source.size(), false);
  t.SetSampleRate(48000); t.SetSpeed(1.5f); t.Start();
  Record(output, t, 5000, 48000, 2, events);
  t.Release(); Record(output, t, 480, 48000, 2, events);
}

void CoefficientBudget(bool gate) {
  constexpr size_t blocks = 31, frames = 480;
  for (float speed : {0.5f, 1.5f, 2.0f, 4.0f}) {
    TrackParams p; p.channels = 2; p.format = PcmFormat::kFloat;
    p.capacity_frames = 4096; p.is_static = true;
    Track t(&engine, p); const auto source = Payload(p.format, p.channels, p.capacity_frames);
    t.Write(source.data(), source.size(), false); t.SetLoop(0, 4096, -1); t.SetSpeed(speed); t.Start();
    std::array<float, frames * 2> output{};
    resampler_kernel_calls = 0;
    for (size_t block = 0; block < blocks; ++block) {
      output.fill(0); t.MixInto(output.data(), frames, 48000, 2);
    }
    const size_t evaluated = resampler_kernel_calls;
    if (gate) Check(evaluated <= blocks * 4 * t.rs_->width,
                    "repeated-phase coefficient work is bounded by two actual phases per mix");
    Check(t.Position() == static_cast<uint32_t>(blocks * frames * speed), "budget workload transfers all source centers");
    std::printf("resampler speed=%.1f output_frames=%zu kernel_calls=%zu width=%zu\n",
                speed, blocks * frames, evaluated, t.rs_->width);
    t.Release();
  }
}
}  // namespace

int main(int argc, char** argv) {
  if (argc != 4) return 2;
  const bool gate = std::strcmp(argv[2], "gate") == 0;
  const bool full = std::strcmp(argv[3], "full") == 0;
  FILE* output = std::fopen(argv[1], "wb"); if (!output) return 2;
  std::fesetround(FE_TONEAREST); (void)KernelTable();
  ExactPhaseBounds();
  for (int rounding : {FE_TONEAREST, FE_DOWNWARD, FE_UPWARD, FE_TOWARDZERO}) {
    for (float speed : {0.5f, 1.5f, 2.0f, 4.0f, 5.0f, 6.0f}) {
      PhaseOracle(output, 2, speed, 0, 0, rounding, gate);
      PhaseOracle(output, 2, speed, 0.5, 4117, rounding, gate);
      PhaseOracle(output, 2, speed, 0.25, 16, rounding, gate);
      PhaseOracle(output, 2, speed, -1, 256, rounding, gate);
    }
  }
  for (uint32_t channels : {1u, 3u, 8u, 24u})
    for (float speed : {0.5f, 1.5f, 2.0f}) PhaseOracle(output, channels, speed, 0, 7, FE_TONEAREST, gate);
  for (float speed : {0.5f, 1.5f, 2.0f}) PhaseOracle(output, 2, speed, 0, 31, FE_TONEAREST, gate, true);
  for (float speed : {5.052083f, 5.133125f, 5.21375f})
    PhaseOracle(output, 2, speed, 0.5, 19, FE_TONEAREST, gate);
  ZeroWeightNonfinite(output); EmptyAndSilent(output); CoefficientBudget(gate);
  if (full) for (PcmFormat format : {PcmFormat::kU8, PcmFormat::kS16, PcmFormat::kS24Packed, PcmFormat::kS32, PcmFormat::kFloat})
    for (uint32_t channels : {1u, 2u, 3u, 8u, 24u}) {
      Oracle(format, channels, 1); Oracle(format, channels, 2); Oracle(format, channels, 4);
      Lifecycle(output, format, channels, false); Lifecycle(output, format, channels, true);
    }
  if (std::fclose(output)) return 2;
  std::printf("audio resampler weight contracts: %zu checks, %zu failures\n", checks, failures);
  return failures ? 1 : 0;
}
