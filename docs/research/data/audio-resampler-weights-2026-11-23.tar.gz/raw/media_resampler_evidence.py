from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
BASE = Path(__file__).resolve().parent
REPO = BASE / 'gesher-media-resample-channels'
DOC = REPO / 'docs/research/audio-resampler-weights-2026-11-23.json'
ARCHIVE = REPO / 'docs/research/data/audio-resampler-weights-2026-11-23.tar.gz'
BASELINE = 'bcfb5044029d486e17138dc417f3ced81524cf3f'
CURRENT_MAIN = '3b2eaca95b5ddd9cee3c3db4e430460e512eb355'
sha = lambda b: hashlib.sha256(b).hexdigest()
members = {}
def add(name, content):
    if name in members: assert members[name] == content, name
    members[name] = content
suffixes = {'.json','.log','.py','.cc','.h','.in','.patch','.txt','.su','.d'}
directories = ['media-resample-register-prototype','media-resample-weights-prototype',
               'media-resample-weights-contracts-v1','media-resample-weights-contracts-v2',
               'native-review-resampler-weights','media-resampler-weights-final-build',
               'media-resampler-weights-windows']
for directory in directories:
    for path in sorted((BASE/directory).rglob('*')):
        if path.is_file() and path.suffix in suffixes:
            add('raw/'+str(path.relative_to(BASE)),path.read_bytes())
for pattern in ['media-resample*.json','media-resample*.log','media_resample*.py',
                'media_resample*.cc','media_resample*.h','native-review-resampler*.json',
                'native-review-resampler*.log','native_review_resampler*.py']:
    for path in sorted(BASE.glob(pattern)):
        if path != Path(__file__): add('raw/'+path.name,path.read_bytes())
integration = json.loads((BASE/'media-resampler-main3b2-integration.json').read_text())
source_paths = list(integration['unchanged_feature_and_dependency_sha256'])
for relative in source_paths:
    content = (REPO/relative).read_bytes()
    assert sha(content) == integration['unchanged_feature_and_dependency_sha256'][relative],relative
    add('source/current/'+relative,content)
    result = subprocess.run(['git','show',BASELINE+':'+relative],cwd=REPO,capture_output=True)
    if result.returncode == 0: add('source/baseline/'+relative,result.stdout)
add('raw/media_resampler_evidence.py',Path(__file__).read_bytes())
add('source/current/production.patch',subprocess.check_output(
    ['git','diff',CURRENT_MAIN,'--','compat/media/audio/engine.cc'],cwd=REPO))
manifest = {name:{'bytes':len(content),'sha256':sha(content)} for name,content in sorted(members.items())}
manifest_bytes = (json.dumps({'schema':1,'members':manifest},indent=2)+'\n').encode()
add('manifest.json',manifest_bytes)
ARCHIVE.parent.mkdir(parents=True,exist_ok=True)
with ARCHIVE.open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
            for name,content in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(content);info.mode=0o644;info.mtime=0
                archive.addfile(info,io.BytesIO(content))
with tarfile.open(ARCHIVE,'r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,content in members.items():assert archive.extractfile(name).read()==content,name

def load(name): return json.loads((BASE/name).read_text())
campaigns = {}
for key,name in [('primary','media-resampler-weights-final-abba.json'),
                 ('longer_controls','media-resampler-weights-long-controls.json')]:
    raw = load(name)
    campaigns[key] = {k:v for k,v in raw.items() if k != 'processes'}
    campaigns[key].update({'raw_member':'raw/'+name,
                          'raw_sha256':sha((BASE/name).read_bytes()),
                          'process_count':len(raw['processes']),
                          'observation_count':sum(len(p['rows']) for p in raw['processes'])})
raw_timing = []
for pattern in ['media-resample-pilot-*.json','media-resample-weights-*.json',
                'media-resampler-weights-final-*.json','media-resampler-weights-long-controls*.json']:
    for path in sorted(BASE.glob(pattern)):
        value = load(path.name)
        if 'processes' in value:
            raw_timing.append({'member':'raw/'+path.name,'sha256':sha(path.read_bytes()),
                               'processes':len(value['processes'])})
payload = {
    'schema':1,
    'scope':'Exact repeated-phase coefficient reuse within one actual Track mix; complete host component evidence, not Windows/ART/application or release-budget acceptance.',
    'measured_baseline':BASELINE,'current_main':CURRENT_MAIN,
    'source_sha256':integration['unchanged_feature_and_dependency_sha256'],
    'main_integration':integration,
    'production_patch_sha256':sha(members['source/current/production.patch']),
    'contracts':load('media-resample-weights-contracts-v2/source.json'),
    'independent_contracts':load('native-review-resampler-weights/source.json'),
    'independent_evidence':load('native-review-resampler-evidence.json'),
    'campaigns':campaigns,
    'descriptive_paired':{
        'primary':load('media-resampler-weights-final-paired.json'),
        'longer_controls':load('media-resampler-weights-long-controls-paired.json')},
    'all_timing_reports':raw_timing,
    'crossbuild':load('media-resampler-weights-windows/receipt.json'),
    'ordinary_object_inspection':load('media-resampler-weights-final-build/MixInto-assembly-review.json'),
    'open_pr_audit':load('media-resampler-open-pr-audit.json'),
    'new_pr_overlap_followup':load('media-resampler-pr398399-followup.json'),
    'gates':{},
    'archive':{'path':str(ARCHIVE.relative_to(REPO)),'bytes':ARCHIVE.stat().st_size,
               'sha256':sha(ARCHIVE.read_bytes()),'member_count':len(members),
               'manifest_sha256':sha(manifest_bytes),'members':manifest},
    'limits':[
        'Actual Track members/primitives/header execute; Engine registration, endpoint loop and callback transport are explicit host boundaries.',
        'Normal timing constructs Track directly and excludes caller input/output-buffer preparation, ART, WASAPI, IPC, hardware and whole-application startup.',
        'Uninitialized coefficient scratch is1024B per call; larger stack frame affects passthrough and fallback too; no heap/RSS/power claim.',
        'All original adverse first/control results and longer-control paired variance remain; no release-budget pass or universal improvement is inferred.',
        'Complete PCM/state/fenv/callback transcripts retain size/hash and reproducible source, not redundant hundreds-of-megabytes payload copies.',
        'Current source and probe compile strictly for Windows x64/AArch64; actual linking, engine/capture/ART behavior and full manual forkCI remain pending.',
        'Local ASAN_OPTIONS=detect_leaks=0 is an explicit ptrace limitation; ASan/UBSan remain active and CI environment is unchanged.',
        'T12 receives bounded component evidence; broad application/ABI/tail/power budgets and M11 independent pitch/time-stretch/sync stay open.'
    ]}
for name in ['media-resampler-selected-policy.log','media-resampler-selected-supplier.log',
             'media-resampler-fork-diagnostic.log','media-resampler-powershell.log']:
    content = (BASE/name).read_bytes()
    payload['gates'][name]={'sha256':sha(content),'content':content.decode(),'archive_member':'raw/'+name}
DOC.write_text(json.dumps(payload,indent=2)+'\n')
print('RESAMPLER_EVIDENCE_ARCHIVE_PASS',len(members),ARCHIVE.stat().st_size,sha(ARCHIVE.read_bytes()))
