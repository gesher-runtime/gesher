/workspace/scratch/aa09b1a0dc1f/media-resampler-weights-windows/x86_64-candidate.o: \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/audio/engine.cc \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/audio/engine.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/sys/types.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/time.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/gesher/clocks.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/errno.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/gesher/awake_clock.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/audio/log.h \
  /workspace/scratch/aa09b1a0dc1f/media-camera-headers/system/logging/liblog/include/android/log.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/sys/cdefs.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/sys/time.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/audio/shared_state.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/audio/sink.h
