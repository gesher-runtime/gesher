/workspace/scratch/aa09b1a0dc1f/media-resampler-weights-windows/x86_64-probe.o: \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/probe/media_probe.cc \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/time.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/probe/../audio/capture.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/posix/include/sys/types.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/probe/../audio/engine.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-resample-channels/compat/media/probe/../audio/sink.h
