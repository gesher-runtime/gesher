from pathlib import Path
from collections import defaultdict
import hashlib, json, math, statistics

ROOT=Path(__file__).resolve().parent
checks=0
def check(value, message):
    global checks
    checks+=1
    if not value: raise AssertionError(message)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
names=['media-resampler-weights-final-abba.json','media-resampler-weights-long-controls.json']
reports=[json.loads((ROOT/name).read_text()) for name in names]
check(reports[0]['build']==reports[1]['build'], 'unchanged complete build across campaigns')
check(sha(ROOT/names[0])==reports[1]['prior_campaign_sha256'], 'retained original evidence identity')
for path,digest in reports[0]['build']['inputs'].items():
    check(sha(Path(path))==digest,'build input '+path)
for command in reports[0]['build']['commands']:
    check(command['returncode']==0,'compiled original source objects')
for variant,digest in reports[0]['binary_hashes'].items():
    check(sha(ROOT/'media-resampler-weights-final-build'/variant)==digest,'ordinary binary '+variant)
first={}
totals=[]
for index,report in enumerate(reports):
    wanted_blocks=6 if index==0 else 12
    wanted_cases=12 if index==0 else 7
    wanted_processes=wanted_blocks*wanted_cases*4
    check(len(report['processes'])==wanted_processes,'complete process matrix')
    observed=set();identities={};values=defaultdict(list)
    for process in report['processes']:
        identity=(process['block'],process['slot'],process['case'])
        check(identity not in observed,'unique scheduled process');observed.add(identity)
        check(0<=process['block']<wanted_blocks,'scheduled block')
        check(process['variant']==['baseline','candidate','candidate','baseline'][process['slot']],'ABBA variant')
        check(process['returncode']==0 and process['stderr']=='','successful original process')
        rows=[json.loads(line) for line in process['stdout'].splitlines()]
        check(rows==process['rows'],'unaltered parsed stdout')
        check([r['phase'] for r in rows]==['first','steady'],'both lifecycle phases')
        command=process['command']
        check(Path(command[0]).name==process['variant'],'actual ordinary binary command')
        for row in rows:
            check(row['process_ns']>=row['cpu_ns']>0,'full process interval contains timed thread')
            check(row['cycles']==(1 if row['phase']=='first' else int(command[7])),'declared cycle count')
            check(row['channels']==int(command[1]) and row['input_rate']==int(command[2]) and
                  row['output_rate']==int(command[3]) and row['frames']==int(command[4]) and
                  row['speed']==float(command[5]) and row['streaming']==bool(int(command[6])), 'exact workload identity')
            check(row['inputs']==row['frames']*row['cycles'],'all input frames transferred')
            check(row['mixes']==rows[0]['mixes']*row['cycles'],'all complete delivery calls')
            actual={k:v for k,v in row.items() if k not in ('cpu_ns','process_ns','wall_ns')}
            key=(process['case'],row['phase'])
            check(key not in identities or identities[key]==actual,'complete baseline/candidate PCM/state identity')
            identities[key]=actual
            if row['phase']=='first':
                check(process['case'] not in first or first[process['case']]==actual,'original first observation retained in longer campaign')
                first[process['case']]=actual
            for metric in ('cpu_ns','process_ns','wall_ns'):
                values[(*key,metric,process['variant'])].append(row[metric]/row['cycles'])
    check(len(identities)==wanted_cases*2,'complete cases and phases')
    check(len(report['summaries'])==wanted_cases*2,'complete summary rows')
    for row in report['summaries']:
        for metric in ('cpu_ns','process_ns','wall_ns'):
            current=row[metric]
            for variant in ('baseline','candidate'):
                samples=values[(row['case'],row['phase'],metric,variant)]
                check(len(samples)==wanted_blocks*2,'independent process observations')
                check(samples==current['samples_per_cycle'][variant],'all original observations included')
                check(statistics.median(samples)==current['median'][variant],'recomputed median')
            delta=(current['median']['candidate']/current['median']['baseline']-1)*100
            check(math.isclose(delta,current['change_percent'],rel_tol=1e-12,abs_tol=1e-10),'recomputed delta')
    totals.append(dict(file=names[index],sha256=sha(ROOT/names[index]),processes=len(report['processes']),
                       observations=2*len(report['processes'])))
result=dict(verdict='PASS: both complete fixed-source campaigns independently recomputed',checks=checks,
            campaigns=totals,limitations='No timed rerun. All adverse original and longer controls remain separate; no universal regression budget or Windows runtime acceptance inferred.')
(ROOT/'native-review-resampler-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
