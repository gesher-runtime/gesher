#!/usr/bin/env python3
"""Predeclared longer controls for unchanged final resampler binaries.

The original 576 observations remain complete-work evidence. This separate
campaign addresses short-control duration and common-path risk; source,
compiler, allocator, executable and first lifecycle remain unchanged.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'gesher-media-resample-channels/tools'))
import benchmark_audio_resampler_weights as original
WORK = BASE / 'media-resampler-weights-final-build'
OUTPUT = BASE / 'media-resampler-weights-long-controls.json'
DECLARED = [('stereo_unity_stream',2048), ('stereo_short_stream',4096),
            ('mono_one_static',65536), ('no_read_static',262144),
            ('stereo_44100_stream',64), ('stereo_wide_fallback',64),
            ('stereo_96000_stream',64)]
BLOCKS = 12


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    if OUTPUT.exists():
        raise RuntimeError('Refusing to overwrite earlier control measurements')
    build = json.loads((WORK / 'build.json').read_text())
    for path, digest in build['inputs'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    prior_path = BASE / 'media-resampler-weights-final-abba.json'
    prior = json.loads(prior_path.read_text())
    assert prior['build'] == build
    cases = dict(original.CASES)
    identities, first_identities = {}, {}
    excluded = {'cpu_ns','process_ns','wall_ns'}
    for proc in prior['processes']:
        row = next(r for r in proc['rows'] if r['phase'] == 'first')
        first_identities[proc['case']] = {k:v for k,v in row.items() if k not in excluded}
    payload = {'purpose':__doc__, 'start_utc':now(), 'blocks':BLOCKS,
               'declared_cases_and_cycles':DECLARED, 'order':'ABBA; rotate cases per block',
               'build':build, 'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'prior_campaign_sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest(), 'processes':[]}
    for block in range(BLOCKS):
        offset = block % len(DECLARED)
        for name, cycles in DECLARED[offset:] + DECLARED[:offset]:
            for slot, variant in enumerate(['baseline','candidate','candidate','baseline']):
                command = [str(WORK/variant),*cases[name],str(cycles),'128']
                started = now()
                result = subprocess.run(command,text=True,capture_output=True,timeout=60)
                record = {'block':block,'slot':slot,'case':name,'variant':variant,
                          'start_utc':started,'end_utc':now(),'command':command,
                          'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
                payload['processes'].append(record)
                OUTPUT.write_text(json.dumps(payload,indent=2)+'\n')
                assert result.returncode == 0 and not result.stderr, record
                rows = [json.loads(line) for line in result.stdout.splitlines()]
                assert [r['phase'] for r in rows] == ['first','steady']
                record['rows'] = rows
                for row in rows:
                    assert row['process_ns'] >= row['cpu_ns']
                    identity = {k:v for k,v in row.items() if k not in excluded}
                    key = name,row['phase']
                    assert key not in identities or identities[key] == identity, key
                    identities[key] = identity
                    if row['phase'] == 'first': assert identity == first_identities[name],name
                print(block,name,slot,variant,'PASS',flush=True)
    payload['end_utc'] = now()
    payload['summaries'] = []
    for name,_ in DECLARED:
        for phase in ['first','steady']:
            summary = {'case':name,'phase':phase}
            for metric in ['cpu_ns','process_ns','wall_ns']:
                values = {variant:[r[metric]/r['cycles'] for proc in payload['processes']
                                    if proc['case']==name and proc['variant']==variant
                                    for r in proc['rows'] if r['phase']==phase]
                          for variant in ['baseline','candidate']}
                medians = {k:statistics.median(v) for k,v in values.items()}
                summary[metric] = {'samples_per_cycle':values,'median':medians,
                                   'change_percent':(medians['candidate']/medians['baseline']-1)*100}
            payload['summaries'].append(summary)
    OUTPUT.write_text(json.dumps(payload,indent=2)+'\n')
    for row in payload['summaries']:
        print(row['case'],row['phase'],'CPU',round(row['cpu_ns']['change_percent'],3),
              'wall',round(row['wall_ns']['change_percent'],3),flush=True)


if __name__ == '__main__': main()
