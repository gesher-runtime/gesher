#!/usr/bin/env python3
"""Preserve the separately scoped Scandir supplier-CI integration evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

W = Path(__file__).resolve().parent
REPO = W / 'gesher-native-scandir-suppliers'
HEAD = '0654cde8fb473b463a0ac5ad29149d6a5b2037c0'
MAIN = '52513f0fc3f5fc657138cf01429cf969b2f21649'
report_path = REPO / 'docs/research/scandir-stable-sort-2026-11-23.json'
archive_path = 'docs/research/data/scandir-supplier-ci-2026-11-23.tar.gz'

def sha(data):
    return hashlib.sha256(data).hexdigest()

result = subprocess.run(['python3', str(W / 'native_scandir_main525_proof.py')],
                        text=True, capture_output=True)
(W / 'native-scandir-main525-proof.log').write_text(result.stdout + result.stderr)
result.check_returncode()
proof = json.loads((W / 'native-scandir-main525-composition-proof.json').read_text())
payload = {}
workspace = [
    'native_scandir_main525_proof.py', 'native_scandir_main525_package.py',
    'native-scandir-main525-composition-proof.json', 'native-scandir-main525-proof.log',
    'native-scandir-main525-initial-proof.json', 'native-scandir-main525-compatibility.json',
    'native-scandir-main525-gates.json', 'main-52513f0f-2132.json',
    'native-scandir-main525-test_supplier_bundle.log',
    'native-scandir-main525-test_artifact_batch.log',
    'native-scandir-main525-test_github_rate_limits.log',
    'native-scandir-main525-report-original-negative.log',
    'native-scandir-main525-report.log', 'native-scandir-main525-source.log',
    'native-scandir-main525-supplier.log', 'native-scandir-main525-selected-supplier.log',
    'native-scandir-main525-vector.log', 'native-scandir-main525-memrchr-report.log',
]
for name in workspace:
    payload['workspace/' + name] = (W / name).read_bytes()
incoming_paths = subprocess.check_output(['git', 'diff', '--name-only', MAIN + '^', MAIN],
                                         cwd=REPO, text=True).splitlines()
for path in incoming_paths:
    payload['main525/' + path] = subprocess.check_output(['git', 'show', MAIN + ':' + path], cwd=REPO)
    payload['repo/' + path] = (REPO / path).read_bytes()
for path in ('tools/scandir_ci_integration.py', 'tools/test_scandir_report.py'):
    payload['repo/' + path] = (REPO / path).read_bytes()
for path in ('.github/workflows/ci.yml', 'tools/test_scandir_report.py',
             'tools/ci/artifact_receipt.py', 'docs/research/scandir-stable-sort-2026-11-23.json'):
    payload['published430/' + path] = subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=REPO)
manifest = {'format': 1, 'scope': 'Separate canonical supplier-CI integration; original timing archive unchanged.',
            'members': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payload.items())}}
payload['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(payload.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = 0
        archive.addfile(entry, io.BytesIO(data))
blob = gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0)
(REPO / archive_path).write_bytes(blob)
with tarfile.open(fileobj=io.BytesIO(blob), mode='r:gz') as archive:
    observed = {entry.name: archive.extractfile(entry).read() for entry in archive if entry.isfile()}
assert observed == payload
report = json.loads(report_path.read_text())
section = report['supplier_bundle_integration']
section['local_canonical_merge_commit'] = section.pop('canonical_merge_commit', proof['canonical_local_commit'])
section['canonical_proof'] = proof
section['compatibility_checks'] = json.loads((W / 'native-scandir-main525-compatibility.json').read_text())
section['gate_receipts'] = json.loads((W / 'native-scandir-main525-gates.json').read_text())
section['invocation_note'] = 'The first supplier command named a nonexistent file; its exit2 is retained. The actual maintained test-selected-supplier.py passed unchanged. This is a command-path error, not a source assertion or a relaxed gate.'
section['evidence_archive'] = {'path': archive_path, 'sha256': sha(blob), 'bytes': len(blob), 'members': len(payload)}
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(section['evidence_archive'], indent=2))
