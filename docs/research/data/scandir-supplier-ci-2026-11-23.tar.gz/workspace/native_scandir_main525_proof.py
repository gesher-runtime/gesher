#!/usr/bin/env python3
"""Reconstruct the published Scandir/main525 merge and its narrow report adapter."""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import subprocess

W = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, default=W / 'gesher-native-scandir-suppliers')
parser.add_argument('--output', type=Path, default=W / 'native-scandir-main525-composition-proof.json')
parser.add_argument('--merge-commit', help='optional exact merge to inspect; otherwise locate its ordered parents in HEAD ancestry')
args = parser.parse_args()
REPO = args.repo.resolve()
HEAD = '0654cde8fb473b463a0ac5ad29149d6a5b2037c0'
MAIN = '52513f0fc3f5fc657138cf01429cf969b2f21649'
checks = 0

def need(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def text(*args):
    return git(*args).decode().strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(ref):
    result = {}
    for row in git('ls-tree', '-rz', ref).split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            result[path.decode()] = {'mode': mode, 'type': kind, 'sha': blob}
    return result

base = text('merge-base', HEAD, MAIN)
need(base == text('rev-parse', MAIN + '^'), 'public main advances the previously composed ancestor')
canonical = text('merge-tree', '--write-tree', HEAD, MAIN).splitlines()[0]
need(canonical == 'e821b52bbaf8f8582ec96313ad1573a1d08ee755', 'exact canonical merged tree')
matches = [row.split()[0] for row in text('rev-list', '--parents', 'HEAD').splitlines()
           if row.split()[1:] == [HEAD, MAIN]]
need(bool(matches) or args.merge_commit is not None, 'canonical ordered merge exists in the reviewed history')
MERGE = args.merge_commit or matches[0]
need(text('show', '-s', '--format=%T', MERGE) == canonical, 'committed complete canonical tree')
need(text('show', '-s', '--format=%P', MERGE).split() == [HEAD, MAIN], 'ordered published parents')
ancestor, feature, incoming, merged = map(tree, (base, HEAD, MAIN, MERGE))
changed_feature = {p for p in set(ancestor) | set(feature) if ancestor.get(p) != feature.get(p)}
changed_main = {p for p in set(ancestor) | set(incoming) if ancestor.get(p) != incoming.get(p)}
need(len(changed_main) == 14, 'complete fourteen-path main advance')
need(changed_feature & changed_main == {'.github/workflows/ci.yml'}, 'sole shared path is CI')
for path in changed_feature - changed_main:
    need(merged.get(path) == feature.get(path), 'exact feature path/mode: ' + path)
for path in changed_main - changed_feature:
    need(merged.get(path) == incoming.get(path), 'exact incoming path/mode: ' + path)
for path in (set(ancestor) | set(merged)) - changed_feature - changed_main:
    need(merged.get(path) == ancestor.get(path), 'all other paths untouched: ' + path)

adapter_path = REPO / 'tools/scandir_ci_integration.py'
spec = importlib.util.spec_from_file_location('scandir_ci_integration', adapter_path)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)
ci = (REPO / adapter.CI).read_bytes()
need(ci == git('show', MERGE + ':' + adapter.CI), 'current workflow is the automatic merge')
stripped = ci
for command in adapter.COMMANDS:
    need(stripped.count(command) == 1, 'each inherited feature gate occurs once')
    stripped = stripped.replace(command, b'')
need(stripped == git('show', MAIN + ':' + adapter.CI), 'full incoming workflow plus only four retained gates')
historical_report = json.loads(git('show', HEAD + ':docs/research/scandir-stable-sort-2026-11-23.json'))
current_report = json.loads((REPO / 'docs/research/scandir-stable-sort-2026-11-23.json').read_text())
need(set(current_report) == set(historical_report) | {'supplier_bundle_integration'}, 'one separately scoped report section')
for key, value in historical_report.items():
    need(current_report[key] == value, 'historical report field retained: ' + key)
for path, expected in historical_report['sources'].items():
    if path not in (adapter.CI, adapter.VERIFIER):
        need(sha((REPO / path).read_bytes()) == expected, 'all measured/protected inputs unchanged: ' + path)
original_verifier = git('show', HEAD + ':' + adapter.VERIFIER)
need((REPO / adapter.VERIFIER).read_bytes() == adapter.integrated_verifier(original_verifier, sha(adapter_path.read_bytes())), 'complete original verifier plus exact two edits')
archive = REPO / historical_report['archive']['path']
need(sha(archive.read_bytes()) == historical_report['archive']['sha256'], 'complete original evidence archive unchanged')

def functions(source):
    value = source.decode()
    return {node.name: ast.get_source_segment(value, node) for node in ast.parse(value).body
            if isinstance(node, ast.FunctionDef)}

old = functions(git('show', HEAD + ':tools/ci/artifact_receipt.py'))
new = functions(git('show', MAIN + ':tools/ci/artifact_receipt.py'))
changed = sorted(name for name in old if old[name] != new.get(name))
need(changed == ['batch', 'main'], 'all original producer/single/retained-installer predicates unchanged')
data = {
    'checks': checks, 'published_feature': HEAD, 'incoming_main': MAIN,
    'merge_base': base, 'canonical_local_commit': MERGE, 'canonical_tree': canonical,
    'ordered_parents': [HEAD, MAIN],
    'feature_only_paths': {p: feature.get(p) for p in sorted(changed_feature - changed_main)},
    'main_only_paths': {p: incoming.get(p) for p in sorted(changed_main - changed_feature)},
    'shared_paths': ['.github/workflows/ci.yml'],
    'workflow_sha256': sha(ci), 'incoming_workflow_sha256': sha(stripped),
    'retained_feature_commands': [line.decode().strip() for line in adapter.COMMANDS],
    'historical_report_fields': list(historical_report),
    'original_archive': historical_report['archive'],
    'all_measured_and_protected_sources_unchanged': True,
    'original_artifact_functions_changed': changed,
    'adapter_sha256': sha(adapter_path.read_bytes()),
    'verifier_sha256': sha((REPO / adapter.VERIFIER).read_bytes()),
    'limits': 'No new timing or runtime acceptance. Existing authenticated bundle transport is simulated only by its maintained contract suites; actual full CI remains separate.'
}
args.output.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({k: data[k] for k in ('checks', 'canonical_tree', 'workflow_sha256', 'adapter_sha256', 'verifier_sha256')}, indent=2))
