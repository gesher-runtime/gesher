#include <cstdio>
#include <vector>
int main(){std::vector<int> x{1}; std::printf("AVX2=%d\n", int(__builtin_cpu_supports("avx2"))); return x[0]!=1;}
