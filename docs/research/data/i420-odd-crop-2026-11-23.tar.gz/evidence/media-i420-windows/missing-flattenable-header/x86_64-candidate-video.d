/workspace/scratch/aa09b1a0dc1f/media-i420-windows/x86_64-candidate-video.o: \
  /workspace/scratch/aa09b1a0dc1f/media-i420-windows/candidate-video.cc \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/media/video/video_decoder.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/media/video/../player/extractor.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/media/video/../player/data_source.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/posix/include/sys/types.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/posix/include/time.h \
  /workspace/scratch/aa09b1a0dc1f/media-i420-native-headers/frameworks/av/media/ndk/include/media/NdkMediaFormat.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/posix/include/sys/cdefs.h \
  /workspace/scratch/aa09b1a0dc1f/media-i420-native-headers/frameworks/av/media/ndk/include/media/NdkMediaError.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/media/video/../audio/log.h \
  /workspace/scratch/aa09b1a0dc1f/media-camera-headers/system/logging/liblog/include/android/log.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/posix/include/sys/time.h \
  /workspace/scratch/aa09b1a0dc1f/gesher-media-i420-crop/compat/media/video/yuv_rgba.h
