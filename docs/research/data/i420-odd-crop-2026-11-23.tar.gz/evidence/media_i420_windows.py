from pathlib import Path
import subprocess,json,hashlib,datetime,sys,os
base=Path('/workspace/scratch/aa09b1a0dc1f');repo=base/'gesher-media-i420-crop';out=base/'media-i420-windows';out.mkdir(exist_ok=True)
compiler=base/'toolchains/llvm-mingw-20261006-ucrt-ubuntu-22.04-x86_64/bin'
common=['-std=c++23','-O2','-g','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-deprecated-copy','-mno-ms-bitfields','-fno-exceptions','-fsized-deallocation','-include','new','-include','cmath','-Wno-invalid-specialization','-Wno-deprecated-declarations']
common += ['-D'+v for v in ['GESHER','USE_MINGW','WIN32_LEAN_AND_MEAN','NOMINMAX','NOGDI','_USE_MATH_DEFINES','__STDC_FORMAT_MACROS','__STDC_CONSTANT_MACROS','__STDC_LIMIT_MACROS','_WIN32_WINNT=0x0A00','WINVER=0x0A00','_FILE_OFFSET_BITS=64','_POSIX_THREAD_SAFE_FUNCTIONS']]
includes=[repo,repo/'compat/posix/include',repo/'compat/framework/include',repo/'compat/hwui/include-native',repo/'include',repo/'compat/media/video',base/'media-i420-native-headers/frameworks/av/media/ndk/include',base/'frameworks-av-android16/media/ndk/include/private',base/'libnativehelper-android16/include_jni']
headers=base/'media-i420-native-headers';camera=base/'media-camera-headers'
includes += [headers/'system/core/libcutils/include',headers/'system/core/libutils/binder/include',headers/'system/core/libutils/include']
includes += [headers/p for p in ['frameworks/base/libs/hostgraphics/include','frameworks/native/libs/ui/include','frameworks/native/libs/nativebase/include','frameworks/native/libs/nativewindow/include','frameworks/native/libs/arect/include','frameworks/native/libs/math/include','frameworks/native/libs/nativedisplay/include']]
includes += [camera/p for p in ['system/core/libutils/binder/include','system/core/libutils/include','system/core/libsystem/include','system/core/libcutils/include','system/logging/liblog/include','system/libbase/include']]
common += [v for p in includes for v in ['-I',str(p)]]
paths={'video':'compat/media/video/video_decoder.cc','renderer':'compat/media/video/render.cc','surface':'compat/media/surface/queue_surface.cc','fixture':'tests/media/i420_crop_test.cc'}
selected=sys.argv[1:] or list(paths)
records=[]
for arch in os.environ.get('I420_ARCHS','x86_64,aarch64').split(','):
 for label in selected:
  path=paths[label]
  for variant in (('baseline','candidate') if label=='video' else ('candidate',)):
   source=(subprocess.check_output(['git','show','e505ad227523aaca566d05b8af6e466495c819cc:'+path],cwd=repo) if variant=='baseline' else (repo/path).read_bytes())
   src=out/(variant+'-'+label+'.cc');src.write_bytes(source)
   # Full real TU, with only the original quoted-header directory added.
   options=list(common)
   if label in ('video','renderer'):
    for flag in ('-Wno-invalid-specialization','-Wno-deprecated-declarations'):
     options.remove(flag)
    for header in ('new','cmath'):
     index=options.index('-include'); assert options[index+1]==header; del options[index:index+2]
   cmd=[str(compiler/(arch+'-w64-mingw32-g++'))]+options+['-I',str((repo/path).parent),'-c',str(src),'-o',str(out/(arch+'-'+variant+'-'+label+'.o')),'-MMD','-MF',str(out/(arch+'-'+variant+'-'+label+'.d'))]
   start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);end=datetime.datetime.now(datetime.timezone.utc).isoformat()
   log=out/(arch+'-'+variant+'-'+label+'.log');log.write_text(r.stdout+r.stderr)
   row={'arch':arch,'label':label,'variant':variant,'path':path,'source_sha256':hashlib.sha256(source).hexdigest(),'command':cmd,'start':start,'end':end,'returncode':r.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
   (out/(arch+'-'+variant+'-'+label+'.json')).write_text(json.dumps(row,indent=2)+'\n');records.append(row)
   print(arch,variant,label,r.returncode,flush=True)
   if r.returncode:print(r.stderr[:8000],flush=True)
(out/'last-run.json').write_text(json.dumps(records,indent=2)+'\n')
