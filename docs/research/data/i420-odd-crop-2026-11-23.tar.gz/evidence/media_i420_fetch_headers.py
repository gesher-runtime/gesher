from pathlib import Path
import base64,json,hashlib,urllib.request,sys
root=Path('/workspace/scratch/aa09b1a0dc1f/media-i420-native-headers')
manifest=root/'source-manifest-extra.json'
rows=json.loads(manifest.read_text()) if manifest.exists() else []
for arg in sys.argv[1:]:
 project,path=arg.split(':',1);url=f'https://android.googlesource.com/platform/{project}/+/android-16.0.0_r4/{path}?format=TEXT'
 dest=root/project/path
 if dest.exists():
  print('existing',project,path);continue
 data=base64.b64decode(urllib.request.urlopen(url,timeout=40).read());dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 rows.append({'project':project,'path':path,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 manifest.write_text(json.dumps(rows,indent=2)+'\n');print('fetched',project,path,len(data),flush=True)
