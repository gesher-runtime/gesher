#pragma once
#include "compat/media/video/video_decoder.h"
// Android object/dispatch and Win32 Window adapters only. Complete surfaces follow below.
#include <algorithm>
#include <cerrno>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <limits>
#include <memory>
#include <mutex>
#include <optional>
#include <vector>

// <gesher/perf_trace.h>'s timing sites as production runs them without
// GESHER_PERF_TRACE (docs/media.md, "Measuring playback"): off.
namespace gesher::perf {
inline bool Enabled() { return false; }
inline int64_t Now() { return 0; }
struct Site {
  constexpr explicit Site(const char*, int64_t = 0) {}
  void Add(int64_t, int64_t = 0) {}
};
}  // namespace gesher::perf

enum { NATIVE_WINDOW_CONCRETE_TYPE, NATIVE_WINDOW_DEFAULT_HEIGHT, NATIVE_WINDOW_DEFAULT_WIDTH, NATIVE_WINDOW_FORMAT, NATIVE_WINDOW_GET_COMPOSITOR_TIMING, NATIVE_WINDOW_GET_CONSUMER_USAGE64, NATIVE_WINDOW_GET_FRAME_TIMESTAMPS, NATIVE_WINDOW_GET_LAST_DEQUEUE_DURATION, NATIVE_WINDOW_GET_LAST_DEQUEUE_START, NATIVE_WINDOW_GET_LAST_QUEUED_BUFFER, NATIVE_WINDOW_GET_LAST_QUEUED_BUFFER2, NATIVE_WINDOW_GET_LAST_QUEUE_DURATION, NATIVE_WINDOW_GET_NEXT_FRAME_ID, NATIVE_WINDOW_GET_REFRESH_CYCLE_DURATION, NATIVE_WINDOW_HEIGHT, NATIVE_WINDOW_IS_VALID, NATIVE_WINDOW_LOCK, NATIVE_WINDOW_MAX_BUFFER_COUNT, NATIVE_WINDOW_MIN_UNDEQUEUED_BUFFERS, NATIVE_WINDOW_QUEUES_TO_WINDOW_COMPOSER, NATIVE_WINDOW_SET_BUFFERS_DIMENSIONS, NATIVE_WINDOW_SET_BUFFERS_FORMAT, NATIVE_WINDOW_SET_BUFFERS_GEOMETRY, NATIVE_WINDOW_SET_BUFFERS_TIMESTAMP, NATIVE_WINDOW_SET_BUFFERS_USER_DIMENSIONS, NATIVE_WINDOW_SURFACE, NATIVE_WINDOW_UNLOCK_AND_POST, NATIVE_WINDOW_WIDTH };
constexpr int ANDROID_NATIVE_WINDOW_MAGIC = 0x574e444f;
constexpr int HAL_PIXEL_FORMAT_RGBA_8888 = 1, HAL_PIXEL_FORMAT_RGBX_8888 = 2;
constexpr int HAL_PIXEL_FORMAT_BGRA_8888 = 5, SYSTEM_TIME_MONOTONIC = 1;
constexpr int64_t NATIVE_WINDOW_TIMESTAMP_AUTO = INT64_MIN;
inline int64_t systemTime(int) { return 12345678; }
struct ARect { int left, top, right, bottom; };
struct ANativeWindow_Buffer {
  int width = 0, height = 0, stride = 0, format = 0;
  void* bits = nullptr;
  uint32_t reserved[6] = {};
};
struct ANativeWindowBuffer {
  int width = 0, height = 0, stride = 0, format = 0;
  int usage_deprecated = 0, layerCount = 0;
  void* reserved[4] = {};
  void* handle = nullptr;
  uint64_t usage = 0;
};
struct ANativeWindow {
  struct { int magic = ANDROID_NATIVE_WINDOW_MAGIC; } common;
  float xdpi = 0, ydpi = 0;
  int minSwapInterval = 0, maxSwapInterval = 0;
  int (*setSwapInterval)(ANativeWindow*, int) = nullptr;
  int (*queueBuffer)(ANativeWindow*, ANativeWindowBuffer*, int) = nullptr;
  int (*cancelBuffer)(ANativeWindow*, ANativeWindowBuffer*, int) = nullptr;
  int (*dequeueBuffer)(ANativeWindow*, ANativeWindowBuffer**, int*) = nullptr;
  int (*query)(const ANativeWindow*, int, int*) = nullptr;
  int (*perform)(ANativeWindow*, int, ...) = nullptr;
  void *dequeueBuffer_DEPRECATED = nullptr, *lockBuffer_DEPRECATED = nullptr;
  void *queueBuffer_DEPRECATED = nullptr, *cancelBuffer_DEPRECATED = nullptr;
};
namespace android {
class RefBase {};
template<class Base, class Self, class Ref> class ANativeObjectBase : public Base {};
template<class T> class sp {
 public:
  sp() = default;
  sp(std::nullptr_t) {}
  template<class... A> static sp make(A&&... args) {
    sp result;
    result.ptr_ = std::make_shared<T>(std::forward<A>(args)...);
    return result;
  }
  T* get() const { return ptr_.get(); }
  T* operator->() const { return get(); }
  bool operator==(std::nullptr_t) const { return !ptr_; }
  bool operator!=(std::nullptr_t) const { return bool(ptr_); }
  bool operator!=(const sp& other) const { return ptr_ != other.ptr_; }
 private:
  std::shared_ptr<T> ptr_;
};
class Surface : public ANativeWindow {
 public:
  explicit Surface(std::nullptr_t) {
    ANativeWindow::perform = Perform;
    ANativeWindow::query = [](const ANativeWindow* window, int what, int* value) {
      return static_cast<const Surface*>(window)->query(what, value);
    };
    ANativeWindow::dequeueBuffer = [](ANativeWindow* window, ANativeWindowBuffer** out, int* fence) {
      return getSelf(window)->dequeueBuffer(out, fence);
    };
  }
  virtual ~Surface() = default;
  static int Perform(ANativeWindow* window, int operation, ...) {
    va_list args;
    va_start(args, operation);
    int result = getSelf(window)->perform(operation, args);
    va_end(args);
    return result;
  }
  static Surface* getSelf(ANativeWindow* window) { return static_cast<Surface*>(window); }
  virtual int lock(ANativeWindow_Buffer*, ARect*) = 0;
  virtual int unlockAndPost() = 0;
  virtual int query(int, int*) const = 0;
  virtual int dequeueBuffer(ANativeWindowBuffer**, int*) = 0;
  virtual int cancelBuffer(ANativeWindowBuffer*, int) = 0;
  virtual int queueBuffer(ANativeWindowBuffer*, int) = 0;
  virtual int perform(int, va_list) = 0;
  virtual int setSwapInterval(int) = 0;
};
}
namespace gesher {
class Window {
 public:
  Window(int w, int h) : w_(w), h_(h), pixels_(static_cast<size_t>(w) * h) {}
  int width() const { return w_; }
  int height() const { return h_; }
  uint8_t* Lock(int* w, int* h, int* stride) {
    *w = w_; *h = h_; *stride = w_;
    return reinterpret_cast<uint8_t*>(pixels_.data());
  }
  void UnlockAndPost() {}
  void PresentPixels(const uint32_t*, int, int, int = 0) {}
  void ReadBackBuffer(std::vector<uint32_t>* dst, int* w, int* h) {
    *dst = pixels_; *w = w_; *h = h_;
  }
 private:
  int w_, h_;
  std::vector<uint32_t> pixels_;
};
}

namespace android { constexpr int OK = 0, BAD_VALUE = -EINVAL, NO_INIT = -ENODEV; }
// Gesher media: a Surface whose frames stay in the process (docs/media.md
// "Video", ADR 0051): what a SurfaceTexture (TextureView) and a SurfaceView
// hand their producer (MediaCodec, MediaPlayer, an app's Canvas or NDK code).
//
// QueueSurface is hostgraphics' android::Surface, like the window's
// Win32Surface, but its buffers go nowhere on screen by themselves: each
// frame queued (queueBuffer, unlockAndPost) becomes its latest frame, an
// immutable RGBA copy, and its listener is called; hwui draws the latest
// frame where the TextureView or the SurfaceView is (surface_jni.cc). There is
// no compositor: the window redraws to show a new frame.

namespace gesher::media {

struct SurfaceFrame {
  int width = 0, height = 0;  // stride == width
  std::vector<uint32_t> pixels;  // RGBA_8888 (R in the low byte)
  int64_t timestamp_ns = 0;
  uint64_t number = 0;
  int video_scaling_mode = 1;  // MediaCodec scale-to-fit; pixels remain uncropped.
};

class QueueSurface : public android::Surface {
 public:
  QueueSurface(int default_width, int default_height);

  // The QueueSurface `window` is, or null.
  static QueueSurface* From(ANativeWindow* window);

  // The size buffers have when the producer sets none (SurfaceTexture's
  // setDefaultBufferSize, the SurfaceView's size).
  void SetDefaultSize(int width, int height);
  // Called on the producer's thread after each frame.
  void SetListener(std::function<void()> listener);
  // The last frame queued, or null.
  std::shared_ptr<const SurfaceFrame> Latest() const;
  uint64_t frames() const;
  // No producer may draw any more (SurfaceTexture.release).
  void Abandon();
  // A frame from a producer in another process (a Surface parceled to it,
  // compat/framework/surface_parcel.cc), queued as queueBuffer queues one:
  // `pixels` (RGBA_8888, `stride` pixels a row) become the latest frame, with
  // the producer's time stamp, and the listener is called. This surface's own
  // producer state (its buffer, requested size and format, a lock) is left
  // alone. False once abandoned.
  bool PostFrame(int width, int height, int stride, const uint32_t* pixels, int64_t timestamp_ns,
                 int video_scaling_mode = 1);

  int lock(ANativeWindow_Buffer* out_buffer, ARect* in_out_dirty) override;
  int unlockAndPost() override;
  // Set a timestamp for this frame alone, preserving the native producer setting.
  int UnlockAndPostWithTimestamp(int64_t timestamp_ns, int video_scaling_mode = 1);
  int query(int what, int* value) const override;

 public:
  ~QueueSurface() override;

  int dequeueBuffer(ANativeWindowBuffer** buffer, int* fence_fd) override;
  int cancelBuffer(ANativeWindowBuffer* buffer, int fence_fd) override;
  int queueBuffer(ANativeWindowBuffer* buffer, int fence_fd) override;
  int perform(int operation, va_list args) override;
  int setSwapInterval(int interval) override;

 private:
  class Buffer;
  class FramePool;
  class RecycledFrame;

  void Size(int* width, int* height) const;
  void UpdateFrameGeometry();  // with mutex_ held; drops obsolete reusable pixels
  void EnsureBuffer();  // with mutex_ held
  int UnlockAndPost(std::optional<int64_t> timestamp_ns, int video_scaling_mode = 1);
  // Copies buffer_ as the latest frame with mutex_ held. Invoke the returned
  // listener after unlocking, so it can read back the published frame.
  std::function<void()> PublishLocked(std::optional<int64_t> timestamp_ns,
                                       int video_scaling_mode = 1);

  static int HookSetSwapInterval(ANativeWindow* window, int interval);
  static int HookQueueBuffer(ANativeWindow* window, ANativeWindowBuffer* buffer, int fence_fd);
  static int HookCancelBuffer(ANativeWindow* window, ANativeWindowBuffer* buffer, int fence_fd);

  mutable std::mutex mutex_;
  android::sp<Buffer> buffer_;
  std::vector<android::sp<Buffer>> dequeued_;
  int format_ = 1;  // PIXEL_FORMAT_RGBA_8888
  int requested_width_ = 0, requested_height_ = 0;
  int user_width_ = 0, user_height_ = 0;
  int default_width_ = 1, default_height_ = 1;
  int64_t timestamp_ns_ = NATIVE_WINDOW_TIMESTAMP_AUTO;
  bool locked_ = false;
  bool buffer_contents_valid_ = false;
  bool abandoned_ = false;
  std::shared_ptr<FramePool> frame_pool_;
  std::shared_ptr<const SurfaceFrame> latest_;
  uint64_t frames_ = 0;
  std::function<void()> listener_;
};

}  // namespace gesher::media

inline int ANativeWindow_setBuffersGeometry(ANativeWindow* w, int width, int height, int format) {
  return w->perform(w, NATIVE_WINDOW_SET_BUFFERS_GEOMETRY, width, height, format);
}
inline int ANativeWindow_lock(ANativeWindow* w, ANativeWindow_Buffer* b, ARect* dirty) {
  return static_cast<android::Surface*>(w)->lock(b, dirty);
}
inline int ANativeWindow_unlockAndPost(ANativeWindow* w) {
  return static_cast<android::Surface*>(w)->unlockAndPost();
}
