#!/usr/bin/env python3
"""Exact production timestamp and codec owner methods with declared host boundaries.

The real QueueSurface/ANativeWindow fixture is separate and runs on Windows.
This does not establish complete MediaCodec-object lifetime under MC_release.
"""
from __future__ import annotations
import argparse
import hashlib
import os
from pathlib import Path
import re
import shlex
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def section(source: str, start: str, end: str) -> str:
    if source.count(start) != 1 or source.count(end) != 1:
        raise ValueError("production boundaries changed: " + start)
    return source[source.index(start):source.index(end, source.index(start))]


def source_text(relative: str, ref: str | None) -> str:
    if ref:
        return subprocess.run(["git", "show", ref + ":" + relative], cwd=ROOT,
                              capture_output=True, check=True, text=True).stdout
    return (ROOT / relative).read_text(encoding="utf-8")


def method(source: str, marker: str) -> str:
    if source.count(marker) != 1:
        raise ValueError("production method boundary changed: " + marker)
    start = source.index(marker)
    end = source.index("{", start) + 1
    depth = 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


def generate(component: str, ref: str | None) -> str:
    if component == "codec":
        source = source_text("compat/media/jni/media_codec_jni.cc", ref)
        template = (ROOT / "tests/media/codec_window_host.cc.in").read_text(encoding="utf-8")
        replacements = {
            "@THROW_CODEC_EXCEPTION@": section(source, "void ThrowCodecException(JNIEnv* env,",
                                               "// A MediaFormat's keys"),
            "@SET_SURFACE@": section(source, "  void SetSurface(JNIEnv* env, jobject surface",
                                      "  bool has_surface() const"),
            "@RELEASE_OUTPUT@": section(source, "  bool ReleaseOutput(int index, bool render,",
                                        "  jobject InputBuffer(JNIEnv* env, int index)"),
            "@JNI_RELEASE_OUTPUT@": section(source, "void JNICALL MC_releaseOutputBuffer(JNIEnv* env,",
                                            "void JNICALL MC_signalEndOfInputStream(")}
        for name, marker in {
            "START": "  bool Start(", "STOP": "  void Stop(",
            "STOP_LOCKED": "  void StopLocked(", "STOP_WORKER": "  void StopWorker(",
            "RESET": "  void Reset(", "FLUSH": "  void Flush(",
            "RELEASE": "  void Release(", "POST_FATAL": "  void PostFatalErrorLocked(",
            "DEQUEUE_INPUT": "  int DequeueInput(", "DEQUEUE_OUTPUT": "  int DequeueOutput(",
            "JNI_DEQUEUE_INPUT": "jint JNICALL MC_dequeueInputBuffer(",
            "JNI_DEQUEUE_OUTPUT": "jint JNICALL MC_dequeueOutputBuffer(",
            "JNI_SET_SURFACE": "void JNICALL MC_setSurface(",
            "JNI_START": "void JNICALL MC_start(", "JNI_STOP": "void JNICALL MC_stop(",
            "JNI_FLUSH": "void JNICALL MC_flush(",
            "JNI_VIDEO_SCALING": "void JNICALL MC_setVideoScalingMode(",
        }.items():
            replacements["@" + name + "@"] = method(source, marker)
        replacements["@SET_VIDEO_SCALING@"] = (method(source, "  bool SetVideoScalingMode(")
                if "  bool SetVideoScalingMode(" in source else "")
    else:
        source = source_text("compat/media/surface/queue_surface.cc", ref)
        header = source_text("compat/media/surface/queue_surface.h", ref)
        members = re.findall(r"  int64_t timestamp_ns_ = [^;]+;", header)
        if len(members) != 1:
            raise ValueError("timestamp member boundary changed")
        template = (ROOT / "tests/media/surface_timestamp_host.cc.in").read_text(encoding="utf-8")
        if "int video_scaling_mode" not in source:
            template = template.replace(", int video_scaling_mode = 1", "")
        pool_members = pool_classes = ""
        if "class QueueSurface::FramePool {" in source:
            pool_members = ("class FramePool; class RecycledFrame;\n"
                            "  std::shared_ptr<FramePool> frame_pool_;\n  QueueSurface();")
            pool_classes = section(source, "class QueueSurface::FramePool {",
                                   "class QueueSurface::Buffer")
            pool_classes += ("\nQueueSurface::QueueSurface() : frame_pool_(std::make_shared<FramePool>()) {\n"
                             "  frame_pool_->Configure(buffer_->width, buffer_->height);\n}\n")
        replacements = {
            "@FRAME_POOL_MEMBERS@": pool_members,
            "@FRAME_POOL_CLASSES@": pool_classes,
            "@TIMESTAMP_MEMBER@": members[0].strip(),
            "@TIMESTAMP_DISPATCH@": section(source, "    case NATIVE_WINDOW_SET_BUFFERS_TIMESTAMP: {",
                                            "    case NATIVE_WINDOW_GET_REFRESH_CYCLE_DURATION:"),
            "@PUBLISH@": section(source, "int QueueSurface::unlockAndPost() {",
                                  "int QueueSurface::dequeueBuffer(")}
        source += header
    for marker, body in replacements.items():
        if template.count(marker) != 1:
            raise ValueError("template marker changed: " + marker)
        template = template.replace(marker, body)
    digest = hashlib.sha256(source.encode()).hexdigest()
    print(component + " source SHA256 " + digest, flush=True)
    return "// Production source SHA256: " + digest + "\n" + template


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-ref")
    parser.add_argument("--cxx", default=os.environ.get("CXX", "c++"))
    parser.add_argument("--sanitize", action="store_true")
    parser.add_argument("--generate-codec", type=Path, help="Emit the portable exact-method fixture for CMake")
    args = parser.parse_args()
    if args.generate_codec:
        args.generate_codec.write_text(generate("codec", args.source_ref), encoding="utf-8")
        return 0
    with tempfile.TemporaryDirectory(prefix="gesher-media-surface-") as temporary:
        work = Path(temporary)
        failed = False
        for component in ["surface", "codec"]:
            source = work / (component + ".cc")
            source.write_text(generate(component, args.source_ref), encoding="utf-8")
            binary = work / component
            command = shlex.split(args.cxx) + [
                "-std=c++20", "-O2", "-g", "-Wall", "-Wextra", "-Werror", "-pthread",
                str(source), "-o", str(binary)]
            if args.sanitize:
                command += ["-fsanitize=address,undefined", "-fno-sanitize-recover=all",
                            "-fno-omit-frame-pointer"]
            subprocess.run(command, check=True, timeout=120)
            failed |= subprocess.run([str(binary)], check=False, timeout=30).returncode != 0
        return int(failed)


if __name__ == "__main__":
    raise SystemExit(main())
