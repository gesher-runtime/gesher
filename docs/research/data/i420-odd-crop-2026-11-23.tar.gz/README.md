# I420 odd-crop evidence

All original pilot and fixed final processes remain in the raw JSON files, including stdout, clocks, complete workload checksums and adverse controls. The final source is the 26-line bounded odd-crop addition; the original even branch is unchanged. The pilot used the retained combined-loop prototype. Both campaigns use the same caller source and exact output oracle.

Host component correctness and timing use the explicit Android object/dispatch/clock adapter. Actual Windows full TU compilation uses the archived real pinned headers; no Windows execution or complete media link is claimed. Initial instrumentation and header-assembly failures remain as history. The complete current fixture and production source, generated source, build commands, object/binary hashes, policy receipts and source-composition proofs are retained. Binaries are not bundled.

MANIFEST.json hashes every other member. Reproduce using the maintained tools from the PR and public baseline e505ad227523aaca566d05b8af6e466495c819cc.
