cmake_minimum_required(VERSION 3.24)
project(i420_object_closure LANGUAGES C CXX)
set(_media "${CMAKE_SOURCE_DIR}/compat/media")
function(gesher_graphics_cxx target)
  set_target_properties(${target} PROPERTIES CXX_STANDARD 23)
  target_compile_options(${target} PRIVATE
    "$<$<COMPILE_LANGUAGE:CXX>:SHELL:-include new -include cmath>"
    $<$<COMPILE_LANGUAGE:CXX>:-Wno-invalid-specialization>
    $<$<COMPILE_LANGUAGE:CXX>:-Wno-deprecated-declarations>)
endfunction()
set(GESHER_MEDIA_AUDIO_SOURCES
  ${_media}/audio/engine.cc
  ${_media}/audio/shared_state.cc
  ${_media}/audio/sink_file.cc
  ${_media}/audio/sink_wasapi.cc
  ${_media}/audio/wasapi_sink.cc
  # Audio input (media3, ADR 0059).
  ${_media}/audio/capture.cc
  ${_media}/audio/capture_wasapi.cc)

# Pure audio and its recording gate have no Java VM dependency.
add_library(gesher_media_audio OBJECT ${GESHER_MEDIA_AUDIO_SOURCES}
  ${_media}/audio/record_permission.cc)
target_link_libraries(gesher_media_audio PUBLIC log ole32 uuid)
target_compile_options(gesher_media_audio PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter)
add_library(gesher_media_player_core OBJECT
  ${_media}/player/data_source.cc
  ${_media}/player/http_source.cc
  ${_media}/player/extractor.cc
  ${_media}/player/decoder.cc
  ${_media}/player/decode_file.cc
  ${_media}/player/mf_decoder.cc
  ${_media}/player/player.cc
  # Video (stage 2, ADR 0051): decoders and MediaCodec.
  ${_media}/video/video_decoder.cc
  ${_media}/video/d3d11_decoder.cc
  ${_media}/video/mf_video.cc
  ${_media}/video/soft_video.cc
  ${_media}/video/soft_video_avc.cc
  ${_media}/video/soft_video_m4v.cc
  ${_media}/video/render.cc)
target_link_libraries(gesher_media_player_core PUBLIC gesher_media_audio gesher_media_codecs
  gesher_bionic gesher_window_surface winhttp ole32)
target_compile_options(gesher_media_player_core PRIVATE -Wall -Wextra -Werror
  -Wno-unused-parameter -Wno-deprecated-copy)
set_target_properties(gesher_media_player_core PROPERTIES CXX_STANDARD 23)
add_executable(media_i420_crop_test "${CMAKE_SOURCE_DIR}/tests/media/i420_crop_test.cc")
target_include_directories(media_i420_crop_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_i420_crop_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter -Wno-deprecated-copy)
target_link_libraries(media_i420_crop_test PRIVATE gesher_media_player_core gesher_elf)
gesher_graphics_cxx(media_i420_crop_test)
