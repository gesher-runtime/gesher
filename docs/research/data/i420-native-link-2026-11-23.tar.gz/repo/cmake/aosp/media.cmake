# Media (docs/media.md, roadmap phase 8, ADR 0042): sound and video for apps.
#
# compat/media/audio: the audio engine of an app process (resampling, mixing,
# WASAPI shared mode, a WAV capture for machines without an audio endpoint)
# and the audio state the device's processes share. compat/media/jni: the
# framework's media natives over it (AudioTrack, AudioSystem, the audio
# policy's), registered in libandroid_runtime through register_gesher_media
# (compat/framework/android_runtime.cc).
#
# An OBJECT library: every object reaches dalvikvm, as framework_runtime's.

set(_media "${CMAKE_SOURCE_DIR}/compat/media")

# Synthetic inputs belong to separately named CI fixtures, never the package.
option(GESHER_CAPTURE_TEST_SOURCES "Compile isolated synthetic audio capture fixtures" OFF)
set_property(SOURCE ${_media}/audio/capture.cc APPEND PROPERTY COMPILE_DEFINITIONS
  "$<$<BOOL:${GESHER_CAPTURE_TEST_SOURCES}>:GESHER_CAPTURE_TEST_SOURCES=1>")

# AOSP's extractors and the open codecs (cmake/aosp/media_codecs.cmake).
include(${CMAKE_CURRENT_LIST_DIR}/media_codecs.cmake)

# Media4's NDK format bridge has no ART/JNI dependency. The actual pinned
# AMediaFormat backend is shared by native processes and app libraries.
add_library(gesher_media_format OBJECT ${_media}/ndk/media_format.cc)
target_link_libraries(gesher_media_format PUBLIC stagefright_foundation gesher_bionic)
target_compile_options(gesher_media_format PRIVATE -Wall -Wextra -Werror)
set_target_properties(gesher_media_format PROPERTIES CXX_STANDARD 23)
target_link_libraries(dalvikvm PRIVATE gesher_media_format)
target_link_libraries(gesher-exec PRIVATE gesher_media_format)

# The NDK's MediaDrm/MediaCrypto: no DRM plugin, so no scheme is supported
# and no object is created (compat/media/ndk/media_drm.cc).
add_library(gesher_media_drm OBJECT ${_media}/ndk/media_drm.cc)
target_include_directories(gesher_media_drm PRIVATE ${AOSP_DIR}/frameworks/av/media/ndk/include)
target_link_libraries(gesher_media_drm PUBLIC gesher_bionic)
target_compile_options(gesher_media_drm PRIVATE -Wall -Wextra -Werror)
set_target_properties(gesher_media_drm PROPERTIES CXX_STANDARD 23)
target_link_libraries(dalvikvm PRIVATE gesher_media_drm)
target_link_libraries(gesher-exec PRIVATE gesher_media_drm)

set(GESHER_MEDIA_AUDIO_SOURCES
  ${_media}/audio/engine.cc
  ${_media}/audio/shared_state.cc
  ${_media}/audio/sink_file.cc
  ${_media}/audio/sink_wasapi.cc
  ${_media}/audio/wasapi_sink.cc
  # Audio input (media3, ADR 0059).
  ${_media}/audio/capture.cc
  ${_media}/audio/capture_wasapi.cc)

# Pure audio and its recording gate have no Java VM dependency.
add_library(gesher_media_audio OBJECT ${GESHER_MEDIA_AUDIO_SOURCES}
  ${_media}/audio/record_permission.cc)
target_link_libraries(gesher_media_audio PUBLIC log ole32 uuid)
target_compile_options(gesher_media_audio PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter)

add_library(gesher_media OBJECT
  ${_media}/jni/jni_util.cc
  ${_media}/jni/audio_system_jni.cc
  ${_media}/jni/audio_track_jni.cc
  ${_media}/jni/audio_record_jni.cc)
target_link_libraries(gesher_media PUBLIC gesher_media_audio nativehelper log ole32 uuid)
target_compile_options(gesher_media PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter)

target_link_libraries(dalvikvm PRIVATE gesher_media)

# The player under MediaPlayer, SoundPool and MediaMetadataRetriever
# (compat/media/player) and their natives.
add_library(gesher_media_player_core OBJECT
  ${_media}/player/data_source.cc
  ${_media}/player/http_source.cc
  ${_media}/player/extractor.cc
  ${_media}/player/decoder.cc
  ${_media}/player/decode_file.cc
  ${_media}/player/mf_decoder.cc
  ${_media}/player/player.cc
  # Video (stage 2, ADR 0051): decoders and MediaCodec.
  ${_media}/video/video_decoder.cc
  ${_media}/video/d3d11_decoder.cc
  ${_media}/video/mf_video.cc
  ${_media}/video/soft_video.cc
  ${_media}/video/soft_video_avc.cc
  ${_media}/video/soft_video_m4v.cc
  ${_media}/video/render.cc)
target_link_libraries(gesher_media_player_core PUBLIC gesher_media_audio gesher_media_codecs
  gesher_bionic gesher_window_surface winhttp ole32)
target_compile_options(gesher_media_player_core PRIVATE -Wall -Wextra -Werror
  -Wno-unused-parameter -Wno-deprecated-copy)
set_target_properties(gesher_media_player_core PROPERTIES CXX_STANDARD 23)

# The native APIs share the actual audio/file-player backend in both hosts.
add_library(gesher_media_ndk OBJECT
  ${_media}/ndk/aaudio.cc ${_media}/ndk/opensles.cc ${_media}/ndk/media_extractor.cc)
target_link_libraries(gesher_media_ndk PUBLIC gesher_media_audio gesher_media_player_core gesher_bionic)
target_compile_options(gesher_media_ndk PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter)
set_target_properties(gesher_media_ndk PROPERTIES CXX_STANDARD 23)
foreach(_host dalvikvm gesher-exec)
  target_link_libraries(${_host} PRIVATE gesher_media_audio gesher_media_player_core gesher_media_ndk)
endforeach()

# The actual container writers and pure packet metadata are shared by JNI
# and native processes; neither host pulls the encoder factories through them.
add_library(gesher_media_muxer OBJECT
  ${_media}/ndk/media_muxer.cc
  ${_media}/encode/codec_config.cc
  ${_media}/mux/mp4_muxer.cc
  ${_media}/mux/webm_muxer.cc
  ${_media}/mux/ogg_muxer.cc
)
target_link_libraries(gesher_media_muxer PUBLIC gesher_media_player_core
  stagefright_foundation gesher_media_codecs gesher_bionic)
target_include_directories(gesher_media_muxer PRIVATE ${CMAKE_SOURCE_DIR}/compat/bionic)
target_compile_options(gesher_media_muxer PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter
  -Wno-deprecated-copy)
set_target_properties(gesher_media_muxer PROPERTIES CXX_STANDARD 23)
target_link_libraries(dalvikvm PRIVATE gesher_media_muxer)
target_link_libraries(gesher-exec PRIVATE gesher_media_muxer)

# This reader/decoder oracle deliberately does not link the muxer writers.
add_executable(media_muxer_verify "${CMAKE_SOURCE_DIR}/tests/media/ndk-muxer/verify_output.cc")
target_include_directories(media_muxer_verify PRIVATE "${CMAKE_SOURCE_DIR}")
target_link_libraries(media_muxer_verify PRIVATE gesher_media_audio gesher_media_player_core gesher_elf)
target_compile_options(media_muxer_verify PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter
  -Wno-deprecated-copy)
set_target_properties(media_muxer_verify PROPERTIES CXX_STANDARD 23)

add_library(gesher_media_player OBJECT
  ${_media}/jni/java_data_source.cc
  ${_media}/jni/media_codec_jni.cc
  ${_media}/jni/media_jni.cc
  ${_media}/jni/media_player_jni.cc
  ${_media}/jni/media_jni_others.cc
  ${_media}/jni/media_extractor_jni.cc
  ${_media}/jni/soundpool_jni.cc
  # Recording (media3, ADR 0059): encoders, container writers, MediaMuxer, MediaRecorder.
  ${_media}/encode/encoder.cc
  ${_media}/encode/mf_encoder.cc
  ${_media}/encode/opus_encoder.cc
  ${_media}/encode/soft_avc_encoder.cc
  ${_media}/record/recorder.cc
  ${_media}/jni/media_muxer_jni.cc
  ${_media}/jni/media_recorder_jni.cc)
target_include_directories(gesher_media_player PRIVATE ${CMAKE_SOURCE_DIR}/compat/bionic)
target_link_libraries(gesher_media_player PUBLIC gesher_media gesher_media_player_core gesher_media_ndk gesher_media_muxer gesher_media_codecs gesher_bionic
  winhttp ole32 mmdevapi dxgi)
target_compile_options(gesher_media_player PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter
  # libutils' TypeHelpers.h trips -Wdeprecated-copy on key_value_pair_t<String8, String8>.
  -Wno-deprecated-copy)
set_target_properties(gesher_media_player PROPERTIES CXX_STANDARD 23)
# The software video decoders' headers (cmake/aosp/media_video_codecs.cmake), as system
# headers: -Werror holds for soft_video.cc itself.
set(_soft_video_isystem)
foreach(_d ${GESHER_SOFT_VIDEO_INCLUDES})
  list(APPEND _soft_video_isystem "-isystem${_d}")
endforeach()
set_source_files_properties(${_media}/video/soft_video.cc PROPERTIES COMPILE_OPTIONS "${_soft_video_isystem}")
# libwebm's mkvmuxer headers for the WebM writer.
set_source_files_properties(${_media}/mux/webm_muxer.cc PROPERTIES COMPILE_OPTIONS
  "-isystem${AOSP_DIR}/external/libwebm")
foreach(_s AVC M4V)
  set(_isystem)
  foreach(_d ${GESHER_SOFT_${_s}_INCLUDES})
    list(APPEND _isystem "-isystem${_d}")
  endforeach()
  string(TOLOWER ${_s} _file)
  set_source_files_properties(${_media}/video/soft_video_${_file}.cc PROPERTIES COMPILE_OPTIONS "${_isystem}")
endforeach()
# libavc's encoder headers (its iv2.h is not the decoder's iv.h: a file of its own).
set(_isystem)
foreach(_d ${GESHER_SOFT_AVCENC_INCLUDES})
  list(APPEND _isystem "-isystem${_d}")
endforeach()
set_source_files_properties(${_media}/encode/soft_avc_encoder.cc PROPERTIES COMPILE_OPTIONS "${_isystem}")
add_dependencies(media_codecs_all gesher_media_player)

target_link_libraries(dalvikvm PRIVATE gesher_media_player)

# The engine's probe (compat/media/probe), run in CI on Windows
# (tests/windows/tracks/38-media.ps1): logs to stderr, no runtime.
add_executable(media_probe ${_media}/probe/media_probe.cc ${GESHER_MEDIA_AUDIO_SOURCES})
target_compile_definitions(media_probe PRIVATE GESHER_MEDIA_STANDALONE)
target_compile_options(media_probe PRIVATE -Wall -Wextra -Werror -Wno-unused-parameter)
target_link_libraries(media_probe PRIVATE ole32 mmdevapi avrt uuid pthread)

# The CPU estimate block comes from the patched heap.cc compiled into ART.
# Compile/run this regression in CI only (59-media3), preserving all valid
# finite/unknown estimates and avoiding undefined zero-duration CPU ratios.
set(_media_gc_estimate_cpp "${CMAKE_CURRENT_BINARY_DIR}/media-gc-estimate-test.cc")
add_custom_command(OUTPUT "${_media_gc_estimate_cpp}"
  COMMAND "${Python3_EXECUTABLE}" "${CMAKE_SOURCE_DIR}/tests/media/generate_gc_estimate_test.py"
    --art-root "${AOSP_DIR}/art"
    --template "${CMAKE_SOURCE_DIR}/tests/media/gc_estimate_test.cc.in"
    --output "${_media_gc_estimate_cpp}"
  DEPENDS "${CMAKE_SOURCE_DIR}/tests/media/generate_gc_estimate_test.py"
    "${CMAKE_SOURCE_DIR}/tests/media/gc_estimate_test.cc.in" "${AOSP_DIR}/art/runtime/gc/heap.cc"
  VERBATIM)
add_executable(media_gc_estimate_test "${_media_gc_estimate_cpp}")
target_compile_options(media_gc_estimate_test PRIVATE -Wall -Wextra -Werror)

add_executable(surface_invalidation_test "${CMAKE_SOURCE_DIR}/tests/surfaces/invalidation_test.cc")
target_include_directories(surface_invalidation_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(surface_invalidation_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(surface_invalidation_test PRIVATE pthread)

# Complete production sources over actual Windows file, HTTP and buffer APIs.
# These default targets are collected with the other out/*.exe CI artifacts.
add_executable(media_source_contract_test
  "${CMAKE_SOURCE_DIR}/tests/media/source_contract_test.cc" ${_media}/player/data_source.cc)
target_include_directories(media_source_contract_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_source_contract_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(media_source_contract_test PRIVATE gesher_posix)

add_executable(media_http_source_contract_test
  "${CMAKE_SOURCE_DIR}/tests/media/http_source_contract_test.cc" ${_media}/player/http_source.cc)
target_include_directories(media_http_source_contract_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_definitions(media_http_source_contract_test PRIVATE GESHER_MEDIA_STANDALONE)
target_compile_options(media_http_source_contract_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(media_http_source_contract_test PRIVATE gesher_posix winhttp pthread)

add_executable(media_surface_timestamp_contract_test
  "${CMAKE_SOURCE_DIR}/tests/media/surface_timestamp_contract_test.cc")
target_include_directories(media_surface_timestamp_contract_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_surface_timestamp_contract_test PRIVATE -Wall -Werror)
target_link_libraries(media_surface_timestamp_contract_test PRIVATE gesher_window_surface)
gesher_graphics_cxx(media_surface_timestamp_contract_test)

add_executable(media_surface_geometry_contract_test
  "${CMAKE_SOURCE_DIR}/tests/media/surface_geometry_contract_test.cc")
target_include_directories(media_surface_geometry_contract_test PRIVATE "${CMAKE_SOURCE_DIR}")
# Pinned hostgraphics inline adapters retain unused signature parameters, as
# in window_probe. Keep all other extra warnings and warnings-as-errors enabled.
target_compile_options(media_surface_geometry_contract_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter)
target_link_libraries(media_surface_geometry_contract_test PRIVATE gesher_window_surface)
gesher_graphics_cxx(media_surface_geometry_contract_test)

add_executable(media_surface_frame_recycling_test
  "${CMAKE_SOURCE_DIR}/tests/media/surface_frame_recycling_contract_test.cc"
  ${_media}/surface/queue_surface.cc)
target_include_directories(media_surface_frame_recycling_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_surface_frame_recycling_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter)
target_link_libraries(media_surface_frame_recycling_test PRIVATE hostgraphics)
gesher_graphics_cxx(media_surface_frame_recycling_test)

# I420 rows to RGBA (compat/media/video/yuv_rgba.h): every Y, U, V against the
# reference formula, generic and AVX2 (38-media.ps1).
add_executable(media_yuv_rgba_test "${CMAKE_SOURCE_DIR}/tests/media/yuv_rgba_test.cc")
target_include_directories(media_yuv_rgba_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_yuv_rgba_test PRIVATE -Wall -Wextra -Werror)

# Actual full cropped-frame conversion and QueueSurface ownership. This links
# the production renderer and hostgraphics objects, without host test adapters.
add_executable(media_i420_crop_test "${CMAKE_SOURCE_DIR}/tests/media/i420_crop_test.cc")
target_include_directories(media_i420_crop_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_i420_crop_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter -Wno-deprecated-copy)
target_link_libraries(media_i420_crop_test PRIVATE gesher_media_audio gesher_media_player_core gesher_elf)
gesher_graphics_cxx(media_i420_crop_test)

add_executable(wasapi_refill_test "${CMAKE_SOURCE_DIR}/tests/media/wasapi_refill_test.cc")
target_include_directories(wasapi_refill_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(wasapi_refill_test PRIVATE -Wall -Wextra -Werror)

# The surfaces hwui draws (stage 2, ADR 0051): SurfaceTexture and TextureView's layer,
# SurfaceView's surface (compat/media/surface), built with hwui (its headers, Skia).
# QueueSurface itself uses only hostgraphics and is shared by hwui and the renderer.
target_sources(gesher_window_surface PRIVATE ${_media}/surface/queue_surface.cc)
target_sources(hwui PRIVATE
  ${_media}/surface/retriever_bitmap.cc
  ${_media}/video/retriever_pixels.cc
  ${_media}/surface/reader_surface.cc
  ${_media}/surface/surface_jni.cc
  # SurfaceTexture's GL consumer: frames into the app's external texture.
  ${_media}/surface/surface_texture_gl.cc
  # The encoders' input surfaces (media3, ADR 0059): QueueSurfaces too.
  ${_media}/video/input_surface.cc)

# Run actual input-surface producer/consumer callback teardown on Windows.
add_executable(media_input_surface_callback_test
  "${CMAKE_SOURCE_DIR}/tests/media/input_surface_callback_test.cc"
  ${_media}/video/input_surface.cc ${_media}/surface/queue_surface.cc)
target_include_directories(media_input_surface_callback_test PRIVATE
  "${CMAKE_SOURCE_DIR}" "${AOSP_DIR}/libnativehelper/include_jni"
  "${AOSP_DIR}/frameworks/base/core/jni/include")
# Only the fixture throws a callback exception to check capture cleanup.
target_compile_options(media_input_surface_callback_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter -fexceptions)
target_link_libraries(media_input_surface_callback_test PRIVATE hostgraphics pthread)
gesher_graphics_cxx(media_input_surface_callback_test)

# Actual pinned-Skia raster conversion and the previous full-image oracle.
add_executable(media_retriever_pixels_test
  "${CMAKE_SOURCE_DIR}/tests/media/retriever_pixels_test.cc"
  ${_media}/video/retriever_pixels.cc)
target_include_directories(media_retriever_pixels_test PRIVATE "${CMAKE_SOURCE_DIR}")
target_compile_options(media_retriever_pixels_test PRIVATE
  -Wall -Wextra -Werror -Wno-unused-parameter)
target_link_libraries(media_retriever_pixels_test PRIVATE skia)
gesher_graphics_cxx(media_retriever_pixels_test)
