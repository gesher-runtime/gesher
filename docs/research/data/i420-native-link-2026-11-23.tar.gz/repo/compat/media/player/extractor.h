// Gesher media: AOSP's extractors behind one interface (docs/media.md).
//
// Each extractor is a plugin with a sniffer (cmake/aosp/media_codecs.cmake
// builds them in, their GETEXTRACTORDEF renamed); Open asks every one, as
// MediaExtractorFactory does, and takes the most confident. Formats are the
// extractors' AMediaFormats (the NDK's keys: "mime", "durationUs",
// "sample-rate", "channel-count", "csd-0", ...).
#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "data_source.h"

struct AMediaFormat;

namespace gesher::media {

// An AMediaFormat, owned.
class Format {
 public:
  Format();
  explicit Format(AMediaFormat* f) : f_(f) {}
  ~Format();
  Format(Format&& o) noexcept : f_(o.f_) { o.f_ = nullptr; }
  Format& operator=(Format&& o) noexcept;
  Format(const Format&) = delete;
  Format& operator=(const Format&) = delete;

  AMediaFormat* get() const { return f_; }
  AMediaFormat* Release() { return std::exchange(f_, nullptr); }
  bool GetInt32(const char* key, int32_t* out) const;
  bool GetInt64(const char* key, int64_t* out) const;
  bool GetRect(const char* key, int32_t* left, int32_t* top, int32_t* right, int32_t* bottom) const;
  bool GetFloat(const char* key, float* out) const;
  bool GetString(const char* key, std::string* out) const;
  bool GetBuffer(const char* key, std::vector<uint8_t>* out) const;
  std::string Mime() const;
  std::string ToString() const;

 private:
  AMediaFormat* f_;
};

struct Sample {
  std::vector<uint8_t> data;
  int64_t time_us = 0;
  bool sync = false;
  int32_t valid_samples = -1;  // Ogg Vorbis: samples of the page's last packet
  // A closest seek starts decoding at an earlier sync sample; the extractor
  // identifies the actual presentation timestamp to return separately.
  int64_t target_time_us = -1;
};

// AOSP's CMediaTrackReadOptions seek modes.
enum class SeekMode : uint32_t {
  kPreviousSync = 0,
  kNextSync = 1,
  kClosestSync = 2,
  kClosest = 3,
  kFrameIndex = 4,
};

class TrackReader {
 public:
  virtual ~TrackReader() = default;
  // CMediaTrack's NDK status from starting this reader. Callers that expose
  // selection must report a failed start before retaining the reader.
  virtual int StartStatus() const { return 0; }
  // The next sample. Returns 0, 1 at the end, negative on error; with
  // position >= 0, the first sample at or around that time in microseconds,
  // or at a preceding sync sample for a presentation-order kFrameIndex seek.
  virtual int Read(Sample* out, int64_t position = -1,
                   SeekMode mode = SeekMode::kPreviousSync) = 0;

  // The NDK also exposes per-sample metadata. Playback readers need no copy.
  virtual void EnableSampleMetadata() {}
  virtual const Format* SampleMetadata() const { return nullptr; }
};

class Extractor {
 public:
  virtual ~Extractor() = default;
  // Sniffs `source` with every extractor; null (with `error`) if none takes it.
  static std::unique_ptr<Extractor> Open(std::shared_ptr<DataSource> source, std::string* error);

  virtual std::string Name() const = 0;
  virtual size_t TrackCount() = 0;
  virtual Format TrackFormat(size_t index) = 0;
  // The container's metadata (title, artist, album, ...).
  virtual Format FileFormat() = 0;
  // A track's samples, from its start. One reader per track at a time.
  virtual std::unique_ptr<TrackReader> OpenTrack(size_t index) = 0;
};

}  // namespace gesher::media
