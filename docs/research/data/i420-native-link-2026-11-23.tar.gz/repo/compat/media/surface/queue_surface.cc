// Gesher media: a Surface whose frames stay in the process. See queue_surface.h.
#include "queue_surface.h"

#include <errno.h>
#include <stdarg.h>
#include <string.h>

#include <algorithm>

#include <gesher/perf_trace.h>
#include <system/window.h>

namespace gesher::media {

// Keep at most one returned pixel allocation, never a published frame. A
// consumer (including SkData or an externally promoted weak_ptr) may keep any
// frame immutable for as long as it needs. Only that frame's final destruction
// returns its pixels. The pool never calls back into QueueSurface while locked.
class QueueSurface::FramePool {
 public:
  void Configure(int width, int height) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (width_ == width && height_ == height) return;
    width_ = width;
    height_ = height;
    ++generation_;
    std::vector<uint32_t>().swap(spare_);
  }

  std::vector<uint32_t> Take(int width, int height, uint64_t* generation) {
    std::vector<uint32_t> pixels;
    std::lock_guard<std::mutex> lock(mutex_);
    *generation = generation_;
    if (!closed_ && width == width_ && height == height_) pixels.swap(spare_);
    return pixels;
  }

  void Return(SurfaceFrame* frame, uint64_t generation) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!closed_ && generation == generation_ &&
        frame->width == width_ && frame->height == height_ && spare_.empty() &&
        frame->pixels.capacity() <= kMaxSpareBytes / sizeof(uint32_t)) {
      spare_.swap(frame->pixels);
    }
  }

  void Close() {
    std::lock_guard<std::mutex> lock(mutex_);
    closed_ = true;
    std::vector<uint32_t>().swap(spare_);
  }

 private:
  // A single 4K RGBA frame fits. Larger frames still work, without caching.
  static constexpr size_t kMaxSpareBytes = 32u << 20;
  std::mutex mutex_;
  int width_ = 0, height_ = 0;
  uint64_t generation_ = 0;
  bool closed_ = false;
  std::vector<uint32_t> spare_;
};

class QueueSurface::RecycledFrame : public SurfaceFrame {
 public:
  RecycledFrame(const std::shared_ptr<FramePool>& pool, int width, int height) : pool_(pool) {
    pixels = pool->Take(width, height, &generation_);
  }
  ~RecycledFrame() {
    if (auto pool = pool_.lock()) pool->Return(this, generation_);
  }

 private:
  // Outstanding readers cannot prolong the Surface or its spare allocation.
  std::weak_ptr<FramePool> pool_;
  uint64_t generation_ = 0;
};

class QueueSurface::Buffer
    : public android::ANativeObjectBase<ANativeWindowBuffer, QueueSurface::Buffer, android::RefBase> {
 public:
  Buffer(int w, int h, int f) : pixels(static_cast<size_t>(w) * h, 0xff000000u) {
    width = w;
    height = h;
    stride = w;
    format = f;
    usage_deprecated = 0;
    layerCount = 1;
    reserved[0] = pixels.data();
    handle = nullptr;
    usage = 0;
  }

  std::vector<uint32_t> pixels;
};

QueueSurface::QueueSurface(int default_width, int default_height)
    : android::Surface(nullptr), frame_pool_(std::make_shared<FramePool>()) {
  default_width_ = default_width > 0 ? default_width : 1;
  default_height_ = default_height > 0 ? default_height : 1;
  UpdateFrameGeometry();
  ANativeWindow::setSwapInterval = HookSetSwapInterval;
  ANativeWindow::queueBuffer = HookQueueBuffer;
  ANativeWindow::cancelBuffer = HookCancelBuffer;
  ANativeWindow::dequeueBuffer_DEPRECATED = nullptr;
  ANativeWindow::lockBuffer_DEPRECATED = nullptr;
  ANativeWindow::queueBuffer_DEPRECATED = nullptr;
  ANativeWindow::cancelBuffer_DEPRECATED = nullptr;
  const_cast<float&>(ANativeWindow::xdpi) = 160;
  const_cast<float&>(ANativeWindow::ydpi) = 160;
  const_cast<int&>(ANativeWindow::minSwapInterval) = 0;
  const_cast<int&>(ANativeWindow::maxSwapInterval) = 1;
}

QueueSurface::~QueueSurface() { frame_pool_->Close(); }

QueueSurface* QueueSurface::From(ANativeWindow* window) {
  if (window == nullptr || window->common.magic != ANDROID_NATIVE_WINDOW_MAGIC ||
      window->queueBuffer != HookQueueBuffer) {
    return nullptr;
  }
  return static_cast<QueueSurface*>(getSelf(window));
}

void QueueSurface::SetDefaultSize(int width, int height) {
  std::lock_guard<std::mutex> lock(mutex_);
  if (width > 0) default_width_ = width;
  if (height > 0) default_height_ = height;
  UpdateFrameGeometry();
}

void QueueSurface::SetListener(std::function<void()> listener) {
  std::lock_guard<std::mutex> lock(mutex_);
  if (!abandoned_) listener_ = std::move(listener);
}

std::shared_ptr<const SurfaceFrame> QueueSurface::Latest() const {
  std::lock_guard<std::mutex> lock(mutex_);
  return latest_;
}

uint64_t QueueSurface::frames() const {
  std::lock_guard<std::mutex> lock(mutex_);
  return frames_;
}

void QueueSurface::Abandon() {
  std::lock_guard<std::mutex> lock(mutex_);
  abandoned_ = true;
  listener_ = nullptr;
  frame_pool_->Close();
  latest_.reset();
  // Dequeued producers own their buffers through dequeued_. A CPU lock has
  // only a raw pixels pointer, so keep its buffer until unlockAndPost returns.
  if (!locked_) buffer_ = nullptr;
}

bool QueueSurface::PostFrame(int width, int height, int stride, const uint32_t* pixels,
                             int64_t timestamp_ns, int video_scaling_mode) {
  if (width <= 0 || height <= 0 || stride < width || pixels == nullptr ||
      (video_scaling_mode != 1 && video_scaling_mode != 2)) return false;
  // The copy is made unlocked: a large frame does not hold up this surface's
  // own producer or its readers.
  auto f = std::make_shared<RecycledFrame>(frame_pool_, width, height);
  f->width = width;
  f->height = height;
  f->video_scaling_mode = video_scaling_mode;
  f->pixels.resize(static_cast<size_t>(width) * height);
  if (stride == width) {
    memcpy(f->pixels.data(), pixels, f->pixels.size() * sizeof(uint32_t));
  } else {
    for (int y = 0; y < height; y++) {
      memcpy(&f->pixels[static_cast<size_t>(y) * width], pixels + static_cast<size_t>(y) * stride,
             static_cast<size_t>(width) * 4);
    }
  }
  f->timestamp_ns = timestamp_ns == NATIVE_WINDOW_TIMESTAMP_AUTO
                        ? systemTime(SYSTEM_TIME_MONOTONIC) : timestamp_ns;
  std::function<void()> listener;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (abandoned_) return false;
    f->number = ++frames_;
    latest_ = std::move(f);
    listener = listener_;
  }
  if (listener) listener();
  return true;
}

void QueueSurface::Size(int* width, int* height) const {
  if (requested_width_ > 0 && requested_height_ > 0) {
    *width = requested_width_;
    *height = requested_height_;
  } else if (user_width_ > 0 && user_height_ > 0) {
    *width = user_width_;
    *height = user_height_;
  } else {
    *width = default_width_;
    *height = default_height_;
  }
}

void QueueSurface::UpdateFrameGeometry() {
  int w, h;
  Size(&w, &h);
  frame_pool_->Configure(w, h);
}

void QueueSurface::EnsureBuffer() {
  int w, h;
  Size(&w, &h);
  if (buffer_ == nullptr || buffer_->width != w || buffer_->height != h ||
      buffer_->format != format_) {
    buffer_ = android::sp<Buffer>::make(w, h, format_);
    buffer_contents_valid_ = false;
  }
}

int QueueSurface::lock(ANativeWindow_Buffer* out, ARect* dirty) {
  std::lock_guard<std::mutex> lock(mutex_);
  // Surface::lock rejects a second CPU lock before consulting the consumer.
  if (locked_) return -ENOSYS;  // Android INVALID_OPERATION.
  if (abandoned_) return -ENODEV;
  EnsureBuffer();
  locked_ = true;
  out->width = buffer_->width;
  out->height = buffer_->height;
  out->stride = buffer_->stride;
  out->format = buffer_->format;
  out->bits = buffer_->pixels.data();
  memset(out->reserved, 0, sizeof out->reserved);
  if (dirty != nullptr) {
    // A new size/format has no previous frame to copy back. Otherwise preserve
    // the existing pixels outside the caller's damage, clipped to this buffer.
    if (!buffer_contents_valid_) {
      *dirty = {0, 0, buffer_->width, buffer_->height};
    } else {
      dirty->left = std::max(0, dirty->left);
      dirty->top = std::max(0, dirty->top);
      dirty->right = std::min(buffer_->width, dirty->right);
      dirty->bottom = std::min(buffer_->height, dirty->bottom);
      if (dirty->left >= dirty->right || dirty->top >= dirty->bottom) *dirty = {0, 0, 0, 0};
    }
  }
  return 0;
}

int QueueSurface::unlockAndPost() {
  return UnlockAndPost(std::nullopt);
}

int QueueSurface::UnlockAndPostWithTimestamp(int64_t timestamp_ns, int video_scaling_mode) {
  if (video_scaling_mode != 1 && video_scaling_mode != 2) return -EINVAL;
  return UnlockAndPost(timestamp_ns, video_scaling_mode);
}

int QueueSurface::UnlockAndPost(std::optional<int64_t> timestamp_ns, int video_scaling_mode) {
  std::function<void()> listener;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!locked_) return -EINVAL;
    locked_ = false;
    if (abandoned_) {
      buffer_ = nullptr;
      return -ENODEV;
    }
    listener = PublishLocked(timestamp_ns, video_scaling_mode);
  }
  if (listener) listener();
  return 0;
}

std::function<void()> QueueSurface::PublishLocked(std::optional<int64_t> timestamp_ns,
                                                int video_scaling_mode) {
  static gesher::perf::Site copy_site("queue surface: publish a queued frame (copy)");
  const int64_t start = gesher::perf::Now();
  if (buffer_ == nullptr) return {};
  buffer_contents_valid_ = true;
  auto f = std::make_shared<RecycledFrame>(frame_pool_, buffer_->width, buffer_->height);
  f->width = buffer_->width;
  f->height = buffer_->height;
  f->video_scaling_mode = video_scaling_mode;
  const bool opaque = buffer_->format == HAL_PIXEL_FORMAT_RGBX_8888;
  const bool bgra = buffer_->format == HAL_PIXEL_FORMAT_BGRA_8888;
  f->pixels.resize(static_cast<size_t>(f->width) * f->height);
  if (!opaque && !bgra && buffer_->stride == f->width) {
    // Ordinary RGBA producer storage is already packed. Let memcpy handle
    // the complete frame instead of restarting its copy loop on every row.
    memcpy(f->pixels.data(), buffer_->pixels.data(), f->pixels.size() * sizeof(uint32_t));
  } else for (int y = 0; y < f->height; y++) {
    const uint32_t* s = &buffer_->pixels[static_cast<size_t>(y) * buffer_->stride];
    uint32_t* d = &f->pixels[static_cast<size_t>(y) * f->width];
    if (!opaque && !bgra) {
      memcpy(d, s, static_cast<size_t>(f->width) * 4);
      continue;
    }
    for (int x = 0; x < f->width; x++) {
      uint32_t p = s[x];
      if (bgra) p = (p & 0xff00ff00u) | ((p & 0xffu) << 16) | ((p >> 16) & 0xffu);
      d[x] = opaque ? (p | 0xff000000u) : p;
    }
  }
  // A per-frame codec timestamp is data, including INT64_MIN. Only the native
  // producer's persistent setting gives that value its AUTO sentinel meaning.
  f->timestamp_ns = timestamp_ns.has_value() ? *timestamp_ns
      : timestamp_ns_ == NATIVE_WINDOW_TIMESTAMP_AUTO
          ? systemTime(SYSTEM_TIME_MONOTONIC) : timestamp_ns_;
  f->number = ++frames_;
  latest_ = std::move(f);
  copy_site.Add(gesher::perf::Now() - start);
  return listener_;
}

int QueueSurface::dequeueBuffer(ANativeWindowBuffer** buffer, int* fence_fd) {
  std::lock_guard<std::mutex> lock(mutex_);
  if (abandoned_) return -ENODEV;
  EnsureBuffer();
  *buffer = buffer_.get();
  dequeued_.push_back(buffer_);
  if (fence_fd != nullptr) *fence_fd = -1;
  return 0;
}

int QueueSurface::cancelBuffer(ANativeWindowBuffer* buffer, int) {
  std::lock_guard<std::mutex> lock(mutex_);
  for (auto it = dequeued_.begin(); it != dequeued_.end(); ++it) {
    if (static_cast<ANativeWindowBuffer*>(it->get()) == buffer) {
      dequeued_.erase(it);
      break;
    }
  }
  return 0;
}

int QueueSurface::queueBuffer(ANativeWindowBuffer* buffer, int) {
  std::function<void()> listener;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto it = dequeued_.begin(); it != dequeued_.end(); ++it) {
      if (static_cast<ANativeWindowBuffer*>(it->get()) == buffer) {
        if (!abandoned_) buffer_ = *it;
        dequeued_.erase(it);
        break;
      }
    }
    if (abandoned_) return -ENODEV;
    listener = PublishLocked(std::nullopt);
  }
  if (listener) listener();
  return 0;
}

int QueueSurface::setSwapInterval(int) {
  return 0;
}

int QueueSurface::query(int what, int* value) const {
  std::lock_guard<std::mutex> lock(mutex_);
  switch (what) {
    case NATIVE_WINDOW_WIDTH:
      *value = default_width_;
      return 0;
    case NATIVE_WINDOW_DEFAULT_WIDTH:
      *value = user_width_ > 0 ? user_width_ : default_width_;
      return 0;
    case NATIVE_WINDOW_HEIGHT:
      *value = default_height_;
      return 0;
    case NATIVE_WINDOW_DEFAULT_HEIGHT:
      *value = user_height_ > 0 ? user_height_ : default_height_;
      return 0;
    case NATIVE_WINDOW_FORMAT:
      *value = format_;
      return 0;
    case NATIVE_WINDOW_MIN_UNDEQUEUED_BUFFERS:
      *value = 1;
      return 0;
    case NATIVE_WINDOW_QUEUES_TO_WINDOW_COMPOSER:
      *value = 0;
      return 0;
    case NATIVE_WINDOW_CONCRETE_TYPE:
      *value = NATIVE_WINDOW_SURFACE;
      return 0;
    case NATIVE_WINDOW_IS_VALID:
      *value = abandoned_ ? 0 : 1;
      return 0;
    case NATIVE_WINDOW_MAX_BUFFER_COUNT:
      *value = 1;
      return 0;
    default:
      *value = 0;
      return 0;
  }
}

int QueueSurface::perform(int operation, va_list args) {
  switch (operation) {
    case NATIVE_WINDOW_LOCK: {
      auto* out = va_arg(args, ANativeWindow_Buffer*);
      auto* dirty = va_arg(args, ARect*);
      return lock(out, dirty);
    }
    case NATIVE_WINDOW_UNLOCK_AND_POST:
      return unlockAndPost();
    case NATIVE_WINDOW_SET_BUFFERS_FORMAT: {
      int format = va_arg(args, int);
      if (format == 0) format = HAL_PIXEL_FORMAT_RGBA_8888;
      if (format != HAL_PIXEL_FORMAT_RGBA_8888 && format != HAL_PIXEL_FORMAT_RGBX_8888 &&
          format != HAL_PIXEL_FORMAT_BGRA_8888) {
        return -EINVAL;
      }
      std::lock_guard<std::mutex> lock(mutex_);
      format_ = format;
      return 0;
    }
    case NATIVE_WINDOW_SET_BUFFERS_USER_DIMENSIONS:
    case NATIVE_WINDOW_SET_BUFFERS_DIMENSIONS: {
      int w = va_arg(args, int);
      int h = va_arg(args, int);
      if (w < 0 || h < 0 || ((w == 0) != (h == 0))) return -EINVAL;
      std::lock_guard<std::mutex> lock(mutex_);
      if (operation == NATIVE_WINDOW_SET_BUFFERS_USER_DIMENSIONS) {
        user_width_ = w;
        user_height_ = h;
      } else {
        requested_width_ = w;
        requested_height_ = h;
      }
      UpdateFrameGeometry();
      return 0;
    }
    case NATIVE_WINDOW_SET_BUFFERS_GEOMETRY: {
      int w = va_arg(args, int);
      int h = va_arg(args, int);
      int format = va_arg(args, int);
      if (w < 0 || h < 0 || ((w == 0) != (h == 0))) return -EINVAL;
      std::lock_guard<std::mutex> lock(mutex_);
      // The legacy dispatch sets producer dimensions before setting format.
      requested_width_ = w;
      requested_height_ = h;
      UpdateFrameGeometry();
      if (format == 0) format = HAL_PIXEL_FORMAT_RGBA_8888;
      if (format != HAL_PIXEL_FORMAT_RGBA_8888 && format != HAL_PIXEL_FORMAT_RGBX_8888 &&
          format != HAL_PIXEL_FORMAT_BGRA_8888) return -EINVAL;
      format_ = format;
      return 0;
    }
    case NATIVE_WINDOW_SET_BUFFERS_TIMESTAMP: {
      int64_t t = va_arg(args, int64_t);
      std::lock_guard<std::mutex> lock(mutex_);
      timestamp_ns_ = t;
      return 0;
    }
    case NATIVE_WINDOW_GET_REFRESH_CYCLE_DURATION:
      *va_arg(args, int64_t*) = 16666667;
      return 0;
    case NATIVE_WINDOW_GET_NEXT_FRAME_ID: {
      std::lock_guard<std::mutex> lock(mutex_);
      *va_arg(args, uint64_t*) = frames_ + 1;
      return 0;
    }
    case NATIVE_WINDOW_GET_CONSUMER_USAGE64:
      *va_arg(args, uint64_t*) = 0;
      return 0;
    case NATIVE_WINDOW_GET_LAST_DEQUEUE_START:
    case NATIVE_WINDOW_GET_LAST_DEQUEUE_DURATION:
    case NATIVE_WINDOW_GET_LAST_QUEUE_DURATION:
      *va_arg(args, int64_t*) = 0;
      return 0;
    case NATIVE_WINDOW_GET_COMPOSITOR_TIMING:
    case NATIVE_WINDOW_GET_FRAME_TIMESTAMPS:
    case NATIVE_WINDOW_GET_LAST_QUEUED_BUFFER:
    case NATIVE_WINDOW_GET_LAST_QUEUED_BUFFER2:
      return -ENOSYS;
    default:
      return 0;
  }
}

int QueueSurface::HookSetSwapInterval(ANativeWindow* window, int interval) {
  return static_cast<QueueSurface*>(getSelf(window))->setSwapInterval(interval);
}

int QueueSurface::HookQueueBuffer(ANativeWindow* window, ANativeWindowBuffer* buffer, int fence_fd) {
  return static_cast<QueueSurface*>(getSelf(window))->queueBuffer(buffer, fence_fd);
}

int QueueSurface::HookCancelBuffer(ANativeWindow* window, ANativeWindowBuffer* buffer,
                                   int fence_fd) {
  return static_cast<QueueSurface*>(getSelf(window))->cancelBuffer(buffer, fence_fd);
}

}  // namespace gesher::media
