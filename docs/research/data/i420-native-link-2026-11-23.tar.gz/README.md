# I420 native-link follow-up evidence

The original full CI log is preserved exactly. The qualification directory holds
both actual extracted CMake target graphs, complete generated Ninja commands,
strict Windows x64/AArch64 engine objects, dependency lists, defined-symbol output
and their original proof. Source inputs are copied byte-for-byte under repo/ and
workspace/. No AOSP function body or successful executable is substituted.

evidence/qualify_pr412_audio_link.py is the exact script that produced these
receipts in the declared original workspace layout. Its absolute tool/source
paths and dependency on the archived earlier media-audio-refill-windows command
receipt are historical execution inputs, not a portable full-project build claim. The
proof records every expanded compiler command. Reproduction elsewhere must map
those paths to the recorded exact inputs and the pinned LLVM-MinGW toolchain.
CMake 3.31.10 and Ninja 1.13.0 were installed for the graph qualification; the
initial missing-CMake failure and actual installation log are retained.
The first archive assembly used the wrong Windows-script directory literal;
its FileNotFoundError is retained, and only that packaging path was corrected.

The isolated graph leaves other AOSP libraries as unresolved library names. It
proves that this explicit OBJECT-library dependency adds the eight real audio
objects while retaining all fourteen player objects. The real engine objects
define all sixteen symbols missing in the original full-CI link. Complete
aggregate executable linking and Windows runtime remain the unchanged full-CI
requirements. This archive is separate from the unchanged 451-member performance
archive and adds no timing or runtime acceptance claim.
