#!/usr/bin/env python3
"""Retain the observed native-link failure and bounded object-closure evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

W = Path(__file__).resolve().parent
ROOT = W / 'gesher-media-i420-ci-fix'
BASE = '5c9b88fb108d122ae19f2b72d3be13aa7ee31022'
REPORT = 'docs/research/i420-odd-crop-2026-11-23.json'
ARCHIVE = 'docs/research/data/i420-native-link-2026-11-23.tar.gz'
OUT = W / 'media-pr412-audio-link-qualification'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def old(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)

original_report = json.loads(old(REPORT))
proof = json.loads((OUT / 'proof.json').read_text())
members = {}

def add(name, data):
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name] = data

for folder, dirs, files in os.walk(OUT, followlinks=False):
    dirs[:] = sorted(d for d in dirs if not (Path(folder) / d).is_symlink())
    for filename in sorted(files):
        path = Path(folder) / filename
        if not path.is_symlink():
            add('qualification/' + str(path.relative_to(OUT)), path.read_bytes())
for name in (
    'qualify_pr412_audio_link.py', 'media-pr412-build137962507717-original.log',
    'media-pr412-audio-link-qualification.log', 'media-pr412-audio-link-no-cmake.log',
    'pr412-cmake-install.log', 'root-pr412-source-adoption.json',
    'media-pr412-link-package-path-error.log',
):
    add('evidence/' + name, (W / name).read_bytes())
add('evidence/build_pr412_link_followup.py', Path(__file__).read_bytes())
add('workspace/media-audio-refill-windows/receipt.json',
    (W / 'media-audio-refill-windows/receipt.json').read_bytes())

inputs = set()
for result in proof['real_engine_exports']:
    for entry in result['actual_inputs']:
        path = Path(entry['path'])
        assert sha(path.read_bytes()) == entry['sha256']
        inputs.add(path)
for path in sorted(inputs):
    if path.is_relative_to(ROOT):
        add('repo/' + str(path.relative_to(ROOT)), path.read_bytes())
    else:
        add('workspace/' + str(path.relative_to(W)), path.read_bytes())
for path in (
    'cmake/aosp/media.cmake', 'cmake/aosp/hwui.cmake', 'cmake/toolchain-llvm-mingw.cmake',
    'compat/media/video/video_decoder.cc', 'compat/media/video/video_decoder.h',
    'compat/media/video/yuv_rgba.h', 'compat/media/video/render.cc',
    'compat/media/surface/queue_surface.cc', 'compat/media/surface/queue_surface.h',
    'compat/media/player/extractor.h', 'compat/media/player/data_source.h',
    'tests/media/surface_geometry_host.cc.in', 'tests/media/i420_crop_test.cc',
    'tests/media/i420-host/include/media/NdkMediaFormat.h',
    'tools/test_i420_crop.py', '.github/workflows/ci.yml', 'tests/windows/tracks/38-media.ps1',
):
    data = (ROOT / path).read_bytes()
    if 'repo/' + path not in members:
        add('repo/' + path, data)
    if path == 'cmake/aosp/media.cmake':
        add('baseline/' + path, old(path))
    else:
        assert data == old(path), path
assert sha(members['evidence/media-pr412-build137962507717-original.log']) == proof['actual_failed_log_sha256']

readme = '''# I420 native-link follow-up evidence

The original full CI log is preserved exactly. The qualification directory holds
both actual extracted CMake target graphs, complete generated Ninja commands,
strict Windows x64/AArch64 engine objects, dependency lists, defined-symbol output
and their original proof. Source inputs are copied byte-for-byte under repo/ and
workspace/. No AOSP function body or successful executable is substituted.

evidence/qualify_pr412_audio_link.py is the exact script that produced these
receipts in the declared original workspace layout. Its absolute tool/source
paths and dependency on the archived earlier media-audio-refill-windows command
receipt are historical execution inputs, not a portable full-project build claim. The
proof records every expanded compiler command. Reproduction elsewhere must map
those paths to the recorded exact inputs and the pinned LLVM-MinGW toolchain.
CMake 3.31.10 and Ninja 1.13.0 were installed for the graph qualification; the
initial missing-CMake failure and actual installation log are retained.
The first archive assembly used the wrong Windows-script directory literal;
its FileNotFoundError is retained, and only that packaging path was corrected.

The isolated graph leaves other AOSP libraries as unresolved library names. It
proves that this explicit OBJECT-library dependency adds the eight real audio
objects while retaining all fourteen player objects. The real engine objects
define all sixteen symbols missing in the original full-CI link. Complete
aggregate executable linking and Windows runtime remain the unchanged full-CI
requirements. This archive is separate from the unchanged 451-member performance
archive and adds no timing or runtime acceptance claim.
'''
add('README.md', readme.encode())
manifest = {'schema': 1, 'members': {name: {'bytes': len(data), 'sha256': sha(data)}
                                  for name, data in sorted(members.items())}}
add('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())
target = ROOT / ARCHIVE
with target.open('wb') as file:
    with gzip.GzipFile(filename='', mode='wb', fileobj=file, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = 0
                archive.addfile(entry, io.BytesIO(data))
blob = target.read_bytes()
section = {
    'published_parent': BASE,
    'actual_failed_run': 'https://github.com/yom-chadash/gesher/actions/runs/45241081232',
    'actual_failed_job': 'https://github.com/yom-chadash/gesher/actions/runs/45241081232/job/137962507717',
    'attempt': 1,
    'event': 'workflow_dispatch',
    'failure': 'The required media_i420_crop_test.exe link has all fourteen player objects but no audio objects and fails with sixteen real audio-engine undefined symbols.',
    'fix': 'Add gesher_media_audio as an explicit direct OBJECT-library dependency of media_i420_crop_test, matching the existing media_muxer_verify target pattern.',
    'qualification': proof,
    'independent_source_review': json.loads((W / 'root-pr412-source-adoption.json').read_text()),
    'historical_report_unchanged': True,
    'historical_archive_unchanged': original_report['archive'],
    'archive': {'path': ARCHIVE, 'bytes': len(blob), 'sha256': sha(blob),
                'members': len(members), 'manifest_sha256': sha(members['manifest.json'])},
    'limits': [
        'Earlier strict full-translation-unit compilation did not exercise the aggregate executable link; this missing dependency was found by genuine full CI.',
        'The isolated CMake graph does not configure or link the complete external AOSP dependency closure.',
        'Real Windows engine objects compile and define the missing symbols; complete executable link and actual Windows runtime remain pending full-CI evidence.',
        'Production behavior, samples, oracle, assertions, warning flags, Windows/CI gates and all historical timing rows are unchanged.',
    ],
}
report = dict(original_report)
report['native_link_followup'] = section
(ROOT / REPORT).write_text(json.dumps(report, indent=2) + '\n')
assert {k: report[k] for k in original_report} == original_report
historical_archive = ROOT / original_report['archive']['path']
assert sha(historical_archive.read_bytes()) == original_report['archive']['sha256']
integrity = {
    'parent': BASE, 'archive': section['archive'], 'original_json_fields_preserved': len(original_report),
    'original_performance_archive': original_report['archive'],
    'cmake_before_sha256': proof['cmake_before_sha256'],
    'cmake_after_sha256': proof['cmake_after_sha256'],
    'actual_failed_log_sha256': proof['actual_failed_log_sha256'],
    'source_assertion_gate_changes': 'exact one direct link dependency only; preserved source assertions and runtime gates',
}
(W / 'media-pr412-link-final-proof.json').write_text(json.dumps(integrity, indent=2) + '\n')
print(json.dumps(integrity))
