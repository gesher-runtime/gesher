#!/usr/bin/env python3
"""Qualify the actual CMake object closure and missing real Windows exports.

This generates the exact three target declarations in an isolated CMake graph.
Other linked libraries stay unresolved names; this is not a full AOSP link or
Windows execution. Separately compile the full real engine.cc for both ABIs.
"""
from pathlib import Path
import hashlib
import json
import re
import shlex
import subprocess

W=Path(__file__).resolve().parent
ROOT=W/'gesher-media-i420-ci-fix'
OUT=W/'media-pr412-audio-link-qualification'
OUT.mkdir(exist_ok=True)
BASE='5c9b88fb108d122ae19f2b72d3be13aa7ee31022'
TOOL=W/'toolchains/llvm-mingw-20261006-ucrt-ubuntu-22.04-x86_64'
CMAKE=W/'toolchains/cmake-python/cmake/data/bin/cmake'
NINJA=W/'toolchains/cmake-python/bin/ninja'


def sha(data): return hashlib.sha256(data).hexdigest()
def git(path): return subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
def between(text,begin,end):
    a=text.index(begin);b=text.index(end,a);return text[a:b]
def run(label,command,cwd=None):
    r=subprocess.run(command,cwd=cwd,text=True,capture_output=True,timeout=120)
    (OUT/(label+'.log')).write_text(r.stdout+r.stderr)
    assert r.returncode==0,(label,r.stdout,r.stderr)
    return r.stdout

before=git('cmake/aosp/media.cmake').decode()
after=(ROOT/'cmake/aosp/media.cmake').read_text()
old='target_link_libraries(media_i420_crop_test PRIVATE gesher_media_player_core gesher_elf)'
new='target_link_libraries(media_i420_crop_test PRIVATE gesher_media_audio gesher_media_player_core gesher_elf)'
assert before.count(old)==1 and after.replace(new,old)==before
assert 'target_link_libraries(media_muxer_verify PRIVATE gesher_media_audio gesher_media_player_core gesher_elf)' in before
graphics=(ROOT/'cmake/aosp/hwui.cmake').read_text()
a=graphics.index('function(gesher_graphics_cxx target)')
b=graphics.index('endfunction()',a)+len('endfunction()')
graphics=graphics[a:b]
graphs=[]
for label,text in [('baseline',before),('repaired',after)]:
    root=OUT/label;root.mkdir(exist_ok=True)
    for name in ['compat','tests']:
        p=root/name
        if not p.exists():p.symlink_to(ROOT/name,target_is_directory=True)
    audio=between(text,'set(GESHER_MEDIA_AUDIO_SOURCES','\nadd_library(gesher_media OBJECT')
    player=between(text,'add_library(gesher_media_player_core OBJECT','\n# The native APIs')
    target=between(text,'add_executable(media_i420_crop_test','\nadd_executable(wasapi_refill_test')
    cmake=('cmake_minimum_required(VERSION 3.24)\nproject(i420_object_closure LANGUAGES C CXX)\n'
           'set(_media "${CMAKE_SOURCE_DIR}/compat/media")\n'+graphics+'\n'+audio+player+target)
    (root/'CMakeLists.txt').write_text(cmake)
    configure=[str(CMAKE),'-S',str(root),'-B',str(root/'build'),'-G','Ninja',
               '-DCMAKE_MAKE_PROGRAM='+str(NINJA),
               '-DCMAKE_TOOLCHAIN_FILE='+str(ROOT/'cmake/toolchain-llvm-mingw.cmake'),
               '-DLLVM_MINGW='+str(TOOL)]
    run(label+'-configure',configure)
    commands=run(label+'-commands',[str(NINJA),'-C',str(root/'build'),'-t','commands','media_i420_crop_test.exe'])
    link=next(x for x in commands.splitlines() if ' -o media_i420_crop_test.exe ' in x)
    audio_objects=re.findall(r'CMakeFiles/gesher_media_audio\.dir/[^ ]+\.obj',link)
    player_objects=re.findall(r'CMakeFiles/gesher_media_player_core\.dir/[^ ]+\.obj',link)
    assert len(player_objects)==14 and len(audio_objects)==(8 if label=='repaired' else 0)
    assert all(x in link for x in ['-llog','-lole32','-luuid'])
    graphs.append({'label':label,'exact_audio_block_sha256':sha(audio.encode()),
                   'exact_player_block_sha256':sha(player.encode()),'exact_target_block_sha256':sha(target.encode()),
                   'cmake_lists_sha256':sha(cmake.encode()),'configure':configure,
                   'link':link,'audio_objects':audio_objects,'player_objects':player_objects})
assert graphs[0]['player_objects']==graphs[1]['player_objects']
assert graphs[0]['exact_audio_block_sha256']==graphs[1]['exact_audio_block_sha256']
assert graphs[0]['exact_player_block_sha256']==graphs[1]['exact_player_block_sha256']
log=(W/'media-pr412-build137962507717-original.log').read_text()
failed_link=next(x.split('Z ',1)[1] for x in log.splitlines() if ' -o media_i420_crop_test.exe ' in x)
missing=sorted(set(re.findall(r'ld\.lld: error: undefined symbol: (.+)',log)))
assert len(missing)==16 and 'CMakeFiles/gesher_media_audio.dir/' not in failed_link
assert sorted(re.findall(r'CMakeFiles/gesher_media_player_core\.dir/[^ ]+\.obj',failed_link))==sorted(graphs[0]['player_objects'])
assert 'media_i420_crop_test' in failed_link
previous=json.loads((W/'media-audio-refill-windows/receipt.json').read_text())['results']
exports=[]
for arch in ['x86_64','aarch64']:
    prior=next(x for x in previous if x['arch']==arch and x['variant']=='baseline')
    command=[x.replace(str(W/'gesher-media-audio-refill'),str(ROOT)) for x in prior['command']]
    command[command.index('-c')+1]=str(ROOT/'compat/media/audio/engine.cc')
    obj=OUT/(arch+'-engine.o');dep=OUT/(arch+'-engine.d')
    command[command.index('-o')+1]=str(obj);command[command.index('-MF')+1]=str(dep)
    run(arch+'-engine',command,cwd=ROOT)
    symbols=run(arch+'-symbols',[str(TOOL/'bin/llvm-nm'),'--defined-only','--demangle',str(obj)])
    defined={line.split(' ',2)[-1] for line in symbols.splitlines() if re.match(r'^[0-9a-fA-F]+ [TtWw] ',line)}
    assert all(s in defined for s in missing),(arch,[s for s in missing if s not in defined])
    inputs=[]
    for path in shlex.split(dep.read_text().split(':',1)[1].replace('\\\n',' ')):
        p=Path(path).resolve();inputs.append({'path':str(p),'sha256':sha(p.read_bytes())})
    exports.append({'arch':arch,'command':command,'object_sha256':sha(obj.read_bytes()),
                    'all_sixteen_missing_definitions_present':True,'actual_inputs':inputs})
proof={'published_parent':BASE,'cmake_before_sha256':sha(before.encode()),'cmake_after_sha256':sha(after.encode()),
       'only_edit':{'before':old,'after':new},'existing_working_target':'media_muxer_verify',
       'actual_failed_run':45241081232,'actual_failed_job':137962507717,'attempt':1,
       'actual_failed_log_sha256':sha((W/'media-pr412-build137962507717-original.log').read_bytes()),
       'actual_failed_link':failed_link,'missing_symbols':missing,'graphs':graphs,'real_engine_exports':exports,
       'cmake_reference':'https://cmake.org/cmake/help/latest/command/target_link_libraries.html#linking-object-libraries',
       'limits':['The graph boundary preserves the actual audio/player/test declarations and source files but does not configure or link all external AOSP libraries.',
                 'Both full real Windows engine translation units compile strictly and define all missing symbols; complete executable link and Windows execution remain the full CI gate.',
                 'No production, test assertion, warning policy, workflow gate or historical performance source changed.']}
(OUT/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'graphs':2,'baseline_audio_objects':0,'repaired_audio_objects':8,
                  'player_objects':14,'missing_real_exports_covered':16,'abis':['x86_64','aarch64']}))
