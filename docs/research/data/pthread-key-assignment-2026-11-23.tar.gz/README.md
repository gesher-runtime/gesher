# pthread_setspecific evidence

All final and original pilot receipts and adjacent stdout are retained. No
executables or object files are bundled: their exact hashes and rebuild commands
are in each build.json or target receipt. current/ contains the exact source
inputs, including newly added untracked-at-measurement files. The tracked patch
is supplemental; current/ is the complete source snapshot.

Recompute final tables from this directory with:
python3 summarize_pthread_set_evidence.py pthread-set-final-block0/raw.json pthread-set-final-block1/raw.json --output recomputed.json

The source build receipt names local baseline5f3eb587. Public8b3f0bc2 has the
identical full tree and ordered parents, with independent composition proof.
No actual Windows, ART, ELF or application timing is represented by host tests.
Original fixture setup/negative-control targeting failures remain in their named
logs; the final twelve mutation checks use the current exact source.
