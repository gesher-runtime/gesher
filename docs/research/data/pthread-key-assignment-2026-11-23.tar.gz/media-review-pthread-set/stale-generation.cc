// Real production key state and exit logic. Host pthreads supply only the
// external TLS notification boundary; Windows thread creation is not exercised.
#include "shim_internal.h"
#include "pthread_cleanup.h"

#include <cerrno>
#include <array>
#include <atomic>
#include <barrier>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <future>
#include <mutex>
#include <pthread.h>
#include <thread>
#include <vector>

namespace gesher::bionic {
namespace {
constexpr int kKeysMax = 128;         // bionic's PTHREAD_KEYS_MAX
constexpr int kDestructorPasses = 4;  // PTHREAD_DESTRUCTOR_ITERATIONS

std::mutex g_keys_mutex;
void (BIONIC_SYSV* g_key_dtors[kKeysMax])(void*) = {};
// Zero means unused; a live slot publishes its complete generation in one
// observation. Access to a calling thread's value needs no process-wide lock.
// Creation, deletion and destructor selection remain serialized.
static_assert(std::atomic<uint64_t>::is_always_lock_free);
std::atomic<uint64_t> g_key_live_generations[kKeysMax] = {};
// A reused key slot must not expose another generation's thread-local value.
// Retire a slot at UINT64_MAX rather than letting its generation wrap.
uint64_t g_key_generations[kKeysMax] = {};
thread_local void* t_key_values[kKeysMax] = {};
thread_local uint64_t t_key_generations[kKeysMax] = {};

struct ThreadAtExit {
  void (BIONIC_SYSV* dtor)(void*);
  void* obj;
};
thread_local std::vector<ThreadAtExit>* t_thread_atexit = nullptr;
thread_local CleanupStack t_cleanups;

// C++ thread_local destructors, last registered first (as bionic).
void RunThreadAtExit() {
  if (t_thread_atexit == nullptr) return;
  while (!t_thread_atexit->empty()) {
    ThreadAtExit e = t_thread_atexit->back();
    t_thread_atexit->pop_back();
    e.dtor(e.obj);
  }
  delete t_thread_atexit;
  t_thread_atexit = nullptr;
}

// One round of key destructors: each key set when the round reaches it, once.
// Returns whether any destructor ran.
bool RunKeyRound() {
  bool any = false;
  for (int k = 0; k < kKeysMax; ++k) {
    void* value = t_key_values[k];
    if (value == nullptr) continue;
    void (BIONIC_SYSV* dtor)(void*) = nullptr;
    {
      std::lock_guard<std::mutex> lock(g_keys_mutex);
      if (g_key_live_generations[k].load(std::memory_order_relaxed) != 0 &&
          t_key_generations[k] == g_key_generations[k]) {
        dtor = g_key_dtors[k];
      }
    }
    t_key_values[k] = nullptr;
    t_key_generations[k] = 0;
    if (dtor != nullptr) {
      dtor(value);
      any = true;
    }
  }
  return any;
}

void RunThreadExit() {
  t_cleanups.Run();
  RunThreadAtExit();
  for (int pass = 0; pass < kDestructorPasses; ++pass) {
    if (!RunKeyRound()) break;
  }
}


struct ThreadRecord {};
thread_local ThreadRecord* t_record = nullptr;
pthread_key_t g_host_exit_key;
std::once_flag g_host_exit_once;
thread_local int t_host_exit_rounds = -1;  // -1: not armed on this thread

void HostExitRound(void*) {
  ++t_host_exit_rounds;
  t_cleanups.Run();
  RunThreadAtExit();
  RunKeyRound();
}

void ArmHostExit() {
  if (t_record != nullptr) return;
  if (t_host_exit_rounds < 0) {
    std::call_once(g_host_exit_once,
                   [] { pthread_key_create(&g_host_exit_key, HostExitRound); });
    t_host_exit_rounds = 0;
  } else if (t_host_exit_rounds == 0 || t_host_exit_rounds >= kDestructorPasses) {
    return;
  }
  // Armed, or set again while the thread exits: its destructor runs next round.
  pthread_setspecific(g_host_exit_key, &t_host_exit_rounds);
}


#ifdef KEY_SET_SNAPSHOT_PROBE
// Only the separately compiled overlap probe injects this callback immediately
// after the real setter's generation load. The ordinary suite has no hooks.
struct SetSnapshotPause {
  std::promise<void> captured, release;
};
thread_local SetSnapshotPause* t_set_snapshot_pause = nullptr;
void ObserveSetSnapshot() {
  if (t_set_snapshot_pause == nullptr) return;
  SetSnapshotPause* pause = t_set_snapshot_pause;
  t_set_snapshot_pause = nullptr;
  pause->captured.set_value();
  pause->release.get_future().wait();
}
#endif
}
extern "C" {
int BIONIC_SYSV gesher_bionic_pthread_key_create(bionic_pthread_key_t* key,
                                                void (BIONIC_SYSV* dtor)(void*)) {
  std::lock_guard<std::mutex> lock(g_keys_mutex);
  for (int i = 0; i < kKeysMax; ++i) {
    if (g_key_live_generations[i].load(std::memory_order_relaxed) == 0 &&
        g_key_generations[i] != UINT64_MAX) {
      ++g_key_generations[i];
      g_key_dtors[i] = dtor;
      g_key_live_generations[i].store(g_key_generations[i], std::memory_order_release);
      *key = i;
      return 0;
    }
  }
  return kEAGAIN;
}

int BIONIC_SYSV gesher_bionic_pthread_key_delete(bionic_pthread_key_t key) {
  if (key < 0 || key >= kKeysMax) return kEINVAL;
  std::lock_guard<std::mutex> lock(g_keys_mutex);
  if (g_key_live_generations[key].load(std::memory_order_relaxed) == 0) return kEINVAL;
  g_key_live_generations[key].store(0, std::memory_order_release);
  g_key_dtors[key] = nullptr;
  return 0;
}

void* BIONIC_SYSV gesher_bionic_pthread_getspecific(bionic_pthread_key_t key) {
  if (key < 0 || key >= kKeysMax) return nullptr;
  const uint64_t generation = g_key_live_generations[key].load(std::memory_order_acquire);
  if (generation == 0) {
    t_key_values[key] = nullptr;
    t_key_generations[key] = 0;
    return nullptr;
  }
  return t_key_values[key];
}

int BIONIC_SYSV gesher_bionic_pthread_setspecific(bionic_pthread_key_t key, const void* value) {
  if (key < 0 || key >= kKeysMax) return kEINVAL;
  const uint64_t generation = g_key_live_generations[key].load(std::memory_order_acquire);
  if (generation == 0) return kEINVAL;
  // Stamp the observed live generation, even if deletion/reuse overlaps this
  // assignment. A later read or exit round then rejects the obsolete value.
  t_key_values[key] = const_cast<void*>(value);
  t_key_generations[key] = generation;
  if (value != nullptr) ArmHostExit();
  return 0;
}

// C++ thread_local destructors (libc++abi calls this for every thread_local
// object with a destructor). Run when the thread ends, before its keys.
int BIONIC_SYSV gesher_bionic_cxa_thread_atexit_impl(void (BIONIC_SYSV* dtor)(void*), void* obj,
                                                    void* /*dso*/) {
  if (t_thread_atexit == nullptr) t_thread_atexit = new std::vector<ThreadAtExit>();
  t_thread_atexit->push_back({dtor, obj});
  ArmHostExit();
  return 0;
}


}
void RegisterKeyContracts(SymbolTable& t) {
#define P(name) t[#name] = reinterpret_cast<void*>(&gesher_bionic_##name)
  P(pthread_key_create);
  P(pthread_key_delete);
  P(pthread_getspecific);
  P(pthread_setspecific);
#undef P
}
}

static int failures;
static void check(const char* label, bool ok) {
  std::printf("%-78s %s\n", label, ok ? "ok" : "FAIL");
  if (!ok) ++failures;
  std::fflush(stdout);
}
static void* key_symbol(void*, const char* name) {
  static gesher::bionic::SymbolTable table = [] {
    gesher::bionic::SymbolTable result;
    gesher::bionic::RegisterKeyContracts(result);
    return result;
  }();
  auto found = table.find(name);
  return found == table.end() ? nullptr : found->second;
}
#define dlsym key_symbol
#include "pthread_key_contract_test.inc"
#undef dlsym

using namespace gesher::bionic;
struct Mutation {
  int32_t first = -1, second = -1, replacement = -1;
  bool assign = false, fresh = false;
  int result = 0, first_calls = 0, old_calls = 0, new_calls = 0;
};
static void NewMutation(void* p) { ++static_cast<Mutation*>(p)->new_calls; }
static void OldMutation(void* p) { ++static_cast<Mutation*>(p)->old_calls; }
static void MutateOther(void* p) {
  auto* m = static_cast<Mutation*>(p);
  ++m->first_calls;
  m->result |= gesher_bionic_pthread_key_delete(m->second);
  m->result |= gesher_bionic_pthread_key_create(&m->replacement, NewMutation);
  if (m->assign) {
    m->fresh = gesher_bionic_pthread_getspecific(m->replacement) == nullptr;
    m->result |= gesher_bionic_pthread_setspecific(m->replacement, m);
  }
}
static void MutateSelf(void* p) {
  auto* m = static_cast<Mutation*>(p);
  ++m->first_calls;
  m->result |= gesher_bionic_pthread_key_delete(m->first);
  m->result |= gesher_bionic_pthread_key_create(&m->replacement, NewMutation);
  m->fresh = gesher_bionic_pthread_getspecific(m->replacement) == nullptr;
  m->result |= gesher_bionic_pthread_setspecific(m->replacement, m);
}
static void test_mutations() {
  ThreadRecord record;
  t_record = &record;
  for (bool assign : {false, true}) {
    Mutation m;
    m.assign = assign;
    gesher_bionic_pthread_key_create(&m.first, MutateOther);
    gesher_bionic_pthread_key_create(&m.second, OldMutation);
    gesher_bionic_pthread_setspecific(m.first, &m);
    gesher_bionic_pthread_setspecific(m.second, &m);
    RunThreadExit();
    check(assign ? "pthread keys: callback may assign the replacement generation"
                 : "pthread keys: callback reuse skips later obsolete values",
          m.result == 0 && m.replacement == m.second && m.first_calls == 1 &&
          m.old_calls == 0 && m.new_calls == (assign ? 1 : 0) && (!assign || m.fresh));
    gesher_bionic_pthread_key_delete(m.first);
    gesher_bionic_pthread_key_delete(m.replacement);
  }
  Mutation self;
  gesher_bionic_pthread_key_create(&self.first, MutateSelf);
  gesher_bionic_pthread_setspecific(self.first, &self);
  RunThreadExit();
  check("pthread keys: destructor may delete/recreate itself without deadlock",
        self.result == 0 && self.replacement == self.first && self.fresh &&
        self.first_calls == 1 && self.new_calls == 1);
  gesher_bionic_pthread_key_delete(self.replacement);
  t_record = nullptr;
}

struct ExitState {
  int32_t key = -1;
  int rounds = 0;
  std::vector<int> order;
  bool cleared_before_callback = true;
};
static void RecordCleanup(void* p) { static_cast<ExitState*>(p)->order.push_back(1); }
static void RecordCpp(void* p) { static_cast<ExitState*>(p)->order.push_back(2); }
static void Reinsert(void* p) {
  auto* s = static_cast<ExitState*>(p);
  s->cleared_before_callback &= gesher_bionic_pthread_getspecific(s->key) == nullptr;
  s->order.push_back(3);
  ++s->rounds;
  gesher_bionic_pthread_setspecific(s->key, s);
}
static void test_exit_order() {
  ThreadRecord record;
  t_record = &record;
  ExitState state;
  CleanupRecord cleanup;
  t_cleanups.Push(&cleanup, RecordCleanup, &state);
  gesher_bionic_cxa_thread_atexit_impl(RecordCpp, &state, nullptr);
  gesher_bionic_pthread_key_create(&state.key, Reinsert);
  gesher_bionic_pthread_setspecific(state.key, &state);
  RunThreadExit();
  check("pthread keys: cleanup/C++ TLS/key order and four reinsertion rounds",
        state.cleared_before_callback && state.rounds == 4 &&
        state.order == std::vector<int>({1, 2, 3, 3, 3, 3}));
  gesher_bionic_pthread_key_delete(state.key);
  t_record = nullptr;
}

struct HostExitState {
  pthread_key_t art_key{};
  int32_t detach_key = -1;
  int art_calls = 0;
  bool detached = false, cpp_before_detach = false;
  ExitState rounds;
};
static void ArtExit(void* p) {
  auto* s = static_cast<HostExitState*>(p);
  if (++s->art_calls == 1) pthread_setspecific(s->art_key, s);
}
static void Detach(void* p) {
  auto* s = static_cast<HostExitState*>(p);
  s->detached = true;
  pthread_setspecific(s->art_key, nullptr);
}
static void HostCpp(void* p) {
  auto* s = static_cast<HostExitState*>(p);
  s->cpp_before_detach = !s->detached;
}
static void test_host_exit() {
  HostExitState state;
  pthread_key_create(&state.art_key, ArtExit);
  gesher_bionic_pthread_key_create(&state.detach_key, Detach);
  gesher_bionic_pthread_key_create(&state.rounds.key, Reinsert);
  std::thread worker([&] {
    pthread_setspecific(state.art_key, &state);
    gesher_bionic_pthread_setspecific(state.detach_key, &state);
    gesher_bionic_pthread_setspecific(state.rounds.key, &state.rounds);
    gesher_bionic_cxa_thread_atexit_impl(HostCpp, &state, nullptr);
  });
  worker.join();
  check("pthread keys: host exit detaches before a second ART callback",
        state.art_calls == 1 && state.detached && state.cpp_before_detach);
  check("pthread keys: host exit retains four callback rounds",
        state.rounds.rounds == 4 && state.rounds.cleared_before_callback);
  pthread_key_delete(state.art_key);
  gesher_bionic_pthread_key_delete(state.detach_key);
  gesher_bionic_pthread_key_delete(state.rounds.key);
}

static void test_generation_limit() {
#ifdef HAVE_KEY_GENERATIONS
  for (int i = 0; i < kKeysMax; ++i) g_key_generations[i] = UINT64_MAX;
  g_key_generations[0] = UINT64_MAX - 1;
  int32_t key = -1, next = -1;
  check("pthread keys: last generation is usable",
        gesher_bionic_pthread_key_create(&key, nullptr) == 0 && key == 0 &&
        g_key_generations[0] == UINT64_MAX);
  int value = 19;
  check("pthread keys: last generation retains its local value",
        gesher_bionic_pthread_setspecific(key, &value) == 0 &&
        gesher_bionic_pthread_getspecific(key) == &value);
  check("pthread keys: exhausted generation retires without wrap",
        gesher_bionic_pthread_key_delete(key) == 0 &&
        gesher_bionic_pthread_key_create(&next, nullptr) == kEAGAIN && next == -1 &&
        g_key_generations[0] == UINT64_MAX);
#else
  std::puts("SKIP generation boundary: baseline has no generation state");
#endif
}

struct KeyReader {
  int calls = 0;
  bool valid = true;
};
static void ReaderExit(void* value) { ++static_cast<KeyReader*>(value)->calls; }

static void test_readers() {
  for (int count : {1, 8, 32}) for (bool distinct : {false, true}) {
    const int key_count = distinct ? count : 1;
    std::array<int32_t, 32> keys{};
    bool created = true;
    for (int i = 0; i < key_count; ++i)
      created &= gesher_bionic_pthread_key_create(&keys[i], ReaderExit) == 0;
    check("pthread keys: create independent or shared reader keys", created);
    if (!created) return;
    std::array<KeyReader, 32> states;
    std::array<std::thread, 32> readers;
    std::barrier start(count + 2);
    std::atomic<bool> writer_ok{true};
    for (int i = 0; i < count; ++i) readers[i] = std::thread([&, i] {
      auto& state = states[i];
      const int32_t key = keys[distinct ? i : 0];
      state.valid = gesher_bionic_pthread_setspecific(key, &state) == 0;
      start.arrive_and_wait();
      for (int n = 0; n < 4000; ++n) {
        errno = ERANGE;
        state.valid &= gesher_bionic_pthread_getspecific(key) == &state && errno == ERANGE;
      }
    });
    std::thread writer([&] {
      start.arrive_and_wait();
      for (int n = 0; n < 1000; ++n) {
        int32_t key = -1;
        if (gesher_bionic_pthread_key_create(&key, nullptr) != 0 ||
            gesher_bionic_pthread_key_delete(key) != 0) writer_ok = false;
      }
    });
    start.arrive_and_wait();
    for (int i = 0; i < count; ++i) readers[i].join();
    writer.join();
    for (int i = 0; i < count; ++i)
      check("pthread keys: concurrent read keeps own value, errno and one exit callback",
            states[i].valid && states[i].calls == 1);
    check("pthread keys: unrelated key churn completes", writer_ok.load());
    for (int i = 0; i < key_count; ++i)
      check("pthread keys: retire reader key after native exit", gesher_bionic_pthread_key_delete(keys[i]) == 0);
  }

  int32_t key = -1;
  check("pthread keys: create synchronized reuse key", gesher_bionic_pthread_key_create(&key, ReaderExit) == 0);
  std::array<KeyReader, 8> states;
  std::array<std::thread, 8> readers;
  std::barrier phase(9);
  for (int i = 0; i < 8; ++i) readers[i] = std::thread([&, i] {
    auto& state = states[i];
    for (int epoch = 0; epoch < 64; ++epoch) {
      state.valid &= gesher_bionic_pthread_setspecific(key, &state) == 0;
      phase.arrive_and_wait();
      phase.arrive_and_wait();
      errno = EDOM;
      state.valid &= gesher_bionic_pthread_getspecific(key) == nullptr && errno == EDOM;
      phase.arrive_and_wait();
    }
  });
  for (int epoch = 0; epoch < 64; ++epoch) {
    phase.arrive_and_wait();
    int32_t replacement = -1;
    const bool replaced = gesher_bionic_pthread_key_delete(key) == 0 &&
        gesher_bionic_pthread_key_create(&replacement, ReaderExit) == 0 && replacement == key;
    check("pthread keys: synchronized same-slot generation publication", replaced);
    phase.arrive_and_wait();
    phase.arrive_and_wait();
  }
  for (auto& reader : readers) reader.join();
  for (const auto& state : states)
    check("pthread keys: published reuse clears every old local generation", state.valid && state.calls == 0);
  check("pthread keys: retire synchronized reuse key", gesher_bionic_pthread_key_delete(key) == 0);
  errno = EDOM;
  check("pthread keys: invalid and deleted reads preserve errno",
        gesher_bionic_pthread_getspecific(-1) == nullptr &&
        gesher_bionic_pthread_getspecific(INT32_MAX) == nullptr &&
        gesher_bionic_pthread_getspecific(key) == nullptr && errno == EDOM);
}

static void test_read_progress(bool require_progress) {
  int32_t key = -1;
  check("pthread keys: create registry-independence key", gesher_bionic_pthread_key_create(&key, nullptr) == 0);
  std::promise<void> ready, go, returned;
  auto ready_future = ready.get_future(), go_future = go.get_future(), returned_future = returned.get_future();
  bool value_ok = false;
  std::thread reader([&] {
    int local = 1;
    value_ok = gesher_bionic_pthread_setspecific(key, &local) == 0;
    ready.set_value();
    go_future.wait();
    value_ok &= gesher_bionic_pthread_getspecific(key) == &local;
    returned.set_value();
  });
  ready_future.wait();
  std::unique_lock<std::mutex> registry(g_keys_mutex);
  go.set_value();
  const bool progressed = returned_future.wait_for(std::chrono::seconds(5)) == std::future_status::ready;
  registry.unlock();  // Also release an unchanged-baseline reader before joining it.
  reader.join();
  check("pthread keys: registry-independence read returns its real local value", value_ok);
  if (require_progress) check("pthread keys: local read proceeds while key registry is locked", progressed);
  else std::printf("OBSERVE local read while key registry locked: %d\n", int(progressed));
  check("pthread keys: retire registry-independence key", gesher_bionic_pthread_key_delete(key) == 0);
}

struct SetOwner;
struct SetValue { SetOwner* owner; bool replacement; };
struct SetOwner {
  SetValue old{this, false}, fresh{this, true};
  int old_calls = 0, new_calls = 0, wrong_calls = 0;
  bool valid = true;
};
#ifdef KEY_SET_SNAPSHOT_PROBE
static void OldSetExit(void* p) { ++static_cast<SetValue*>(p)->owner->old_calls; }
#endif
static void NewSetExit(void* p) {
  auto* value = static_cast<SetValue*>(p);
  if (value->replacement) ++value->owner->new_calls;
  else ++value->owner->wrong_calls;
}

static void test_writers() {
  for (int count : {1, 2, 8, 32}) for (bool distinct : {false, true}) {
    const int key_count = distinct ? count : 1;
    std::array<int32_t, 32> keys{};
    bool created = true;
    for (int i = 0; i < key_count; ++i)
      created &= gesher_bionic_pthread_key_create(&keys[i], NewSetExit) == 0;
    check("pthread sets: create shared or independent writer keys", created);
    if (!created) return;
    std::array<SetOwner, 32> owners;
    std::array<std::thread, 32> writers;
    std::barrier start(count + 1);
    for (int i = 0; i < count; ++i) writers[i] = std::thread([&, i] {
      auto& owner = owners[i];
      const auto key = keys[distinct ? i : 0];
      start.arrive_and_wait();
      errno = EDOM;
      for (int n = 0; n < 2000; ++n) {
        owner.valid &= gesher_bionic_pthread_setspecific(key, &owner.old) == 0 &&
            gesher_bionic_pthread_getspecific(key) == &owner.old;
        owner.valid &= gesher_bionic_pthread_setspecific(key, &owner.fresh) == 0 &&
            gesher_bionic_pthread_getspecific(key) == &owner.fresh;
        owner.valid &= gesher_bionic_pthread_setspecific(key, nullptr) == 0 &&
            gesher_bionic_pthread_getspecific(key) == nullptr;
      }
      owner.valid &= errno == EDOM &&
          gesher_bionic_pthread_setspecific(key, &owner.fresh) == 0;
    });
    start.arrive_and_wait();
    for (int i = 0; i < count; ++i) writers[i].join();
    for (int i = 0; i < count; ++i)
      check("pthread sets: overwrite/clear stays local and only final value reaches exit",
            owners[i].valid && owners[i].new_calls == 1 && owners[i].old_calls == 0 &&
            owners[i].wrong_calls == 0);
    for (int i = 0; i < key_count; ++i)
      check("pthread sets: retire completed writer key", gesher_bionic_pthread_key_delete(keys[i]) == 0);
  }
}

static void test_set_arming() {
  int32_t key = -1;
  check("pthread sets: create arming key", gesher_bionic_pthread_key_create(&key, NewSetExit) == 0);
  for (bool managed : {false, true}) for (bool leave_value : {false, true}) {
    SetOwner owner;
    bool initially_unarmed = false, null_unarmed = false, armed = false;
    std::thread worker([&] {
      ThreadRecord record;
      if (managed) t_record = &record;
      initially_unarmed = t_host_exit_rounds == -1;
      errno = EDOM;
      owner.valid &= gesher_bionic_pthread_setspecific(-1, &owner.fresh) == kEINVAL &&
          gesher_bionic_pthread_setspecific(kKeysMax, &owner.fresh) == kEINVAL &&
          gesher_bionic_pthread_setspecific(key, nullptr) == 0;
      null_unarmed = t_host_exit_rounds == -1;
      owner.valid &= gesher_bionic_pthread_setspecific(key, &owner.fresh) == 0;
      armed = managed ? t_host_exit_rounds == -1 :
          t_host_exit_rounds == 0 && pthread_getspecific(g_host_exit_key) == &t_host_exit_rounds;
      owner.valid &= gesher_bionic_pthread_getspecific(key) == &owner.fresh;
      if (!leave_value)
        owner.valid &= gesher_bionic_pthread_setspecific(key, nullptr) == 0 &&
            gesher_bionic_pthread_getspecific(key) == nullptr;
      owner.valid &= errno == EDOM;
      if (managed) {
        RunThreadExit();
        t_record = nullptr;
      }
    });
    worker.join();
    check("pthread sets: invalid/null assignments do not arm native exit", initially_unarmed && null_unarmed);
    check("pthread sets: first nonnull assignment preserves real exit arming", owner.valid && armed);
    check("pthread sets: host or explicit exit observes only retained final value",
          owner.new_calls == int(leave_value) && owner.old_calls == 0 && owner.wrong_calls == 0);
  }
  check("pthread sets: retire arming key", gesher_bionic_pthread_key_delete(key) == 0);
}

static void test_set_progress(bool require_progress) {
  int32_t key = -1;
  check("pthread sets: create registry-independence key", gesher_bionic_pthread_key_create(&key, NewSetExit) == 0);
  SetOwner owner;
  std::promise<void> ready, go, returned;
  auto ready_future = ready.get_future(), go_future = go.get_future(), returned_future = returned.get_future();
  std::thread writer([&] {
    ready.set_value();
    go_future.wait();
    owner.valid = gesher_bionic_pthread_setspecific(key, &owner.old) == 0 &&
        gesher_bionic_pthread_getspecific(key) == &owner.old &&
        gesher_bionic_pthread_setspecific(key, nullptr) == 0 &&
        gesher_bionic_pthread_getspecific(key) == nullptr &&
        gesher_bionic_pthread_setspecific(key, &owner.fresh) == 0;
    returned.set_value();  // Observe setter progress before TLS-exit locking.
  });
  ready_future.wait();
  std::unique_lock<std::mutex> registry(g_keys_mutex);
  go.set_value();
  const bool progressed = returned_future.wait_for(std::chrono::seconds(5)) == std::future_status::ready;
  registry.unlock();  // Let the real exit round, or the locked baseline, finish.
  writer.join();
  check("pthread sets: registry-independent writes retain actual value and exit", owner.valid && owner.new_calls == 1);
  if (require_progress) check("pthread sets: local assignment proceeds while key registry is locked", progressed);
  else std::printf("OBSERVE local assignment while key registry locked: %d\n", int(progressed));
  check("pthread sets: retire registry-independence key", gesher_bionic_pthread_key_delete(key) == 0);
}

#ifdef KEY_SET_SNAPSHOT_PROBE
static void test_set_snapshot() {
  for (bool replace : {false, true}) {
    int32_t key = -1;
    check("pthread sets: create snapshot key", gesher_bionic_pthread_key_create(&key, OldSetExit) == 0);
    std::array<SetOwner, 2> owners;
    std::array<SetSnapshotPause, 2> pauses;
    std::array<std::future<void>, 2> captured;
    std::array<std::thread, 2> workers;
    for (int i = 0; i < 2; ++i) {
      captured[i] = pauses[i].captured.get_future();
      workers[i] = std::thread([&, i] {
        t_set_snapshot_pause = &pauses[i];
        owners[i].valid = gesher_bionic_pthread_setspecific(key, &owners[i].old) == 0;
        if (i == 0) {
          owners[i].valid &= gesher_bionic_pthread_getspecific(key) == nullptr;
          if (replace)
            owners[i].valid &= gesher_bionic_pthread_setspecific(key, &owners[i].fresh) == 0 &&
                gesher_bionic_pthread_getspecific(key) == &owners[i].fresh;
        }  // The other thread exits with its obsolete value still in TLS.
      });
    }
    for (auto& ready : captured) ready.wait();
    check("pthread sets: delete after both actual generation observations", gesher_bionic_pthread_key_delete(key) == 0);
    if (replace) {
      int32_t replacement = -1;
      check("pthread sets: recreate before paused assignments publish TLS",
            gesher_bionic_pthread_key_create(&replacement, NewSetExit) == 0 && replacement == key);
    }
    for (auto& pause : pauses) pause.release.set_value();
    for (auto& worker : workers) worker.join();
    check("pthread sets: overlapping stale set cannot become replacement value",
          owners[0].valid && owners[1].valid && owners[0].old_calls == 0 &&
          owners[1].old_calls == 0 && owners[0].new_calls == int(replace) &&
          owners[1].new_calls == 0 && owners[0].wrong_calls == 0 && owners[1].wrong_calls == 0);
    if (replace) check("pthread sets: retire snapshot replacement", gesher_bionic_pthread_key_delete(key) == 0);
  }
}
#endif

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  if (std::strcmp(argv[1], "public") == 0) test_pthread_key_contracts();
  else if (std::strcmp(argv[1], "mutations") == 0) test_mutations();
  else if (std::strcmp(argv[1], "exit_order") == 0) test_exit_order();
  else if (std::strcmp(argv[1], "host_exit") == 0) test_host_exit();
  else if (std::strcmp(argv[1], "generation_limit") == 0) test_generation_limit();
  else if (std::strcmp(argv[1], "readers") == 0) test_readers();
  else if (std::strcmp(argv[1], "read_progress") == 0) test_read_progress(true);
  else if (std::strcmp(argv[1], "observe_read_progress") == 0) test_read_progress(false);
  else if (std::strcmp(argv[1], "writers") == 0) test_writers();
  else if (std::strcmp(argv[1], "set_arming") == 0) test_set_arming();
  else if (std::strcmp(argv[1], "set_progress") == 0) test_set_progress(true);
  else if (std::strcmp(argv[1], "observe_set_progress") == 0) test_set_progress(false);
#ifdef KEY_SET_SNAPSHOT_PROBE
  else if (std::strcmp(argv[1], "set_snapshot") == 0) test_set_snapshot();
#endif
  else return 2;
  return failures == 0 ? 0 : 1;
}
