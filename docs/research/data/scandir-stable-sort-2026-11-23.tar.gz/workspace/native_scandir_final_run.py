#!/usr/bin/env python3
"""Execute both predeclared fixed Scandir blocks once, retaining each receipt."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PREDECL = ROOT / 'native-scandir-final-predeclaration.json'
OUT = ROOT / 'native-scandir-final-execution.json'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

assert not OUT.exists(), 'Existing execution receipt forbids accidental repeat'
declaration = json.loads(PREDECL.read_text())
assert hashlib.sha256((ROOT / 'native_scandir_abba.py').read_bytes()).hexdigest() == declaration['driver_sha256']
record = {'start_utc': now(), 'predeclaration_sha256': hashlib.sha256(PREDECL.read_bytes()).hexdigest(), 'blocks': []}
OUT.write_text(json.dumps(record, indent=2) + '\n')
for block in declaration['blocks']:
    command = [sys.executable, str(ROOT / 'native_scandir_abba.py'), '--output-dir', block['output_dir'], '--round-start', str(block['round_start']), '--rounds', str(block['rounds']), '--baseline-dir', declaration['variants']['baseline']['directory'], '--candidate-dir', declaration['variants']['candidate']['directory']]
    entry = {'command': command, 'start_utc': now()}
    completed = subprocess.run(command)
    entry.update(end_utc=now(), returncode=completed.returncode)
    record['blocks'].append(entry)
    OUT.write_text(json.dumps(record, indent=2) + '\n')
    if completed.returncode:
        record.update(end_utc=now(), terminal_failure=True)
        OUT.write_text(json.dumps(record, indent=2) + '\n')
        raise SystemExit(completed.returncode)
record.update(end_utc=now(), terminal_failure=False)
OUT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
