// Reuse the maintained whole-directory/real allocator boundary unchanged,
// with a larger bounded pointer tracker for the additional large fixtures.
#include <algorithm>
#define main original_directory_main
// Production directory adapters with real Linux directories. Allocation and
// reader failures are injected at the host boundary, not into copied logic.
#include "shim_internal.h"

#include <cerrno>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {
bool allocations_armed;
int fail_allocation = -1;
int allocation_calls;
void* owned[16384];
size_t owned_count;
int fail_read_after = -1;
int reads;
int closes;
bool fail_fd_path;

void track(void* pointer) {
  if (pointer == nullptr || !allocations_armed) return;
  if (owned_count == sizeof(owned) / sizeof(owned[0])) std::abort();
  owned[owned_count++] = pointer;
}
void untrack(void* pointer) {
  for (size_t i = 0; i < owned_count; ++i) {
    if (owned[i] == pointer) {
      owned[i] = owned[--owned_count];
      break;
    }
  }
}
bool allocation_fails() {
  if (!allocations_armed) return false;
  if (allocation_calls++ != fail_allocation) return false;
  errno = ENOMEM;
  return true;
}
}

extern "C" void* __real_malloc(size_t);
extern "C" void* __real_realloc(void*, size_t);
extern "C" void __real_free(void*);
extern "C" dirent* __real_readdir(DIR*);
extern "C" int __real_closedir(DIR*);
extern "C" void* __wrap_malloc(size_t n) {
  if (allocation_fails()) return nullptr;
  void* pointer = __real_malloc(n);
  track(pointer);
  return pointer;
}
extern "C" void* __wrap_realloc(void* old, size_t n) {
  if (allocation_fails()) return nullptr;
  void* pointer = __real_realloc(old, n);
  if (pointer != nullptr) {
    untrack(old);
    track(pointer);
  }
  return pointer;
}
extern "C" void __wrap_free(void* pointer) {
  untrack(pointer);
  __real_free(pointer);
}
extern "C" dirent* __wrap_readdir(DIR* dir) {
  if (fail_read_after >= 0 && reads++ >= fail_read_after) return errno = EIO, nullptr;
  return __real_readdir(dir);
}
extern "C" int __wrap_closedir(DIR* dir) {
  ++closes;
  int result = __real_closedir(dir);
  errno = EBUSY;  // Cleanup must not replace the operation's real error.
  return result;
}

namespace gesher::bionic {
namespace {
constexpr int kAtFdcwd = -100;
constexpr int kODirectory = O_DIRECTORY;
bool PathOfFd(int fd, std::string* out) {
  if (fail_fd_path) return errno = EIO, false;
  char proc[64], path[4096];
  std::snprintf(proc, sizeof(proc), "/proc/self/fd/%d", fd);
  ssize_t length = readlink(proc, path, sizeof(path));
  if (length < 0) return false;
  out->assign(path, static_cast<size_t>(length));
  return true;
}
struct BionicDirent {
  uint64_t d_ino;
  int64_t d_off;
  uint16_t d_reclen;
  uint8_t d_type;
  char d_name[256];
};
static_assert(sizeof(BionicDirent) == 280);

struct ShimDir {
  DIR* host = nullptr;
  int fd = -1;  // owned: from fdopendir, or opened by dirfd
  int64_t position = 0;  // opaque guest cookie, never narrowed to Windows long
  std::string path;
  BionicDirent entry{};
  std::mutex mutex;
};

ShimDir* BIONIC_SYSV Opendir(const char* name) {
  DIR* host = opendir(name);
  if (host == nullptr) return nullptr;
  auto* d = new ShimDir();
  d->host = host;
  d->path = name;
  return d;
}
ShimDir* BIONIC_SYSV Fdopendir(int fd) {
  std::string path;
  if (!PathOfFd(fd, &path)) return nullptr;
  ShimDir* d = Opendir(path.c_str());
  if (d != nullptr) d->fd = fd;
  return d;
}
bool Fill(ShimDir* d, BionicDirent* out) {
  if (d->position == INT64_MAX) return errno = EOVERFLOW, false;
  struct dirent* e = readdir(d->host);
  if (e == nullptr) return false;
  out->d_ino = e->d_ino != 0 ? e->d_ino : static_cast<uint64_t>(e->d_off);
  out->d_off = ++d->position;
  out->d_reclen = sizeof(BionicDirent);
  out->d_type = e->d_type;
  size_t n = std::strlen(e->d_name);
  if (n > 255) n = 255;  // a name longer than Linux allows (UTF-8 of 255 UTF-16 units)
  std::memcpy(out->d_name, e->d_name, n);
  out->d_name[n] = 0;
  return true;
}
BionicDirent* BIONIC_SYSV Readdir(ShimDir* d) {
  if (d == nullptr) return errno = kEBADF, nullptr;
  std::lock_guard<std::mutex> lock(d->mutex);
  return Fill(d, &d->entry) ? &d->entry : nullptr;
}
int BIONIC_SYSV ReaddirR(ShimDir* d, BionicDirent* entry, BionicDirent** result) {
  if (d == nullptr || entry == nullptr || result == nullptr) return kEBADF;
  std::lock_guard<std::mutex> lock(d->mutex);
  int saved = errno;
  errno = 0;
  bool ok = Fill(d, entry);
  int e = errno;
  errno = saved;
  *result = ok ? entry : nullptr;
  return ok ? 0 : e;
}
int BIONIC_SYSV Closedir(ShimDir* d) {
  if (d == nullptr) return errno = kEBADF, -1;
  closedir(d->host);
  if (d->fd >= 0) close(d->fd);
  delete d;
  return 0;
}
void BIONIC_SYSV Rewinddir(ShimDir* d) {
  if (d == nullptr) return;
  std::lock_guard<std::mutex> lock(d->mutex);
  rewinddir(d->host);
  d->position = 0;
}
int64_t BIONIC_SYSV Telldir(ShimDir* d) {
  if (d == nullptr) return errno = kEBADF, -1;
  std::lock_guard<std::mutex> lock(d->mutex);
  return d->position;
}
void BIONIC_SYSV Seekdir(ShimDir* d, int64_t location) {
  if (d == nullptr) { errno = kEBADF; return; }
  if (location < 0) { errno = kEINVAL; return; }
  std::lock_guard<std::mutex> lock(d->mutex);
  if (location == d->position) return;
  rewinddir(d->host);
  d->position = 0;
  BionicDirent entry;
  while (d->position < location && Fill(d, &entry)) {}
}
int BIONIC_SYSV Dirfd(ShimDir* d) {
  if (d == nullptr) return errno = kEBADF, -1;
  std::lock_guard<std::mutex> lock(d->mutex);
  if (d->fd < 0) d->fd = open(d->path.c_str(), O_RDONLY | kODirectory | O_CLOEXEC);
  return d->fd;
}

// scandir with the .so's System V filter and comparator; alphasort is the
// shim's, so the .so may pass it as the comparator.
using SysvFilter = int(BIONIC_SYSV*)(const BionicDirent*);
using SysvDirCompare = int(BIONIC_SYSV*)(const BionicDirent**, const BionicDirent**);
int BIONIC_SYSV Alphasort(const BionicDirent** a, const BionicDirent** b) {
  return std::strcmp((*a)->d_name, (*b)->d_name);
}
bool MergeDirectoryEntries(BionicDirent** entries, size_t count, SysvDirCompare compare) {
  // Optional pointer scratch never changes the C API's allocation-failure
  // contract. Keep the comparator's errno even when this allocation fails.
  const int saved_errno = errno;
  auto** scratch = static_cast<BionicDirent**>(std::malloc(count * sizeof(*entries)));
  errno = saved_errno;
  if (scratch == nullptr) return false;
  BionicDirent** from = entries;
  BionicDirent** to = scratch;
  // count is bounded by INT_MAX in ScanDirectory; all width/index arithmetic
  // and the pointer allocation therefore fit the shim's LP64 size_t.
  for (size_t width = 1; width < count; width *= 2) {
    for (size_t begin = 0; begin < count; begin += width * 2) {
      const size_t middle = count - begin < width ? count : begin + width;
      const size_t end = count - middle < width ? count : middle + width;
      size_t left = begin, right = middle;
      for (size_t out = begin; out < end; ++out) {
        if (left == middle) to[out] = from[right++];
        else if (right == end) to[out] = from[left++];
        else {
          const BionicDirent* x = from[left];
          const BionicDirent* y = from[right];
          to[out] = compare(&x, &y) <= 0 ? from[left++] : from[right++];
        }
      }
    }
    std::swap(from, to);
  }
  (void)from;
  std::free(scratch);
  return true;
}
void SortLongDirectory(BionicDirent** entries, size_t count, SysvDirCompare compare) {
  // Already/nearly sorted directories retain insertion sort and allocate no
  // scratch. Bound its work before a stable merge on a disordered directory.
  size_t remaining_swaps = count * 8;
  for (size_t i = 1; i < count; ++i) {
    for (size_t j = i; j > 0; --j) {
      const BionicDirent* x = entries[j - 1];
      const BionicDirent* y = entries[j];
      if (compare(&x, &y) <= 0) break;
      std::swap(entries[j - 1], entries[j]);
      if (--remaining_swaps == 0) {
        if (MergeDirectoryEntries(entries, count, compare)) return;
        // One failed optional allocation resumes the original stable sort.
        remaining_swaps = SIZE_MAX;
      }
    }
  }
}
int ScanDirectory(ShimDir* d, BionicDirent*** list, SysvFilter filter,
                  SysvDirCompare compare) {
  if (d == nullptr) return -1;
  const int saved_errno = errno;
  // These allocations belong to a C API. In a no-exceptions build, vector
  // growth terminates the process on OOM instead of returning -1/ENOMEM.
  BionicDirent** entries = nullptr;
  size_t count = 0, capacity = 0;
  int error = 0;
  BionicDirent e;
  for (;;) {
    // A filter may set errno even when it accepts/skips an entry. Only the
    // directory reader's errno distinguishes a read failure from EOF.
    errno = 0;
    if (!Fill(d, &e)) {
      error = errno;
      break;
    }
    if (filter != nullptr && filter(&e) == 0) continue;
    if (count == INT_MAX) {
      error = EOVERFLOW;  // scandir returns an int count.
      break;
    }
    if (count == capacity) {
      size_t next = capacity == 0 ? 32 : capacity * 2;
      if (next > INT_MAX) next = INT_MAX;
      auto** grown = static_cast<BionicDirent**>(std::realloc(entries, next * sizeof(*entries)));
      if (grown == nullptr) {
        error = kENOMEM;
        break;
      }
      entries = grown;
      capacity = next;
    }
    auto* copy = static_cast<BionicDirent*>(std::malloc(sizeof(e)));
    if (copy == nullptr) {
      error = kENOMEM;
      break;
    }
    *copy = e;
    entries[count++] = copy;
  }
  Closedir(d);
  if (error != 0) {
    for (size_t i = 0; i < count; ++i) std::free(entries[i]);
    std::free(entries);
    errno = error;
    return -1;  // Leave the caller's output untouched and free the prefix.
  }
  if (compare != nullptr && count >= 128) {
    SortLongDirectory(entries, count, compare);
  } else if (compare != nullptr) {
    // Insertion sort through the System V comparator (lists are short).
    for (size_t i = 1; i < count; ++i) {
      for (size_t j = i; j > 0; --j) {
        const BionicDirent* x = entries[j - 1];
        const BionicDirent* y = entries[j];
        if (compare(&x, &y) <= 0) break;
        std::swap(entries[j - 1], entries[j]);
      }
    }
  }
  *list = entries;
  errno = saved_errno;
  return static_cast<int>(count);
}
int BIONIC_SYSV Scandir(const char* path, BionicDirent*** list, SysvFilter filter,
                        SysvDirCompare compare) {
  return ScanDirectory(Opendir(path), list, filter, compare);
}
int BIONIC_SYSV Scandirat(int dirfd, const char* path, BionicDirent*** list,
                          SysvFilter filter, SysvDirCompare compare) {
  if (dirfd == kAtFdcwd) return Scandir(path, list, filter, compare);
  int fd = openat(dirfd, path, O_RDONLY | kODirectory | O_CLOEXEC, 0);
  if (fd < 0) return -1;
  ShimDir* d = Fdopendir(fd);
  if (d == nullptr) {
    const int error = errno;
    close(fd);  // fdopendir takes ownership only on success.
    errno = error;
    return -1;
  }
  return ScanDirectory(d, list, filter, compare);
}


}

void RegisterDirectories(SymbolTable& table) {
#define E(name, fn) table[name] = reinterpret_cast<void*>(&fn)
  E("scandir", Scandir);
  E("scandir64", Scandir);
  E("scandirat", Scandirat);
  E("scandirat64", Scandirat);
  E("opendir", Opendir);
  E("readdir", Readdir);
  E("closedir", Closedir);
  E("rewinddir", Rewinddir);
  E("telldir", Telldir);
  E("seekdir", Seekdir);
#undef E
}
}

static void* directory_symbol(void*, const char* name) {
  static gesher::bionic::SymbolTable table = [] {
    gesher::bionic::SymbolTable result;
    gesher::bionic::RegisterDirectories(result);
    return result;
  }();
  auto found = table.find(name);
  return found == table.end() ? nullptr : found->second;
}
static int failures;
static void check(const char* label, int ok) {
  std::printf("%-72s %s\n", label, ok ? "ok" : "FAIL");
  if (!ok) ++failures;
  std::fflush(stdout);
}

#define dlsym directory_symbol
#include "directory_contract_test.inc"
#undef dlsym

static int descriptor_count() {
  DIR* dir = ::opendir("/proc/self/fd");
  if (!dir) return -1;
  int result = 0;
  while (::readdir(dir)) ++result;
  ::closedir(dir);
  return result;
}

static void test_directory_failures(const char* mode) {
  auto scan = reinterpret_cast<directory_scan_fn>(directory_symbol(nullptr, "scandir"));
  auto scanat = reinterpret_cast<directory_scanat_fn>(directory_symbol(nullptr, "scandirat"));
  char path[] = "gesher-fault-directory-XXXXXX";
  if (!scan || !mkdtemp(path)) { check("directory fault fixture", false); return; }
  for (int i = 0; i < 40; ++i) {
    char name[128];
    std::snprintf(name, sizeof(name), "%s/item-%02d", path, i);
    int fd = ::open(name, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (fd < 0) std::abort();
    ::close(fd);
  }
  const int baseline_fds = descriptor_count();
  struct dirent* sentinel_entry = nullptr;
  struct dirent** sentinel = &sentinel_entry;
  if (std::strcmp(mode, "allocations") == 0) {
    struct dirent** entries = nullptr;
    allocation_calls = 0;
    allocations_armed = true;
    int count = scan(path, &entries, directory_filter, nullptr);
    allocations_armed = false;
    const int total_calls = allocation_calls;
    check("directory: baseline spans list growth", count == 40 && total_calls > 40);
    directory_free_list(entries, count);
    check("directory: caller can free all result allocations", owned_count == 0);
    for (int failure = 0; failure < total_calls; ++failure) {
      entries = sentinel;
      allocation_calls = 0;
      fail_allocation = failure;
      const int close_before = closes;
      allocations_armed = true;
      count = scan(path, &entries, directory_filter, nullptr);
      const int error = errno;
      allocations_armed = false;
      char label[128];
      std::snprintf(label, sizeof(label), "directory: allocation failure %d frees prefix, preserves output", failure);
      check(label, count == -1 && error == ENOMEM && entries == sentinel &&
                   owned_count == 0 && closes == close_before + 1);
      if (count >= 0 && entries != sentinel) directory_free_list(entries, count);
    }
    fail_allocation = -1;
  } else if (std::strcmp(mode, "reader") == 0) {
    for (int after : {0, 5, 30}) {
      reads = 0;
      fail_read_after = after;
      struct dirent** entries = sentinel;
      const int close_before = closes;
      allocations_armed = true;
      int count = scan(path, &entries, nullptr, nullptr);
      const int error = errno;
      allocations_armed = false;
      check("directory: read error frees prefix and preserves original EIO",
            count == -1 && error == EIO && entries == sentinel && owned_count == 0 &&
            closes == close_before + 1);
      if (count >= 0 && entries != sentinel) directory_free_list(entries, count);
    }
    fail_read_after = -1;
  } else if (std::strcmp(mode, "fdopen") == 0) {
    check("directory: scandirat export for failure ownership", scanat != nullptr);
    if (scanat) {
      int parent = ::open(".", O_RDONLY | O_DIRECTORY);
      struct dirent** entries = sentinel;
      fail_fd_path = true;
      errno = 0;
      int count = scanat(parent, path, &entries, nullptr, nullptr);
      const int error = errno;
      fail_fd_path = false;
      check("directory: fdopendir failure returns original error", count == -1 && error == EIO && entries == sentinel);
      check("directory: failed fdopendir closes new fd, retains parent", descriptor_count() == baseline_fds + 1 && fcntl(parent, F_GETFD, 0) >= 0);
      ::close(parent);
    }
  }
  check("directory: no leaked directory descriptors", descriptor_count() == baseline_fds);
  for (int i = 0; i < 40; ++i) {
    char name[128];
    std::snprintf(name, sizeof(name), "%s/item-%02d", path, i);
    ::unlink(name);
  }
  ::rmdir(path);
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  if (std::strcmp(argv[1], "public") == 0) test_directory_contracts();
  else test_directory_failures(argv[1]);
  return failures == 0 ? 0 : 1;
}

#undef main

namespace {
using gesher::bionic::BionicDirent;
using gesher::bionic::Scandir;
using gesher::bionic::Scandirat;
enum class Order { Sorted, Reverse, Nearby, Random, Groups, Lexical };
struct Directory {
  std::string path;
  size_t count;
  explicit Directory(size_t n) : count(n) {
    char name[] = "/tmp/gesher-scandir-sort-XXXXXX";
    if (!::mkdtemp(name)) std::abort();
    path = name;
    for (size_t i = 0; i < n; ++i) {
      char leaf[48]; std::snprintf(leaf, sizeof(leaf), "/item-%05zu", i);
      int fd = ::open((path + leaf).c_str(), O_CREAT | O_EXCL | O_WRONLY, 0600);
      if (fd < 0 || ::close(fd)) std::abort();
    }
  }
  ~Directory() {
    for (size_t i = 0; i < count; ++i) {
      char leaf[48]; std::snprintf(leaf, sizeof(leaf), "/item-%05zu", i);
      if (::unlink((path + leaf).c_str())) std::abort();
    }
    if (::rmdir(path.c_str())) std::abort();
  }
};
size_t sort_checks;
void Require(bool okay, const char* label) {
  ++sort_checks;
  if (!okay) { std::fprintf(stderr, "FAIL SCANDIR_SORT %s\n", label); std::exit(1); }
}
uint64_t Key(const BionicDirent& e, Order order) {
  uint64_t x = static_cast<uint64_t>(e.d_off);
  if (order == Order::Reverse) return UINT64_MAX - x;
  if (order == Order::Nearby) return x ^ 1;
  if (order == Order::Groups) return x % 7;
  if (order == Order::Random) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; }
  return x;
}
int Value(const BionicDirent& a, const BionicDirent& b, Order order) {
  if (order == Order::Lexical) return std::strcmp(a.d_name, b.d_name);
  uint64_t x = Key(a, order), y = Key(b, order);
  return (x > y) - (x < y);
}
struct Context {
  Order order;
  size_t compared = 0;
  int last_errno = EBUSY, first_allocations = -1;
  bool deny = false, reenter = false, entered = false, change_arguments = false;
  const Directory* nested = nullptr;
};
Context* ctx;
int BIONIC_SYSV SelectEntry(const BionicDirent* e) { errno = ENOTTY; return e->d_name[0] != '.'; }
void FreeEntries(BionicDirent** list, int n) {
  for (int i = 0; i < n; ++i) std::free(list[i]);
  std::free(list);
}
int BIONIC_SYSV CompareEntry(const BionicDirent** a, const BionicDirent** b) {
  auto& c = *ctx;
  Require(errno == c.last_errno, "comparator errno chain preserved");
  if (c.first_allocations < 0) c.first_allocations = allocation_calls;
  ++c.compared;
  if (c.deny) fail_allocation = allocation_calls;
  if (c.reenter && !c.entered) {
    c.entered = true;
    bool previous = allocations_armed; allocations_armed = false;
    Context nested{Order::Reverse}; ctx = &nested;
    BionicDirent** list = nullptr; errno = EDOM;
    int n = Scandir(c.nested->path.c_str(), &list, SelectEntry, CompareEntry);
    Require(n == static_cast<int>(c.nested->count) && errno == EDOM, "real nested scan preserves its result and errno");
    for (int i = 1; i < n; ++i) Require(list[i - 1]->d_off > list[i]->d_off, "nested result order");
    FreeEntries(list, n); ctx = &c; allocations_armed = previous;
  }
  int answer = Value(**a, **b, c.order);
  if (c.change_arguments) { *a = nullptr; *b = nullptr; }
  c.last_errno = c.compared % 2 ? E2BIG : EACCES; errno = c.last_errno;
  return answer;
}
std::vector<BionicDirent> Reference(const Directory& dir, Order order) {
  std::vector<BionicDirent> result;
  DIR* d = ::opendir(dir.path.c_str()); if (!d) std::abort();
  int64_t position = 0;
  while (auto* e = ::readdir(d)) {
    ++position;
    if (e->d_name[0] == '.') continue;
    BionicDirent value{};
    value.d_ino = e->d_ino ? e->d_ino : static_cast<uint64_t>(e->d_off);
    value.d_off = position; value.d_type = e->d_type; value.d_reclen = sizeof(value);
    std::strcpy(value.d_name, e->d_name); result.push_back(value);
  }
  if (::closedir(d)) std::abort();
  std::stable_sort(result.begin(), result.end(), [order](const auto& a, const auto& b) { return Value(a, b, order) < 0; });
  return result;
}
void Verify(BionicDirent** actual, int n, const std::vector<BionicDirent>& expected) {
  Require(n == static_cast<int>(expected.size()), "complete directory count");
  for (int i = 0; i < n; ++i) {
    const auto& a = *actual[i]; const auto& e = expected[static_cast<size_t>(i)];
    Require(a.d_ino == e.d_ino && a.d_off == e.d_off && a.d_type == e.d_type &&
      a.d_reclen == e.d_reclen && std::strcmp(a.d_name, e.d_name) == 0,
      "every entry and stable tie matches independent enumeration");
  }
}
void RunCase(const Directory& dir, Order order, bool candidate, bool deny = false, bool nested = false) {
  auto expected = Reference(dir, order);
  Context c{order}; c.deny = deny; c.reenter = nested; c.nested = &dir; c.change_arguments = nested; ctx = &c;
  allocation_calls = 0; fail_allocation = -1; allocations_armed = true;
  BionicDirent** entries = nullptr; int old_closes = closes; errno = EDOM;
  int n = Scandir(dir.path.c_str(), &entries, SelectEntry, CompareEntry); int error = errno;
  allocations_armed = false; fail_allocation = -1;
  Require(error == EDOM, "caller errno restored");
  Require(closes == old_closes + (c.entered ? 2 : 1), "exact directory ownership retirement");
  Verify(entries, n, expected);
  int scratch = c.first_allocations < 0 ? 0 : allocation_calls - c.first_allocations;
  if (candidate && dir.count >= 128 && order == Order::Reverse) {
    Require(scratch == 1, "one optional scratch attempt");
    size_t levels = 0; for (size_t x = 1; x < dir.count; x *= 2) ++levels;
    if (!deny) Require(c.compared <= dir.count * (10 + levels), "bounded large-directory comparison work");
  }
  if (dir.count < 128 || order == Order::Sorted || order == Order::Nearby)
    Require(scratch == 0, "tiny and nearly sorted use no scratch");
  Require(owned_count == dir.count + (dir.count ? 1 : 0), "only caller-owned entries and array remain");
  FreeEntries(entries, n); Require(owned_count == 0, "all result allocations released");
  std::printf("SCANDIR_CASE count=%zu order=%d comparisons=%zu scratch=%d denied=%d nested=%d\n",
    dir.count, static_cast<int>(order), c.compared, scratch, deny, nested);
}
}
int main(int argc, char** argv) {
  bool candidate = argc == 2 && std::strcmp(argv[1], "--candidate") == 0;
  for (size_t n : {0U, 1U, 2U, 16U, 127U, 128U, 129U, 256U, 511U, 1024U}) {
    Directory dir(n);
    for (Order order : {Order::Sorted, Order::Reverse, Order::Nearby, Order::Random, Order::Groups, Order::Lexical})
      RunCase(dir, order, candidate);
  }
  Directory dir(256);
  RunCase(dir, Order::Reverse, candidate, true);
  RunCase(dir, Order::Groups, candidate, false, true);
  test_directory_contracts();
  for (const char* test : {"allocations", "reader", "fdopen"}) test_directory_failures(test);
  Require(failures == 0, "all original public/failure contracts pass");
  std::printf("SCANDIR_SORT_PASS checks=%zu candidate=%d complete_production_directory=true\n", sort_checks, candidate);
}
