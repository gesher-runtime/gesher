#!/usr/bin/env python3
"""Assemble the immutable measured Scandir evidence and review report."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'gesher-native-scandir-main'
DOCS = REPO / 'docs/research'
STEM = 'scandir-stable-sort-2026-11-23'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads((ROOT / p).read_text())
def prose_spacing(text):
    text = re.sub(r'\b(at|for|and|after|After|below|only|over|is|rises|with|exactly|has|within|all|All|records|passes|ran|plus|original|new|the|The|mean|seed|blocks|including)(?=\d)', r'\1 ', text)
    text = re.sub(r'(?<=[A-Za-z])(?=#\d)', ' ', text)
    text = re.sub(r'\b(GCC|Windows)(?=\d|x64|ARM64)', r'\1 ', text)
    for before, after in [('onx64', 'on x64'), ('onARM64', 'on ARM64'), ('supported64', 'supported 64'), ('temporary8N', 'temporary 8N'), ('After8N', 'After 8N'), ('after8N', 'after 8N'), ('exactly8N', 'exactly 8N'), ('adds8N', 'adds 8N'), ('one N-pointer', 'one N-pointer'), ('single-threaded', 'single-threaded'), ('original60', 'original 60'), ('Ordinary64', 'Ordinary 64'), ('32B', '32 B'), ('64B', '64 B'), ('72B', '72 B'), (' /1,440', ' / 1,440'), ('/1,680', ' / 1,680'), ('/240', ' / 240'), ('/1,440', ' / 1,440'), ('1,024 first-call', '1,024 first-call'), ('read-only', 'read-only')]:
        text = text.replace(before, after)
    return text
final = load('native-scandir-final-summary.json')
pilot = load('native-scandir-pilot-summary-recomputed.json')
composition = load('native-scandir-main297-composition.json')
production = (REPO / 'compat/bionic/posix_bionic.cc').read_bytes()
assert sha(production) == 'f19fc1689020d73f57fdc6e6cde0baeb863151dfafa405fac23b491288963a0b'
baseline = subprocess.check_output(['git', '-C', str(REPO), 'show', '7e205878cec54dbbd52bbac8a90b22e190798a5e:compat/bionic/posix_bionic.cc'])
assert sha(baseline) == 'feefc376c3f19b9fe9de0266f0a24da2ad179af0360000874235da54cd8562ab'
bindings = [
    '.github/workflows/ci.yml', 'compat/bionic/posix_bionic.cc',
    'compat/bionic/shim_internal.h', 'tests/native/directory_contract_host_test.cc.in',
    'tests/native/libc_test.c', 'tests/native/scandir_sort_bench.cc.in',
    'tests/native/scandir_sort_contract_test.inc', 'tests/native/scandir_sort_host.cc.in',
    'tools/test_scandir_sort.py', 'tools/test_scandir_report.py', 'tools/test_memrchr_report.py',
    'tools/net-tcp-priority/test-selected-policy.py',
    'tools/net-tcp-priority/test-memrchr-policy.py', 'tools/net-tcp-priority/test-scandir-policy.py',
]
bindings += ['tools/net-tcp-priority/qualified/' + name + suffix
             for name in ['scandir-source', 'memrchr-source', 'ofd-stream-source', 'shared-stdio-source']
             for suffix in ['.json', '.patch']]
sources = {path: sha((REPO / path).read_bytes()) for path in bindings}
members = {'inputs/baseline-posix.cc': baseline}
for path in bindings: members['repo/' + path] = (REPO / path).read_bytes()
for pattern in ['native*scandir*.json', 'native*scandir*.log', 'native*scandir*.py', 'native*scandir*.patch', 'media-review-scandir*.json', 'media-review-scandir*.log']:
    for path in ROOT.glob(pattern):
        if path.is_file(): members['workspace/' + path.name] = path.read_bytes()
folders = ['native-scandir-final-part1', 'native-scandir-final-part2', 'native-scandir-pilot-v1',
           'native-scandir-final-bench-baseline', 'native-scandir-final-bench-candidate',
           'native-scandir-bench-baseline', 'native-scandir-bench-candidate',
           'native-scandir-final-contracts', 'native-scandir-final-baseline', 'native-scandir-final-controls',
           'native-scandir-final-smokes', 'native-scandir-ordinary-smokes', 'native-scandir-windows',
           'native-scandir-candidate', 'native-scandir-baseline', 'native-scandir-controls', 'media-review-scandir']
allowed = {'.json', '.log', '.cc', '.c', '.h', '.py', '.su', '.d', '.txt', '.patch'}
for folder in folders:
    for path in sorted((ROOT / folder).rglob('*')):
        if path.is_file() and (path.suffix in allowed or path.name == 'scandir_bench'):
            members['workspace/' + path.relative_to(ROOT).as_posix()] = path.read_bytes()
members['workspace/native-full-file-census-20261123-2045.json'] = (ROOT / 'native-full-file-census-20261123-2045.json').read_bytes()
manifest = {'schema_version': 1, 'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}}
members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
stream = io.BytesIO()
with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, compresslevel=9) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
compressed = stream.getvalue()
archive_path = 'docs/research/data/' + STEM + '.tar.gz'
(REPO / archive_path).parent.mkdir(parents=True, exist_ok=True)
(REPO / archive_path).write_bytes(compressed)
resources = {}
for variant, label in [('baseline', 'baseline'), ('candidate', 'contracts')]:
    log = (ROOT / ('native-scandir-final-' + label + '.log')).read_text()
    resources[variant] = [{k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)} for line in log.splitlines() if line.startswith('SCANDIR_CASE ')]
stack = {'x86_64': {'ScanDirectory': [600, 664], 'Scandir': [72, 72], 'Scandirat': [72, 72]},
         'aarch64': {'ScanDirectory': [432, 464], 'Scandir': [64, 64], 'Scandirat': [64, 64]}}
report = {
    'schema_version': 1, 'date': '2026-11-23', 'scope': 'Issue56 T12: stable sorting within complete native directory scans; no broad roadmap or release-budget closure.',
    'candidate_production_sha256': sha(production), 'baseline_production_sha256': sha(baseline),
    'public_prerequisite': {'pr': 413, 'head': '7e205878cec54dbbd52bbac8a90b22e190798a5e'},
    'measured_baseline': load('native-scandir-baseline-composition.json'),
    'current_main_composition': composition,
    'archive': {'path': archive_path, 'sha256': sha(compressed), 'bytes': len(compressed), 'members': len(members)},
    'sources': sources, 'final': final, 'pilot': pilot,
    'campaigns': [
        {'name': 'final', 'raw': ['workspace/native-scandir-final-part1/results.json', 'workspace/native-scandir-final-part2/results.json'], 'summary': 'workspace/native-scandir-final-summary.json'},
        {'name': 'pilot', 'raw': ['workspace/native-scandir-pilot-v1/results.json'], 'summary': 'workspace/native-scandir-pilot-summary-recomputed.json'},
    ],
    'resources': resources, 'windows_static_frames_bytes': stack,
    'qualification': {'candidate_assertions': 198874, 'baseline_assertions': 2184791, 'compiled_specific_mutants': 9,
        'policy_original': 26, 'property_repins': 4, 'shared_stdio': 23, 'memrchr': 20, 'scandir': 26,
        'supplier': {'metadata_mutants': 36, 'authority_hash_negative': 1},
        'parent_report': {'checks': 10830, 'members': 828},
        'windows_complete_tu_compiles': load('native-scandir-windows/receipt.json'),
        'independent_source_runtime': load('media-review-scandir-adoption.json'),
        'current_main_gates': load('native-scandir-main-gates.json')},
    'acceptance': {'status': 'focused_review_only', 'universal_five_percent_budget_pass': False, 'cold_start_accepted': False,
        'material_costs': ['tiny2: all six steady paired blocks are adverse; median+11.05%/160.3ns, paired mean+6.81%.',
            'small16: median+2.23%, paired mean+20.85%; retained steady mean and p95 are also adverse.',
            'sorted1024 first median CPU+43.57%/+146.8us; no-sort4096 first+7.51%/+95.9us.',
            'All first-call p95s are retained, including tiny2 5.745us to51.237us and no-sort4096 2.998ms to5.768ms.',
            'Optional scratch adds8N transient bytes; static Windows ScanDirectory frame adds64B x64/32B ARM64.']},
    'limits': ['Real Linux host directories and complete actual production directory section; host allocator/reader fault boundaries are explicit.',
        'CPU is CLOCK_PROCESS_CPUTIME_ID for the complete single-thread scan/copy/sort/validate/free interval; filesystem construction and independent reference enumeration are outside.',
        'First means the first complete Scandir entry after filesystem setup, not whole-process startup.',
        'Native Windows full TU compilation and C public-header syntax were checked; Windows enumeration, exported guest execution, full app/ELF/runtime CI and Android supplier comparison remain pending.',
        'Scoped C allocation counters are not whole-process allocations, RSS or measured stack high-water.',
        'No timing rerun or source retuning followed the fixed final campaign. Original O2 pilot and final O3 project-shaped caller are distinct, fully retained campaigns.',
        'Six paired blocks and12 first calls per variant support the reported observations; bootstrap intervals and p95s do not prove platform-wide/no-regression acceptance.']
}
(DOCS / (STEM + '.json')).write_text(json.dumps(report, indent=2) + '\n')

def cell(case, phase, metric): return final['table'][case][phase + '_' + metric]
def num(value): return f'{value / 1000:,.3f}'
def pct(value): return f'{value:+.2f}%'
def pair(c, phase, metric, stat='median'):
    v = cell(c, phase, metric)['variants']; return num(v['baseline'][stat]) + ' → ' + num(v['candidate'][stat])
steady = ['| Case | CPU µs/call, baseline → candidate | Median CPU | Median wall | Mean CPU | CPU p95 µs/call | Paired mean CPU |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
first = ['| Case | First CPU median µs | CPU change | First CPU p95 µs | First wall median µs | Wall change | First wall p95 µs |', '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
paired = ['| Case | Six steady CPU block changes (%) | Descriptive paired mean95% interval (%) |', '| --- | --- | --- |']
pilottable = ['| Case | O2 pilot steady CPU change | O2 pilot first CPU change |', '| --- | ---: | ---: |']
for c in final['cases']:
    cpu = cell(c, 'steady', 'cpu_ns'); wall = cell(c, 'steady', 'wall_ns')
    steady.append(f"| {c} | {pair(c, 'steady', 'cpu_ns')} | {pct(cpu['delta_percent']['median'])} | {pct(wall['delta_percent']['median'])} | {pct(cpu['delta_percent']['mean'])} | {pair(c, 'steady', 'cpu_ns', 'p95')} | {pct(cpu['paired_mean_delta_percent'])} |")
    first.append(f"| {c} | {pair(c, 'first', 'cpu_ns')} | {pct(cell(c, 'first', 'cpu_ns')['delta_percent']['median'])} | {pair(c, 'first', 'cpu_ns', 'p95')} | {pair(c, 'first', 'wall_ns')} | {pct(cell(c, 'first', 'wall_ns')['delta_percent']['median'])} | {pair(c, 'first', 'wall_ns', 'p95')} |")
    paired_signs = ', '.join(format(x['delta_percent'], '+.2f') for x in cpu['paired_blocks'])
    paired.append(f"| {c} | {paired_signs} | {cpu['paired_bootstrap95_percent'][0]:+.2f} .. {cpu['paired_bootstrap95_percent'][1]:+.2f} |")
    p = pilot['table'][c];pilottable.append(f"| {c} | {pct(p['steady_cpu_ns']['delta_percent']['median'])} | {pct(p['first_cpu_ns']['delta_percent']['median'])} |")

text = f'''# Stable sorting work in complete directory scans

23 November 2026. Refs #56 T12 and #178. Depends on published [#413](https://github.com/gesher-runtime/gesher/pull/413); this does not close a broad filesystem, Android-compatibility or release-performance requirement.

## Result and material costs

The fixed final comparison covers **360 fresh processes /1,440 observations**, six ABBA blocks and15 cases. Complete scan/copy/sort/output-validation/free CPU falls **64.31% at128 reverse entries, 89.54% for1,024 random entries, 94.59–94.99% for1,024 reverse/lexical entries, 86.09% for tied keys and98.27% for4,096 reverse entries**. Every target improves in all six paired blocks. These are host component measurements, not Windows or application speedups.

**The common/control costs are part of the result.** The two-entry case is slower in all six blocks:1.451→1.611µs median CPU (**+160.3ns/+11.05%**), paired mean+6.81% (descriptive95% interval+1.83..12.67%). The16-entry case has only+2.23% marginal median, but **+20.85% paired mean**, +20.74% pooled mean and+67.76% steady CPU p95; those expensive processes are retained. Already-sorted1,024 first-call median rises336.896→483.683µs (**+146.787µs/+43.57%**). No-sort4,096 first-call median rises1,277.229→1,373.094µs (**+95.865µs/+7.51%**).

The first-call tails are not hidden behind medians: tiny2 CPU p95 is5.745→51.237µs; no-sort4,096 is2,998.212→5,768.330µs. There are only12 first calls per variant/case. All absolute CPU/wall medians, p95s, maxima and individual observations are retained. **No universal5% budget, cold-start equivalence or release acceptance is claimed.** No production tuning, replacement run or optional follow-up followed this campaign.

The implementation may allocate **one temporary8N-byte pointer array**; it retains no extra heap after sorting. At1,024 entries the measured scoped peak rises294,912→303,104B. Its compiler-reported Windows `ScanDirectory` static frame rises600→664B onx64 and432→464B onARM64. These costs accompany the CPU gains.

## Change, ownership and compatibility

The existing code used adjacent insertion sort for every accepted entry. The new53-line helper keeps that algorithm below128 entries. Larger scans also begin with insertion sort, so already/nearly-sorted lists allocate no scratch. After8N actual swaps, a stable bottom-up merge finishes the full list with one N-pointer scratch allocation. Left-on-equality selection and the already-stable insertion prefix preserve original enumeration order among equal keys, including a threshold crossing halfway through an insertion.

Every allocated directory record remains owned by the existing result array. Scratch contains borrowed pointers only, every merge pass fills its destination, odd tails are copied correctly, and a final copy-back occurs only when required. Scratch is freed before result publication. Failure of this optional allocation restores the comparator-entry errno and continues the original insertion sort; it does not add a new public ENOMEM result or retry the optional allocation. Existing count≤INT_MAX admission bounds pointer multiplication, merge widths and the post-failure swap counter on supported64-bit hosts.

The four public `scandir`/`scandir64`/`scandirat`/`scandirat64` registrations, System V callback ABI, caller errno, filter/compare ownership, output-on-error contract, partial-prefix cleanup and fd ownership remain unchanged. Comparators receive local const-pointer variables as before. Comparator invocation count/order is intentionally reduced; no exact callback trace or unsupported inconsistent-comparator behavior is promised. Nested independent scans own independent scratch. There is no new exported symbol, persistent index or lock.

## Fixed experiment and source identity

Baseline complete production SHA256: `{sha(baseline)}`. Candidate: `{sha(production)}`. The actual complete directory section is compiled into the same ordinary benchmark caller, selected through a volatile actual Scandir function pointer. Real host directories supply every inode/type/name/position; an independent real `readdir` enumeration plus stable reference sort supplies the expected result. Every timed operation checks every returned field, frees every entry/result, and each fresh process removes its owned directory before reporting completion.

CPU uses `CLOCK_PROCESS_CPUTIME_ID`; wall uses `CLOCK_MONOTONIC`. The program is single-threaded. Directory construction and independent reference enumeration precede measurement. **First-call means the first complete entry after this setup, not process startup.** The three following measured batches all remain in each process cost: sum CPU/wall intervals divided by sum calls. None is dropped as a warmup.

The written predeclaration was saved at20:38:50UTC before the first process. The two fixed three-block parts ran20:39:09.446–20:39:24.588 and20:39:24.635–20:39:40.375UTC. They preserve global blocks0–5, rotating case order, baseline/candidate/candidate/baseline order and all planned calls. Root, Java and Media confirmed no concurrent local build, replay, compression or benchmark. This coordination does not establish isolation from all system activity.

Final ordinary builds use GCC14.2, `-std=gnu++20 -O3 -DNDEBUG -fno-exceptions -fno-builtin -mno-ms-bitfields -fsized-deallocation`, with ordinary allocators and no sanitizer/counter hooks. Those optimization/project options match the inspected configuration; the host GCC binary is not the LLVM Windows product binary. Full commands, generated sources, both actual binaries and source hashes are archived.

## Complete steady results

Each variant/case has12 fresh process costs. CPU p95 here is the distribution of complete batch-average process costs, not a per-operation latency quantile. Negative changes are reductions. Mean and paired results are printed alongside medians to expose asymmetric tails.

{chr(10).join(steady)}

## All first-call results

P95 uses linear interpolation at(n−1)×0.95 over12 complete first calls per variant. These sparse descriptive tails do not establish a startup service-level bound. Individual observations and maxima remain in JSON and raw logs.

{chr(10).join(first)}

## Paired blocks and retained variability

Each block compares the arithmetic mean of its two process costs per variant. The descriptive interval resamples the six fixed block ratios10,000 times with seed178; it does not establish a universal platform or small-workload budget.

{chr(10).join(paired)}

## Actual work and scoped storage

The complete-source sanitizer fixture records62 workload rows per revision, including sorting orders,127/128/129 boundaries, uneven tails, failed scratch and nested cases. The following representative values are observed callback counts and actual delegated C allocator live-byte counters, not an algorithm-only model.

| Entries/order | Baseline comparisons | Candidate comparisons | Extra scratch bytes | Candidate peak scoped bytes |
| --- | ---: | ---: | ---: | ---: |
|128 reverse|8,128|1,496|1,024|37,888|
|129 reverse|8,256|1,504|1,032|39,200|
|1,024 sorted|1,023|1,023|0|294,912|
|1,024 nearly sorted|1,534|1,534|0|294,912|
|1,024 random|261,555|16,903|8,192|303,104|
|1,024 reverse|523,776|13,440|8,192|303,104|
|1,024 tied keys|225,789|16,480|8,192|303,104|

All124 rows are retained. Every successful optional allocation is exactly8N bytes, every completed sort retains the original live output allocation total, and every complete caller frees it to zero. Denied scratch makes exactly one attempt, preserves comparator errno and finishes through the original sort. These counters exclude unrelated C++ runtime/filesystem allocations and are not whole-process RSS. Static Windows `.su` receipts show `Scandir`/`Scandirat` wrapper frames unchanged at72B x64/64B ARM64; the inner frame increases quoted above are static compiler data, not measured peak stack usage.

## Preserved pilot

The original60-process/240-observation exploratory campaign ran19:56:47.510–19:56:49.630UTC. It used GCC14.2 O2 and shorter batches. The production source was already identical, but its caller/optimization/repetition settings differ from the final project-shaped O3 campaign. Both original generated sources and binaries, all logs and the original summary remain in the archive. The following independently recomputed pilot values are historical; the final campaign does not replace or erase them.

{chr(10).join(pilottable)}

In particular the pilot tiny2+72.64%, single+24.40% and sorted first+165.98% remain visible. No equality of O2 and O3 timing distributions is asserted.

## Correctness, source qualification and platform limits

The current production fixture passes198,874 checks under ASan/UBSan, the unchanged baseline2,184,791 checks with only new efficiency budgets disabled. The differing totals include callback-by-callback assertions; they are not distinct API cases. Both use the real complete directory implementation and real host filesystem. All existing directory contracts and original allocation/reader/closedir failure controls remain. Nine separately compiled mutations are rejected at their designated stable-order, copy-back, scratch lifetime/size/retry, errno, OOM completion, work-budget or tiny-path assertion. Independent Media replay passes the same198,874 checks and all nine mutations.

The guest C corpus exercises all four public scan symbols at127/128/129/257 entries and stable ties, errno and owned parent-fd behavior. Its new include passes C syntax checking. Complete baseline and candidate `posix_bionic.cc` TUs compile with strict shipping-shaped LLVM-MinGW flags for Windowsx64 andARM64; this is compilation evidence. **Actual Windows enumeration, guest ABI execution, full app/ELF/runtime acceptance and an Android supplier execution remain pending.** No hardware/whole-application result is inferred from these host probes.

Because this file is part of the existing OFD qualification, the new independently pinned single-file transition strictly reverses only Scandir back to published#413 before the unchanged Memrchr and OFD/shared-stdio normalization. Exact reverse and forward endpoints are checked. All six prior manifests/patches,71 original source digests and original approval predicates remain unchanged. The old Memrchr negative controls run on the strictly reconstructed predecessor;26 new controls exercise the full Scandir chain, including repinned unrelated edits. The retained Memrchr report validator first reconstructs its exact predecessor and also checks that its measured Memrchr body is unchanged; all original numeric/archive checks remain.

Current composed gates pass26 original policy controls +4 property repins +23 shared-stdio +20 Memrchr +26 Scandir, supplier36+1, the maintained vector policy and the unchanged Memrchr828-member report with10,830 checks. An initial invocation used a nonexistent vector helper filename; that command/error remains archived, and the actual maintained `tools/net-tcp-priority/test-vector-policy.py` passes. No source/gate change was made to turn that invocation error into a pass.

## Canonical current-main composition

The measured local baseline `ccd41b07…` is the exact automatic merge of public#413 `7e205878…` and main `d3076fc4…`. Main subsequently merged#297 as `910bebe1…`. Its15 paths affect epoll owner implementation/fixtures; they do not touch the measured complete posix source, directory fixtures, workflow recipe or qualification ledger.

The final local prerequisite is an independently reconstructible automatic merge with ordered parents `[7e205878cec54dbbd52bbac8a90b22e190798a5e, 910bebe1edaf105e289edd60841b8354fd847bea]`, tree `ed45f6b00f03218cb2e6a4a463656d3840118f0f`, local commit `0e440b8df14ede52dfc3bb6a99dec07fb503fb76`. All measured source/fixture bytes are preserved; complete baseline source SHA remains identical. No manual resolution, retiming or claim about newly integrated epoll runtime was introduced. The subsequent Scandir leaf adds its unconditional host and evidence gates while retaining every inherited command.

The fresh20:46:40UTC86-PR file census is archived: only dependency#413 and existing unrelated FIFO#256 touch the production file. This is overlap evidence, not an approval of those other PRs. Historical local IDs remain labeled as local; final publication separately verifies the remote trees and ordered ancestry.

## Evidence and reproduction

Archive: `{archive_path}` — SHA256 `{sha(compressed)}`, {len(compressed):,} bytes, {len(members)} regular members. Its manifest hashes every member except itself. It includes420 fresh timing processes/1,680 observations, all ordinary binaries and generated sources, full raw logs, resource/failure controls, strict Windows commands/static-frame receipts, both baseline composition proofs and independent source/runtime review. JSON contains every numeric distribution, paired block and qualification limit.

```sh
python3 tools/test_scandir_report.py
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 python3 tools/test_scandir_sort.py --sanitize --negative-controls --output-dir /tmp/scandir-current
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 python3 tools/test_scandir_sort.py --sanitize --baseline --source-ref 7e205878cec54dbbd52bbac8a90b22e190798a5e --output-dir /tmp/scandir-baseline
python3 tools/net-tcp-priority/test-selected-policy.py --selftest
python3 tools/net-tcp-priority/test-selected-supplier.py
python3 tools/net-tcp-priority/test-vector-policy.py
python3 tools/test_memrchr_report.py
```

Local LeakSanitizer alone is disabled because this executor uses ptrace; ASan/UBSan are active and the required CI invocation remains unchanged. `--build-benchmark` builds the complete ordinary caller; the archived predeclaration/driver records the fixed final schedule. Reproduction is a new observation, not a reason to discard the published cold/tiny/tail costs.
'''
text = prose_spacing(text)
(DOCS / (STEM + '.md')).write_text(text)
body = f'''Refs #56 T12 and #178. Depends on #413; no broad roadmap or release-budget closure is claimed.

## Problem and change

Scandir used adjacent insertion sort for every accepted directory, making disordered large scans quadratic. This keeps the original tiny and nearly-sorted paths, then finishes after8N swaps with a stable bottom-up merge and one optional8N-byte pointer allocation. The original entries remain owned by the result array. Scratch failure preserves errno and resumes the old stable sort; public ABI, output-on-error, cleanup and fd ownership stay unchanged.

## Complete-operation result and retained costs

The predeclared fixed360-process/1,440-observation campaign covers actual scan/copy/sort/full output validation/free. CPU improves64.31% at128 reverse entries,86.09–94.99% for1,024 disordered/tied entries and98.27% for4,096 reverse entries, in every paired block. All60 earlier O2 pilot processes/240 observations remain; final ordinary GCC14.2 O3 flags and longer fixed batches are separately documented.

**Material costs remain:** tiny2 is slower in all six blocks (+160.3ns/+11.05% median; paired mean+6.81%). Small16 paired mean is+20.85% despite its+2.23% marginal median. Sorted1,024 first CPU is+146.8µs/+43.57%; no-sort4,096 first+95.9µs/+7.51%. All first/steady p95s and maxima remain, including tiny first CPU p955.745→51.237µs and no-sort2.998→5.768ms. There is no universal5%, cold-start or Windows performance acceptance claim.

Scratch adds8N transient bytes (8,192B at1,024 entries), zero retained heap after sorting. Windows compiler static inner frames add64B x64/32B ARM64. Detailed absolute tables, all raw observations and limits: [report](docs/research/{STEM}.md), [machine-readable evidence](docs/research/{STEM}.json).

## Validation and integration

- Complete actual production directory section:198,874 candidate and2,184,791 baseline sanitizer checks, with nine assertion-specific compiled mutations. Independent replay confirms the candidate and all mutations.
- Real caller/allocator/error/tie/nested/127–129 boundaries; four exported guest scan variants added to the existing C contract entry. Full posix TU strict Windowsx64/ARM64 compilation passes; actual Windows/guest/app execution remains full CI work.
- Exact current→published#413→original OFD/shared-stdio source chain, preserving all original receipts/approval predicates;26 new repinning controls. Selected/supplier/vector and unchanged Memrchr evidence gates pass.
- Canonical prerequisite tree `ed45f6b0` has ordered parents public#413 `7e205878` and current main `910bebe1`; all measured inputs remain identical. Current main’s epoll change is retained without manual resolution or retiming.

The required workflow adds unconditional Scandir runtime and archived-evidence checks, with no gate or deadline relaxation. Archive SHA256 `{sha(compressed)}` preserves all {len(members)} regular members. Full manual CI will be linked for the exact published head; local compilation is not a Windows runtime result.
'''
(ROOT / 'native-scandir-PR_BODY.md').write_text(prose_spacing(body))
print(json.dumps({'archive': archive_path, 'archive_sha256': sha(compressed), 'archive_bytes': len(compressed), 'members': len(members), 'report_bytes': len(text.encode()), 'json_bytes': (DOCS / (STEM + '.json')).stat().st_size, 'sources': len(sources)}))
