#!/usr/bin/env python3
"""Fixed whole-scandir ABBA campaign; keeps every first/steady observation."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CASES = ('empty', 'single', 'tiny2', 'small16', 'floor127', 'floor128', 'sorted1024',
         'nearby1024', 'random1024', 'reverse1024', 'lexical1024', 'ties1024',
         'reverse4096', 'nosort4096', 'filtered4096')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--rounds', type=int, default=1)
    p.add_argument('--round-start', type=int, default=0)
    p.add_argument('--baseline-dir', type=Path, default=ROOT / 'native-scandir-bench-baseline')
    p.add_argument('--candidate-dir', type=Path, default=ROOT / 'native-scandir-bench-candidate')
    args = p.parse_args()
    assert args.rounds > 0 and args.round_start >= 0
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    variants = {}
    for variant in ('baseline', 'candidate'):
        folder = (args.baseline_dir if variant == 'baseline' else args.candidate_dir).resolve()
        receipt = json.loads((folder / 'source.json').read_text())
        binary = folder / 'scandir_bench'
        assert hashlib.sha256(binary.read_bytes()).hexdigest() == receipt['binary_sha256']
        variants[variant] = {'binary': str(binary), 'receipt': receipt}
    assert variants['baseline']['receipt']['template_sha256'] == variants['candidate']['receipt']['template_sha256']
    assert hashlib.sha256((ROOT / 'gesher-native-scandir/compat/bionic/posix_bionic.cc').read_bytes()).hexdigest() == variants['candidate']['receipt']['production_sha256']
    data = {'start_utc': now(), 'rounds': args.rounds, 'round_start': args.round_start, 'cases': CASES, 'variants': variants,
            'scope': 'Complete actual scan/copy/sort/full entry validation/free, ordinary allocators; real directory construction and independent enumeration outside measured intervals.',
            'processes': []}
    index = out / 'results.json'
    index.write_text(json.dumps(data, indent=2) + '\n')
    for round_number in range(args.round_start, args.round_start + args.rounds):
        cases = CASES[round_number % len(CASES):] + CASES[:round_number % len(CASES)]
        for case in cases:
            for position, variant in enumerate(('baseline', 'candidate', 'candidate', 'baseline')):
                label = f'{len(data["processes"]):04d}-{case}-{variant}'
                started = now()
                run = subprocess.run([variants[variant]['binary'], case], capture_output=True, text=True, timeout=60)
                log = run.stdout + run.stderr
                (out / (label + '.log')).write_text(log)
                rows = [json.loads(line) for line in run.stdout.splitlines() if line.startswith('{')]
                assert run.returncode == 0 and len(rows) == 4 and 'SCANDIR_BENCH_COMPLETE owned_directory_removed=true' in run.stdout, (label, log[-4000:])
                assert [r['sample'] for r in rows] == list(range(4))
                assert all(r['case'] == case and r['complete_output'] and r['calls'] > 0 and r['cpu_ns'] > 0 and r['wall_ns'] > 0 for r in rows)
                record = {'round': round_number, 'position': position, 'variant': variant, 'case': case,
                          'start_utc': started, 'end_utc': now(), 'rows': rows, 'returncode': run.returncode,
                          'log': label + '.log', 'log_sha256': hashlib.sha256(log.encode()).hexdigest()}
                data['processes'].append(record)
                index.write_text(json.dumps(data, indent=2) + '\n')
        print('SCANDIR_ABBA_ROUND', round_number, 'processes', len(data['processes']), flush=True)
    for variant in variants:
        assert hashlib.sha256(Path(variants[variant]['binary']).read_bytes()).hexdigest() == variants[variant]['receipt']['binary_sha256']
    data['end_utc'] = now()
    index.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'start': data['start_utc'], 'end': data['end_utc'], 'processes': len(data['processes']), 'rows': sum(len(p['rows']) for p in data['processes'])}))


if __name__ == '__main__':
    main()
