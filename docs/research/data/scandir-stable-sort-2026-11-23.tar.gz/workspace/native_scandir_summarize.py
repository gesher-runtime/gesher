#!/usr/bin/env python3
"""Verify every fixed Scandir receipt and summarize all process observations."""
import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import random
import statistics

def sha(data):
    return hashlib.sha256(data).hexdigest()

def percentile(values, probability):
    ordered = sorted(values)
    point = (len(ordered) - 1) * probability
    lo = int(point)
    hi = min(lo + 1, len(ordered) - 1)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (point - lo)

def summarize(campaigns):
    records = []
    variants = None
    checks = 0
    def require(value, message):
        nonlocal checks
        checks += 1
        if not value:
            raise AssertionError(message)
    for directory in campaigns:
        raw = json.loads((directory / 'results.json').read_text())
        require('end_utc' in raw, 'Incomplete campaign')
        if variants is None:
            variants = raw['variants']
        else:
            require(variants == raw['variants'], 'Changed binary or source between blocks')
        for p in raw['processes']:
            log = (directory / p['log']).read_bytes()
            require(sha(log) == p['log_sha256'], 'Changed stdout/stderr')
            parsed = [json.loads(x) for x in log.decode().splitlines() if x.startswith('{')]
            require(parsed == p['rows'], 'Raw rows differ from log')
            require(p['returncode'] == 0 and b'SCANDIR_BENCH_COMPLETE owned_directory_removed=true' in log, 'Missing complete retirement')
            require([x['sample'] for x in p['rows']] == [0, 1, 2, 3], 'Missing first or steady observation')
            require(all(x['complete_output'] and x['cpu_ns'] > 0 and x['wall_ns'] > 0 and x['calls'] > 0 and x['case'] == p['case'] for x in p['rows']), 'Invalid complete-call receipt')
            records.append(p)
        require(len(raw['processes']) == raw['rounds'] * len(raw['cases']) * 4, 'Incomplete fixed process plan')
    rounds = sorted({p['round'] for p in records})
    cases = list(raw['cases'])
    require(Counter((p['round'], p['case'], p['position']) for p in records) == Counter(itertools.product(rounds, cases, range(4))), 'Missing or duplicate fixed position')
    require(all(p['variant'] == ('baseline', 'candidate', 'candidate', 'baseline')[p['position']] for p in records), 'Changed ABBA order')
    for variant, metadata in variants.items():
        require(sha(Path(metadata['binary']).read_bytes()) == metadata['receipt']['binary_sha256'], 'Changed measured binary')
    require(variants['baseline']['receipt']['template_sha256'] == variants['candidate']['receipt']['template_sha256'], 'Different common caller')
    def value(record, metric, phase):
        rows = record['rows'][:1] if phase == 'first' else record['rows'][1:]
        return sum(x[metric] for x in rows) / sum(x['calls'] for x in rows)
    table = {}
    for case in cases:
        row = {}
        for phase, metric in itertools.product(('first', 'steady'), ('cpu_ns', 'wall_ns')):
            samples = {v: [value(p, metric, phase) for p in records if p['case'] == case and p['variant'] == v] for v in ('baseline', 'candidate')}
            distribution = {v: {'n': len(x), 'median': statistics.median(x), 'mean': statistics.mean(x), 'p95': percentile(x, .95), 'min': min(x), 'max': max(x), 'values': x} for v, x in samples.items()}
            deltas = {stat: 100 * (distribution['candidate'][stat] / distribution['baseline'][stat] - 1) for stat in ('median', 'mean', 'p95')}
            paired = []
            for block in rounds:
                vals = {v: statistics.mean(value(p, metric, phase) for p in records if p['case'] == case and p['round'] == block and p['variant'] == v) for v in samples}
                paired.append({'block': block, **vals, 'delta_percent': 100 * (vals['candidate'] / vals['baseline'] - 1)})
            paired_deltas = [p['delta_percent'] for p in paired]
            rng = random.Random(178)
            boots = [statistics.mean(rng.choices(paired_deltas, k=len(rounds))) for _ in range(10000)]
            row[f'{phase}_{metric}'] = {'variants': distribution, 'delta_percent': deltas, 'paired_blocks': paired, 'paired_mean_delta_percent': statistics.mean(paired_deltas), 'paired_bootstrap95_percent': [percentile(boots, .025), percentile(boots, .975)], 'bootstrap_limit': 'Descriptive resampling of the fixed block ratios; six blocks do not establish platform-wide or startup-tail equivalence.'}
        table[case] = row
    return {'processes': len(records), 'observations': sum(len(p['rows']) for p in records), 'rounds': rounds, 'cases': cases, 'variants': variants, 'checks': checks, 'campaigns': [str(p) for p in campaigns], 'table': table, 'method': 'Sum all three steady intervals and divide by all calls for each process; summarize all independent process values. First call is retained separately. P95 uses linear interpolation at (n-1)*0.95. Each ABBA block compares the arithmetic mean of its two processes per variant. No discarded observation or replacement.'}

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--campaign', action='append', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = summarize(args.campaign)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    for case, row in result['table'].items():
        x = row['steady_cpu_ns']; first = row['first_cpu_ns']
        print(json.dumps({'case': case, 'steady_cpu_percent': x['delta_percent']['median'], 'steady_pair_mean': x['paired_mean_delta_percent'], 'steady_pair_CI': x['paired_bootstrap95_percent'], 'paired_signs': [round(p['delta_percent'], 3) for p in x['paired_blocks']], 'first_cpu_percent': first['delta_percent']['median'], 'first_p95_cpu_percent': first['delta_percent']['p95']}))
    print('SCANDIR_EVIDENCE_CHECKS', result['checks'], 'PROCESSES', result['processes'], 'ROWS', result['observations'])
