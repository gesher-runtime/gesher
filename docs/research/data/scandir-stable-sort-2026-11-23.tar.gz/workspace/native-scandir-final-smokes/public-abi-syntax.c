#define _GNU_SOURCE
#include <stdio.h>
static void check(const char* label, int okay) { (void)label; (void)okay; }
#include "directory_contract_test.inc"
#include "scandir_sort_contract_test.inc"
int main(void) { test_directory_contracts(); test_scandir_sort_contracts(); return 0; }
