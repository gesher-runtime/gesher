#define HAS_PENDING_WRITE 1
// Complete actual Track methods, ring, conversion and resampler are supplied by
// the maintained audio-state generator. Engine attachment, clock transport and
// CV scheduling are explicit host boundaries; no WASAPI or JNI VM runs here.
#include <pthread.h>
#include <array>
#include <bit>
#include <cstdlib>
#include <limits>

// Production source SHA256: 64d1afab25dada14b00fa011a68fc9a04a7fdb9aa72f17353b75bb83f4557c95
// Engine attachment/output clock and CV scheduling boundaries; all Track methods are production.
#include <sys/types.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include <time.h>

// Clock transport for the Linux lifecycle fixture. Suspend semantics are
// exercised with the actual adapter in tools/test_clock_domains.py.
namespace gesher {
// The unity-rate transcript advances this by one nominal period per mix.
// Lifecycle checks leave it disabled and use the host clock.
inline thread_local int64_t fixture_playback_ns = -1;
inline int AndroidClockGettime(clockid_t clock, timespec* value) {
  if (clock == CLOCK_MONOTONIC && fixture_playback_ns >= 0) {
    value->tv_sec = fixture_playback_ns / 1000000000;
    value->tv_nsec = fixture_playback_ns % 1000000000;
    return 0;
  }
  return clock_gettime(clock, value);
}
inline int64_t MonotonicNanos() {
  timespec value;
  clock_gettime(CLOCK_MONOTONIC, &value);
  return static_cast<int64_t>(value.tv_sec) * 1000000000 + value.tv_nsec;
}
}

class ObservedConditionVariable {
 public:
  std::atomic<unsigned> waits{0};
  std::function<void()> before_reacquire;
  void notify_all() { cv_.notify_all(); }
  void wait(std::unique_lock<std::mutex>& lock) {
    ++waits;
    if (Hook(lock)) return;
    cv_.wait(lock);
  }
  template<class Rep, class Period>
  std::cv_status wait_for(std::unique_lock<std::mutex>& lock,
                          const std::chrono::duration<Rep, Period>& duration) {
    ++waits;
    if (Hook(lock)) return std::cv_status::no_timeout;
    return cv_.wait_for(lock, duration);
  }
  template<class Rep, class Period, class Predicate>
  bool wait_for(std::unique_lock<std::mutex>& lock,
                const std::chrono::duration<Rep, Period>& duration, Predicate predicate) {
    return cv_.wait_for(lock, duration, predicate);
  }
 private:
  bool Hook(std::unique_lock<std::mutex>& lock) {
    if (!before_reacquire) return false;
    auto hook = std::move(before_reacquire);
    lock.unlock();
    hook();
    lock.lock();
    return true;
  }
  std::condition_variable cv_;
};

// Gesher: the audio output of an app process (docs/media.md, ADR 0042).
//
// Every sound an app makes (AudioTrack, MediaPlayer, SoundPool, AAudio,
// OpenSL ES) is a Track of this process's Engine. The engine's thread mixes
// the tracks at the output's rate, one mix per Android stream volume group
// (media, ring, alarm, notification, call), and hands the mixes to the sink:
//
//  - WASAPI, shared mode: one render stream per group in use, each its own
//    Windows audio session ("<app> (Alarm)"), whose volume is the Android
//    stream volume of the group (shared_state.h; the Windows volume mixer
//    changes it back);
//  - a capture file (GESHER_AUDIO_CAPTURE): the groups mixed into one WAV,
//    paced by the clock as a device would be, with the stream volumes
//    applied in software (what the volume mixer would do), for tests on
//    machines without an audio endpoint;
//  - nothing, paced by the clock, when no endpoint opens (or GESHER_AUDIO=null).
//
// Tracks are format-converted (8/16/24/32-bit PCM, float), resampled from any
// rate (windowed sinc), channel-mapped to the output and mixed in float.
// Nothing here knows Java: the JNI layers sit on top (compat/media/jni).


#include <sys/types.h>

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace gesher::media {

// AudioDeviceInfo and the native routing getters use the same process-local IDs.
constexpr int kOutputDeviceId = 2;
constexpr int kInputDeviceId = 3;

enum class PcmFormat : int { kU8, kS16, kS24Packed, kS32, kFloat };

size_t BytesPerSample(PcmFormat f);

// Android's stream types (AudioSystem.STREAM_*) and their volume groups:
// a stream plays at the volume of its alias (AudioService's
// STREAM_VOLUME_ALIAS_DEFAULT on a phone).
constexpr int kNumStreamTypes = 12;  // STREAM_VOICE_CALL (0) .. STREAM_ASSISTANT (11)
int StreamAlias(int stream);
// The volume groups, by alias: the streams that alias to themselves.
constexpr int kNumGroups = 5;
int GroupOfStream(int stream);       // 0..kNumGroups-1
int StreamOfGroup(int group);        // the alias stream of a group
const char* GroupName(int group);    // "Media", "Ringtone", ...

// Status codes, as Android's (AudioSystem.SUCCESS, ERROR, BAD_VALUE, ...).
constexpr int kOk = 0;
constexpr int kError = -1;
constexpr int kBadValue = -2;
constexpr int kInvalidOperation = -3;
constexpr int kWouldBlock = -7;

struct TrackParams {
  uint32_t sample_rate = 48000;
  uint32_t channels = 2;
  PcmFormat format = PcmFormat::kS16;
  int stream_type = 3;          // STREAM_MUSIC
  size_t capacity_frames = 0;   // the stream's buffer, or the static buffer's size
  bool is_static = false;
  int session_id = 0;
  std::string name;             // for logs
};

// What a track tells its owner; called on the engine's event thread (never
// the mixing thread), in order.
struct TrackEvents {
  std::function<void(uint32_t position)> marker;        // the marker was played
  std::function<void(uint32_t position)> new_position;  // one more update period
  std::function<void()> end;                            // the data ran out (static end, stop drained)
  std::function<void()> underrun;                       // streaming, playing, no data
};

class Engine;

class Track : public std::enable_shared_from_this<Track> {
 public:
  enum class State { kStopped, kPlaying, kStopping, kPaused };

  ~Track();

  const TrackParams& params() const { return params_; }
  size_t frame_size() const { return frame_size_; }

  void SetEvents(TrackEvents events);

  // Playback control, as android::AudioTrack's.
  int Start();
  void Pause();
  // Streaming: drains the data present at stop; later writes prime the next start.
  // Static: stops at once and rewinds.
  void Stop();
  // Streaming, stopped or paused: drops what was not played; position 0.
  void Flush();
  State state() const;
  bool stopped() const;  // stopped, or stopping and drained

  // Streaming: copies up to `bytes` (whole frames) into the buffer; with
  // `blocking`, waits for room until everything is written or the track is
  // stopped, paused or released. Returns the bytes written or an error.
  // Static: writes at the start of the static buffer (data loaded so far).
  ssize_t Write(const void* data, size_t bytes, bool blocking);

  // Static tracks.
  int SetLoop(uint32_t start, uint32_t end, int count);  // count -1: forever
  int Reload();                                          // rewind to 0
  int SetPosition(uint32_t frame);                       // stopped or paused only
  size_t static_frames() const;

  // Position: frames played since the start (uint32 wraps, as Android's).
  uint32_t Position() const;
  // Frames presented and the CLOCK_MONOTONIC time of that, for getTimestamp.
  bool Timestamp(int64_t* frames, int64_t* time_ns) const;
  int SetMarker(uint32_t frame);
  uint32_t marker() const;
  int SetUpdatePeriod(uint32_t frames);
  uint32_t update_period() const;

  void SetVolume(float left, float right);
  // The playback rate in Hz (setPlaybackRate) and speed (PlaybackParams);
  // pitch follows the speed (no time stretching).
  int SetSampleRate(uint32_t rate);
  uint32_t sample_rate() const;
  void SetSpeed(float speed);
  float speed() const;

  uint32_t buffer_capacity_frames() const { return static_cast<uint32_t>(params_.capacity_frames); }
  uint32_t buffer_size_frames() const;
  int SetBufferSizeFrames(uint32_t frames);
  uint32_t underrun_frames() const;
  // Cumulative transitions into underrun, distinct from the frames missing.
  uint32_t underrun_count() const;
  uint32_t LatencyMs() const;

  // Streaming: frames written and not yet played.
  size_t Queued() const;
  // Waits until rames frames fit in the buffer (signalled by the mixer as it
  // plays, not polled), at most timeout_ms; true if they fit. A feeder that
  // sleeps instead wakes late under load (Windows' 15.6 ms timer ticks) and lets
  // a small buffer run dry.
  bool WaitForRoom(size_t frames, int timeout_ms);

  // Detaches the track from the engine; blocked writers return.
  void Release();

 public:
  friend class Engine;
  friend std::shared_ptr<Track> CreateTrack(const TrackParams&, std::string*);
  Track(Engine* engine, const TrackParams& params);

  // Mixing thread: adds up to `frames` output frames at `out_rate` with
  // `out_channels` into `mix` (already scaled by the track's volume).
  // Returns false when the track has nothing to play.
  bool MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels);
  // Reads up to `frames` source frames as float (the track's channels).
  size_t ReadSource(float* dst, size_t frames, bool* ended);
  // Copies only available ring capacity; both callers hold mu_.
  size_t CopyToRing(const uint8_t* source, size_t frames);
  void QueueEvents(uint64_t before, uint64_t after);

  Engine* engine_;
  TrackParams params_;
  size_t frame_size_;

  mutable std::mutex mu_;
  ObservedConditionVariable room_;  // signalled as frames are played, and on state changes
  State state_ = State::kStopped;
  bool released_ = false;
  bool drained_ = false;  // kStopping: all played
  // A writer must observe pause/stop even if start() runs before it reacquires mu_.
  uint64_t write_interrupt_ = 0;
  // Borrowed only while a blocking Write is waiting with its input still alive.
  struct PendingWrite;
  PendingWrite* pending_write_head_ = nullptr;
  PendingWrite* pending_write_tail_ = nullptr;

  // Streaming ring, or static data.
  std::vector<uint8_t> data_;
  uint64_t written_ = 0;      // streaming: frames ever written
  uint64_t read_ = 0;         // streaming: frames ever taken by the resampler
  uint64_t stop_end_ = 0;     // kStopping: frozen source limit for this drain
  size_t buffer_frames_ = 0;  // streaming: setBufferSizeInFrames' limit
  size_t static_frames_ = 0;  // static: frames loaded
  size_t static_pos_ = 0;     // static: next frame to take
  uint32_t loop_start_ = 0, loop_end_ = 0;
  int loop_count_ = 0;

  // Played position (source frames), as the resampler passes them.
  uint64_t played_ = 0;
  uint64_t position_base_ = 0;  // subtracted from played_ for Position()
  int64_t played_time_ns_ = 0;
  uint32_t marker_ = 0;
  bool marker_reached_ = false;
  uint32_t update_period_ = 0;
  uint64_t next_update_ = 0;
  uint32_t underrun_frames_ = 0;
  uint32_t underrun_count_ = 0;
  bool was_underrun_ = false;
  bool end_signalled_ = false;
  int64_t starved_since_ns_ = -1;

  float vol_left_ = 1.0f, vol_right_ = 1.0f;
  float applied_left_ = 1.0f, applied_right_ = 1.0f;  // ramps toward vol_*
  uint32_t rate_;
  float speed_ = 1.0f;

  TrackEvents events_;
  struct Resampler;
  std::unique_ptr<Resampler> rs_;
};

std::shared_ptr<Track> CreateTrack(const TrackParams& params, std::string* error);

// The engine's output, for AudioSystem's answers.
struct OutputInfo {
  uint32_t sample_rate;
  uint32_t channels;
  uint32_t period_frames;   // the mixer's period
  uint32_t latency_frames;  // what the sink holds
  std::string description;  // "WASAPI shared mode, ...", "capture to ...", "none: ..."
  std::string device_name;  // the endpoint's friendly name
  int device_type;          // AUDIO_DEVICE_OUT_* of the endpoint's form factor
  uint32_t generation;      // changes when the output does
};
OutputInfo GetOutputInfo();

// Raises the calling thread's priority for audio work that feeds the engine
// (Android runs such threads at ANDROID_PRIORITY_AUDIO or SCHED_FIFO):
// `urgent` (an app's callback, a buffer queue's feeder) is
// THREAD_PRIORITY_HIGHEST, else (a player's decoder) ABOVE_NORMAL. Under load
// a normal-priority feeder may not run before the engine's time-critical
// mixer has played what the track holds.
void RaiseAudioThreadPriority(bool urgent);

// Runs `fn` on the engine's event thread (after earlier events).
void PostEvent(std::function<void()> fn);

// Streams with a track playing now (or within the last `in_past_ms`), on this
// device (every process; shared_state.h).
bool IsStreamActive(int stream, int in_past_ms);

// The process's application name for the Windows audio sessions
// ("<label> (Media)"); set by the JNI layer when it knows it.
void SetAppName(const std::u16string& name);

}  // namespace gesher::media

namespace gesher::media {

size_t BytesPerSample(PcmFormat f) {
  switch (f) {
    case PcmFormat::kU8: return 1;
    case PcmFormat::kS16: return 2;
    case PcmFormat::kS24Packed: return 3;
    case PcmFormat::kS32: return 4;
    case PcmFormat::kFloat: return 4;
  }
  return 2;
}

// --- Stream volume groups ----------------------------------------------------------------

namespace {

// STREAM_VOICE_CALL 0, SYSTEM 1, RING 2, MUSIC 3, ALARM 4, NOTIFICATION 5,
// BLUETOOTH_SCO 6, SYSTEM_ENFORCED 7, DTMF 8, TTS 9, ACCESSIBILITY 10, ASSISTANT 11:
// AudioService's STREAM_VOLUME_ALIAS_DEFAULT.
constexpr int kAlias[kNumStreamTypes] = {0, 2, 2, 3, 4, 5, 0, 2, 2, 3, 3, 3};
constexpr int kGroupStream[kNumGroups] = {3, 2, 4, 5, 0};
constexpr const char* kGroupName[kNumGroups] = {"Media", "Ringtone", "Alarm", "Notifications",
                                                "Calls"};

int64_t MonotonicNs() {
  timespec ts;
  gesher::AndroidClockGettime(CLOCK_MONOTONIC, &ts);
  return static_cast<int64_t>(ts.tv_sec) * 1000000000 + ts.tv_nsec;
}

}  // namespace

int StreamAlias(int stream) {
  return stream >= 0 && stream < kNumStreamTypes ? kAlias[stream] : 3;
}

int GroupOfStream(int stream) {
  int a = StreamAlias(stream);
  for (int g = 0; g < kNumGroups; g++) {
    if (kGroupStream[g] == a) return g;
  }
  return 0;
}

int StreamOfGroup(int group) { return group >= 0 && group < kNumGroups ? kGroupStream[group] : 3; }

const char* GroupName(int group) {
  return group >= 0 && group < kNumGroups ? kGroupName[group] : "Media";
}

// --- The resampler -----------------------------------------------------------------------

namespace {

// A windowed sinc (Blackman-Harris) of kHalfTaps zero crossings each side,
// tabulated at kTableRes points per zero crossing.
constexpr int kHalfTaps = 12;
constexpr int kTableRes = 512;

const float* KernelTable() {
  static const std::vector<float> table = [] {
    std::vector<float> t(kHalfTaps * kTableRes + 2);
    for (size_t i = 0; i < t.size(); i++) {
      double x = static_cast<double>(i) / kTableRes;
      if (x >= kHalfTaps) {
        t[i] = 0;
        continue;
      }
      double sinc = x == 0 ? 1.0 : std::sin(M_PI * x) / (M_PI * x);
      double n = 0.5 + x / (2.0 * kHalfTaps);  // window over [-H, H] mapped to [0, 1]
      double w = 0.35875 - 0.48829 * std::cos(2 * M_PI * n) + 0.14128 * std::cos(4 * M_PI * n) -
                 0.01168 * std::cos(6 * M_PI * n);
      t[i] = static_cast<float>(sinc * w);
    }
    return t;
  }();
  return table.data();
}

inline float Kernel(const float* table, double x) {
  x = std::fabs(x);
  if (x >= kHalfTaps) return 0;
  double p = x * kTableRes;
  size_t i = static_cast<size_t>(p);
  float f = static_cast<float>(p - static_cast<double>(i));
  return table[i] + (table[i + 1] - table[i]) * f;
}

// Converts `frames` frames of `fmt` to float.
void ToFloat(const uint8_t* src, PcmFormat fmt, size_t samples, float* dst) {
  switch (fmt) {
    case PcmFormat::kU8:
      for (size_t i = 0; i < samples; i++) dst[i] = (static_cast<int>(src[i]) - 128) / 128.0f;
      break;
    case PcmFormat::kS16: {
      for (size_t i = 0; i < samples; i++) {
        int16_t v;
        memcpy(&v, src + 2 * i, 2);
        dst[i] = v / 32768.0f;
      }
      break;
    }
    case PcmFormat::kS24Packed:
      for (size_t i = 0; i < samples; i++) {
        const uint8_t* p = src + 3 * i;
        int32_t v = static_cast<int32_t>((static_cast<uint32_t>(p[0]) << 8) |
                                         (static_cast<uint32_t>(p[1]) << 16) |
                                         (static_cast<uint32_t>(p[2]) << 24)) >> 8;
        dst[i] = v / 8388608.0f;
      }
      break;
    case PcmFormat::kS32:
      for (size_t i = 0; i < samples; i++) {
        int32_t v;
        memcpy(&v, src + 4 * i, 4);
        dst[i] = static_cast<float>(v / 2147483648.0);
      }
      break;
    case PcmFormat::kFloat:
      memcpy(dst, src, samples * 4);
      break;
  }
}

}  // namespace

// Source frames (float, the track's channels) in, output frames out. The
// history starts with kHalfTaps-ish zeros, so the first output frame is
// centered on the first source frame.
struct Track::Resampler {
  explicit Resampler(uint32_t ch) : channels(ch) { Reset(); }

  void Reset() {
    hist.clear();
    width = 0;
    t = 0;
    start_index = 0;
    primed = false;
    real_end = -1;
    played_index = 0;
  }

  uint32_t channels;
  std::vector<float> hist;  // interleaved; hist frame 0 is source frame start_index
  // Mixing scratch belongs to this track and is protected by Track::mu_. Keep
  // its capacity through Reset() so each 10 ms block does not allocate again.
  std::vector<float> frame;
  std::vector<float> source;
  size_t width;             // half-width in source frames of the current filter
  double t;                 // the next output frame's center, in hist frames
  int64_t start_index;      // source index of hist frame 0 (negative while primed zeros)
  bool primed;
  int64_t real_end = -1;    // source index one past the last real frame, once ended
  int64_t played_index = 0; // source frames passed since the last Reset
  size_t frames() const { return hist.size() / channels; }
};


// The mixer is driven explicitly by the test, with no OS endpoint or background thread.
class Engine {
 public:
  void Remove(Track*) {}
  uint32_t out_rate() const { return 48000; }
  uint32_t latency_frames() const { return 0; }
};
void PostEvent(std::function<void()> event) { event(); }
Track::Track(Engine* engine, const TrackParams& params)
    : engine_(engine),
      params_(params),
      frame_size_(BytesPerSample(params.format) * params.channels),
      rate_(params.sample_rate),
      rs_(std::make_unique<Resampler>(params.channels)) {
  data_.resize(params.capacity_frames * frame_size_);
  buffer_frames_ = params.capacity_frames;
}

Track::~Track() = default;

void Track::SetEvents(TrackEvents events) {
  std::lock_guard<std::mutex> lock(mu_);
  events_ = std::move(events);
}

int Track::Start() {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (state_ == State::kPlaying) return kOk;
  if (state_ == State::kStopped || (state_ == State::kStopping && drained_)) {
    // As android::AudioTrack::start: from stopped, the position starts at 0.
    position_base_ = played_;
    next_update_ = update_period_;
    marker_reached_ = false;
    if (params_.is_static && state_ == State::kStopped) {
      // A stopped static track was rewound by stop().
    }
    rs_->Reset();
  }
  if (!params_.is_static && rs_->real_end >= 0) {
    // A draining resampler may have padded its right edge with silence. Resume
    // from its real history and phase, allowing newly primed frames past that
    // edge, including when pause() interrupted the drain before this start().
    size_t real_frames = static_cast<size_t>(
        std::max<int64_t>(0, rs_->real_end - rs_->start_index));
    rs_->hist.resize(std::min(real_frames, rs_->frames()) * rs_->channels);
    rs_->real_end = -1;
  }
  state_ = State::kPlaying;
  drained_ = false;
  was_underrun_ = false;
  end_signalled_ = false;
  room_.notify_all();
  return kOk;
}

void Track::Pause() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ == State::kPlaying || state_ == State::kStopping) {
    state_ = State::kPaused;
    ++write_interrupt_;
  }
  room_.notify_all();
}

void Track::Stop() {
  std::lock_guard<std::mutex> lock(mu_);
  if (state_ != State::kPlaying && state_ != State::kPaused) return;
  ++write_interrupt_;
  if (params_.is_static) {
    state_ = State::kStopped;
    static_pos_ = 0;
    loop_start_ = loop_end_ = 0;
    loop_count_ = 0;
    position_base_ = played_;  // position 0
    rs_->Reset();
  } else if (state_ == State::kPlaying) {
    state_ = State::kStopping;
    stop_end_ = written_;
    drained_ = stop_end_ == read_ && rs_->frames() == 0;
    if (drained_) state_ = State::kStopped;
  } else if (state_ == State::kPaused) {
    // Paused data is dropped at stop (android::AudioTrack: stop from paused
    // flushes what was not played).
    state_ = State::kStopped;
    read_ = written_;
    stop_end_ = read_;
    rs_->Reset();
  }
  room_.notify_all();
}

void Track::Flush() {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static || state_ == State::kPlaying) return;
  read_ = written_;
  stop_end_ = read_;
  rs_->Reset();
  position_base_ = played_;
  marker_ = 0;
  marker_reached_ = false;
  update_period_ = 0;
  next_update_ = 0;
  if (state_ == State::kStopping) state_ = State::kStopped;
  room_.notify_all();
}

Track::State Track::state() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_;
}

bool Track::stopped() const {
  std::lock_guard<std::mutex> lock(mu_);
  return state_ == State::kStopped || (state_ == State::kStopping && drained_);
}

// A blocking caller retains its input until Write returns. Register only the
// remainder waiting for ring space, so a large mix can refill without waiting
// for that caller to reacquire the mutex the mixer itself holds. All links and
// progress are protected by mu_; the wait reacquires it before scope cleanup.
struct Track::PendingWrite {
  PendingWrite(Track& track, const uint8_t* data, size_t frames, uint64_t interrupt)
      : owner(&track), previous(track.pending_write_tail_), data(data), frames(frames),
        interrupt(interrupt) {
    if (previous != nullptr) previous->next = this;
    else track.pending_write_head_ = this;
    track.pending_write_tail_ = this;
  }
  ~PendingWrite() { Unlink(); }
  PendingWrite(const PendingWrite&) = delete;
  PendingWrite& operator=(const PendingWrite&) = delete;

  void Unlink() {
    if (owner == nullptr) return;
    if (previous != nullptr) previous->next = next;
    else owner->pending_write_head_ = next;
    if (next != nullptr) next->previous = previous;
    else owner->pending_write_tail_ = previous;
    owner = nullptr;
  }

  Track* owner;
  PendingWrite* previous;
  PendingWrite* next = nullptr;
  const uint8_t* data;
  size_t frames;
  size_t committed = 0;
  uint64_t interrupt;
};

size_t Track::CopyToRing(const uint8_t* source, size_t frames) {
  size_t limit = std::min(buffer_frames_, params_.capacity_frames);
  size_t queued = static_cast<size_t>(written_ - read_);
  size_t room = queued < limit ? limit - queued : 0;
  size_t n = std::min(room, frames);
  if (n == 0) return 0;
  size_t cap = params_.capacity_frames;
  size_t pos = static_cast<size_t>(written_ % cap);
  size_t first = std::min(n, cap - pos);
  memcpy(data_.data() + pos * frame_size_, source, first * frame_size_);
  if (n > first) {
    memcpy(data_.data(), source + first * frame_size_, (n - first) * frame_size_);
  }
  written_ += n;
  return n;
}

ssize_t Track::Write(const void* data, size_t bytes, bool blocking) {
  const uint8_t* src = static_cast<const uint8_t*>(data);
  size_t frames = bytes / frame_size_;
  std::unique_lock<std::mutex> lock(mu_);
  if (released_) return kInvalidOperation;
  if (params_.is_static) {
    size_t n = std::min(frames, params_.capacity_frames);
    memcpy(data_.data(), src, n * frame_size_);
    static_frames_ = n;
    static_pos_ = 0;
    return static_cast<ssize_t>(n * frame_size_);
  }
  size_t done = 0;
  const uint64_t interrupt = write_interrupt_;
  while (done < frames) {
    if (released_ || write_interrupt_ != interrupt) break;
    size_t n = CopyToRing(src + done * frame_size_, frames - done);
    if (n == 0) {
      // Android makes writes nonblocking while stopped/paused. Priming before
      // play() may fill the buffer, but must not wait for a mixer that is idle.
      if (!blocking || state_ != State::kPlaying) break;
      PendingWrite pending(*this, src + done * frame_size_, frames - done, interrupt);
      room_.wait(lock);
      done += pending.committed;
      continue;
    }
    done += n;
  }
  return static_cast<ssize_t>(done * frame_size_);
}

int Track::SetLoop(uint32_t start, uint32_t end, int count) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (count == 0) {
    loop_count_ = 0;
    loop_start_ = loop_end_ = 0;
    return kOk;
  }
  if (start >= end || end > params_.capacity_frames) return kBadValue;
  loop_start_ = start;
  loop_end_ = end;
  loop_count_ = count;
  return kOk;
}

int Track::Reload() {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static) return kInvalidOperation;
  if (state_ == State::kPlaying) return kInvalidOperation;
  static_pos_ = 0;
  position_base_ = played_;
  rs_->Reset();
  return kOk;
}

int Track::SetPosition(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  if (!params_.is_static || state_ == State::kPlaying) return kInvalidOperation;
  if (frame > static_frames_) return kBadValue;
  static_pos_ = frame;
  position_base_ = played_ - frame;
  rs_->Reset();
  return kOk;
}

size_t Track::static_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_frames_;
}

uint32_t Track::Position() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(played_ - position_base_);
}

bool Track::Timestamp(int64_t* frames, int64_t* time_ns) const {
  std::lock_guard<std::mutex> lock(mu_);
  if (played_time_ns_ == 0) return false;
  *frames = static_cast<int64_t>(played_ - position_base_);
  // What was mixed last is heard after the sink's latency.
  uint32_t out_rate = engine_->out_rate();
  *time_ns = played_time_ns_ +
             (out_rate != 0 ? static_cast<int64_t>(engine_->latency_frames()) * 1000000000 / out_rate
                            : 0);
  return true;
}

int Track::SetMarker(uint32_t frame) {
  std::lock_guard<std::mutex> lock(mu_);
  marker_ = frame;
  marker_reached_ = frame == 0;
  return kOk;
}

uint32_t Track::marker() const {
  std::lock_guard<std::mutex> lock(mu_);
  return marker_;
}

int Track::SetUpdatePeriod(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  update_period_ = frames;
  uint64_t pos = played_ - position_base_;
  next_update_ = frames == 0 ? 0 : (pos / frames + 1) * frames;
  return kOk;
}

uint32_t Track::update_period() const {
  std::lock_guard<std::mutex> lock(mu_);
  return update_period_;
}

void Track::SetVolume(float left, float right) {
  std::lock_guard<std::mutex> lock(mu_);
  vol_left_ = std::clamp(left, 0.0f, 1.0f);
  vol_right_ = std::clamp(right, 0.0f, 1.0f);
}

int Track::SetSampleRate(uint32_t rate) {
  std::lock_guard<std::mutex> lock(mu_);
  if (rate == 0 || rate > params_.sample_rate * 2 * 8) return kBadValue;
  rate_ = rate;
  return kOk;
}

uint32_t Track::sample_rate() const {
  std::lock_guard<std::mutex> lock(mu_);
  return rate_;
}

void Track::SetSpeed(float speed) {
  std::lock_guard<std::mutex> lock(mu_);
  speed_ = std::clamp(speed, 0.01f, 16.0f);
}

float Track::speed() const {
  std::lock_guard<std::mutex> lock(mu_);
  return speed_;
}

uint32_t Track::buffer_size_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return static_cast<uint32_t>(params_.is_static ? params_.capacity_frames : buffer_frames_);
}

int Track::SetBufferSizeFrames(uint32_t frames) {
  std::lock_guard<std::mutex> lock(mu_);
  if (params_.is_static) return kInvalidOperation;
  buffer_frames_ = std::clamp<size_t>(frames, 1, params_.capacity_frames);
  room_.notify_all();
  return static_cast<int>(buffer_frames_);
}

uint32_t Track::underrun_frames() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_frames_;
}

uint32_t Track::underrun_count() const {
  std::lock_guard<std::mutex> lock(mu_);
  return underrun_count_;
}

uint32_t Track::LatencyMs() const {
  uint32_t out_rate = engine_->out_rate();
  uint32_t sink_ms = out_rate != 0 ? engine_->latency_frames() * 1000 / out_rate : 0;
  std::lock_guard<std::mutex> lock(mu_);
  uint32_t buffer_ms =
      params_.is_static ? 0 : static_cast<uint32_t>(buffer_frames_ * 1000 / std::max(rate_, 1u));
  return sink_ms + buffer_ms;
}

bool Track::WaitForRoom(size_t frames, int timeout_ms) {
  std::unique_lock<std::mutex> lock(mu_);
  auto fits = [&] {
    if (released_ || params_.is_static) return true;
    size_t limit = std::min(buffer_frames_, params_.capacity_frames);
    size_t queued = static_cast<size_t>(written_ - read_);
    return queued + std::min(frames, limit) <= limit;
  };
  room_.wait_for(lock, std::chrono::milliseconds(timeout_ms), fits);
  return fits();
}

size_t Track::Queued() const {
  std::lock_guard<std::mutex> lock(mu_);
  return params_.is_static ? 0 : static_cast<size_t>(written_ - read_);
}

void Track::Release() {
  {
    std::lock_guard<std::mutex> lock(mu_);
    released_ = true;
    ++write_interrupt_;
    state_ = State::kStopped;
    room_.notify_all();
  }
  engine_->Remove(this);
}

// Mixing thread, with mu_ held.
size_t Track::ReadSource(float* dst, size_t frames, bool* ended) {
  *ended = false;
  size_t ch = params_.channels;
  size_t bps = BytesPerSample(params_.format);
  size_t done = 0;
  if (!params_.is_static) {
    if (read_ == written_ && state_ == State::kPlaying && !released_) {
      while (pending_write_head_ != nullptr &&
             pending_write_head_->interrupt != write_interrupt_) {
        pending_write_head_->Unlink();
      }
      if (PendingWrite* pending = pending_write_head_) {
        pending->committed += CopyToRing(pending->data + pending->committed * frame_size_,
                                        pending->frames - pending->committed);
        if (pending->committed == pending->frames) pending->Unlink();
      }
    }
    const uint64_t end = state_ == State::kStopping ? stop_end_ : written_;
    size_t avail = static_cast<size_t>(end - read_);
    size_t n = std::min(avail, frames);
    size_t cap = params_.capacity_frames;
    while (done < n) {
      size_t pos = static_cast<size_t>(read_ % cap);
      size_t piece = std::min(n - done, cap - pos);
      ToFloat(data_.data() + pos * frame_size_, params_.format, piece * ch, dst + done * ch);
      read_ += piece;
      done += piece;
    }
    room_.notify_all();
    if (done == 0 && state_ == State::kStopping) *ended = true;
    return done;
  }
  while (done < frames) {
    bool looping = loop_count_ != 0 && loop_end_ > loop_start_ && static_pos_ <= loop_end_;
    size_t end = looping ? loop_end_ : static_frames_;
    if (static_pos_ >= end) {
      if (looping) {
        static_pos_ = loop_start_;
        if (loop_count_ > 0) loop_count_--;
        continue;
      }
      *ended = true;
      break;
    }
    size_t piece = std::min(frames - done, end - static_pos_);
    ToFloat(data_.data() + static_pos_ * frame_size_, params_.format, piece * ch, dst + done * ch);
    static_pos_ += piece;
    done += piece;
  }
  (void)bps;
  return done;
}

bool Track::MixInto(float* mix, size_t frames, uint32_t out_rate, uint32_t out_channels) {
  std::lock_guard<std::mutex> lock(mu_);
  if (released_ || (state_ != State::kPlaying && state_ != State::kStopping) ||
      (state_ == State::kStopping && drained_)) {
    return false;
  }
  Resampler& rs = *rs_;
  const size_t ch = params_.channels;
  const double step = static_cast<double>(rate_) * speed_ / out_rate;
  const bool passthrough = step == 1.0;
  const double cutoff = step > 1.0 ? 1.0 / step * 0.97 : 1.0;
  const size_t width = passthrough ? 0 : static_cast<size_t>(std::ceil(kHalfTaps / cutoff));
  const float* table = KernelTable();

  if (!rs.primed || rs.width != width) {
    if (!rs.primed) {
      // Zeros before the first frame, so the filter has history.
      rs.hist.assign(width * ch, 0.0f);
      rs.start_index = -static_cast<int64_t>(width);
      rs.t = static_cast<double>(width);
      rs.real_end = -1;
      rs.primed = true;
    } else if (width > rs.width) {
      // A rate change can widen the filter beyond retained left-hand history
      // (especially just after startup or compaction). Preserve every real
      // sample and the absolute timeline, padding only unavailable past taps.
      const int64_t first = static_cast<int64_t>(std::floor(rs.t)) -
                            static_cast<int64_t>(width) + 1;
      if (first < 0) {
        const size_t missing = static_cast<size_t>(-first);
        rs.hist.insert(rs.hist.begin(), missing * ch, 0.0f);
        rs.t += static_cast<double>(missing);
        rs.start_index -= static_cast<int64_t>(missing);
      }
    }
    rs.width = width;
  }

  uint64_t played_before = played_;
  std::vector<float>& frame = rs.frame;
  frame.resize(ch);
  std::vector<float>& tmp = rs.source;
  size_t out_done = 0;
  bool ended = false;
  bool starved = false;
  // Volume changes ramp linearly over the block (no clicks).
  const float gl = vol_left_, gr = vol_right_;
  float al = applied_left_, ar = applied_right_;
  const float dl = (gl - al) / static_cast<float>(std::max<size_t>(frames, 1));
  const float dr = (gr - ar) / static_cast<float>(std::max<size_t>(frames, 1));

  auto mix_frame = [&](const float* samples) {
    al += dl;
    ar += dr;
    float* o = mix + out_done * out_channels;
    float l, r;
    if (ch == 1) {
      l = r = samples[0];
    } else if (ch == 2) {
      l = samples[0];
      r = samples[1];
    } else {
      // FL FR FC LFE BL BR SL SR ...: the center and the surrounds at -3 dB.
      constexpr float k = 0.7071f;
      l = samples[0];
      r = samples[1];
      if (ch > 2) { l += k * samples[2]; r += k * samples[2]; }
      for (size_t c = 4; c + 1 < ch && c < 8; c += 2) { l += k * samples[c]; r += k * samples[c + 1]; }
    }
    l *= al;
    r *= ar;
    if (out_channels == 1) {
      o[0] += 0.5f * (l + r);
    } else {
      o[0] += l;
      o[1] += r;
    }
    ++out_done;
  };

  while (out_done < frames) {
    int64_t center = static_cast<int64_t>(std::floor(rs.t));
    size_t need = static_cast<size_t>(center + static_cast<int64_t>(width) + 1);
    while (rs.frames() < need) {
      if (rs.real_end >= 0) {
        // Ended: zeros flush the filter.
        rs.hist.insert(rs.hist.end(), (need - rs.frames()) * ch, 0.0f);
        break;
      }
      size_t want = std::max<size_t>(need - rs.frames(), 256);
      tmp.resize(want * ch);
      bool src_ended = false;
      size_t got = ReadSource(tmp.data(), want, &src_ended);
      rs.hist.insert(rs.hist.end(), tmp.begin(), tmp.begin() + got * ch);
      if (got == 0) {
        if (src_ended) {
          rs.real_end = rs.start_index + static_cast<int64_t>(rs.frames());
          continue;
        }
        starved = true;
        break;
      }
    }
    if (starved) break;
    if (rs.real_end >= 0 && rs.start_index + center >= rs.real_end) {
      ended = true;
      break;
    }
    if (passthrough) {
      // Unity-rate output already has contiguous source frames. Keep the
      // existing read-ahead and history, but check availability once per span
      // instead of once per output frame. A fractional phase left by a rate
      // change keeps the single-frame path: rounding when adding 1 near an
      // integer boundary can otherwise skip a source frame. The bounded
      // integral span advances exactly, including in floating-point arithmetic.
      size_t count = 1;
      if (rs.t == static_cast<double>(center) && rs.t < 0x1p52) {
        count = std::min({frames - out_done, rs.frames() - static_cast<size_t>(center), size_t{256}});
      }
      if (rs.real_end >= 0) {
        count = std::min(count, static_cast<size_t>(rs.real_end - rs.start_index - center));
      }
      const float* samples = rs.hist.data() + static_cast<size_t>(center) * ch;
      for (size_t i = 0; i < count; ++i) {
        mix_frame(samples);
        samples += ch;
        rs.t += 1.0;
      }
    } else {
      std::fill(frame.begin(), frame.end(), 0.0f);
      for (int64_t k = center - static_cast<int64_t>(width) + 1;
           k <= center + static_cast<int64_t>(width); k++) {
        float w = Kernel(table, (rs.t - static_cast<double>(k)) * cutoff) * static_cast<float>(cutoff);
        if (w == 0) continue;
        const float* s = &rs.hist[static_cast<size_t>(k) * ch];
        for (size_t c = 0; c < ch; c++) frame[c] += s[c] * w;
      }
      mix_frame(frame.data());
      rs.t += step;
    }
  }
  applied_left_ = gl;
  applied_right_ = gr;

  // Played: source frames whose center the filter passed.
  int64_t center_index = rs.start_index + static_cast<int64_t>(std::floor(rs.t));
  if (rs.real_end >= 0) center_index = std::min(center_index, rs.real_end);
  // played_ counts frames since the track was created; the resampler's index
  // restarts at each Reset, so advance by the difference.
  if (center_index > rs.played_index) {
    played_ += static_cast<uint64_t>(center_index - rs.played_index);
    rs.played_index = center_index;
  }
  played_time_ns_ = MonotonicNs();

  // Starved for a while (an underrun, or a writer that stopped writing without
  // stop()): the frames the filter still holds back count as played, and the
  // resampler starts over with the next data. Otherwise the last few frames
  // would wait for data that may never come (AAudio's getFramesRead, a
  // position that must reach what was written).
  if (starved && out_done == 0 && rs.primed) {
    if (starved_since_ns_ < 0) starved_since_ns_ = played_time_ns_;
    // Preserve the 10 ms grace between empty mixes when the device asks
    // for frames more often than the engine's periodic timer.
    if (played_time_ns_ - starved_since_ns_ >= 10'000'000) {
      int64_t end = rs.start_index + static_cast<int64_t>(rs.frames());
      if (end > rs.played_index) played_ += static_cast<uint64_t>(end - rs.played_index);
      rs.Reset();
      starved_since_ns_ = -1;
    }
  } else if (!starved) {
    starved_since_ns_ = -1;
  }

  // Drop history the filter no longer needs.
  int64_t keep_from = static_cast<int64_t>(std::floor(rs.t)) - static_cast<int64_t>(width) - 1;
  if (keep_from > 4096) {
    rs.hist.erase(rs.hist.begin(), rs.hist.begin() + keep_from * static_cast<int64_t>(ch));
    rs.t -= static_cast<double>(keep_from);
    rs.start_index += keep_from;
  }

  if (starved && out_done < frames && state_ == State::kPlaying && played_ > position_base_) {
    underrun_frames_ += static_cast<uint32_t>((frames - out_done) * rate_ / out_rate);
    if (!was_underrun_) {
      was_underrun_ = true;
      ++underrun_count_;
      if (events_.underrun) PostEvent(events_.underrun);
    }
  } else if (out_done == frames) {
    was_underrun_ = false;
  }

  bool was_ended = end_signalled_;
  if (ended) {
    if (state_ == State::kStopping) {
      drained_ = true;
      state_ = State::kStopped;
    } else {
      // A static track at its end stays "playing" (as Android's), silent.
      state_ = params_.is_static ? State::kPlaying : state_;
    }
    room_.notify_all();
    if (events_.end && !end_signalled_) {
      end_signalled_ = true;
      PostEvent(events_.end);
    }
  } else {
    end_signalled_ = false;
  }
  QueueEvents(played_before - position_base_, played_ - position_base_);
  return out_done > 0 || (ended && !was_ended);
}

void Track::QueueEvents(uint64_t before, uint64_t after) {
  if (after <= before) return;
  if (!marker_reached_ && marker_ != 0 && before < marker_ && after >= marker_) {
    marker_reached_ = true;
    if (events_.marker) {
      auto fn = events_.marker;
      uint32_t m = marker_;
      PostEvent([fn, m] { fn(m); });
    }
  }
  if (update_period_ != 0 && next_update_ != 0) {
    while (after >= next_update_) {
      if (events_.new_position) {
        auto fn = events_.new_position;
        uint32_t p = static_cast<uint32_t>(next_update_);
        PostEvent([fn, p] { fn(p); });
      }
      next_update_ += update_period_;
    }
  }
}

}  // namespace gesher::media



// Gesher media: where the engine's mixes go (engine.h).


#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace gesher::media {

// The engine, as a sink sees it.
class Mixer {
 public:
  virtual ~Mixer() = default;
  // Mixes the group's tracks into `out` (frames x the sink's channels, at its
  // rate), zeroed first, with the master volume applied (not the group's
  // stream volume). Returns false, and silence, when no track of the group
  // played.
  virtual bool MixGroup(int group, float* out, size_t frames) = 0;
  // A track of the group is playing (or was within the last second).
  virtual bool GroupWanted(int group) = 0;
};

class Sink {
 public:
  virtual ~Sink() = default;
  virtual uint32_t rate() const = 0;
  virtual uint32_t channels() const = 0;
  // Frames the sink holds before they are heard.
  virtual uint32_t latency_frames() const = 0;
  virtual std::string Describe() const = 0;
  // The output device, as AudioManager.getDevices shows it: its name and its
  // Android type (AUDIO_DEVICE_OUT_SPEAKER, ..._WIRED_HEADPHONE, ...).
  virtual std::string DeviceName() const { return "Gesher audio output"; }
  virtual int DeviceType() const { return 0x2; }
  // Wait for the engine's timer or for the output device to request a refill.
  // The opaque timer is a borrowed Windows waitable timer handle.
  virtual void WaitForRefill(void* timer);
  // One period: pull what the output needs now. Returns false when the
  // output is gone (the device was removed); the engine then opens another.
  virtual bool Tick(Mixer* mixer) = 0;
  // The shared stream volumes changed (shared_state.h).
  virtual void OnVolumesChanged() {}
};

// WASAPI shared mode on the default render endpoint; null with `error` set
// when there is none or it fails.
std::unique_ptr<Sink> OpenWasapiSink(const std::u16string& app_name, std::string* error);
// The mixed output, paced by the clock, into a 16-bit stereo 48 kHz WAV file.
std::unique_ptr<Sink> OpenCaptureSink(const std::wstring& path, std::string* error);
// Nothing heard, paced by the clock.
std::unique_ptr<Sink> OpenNullSink(const std::string& reason);

}  // namespace gesher::media


// Group-volume lookup and the single-track Mixer attachment are supplied.
// Capture Render, PCM rounding, WAV ownership/header and Analyze are unchanged.
// Requests are explicitly driven: Windows clock/endpoint scheduling is outside
// this host boundary.
namespace gesher::media {
[[noreturn]] unsigned long WaitForSingleObject(void*, unsigned long) { std::abort(); }
void Sink::WaitForRefill(void* timer) { WaitForSingleObject(timer, 100); }
float StreamGain(int) { return 1.0f; }
namespace {
constexpr uint32_t kRate = 48000;
constexpr uint32_t kChannels = 2;

// Frames due by the clock since the sink opened.
class Clock {
 public:
  Clock() : start_(gesher::MonotonicNanos()) {}
  uint64_t Due(uint32_t rate) const {
    const int64_t elapsed = gesher::MonotonicNanos() - start_;
    return static_cast<uint64_t>(static_cast<__int128>(elapsed) * rate / 1000000000);
  }

 private:
  int64_t start_;
};

class ClockedSink : public Sink {
 public:
  uint32_t rate() const override { return kRate; }
  uint32_t channels() const override { return kChannels; }
  uint32_t latency_frames() const override { return kRate / 50; }  // 20 ms, as a device's

  bool Tick(Mixer* mixer) override {
    uint64_t due = clock_.Due(kRate);
    if (due <= done_) return true;
    size_t frames = static_cast<size_t>(due - done_);
    // After a stall (the machine was busy), catch up in pieces: the timeline
    // stays continuous, as a capture should be.
    while (frames > 0) {
      size_t n = std::min<size_t>(frames, 4800);
      Render(mixer, n);
      frames -= n;
      done_ += n;
    }
    return true;
  }

 protected:
  virtual void Render(Mixer* mixer, size_t frames) = 0;

  Clock clock_;
  uint64_t done_ = 0;
};

class NullSink : public ClockedSink {
 public:
  explicit NullSink(std::string reason) : reason_(std::move(reason)) {}
  std::string Describe() const override { return "none (" + reason_ + "); nothing is heard"; }

 protected:
  void Render(Mixer* mixer, size_t frames) override {
    buf_.resize(frames * kChannels);
    for (int g = 0; g < kNumGroups; g++) mixer->MixGroup(g, buf_.data(), frames);
  }

 private:
  std::string reason_;
  std::vector<float> buf_;
};

class CaptureSink : public ClockedSink {
 public:
  CaptureSink(FILE* f, std::string path) : f_(f), path_(std::move(path)) { WriteHeader(); }
  ~CaptureSink() override {
    WriteHeader();
    fclose(f_);
  }

  std::string DeviceName() const override { return "Gesher audio capture"; }
  std::string Describe() const override {
    return "capture to " + path_ + " (48000 Hz, 2 channels, 16-bit; the stream volumes applied)";
  }

 protected:
  void Render(Mixer* mixer, size_t frames) override {
    sum_.assign(frames * kChannels, 0.0f);
    buf_.resize(frames * kChannels);
    for (int g = 0; g < kNumGroups; g++) {
      if (!mixer->MixGroup(g, buf_.data(), frames)) continue;
      // What the group's Windows session volume would do.
      float gain = StreamGain(StreamOfGroup(g));
      for (size_t i = 0; i < buf_.size(); i++) sum_[i] += buf_[i] * gain;
    }
    pcm_.resize(sum_.size());
    for (size_t i = 0; i < sum_.size(); i++) {
      float v = std::clamp(sum_[i], -1.0f, 1.0f);
      pcm_[i] = static_cast<int16_t>(std::lrint(v * 32767.0f));
    }
    fwrite(pcm_.data(), sizeof(int16_t), pcm_.size(), f_);
    data_bytes_ += static_cast<uint32_t>(pcm_.size() * sizeof(int16_t));
    // The sizes, every time: the file is complete whenever the process ends.
    WriteHeader();
  }

 private:
  void WriteHeader() {
    long pos = ftell(f_);
    uint8_t h[44];
    auto u32 = [&h](int off, uint32_t v) { memcpy(h + off, &v, 4); };
    auto u16 = [&h](int off, uint16_t v) { memcpy(h + off, &v, 2); };
    memcpy(h, "RIFF", 4);
    u32(4, 36 + data_bytes_);
    memcpy(h + 8, "WAVEfmt ", 8);
    u32(16, 16);
    u16(20, 1);  // PCM
    u16(22, kChannels);
    u32(24, kRate);
    u32(28, kRate * kChannels * 2);
    u16(32, kChannels * 2);
    u16(34, 16);
    memcpy(h + 36, "data", 4);
    u32(40, data_bytes_);
    fseek(f_, 0, SEEK_SET);
    fwrite(h, 1, sizeof(h), f_);
    if (pos > 0) fseek(f_, pos, SEEK_SET);
    fflush(f_);
  }

  FILE* f_;
  std::string path_;
  uint32_t data_bytes_ = 0;
  std::vector<float> sum_, buf_;
  std::vector<int16_t> pcm_;
};


}
}
int Analyze(const char* path) {
  FILE* f = fopen(path, "rb");
  if (f == nullptr) {
    printf("cannot open %s\n", path);
    return 2;
  }
  std::vector<uint8_t> file;
  uint8_t buf[65536];
  size_t n;
  while ((n = fread(buf, 1, sizeof(buf), f)) > 0) file.insert(file.end(), buf, buf + n);
  fclose(f);
  if (file.size() < 44 || memcmp(file.data(), "RIFF", 4) != 0) {
    printf("not a WAV file\n");
    return 2;
  }
  uint16_t channels = 0, bits = 0;
  uint32_t rate = 0;
  size_t data_off = 0, data_len = 0;
  for (size_t off = 12; off + 8 <= file.size();) {
    uint32_t len;
    memcpy(&len, file.data() + off + 4, 4);
    if (memcmp(file.data() + off, "fmt ", 4) == 0) {
      memcpy(&channels, file.data() + off + 10, 2);
      memcpy(&rate, file.data() + off + 12, 4);
      memcpy(&bits, file.data() + off + 22, 2);
    } else if (memcmp(file.data() + off, "data", 4) == 0) {
      data_off = off + 8;
      data_len = std::min<size_t>(len, file.size() - data_off);
      break;
    }
    off += 8 + len + (len & 1);
  }
  if (bits != 16 || channels == 0 || rate == 0) {
    printf("unsupported WAV (%u bits)\n", bits);
    return 2;
  }
  size_t frames = data_len / (2 * channels);
  std::vector<float> left(frames), right(frames);
  for (size_t i = 0; i < frames; i++) {
    int16_t l, r;
    memcpy(&l, file.data() + data_off + i * 2 * channels, 2);
    memcpy(&r, file.data() + data_off + i * 2 * channels + (channels > 1 ? 2 : 0), 2);
    left[i] = l / 32768.0f;
    right[i] = r / 32768.0f;
  }
  printf("wav: %u Hz, %u channels, %.3f s\n", rate, channels, static_cast<double>(frames) / rate);
  // Sounding blocks of 5 ms; sounds are runs of them, apart by 50 ms or more.
  const size_t block = rate / 200;
  std::vector<bool> loud(frames / block + 1, false);
  for (size_t b = 0; b * block < frames; b++) {
    double e = 0;
    size_t end = std::min(frames, (b + 1) * block);
    for (size_t i = b * block; i < end; i++) e += left[i] * left[i] + right[i] * right[i];
    loud[b] = std::sqrt(e / (2.0 * (end - b * block))) > 0.003;
  }
  int index = 0;
  for (size_t b = 0; b < loud.size();) {
    if (!loud[b]) {
      b++;
      continue;
    }
    size_t e = b;
    size_t quiet = 0;
    for (size_t k = b; k < loud.size(); k++) {
      if (loud[k]) {
        e = k;
        quiet = 0;
      } else if (++quiet >= 10) {
        break;
      }
    }
    size_t s0 = b * block, s1 = std::min(frames, (e + 1) * block);
    // Zero crossings (upward) of the louder channel, interpolated. A crossing
    // counts only after the signal went below -30% of its rms (hysteresis):
    // the low-level noise lossy codecs leave around a tone's start and end
    // would otherwise add crossings (an MP3 tone of 523 Hz measured 540).
    double el = 0, er = 0;
    for (size_t i = s0; i < s1; i++) {
      el += left[i] * left[i];
      er += right[i] * right[i];
    }
    const std::vector<float>& x = el >= er ? left : right;
    const double threshold = -0.3 * std::sqrt(std::max(el, er) / (s1 - s0));
    double first = -1, last = -1;
    int crossings = 0;
    bool armed = false;
    for (size_t i = s0 + 1; i < s1; i++) {
      if (x[i] < threshold) armed = true;
      if (armed && x[i - 1] < 0 && x[i] >= 0) {
        armed = false;
        double t = (i - 1) + x[i - 1] / (x[i - 1] - x[i]);
        if (first < 0) first = t;
        last = t;
        crossings++;
      }
    }
    double hz = crossings > 1 ? (crossings - 1) * rate / (last - first) : 0;
    double rms_l = std::sqrt(el / (s1 - s0)), rms_r = std::sqrt(er / (s1 - s0));
    printf("sound %d: start %.3f s, duration %.3f s, %.1f Hz, rms %.3f %.3f\n", ++index,
           static_cast<double>(s0) / rate, static_cast<double>(s1 - s0) / rate, hz, rms_l, rms_r);
    b = e + 1;
  }
  printf("sounds: %d\n", index);
  return 0;
}



namespace {
using namespace gesher::media;
using namespace std::chrono_literals;
int checks = 0, failures = 0;
Engine engine;
const char* capture_path = nullptr;
void Check(bool ok, const char* reason) {
  ++checks;
  if (!ok) { ++failures; std::fprintf(stderr, "FAIL blocked audio write: %s\n", reason); }
}
std::shared_ptr<Track> NewTrack(size_t capacity = 4, uint32_t channels = 1,
                              PcmFormat format = PcmFormat::kS16, bool fixed = false) {
  TrackParams params;
  params.capacity_frames = capacity;
  params.channels = channels;
  params.format = format;
  params.is_static = fixed;
  return std::shared_ptr<Track>(new Track(&engine, params));
}
std::vector<int16_t> Samples(size_t count, int seed = 0) {
  std::vector<int16_t> out(count);
  for (size_t i = 0; i < count; ++i)
    out[i] = static_cast<int16_t>((i * 137 + seed * 31) % 30001 - 15000);
  return out;
}
bool Same(const float* output, const int16_t* source, size_t frames) {
  for (size_t i = 0; i < frames; ++i)
    if (output[i] != static_cast<float>(source[i]) / 32768.0f) return false;
  return true;
}
bool Silence(const float* output, size_t count) {
  for (size_t i = 0; i < count; ++i) if (output[i] != 0.0f) return false;
  return true;
}
bool NoPending(const std::shared_ptr<Track>& track) {
#if HAS_PENDING_WRITE
  std::lock_guard<std::mutex> lock(track->mu_);
  return track->pending_write_head_ == nullptr && track->pending_write_tail_ == nullptr;
#else
  (void)track;
  return true;
#endif
}
void WaitBlocked(const std::shared_ptr<Track>& track, unsigned waits = 1) {
  const auto deadline = std::chrono::steady_clock::now() + 2s;
  while (track->room_.waits.load() < waits && std::chrono::steady_clock::now() < deadline)
    std::this_thread::yield();
  // Acquiring mu_ after observing the count ensures the CV actually released it.
  std::lock_guard<std::mutex> lock(track->mu_);
  Check(track->room_.waits.load() >= waits, "writer reached the observed wait boundary");
}
ssize_t Finish(const std::shared_ptr<Track>& track, std::future<ssize_t>& future) {
  const bool ready = future.wait_for(2s) == std::future_status::ready;
  Check(ready, "writer returns after real data has been committed or interrupted");
  if (!ready) track->Release();
  if (future.wait_for(2s) != std::future_status::ready) std::abort();
  return future.get();
}
void Gap() {
  // The actual failed capture differs by 446 inserted zero frames. This is a
  // sufficient deterministic mechanism, not a reconstruction of its scheduler.
  // ClockedSink permits a catch-up block up to 4,800 frames; default capacity is 960.
  auto track = NewTrack(960);
  auto input = Samples(14400, 7);
  track->Start();
  auto writer = std::async(std::launch::async, [&] {
    return track->Write(input.data(), input.size() * sizeof(int16_t), true);
  });
  WaitBlocked(track);
  std::vector<float> output(1406, 0);
  track->MixInto(output.data(), output.size(), 48000, 1);
  Check(Same(output.data(), input.data(), output.size()) && track->Position() == 1406 &&
        track->underrun_frames() == 0,
        "prepared blocking input remains continuous across a catch-up mix");
  track->Release();
  const auto committed = Finish(track, writer);
  Check(committed >= 960 * 2 && committed <= static_cast<ssize_t>(input.size() * 2),
        "interrupted catch-up reports only committed whole bytes");
  Check(NoPending(track), "returned write leaves no borrowed input record");
}
void RealWaitComplete() {
  for (size_t capacity : {size_t{1}, size_t{7}, size_t{17}, size_t{960}}) {
    auto track = NewTrack(capacity);
    auto input = Samples(14400, static_cast<int>(capacity));
    const auto original = input;
    track->Start();
    auto writer = std::async(std::launch::async, [&] {
      return track->Write(input.data(), input.size() * 2, true);
    });
    WaitBlocked(track);
    std::vector<float> output(input.size(), 0);
    for (size_t offset = 0; offset < output.size();) {
      const size_t chunk = std::min<size_t>(4800, output.size() - offset);
      track->MixInto(output.data() + offset, chunk, 48000, 1);
      offset += chunk;
    }
    Check(Finish(track, writer) == static_cast<ssize_t>(input.size() * 2),
          "whole blocking transfer completes across multiple capacity-bounded refills");
    Check(Same(output.data(), original.data(), output.size()), "complete caught-up stream preserves every PCM frame");
    Check(track->Position() == input.size() && track->underrun_frames() == 0,
          "complete caught-up stream preserves source position without false underrun");
    Check(track->data_.size() == capacity * 2 && track->Queued() <= capacity,
          "assisted writer retains the original ring allocation and capacity");
    Check(NoPending(track), "completed real waiter retires its record");
    input.assign(input.size(), 0);
    track->Stop();
    std::array<float, 8> tail{};
    track->MixInto(tail.data(), tail.size(), 48000, 1);
    Check(Silence(tail.data(), tail.size()) && track->stopped(), "stop after full transfer drains without rereading retired input");
  }
}
void RetainedTail() {
  auto track = NewTrack(960);
  auto input = Samples(1025, 21);
  const auto expected = input;
  track->Start();
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  WaitBlocked(track);
  std::vector<float> first(961, 0);
  track->MixInto(first.data(), first.size(), 48000, 1);
  Check(Finish(track, writer) == 2050, "assisted completion counts all bytes before caller retirement");
  Check(NoPending(track), "mixer completion detaches the caller record before later reads");
  input.clear();
  input.shrink_to_fit();
  std::array<float, 64> tail{};
  track->MixInto(tail.data(), tail.size(), 48000, 1);
  Check(Same(first.data(), expected.data(), first.size()) &&
        Same(tail.data(), expected.data() + first.size(), tail.size()),
        "remaining ring and resampler tail own their samples after Write returns");
  track->Release();
}
void PartialAndInterrupt() {
  for (int action = 0; action < 5; ++action) {
    auto track = NewTrack();
    auto input = Samples(20, 51 + action);
    track->Start();
    std::array<float, 8> first{};
    std::array<float, 4> after{};
    track->room_.before_reacquire = [&] {
      // The callback only controls CV scheduling while the actual Write input
      // remains live. Production MixInto/ReadSource and transitions run intact.
      track->MixInto(first.data(), first.size(), 48000, 1);
      if (action == 0 || action == 3) track->Pause();
      else if (action == 1 || action == 4) track->Stop();
      else track->Release();
      if (action == 3 || action == 4) track->Start();
      track->MixInto(after.data(), after.size(), 48000, 1);
    };
    auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
    Check(Finish(track, writer) == 16, "interrupted assisted writer returns exactly its committed prefix");
    Check(Same(first.data(), input.data(), first.size()), "partial assisted write keeps original frame order");
    Check(Silence(after.data(), after.size()) && track->written_ == 8,
          "old pending input is never resumed after its pause stop or release epoch");
    Check(NoPending(track), "interrupted writer retires every intrusive link");
    track->Release();
  }
  auto track = NewTrack();
  auto input = Samples(20, 93);
  track->Start();
  std::array<float, 8> output{};
  track->room_.before_reacquire = [&] {
    track->Stop();
    track->MixInto(output.data(), output.size(), 48000, 1);
  };
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  Check(Finish(track, writer) == 8 && track->written_ == 4 && track->stop_end_ == 4,
        "stop freezes its original committed drain boundary");
  Check(Same(output.data(), input.data(), 4) && Silence(output.data() + 4, 4),
        "stopping never admits old waiting payload beyond its drain");
  Check(NoPending(track), "stopping writer removes its live input record");
}
void EpochControl() {
  auto track = NewTrack();
  const auto input = Samples(20, 49);
  std::array<float, 8> first{};
  std::array<float, 4> later{};
  track->Start();
  track->room_.before_reacquire = [&] {
    track->MixInto(first.data(), first.size(), 48000, 1);
    track->Pause();
    track->Start();
    track->MixInto(later.data(), later.size(), 48000, 1);
  };
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  const ssize_t count = Finish(track, writer);
  Check(count == 16 && track->written_ == 8 && Silence(later.data(), later.size()),
        "a restarted stream cannot borrow an interrupted writer's remaining input");
  Check(NoPending(track), "epoch control retires its caller record");
  track->Release();
}
void ProgressControl() {
  auto track = NewTrack();
  const auto input = Samples(20, 31);
  std::array<float, 8> output{};
  track->Start();
  track->room_.before_reacquire = [&] {
    track->MixInto(output.data(), output.size(), 48000, 1);
    track->Pause();
  };
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  Check(Finish(track, writer) == 16, "assisted byte progress is counted once when interrupted");
  Check(NoPending(track), "progress control retires its caller record");
  track->Release();
}
void ShrinkAndWrap() {
  auto track = NewTrack(7);
  const auto prefix = Samples(3, 20);
  track->Write(prefix.data(), prefix.size() * 2, false);
  track->Start();
  std::array<float, 3> head{};
  track->MixInto(head.data(), head.size(), 48000, 1);
  auto input = Samples(37, 44);
  std::vector<float> output(input.size(), 0);
  track->room_.before_reacquire = [&] {
    Check(track->SetBufferSizeFrames(2) == 2, "live buffer limit can shrink below already queued data");
    std::lock_guard<std::mutex> lock(track->mu_);
    bool ended = false;
    for (size_t i = 0; i < input.size(); ++i) {
      Check(track->ReadSource(output.data() + i, 1, &ended) == 1 && !ended,
            "wrapped pending source supplies one genuine frame");
      const size_t queued = static_cast<size_t>(track->written_ - track->read_);
      Check(queued <= (i < 7 ? 6 - i : 1), "assisted commit respects the smaller current ring limit");
    }
  };
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  Check(Finish(track, writer) == static_cast<ssize_t>(input.size() * 2), "wrapped and resized blocking write reports full transfer");
  Check(Same(head.data(), prefix.data(), prefix.size()) && Same(output.data(), input.data(), input.size()),
        "ring wrap and limit changes preserve full source byte order");
  Check(track->data_.size() == 14 && NoPending(track), "resizing preserves original storage and retires borrowed input");
  track->Release();
}
void MultipleWaiters() {
  for (size_t writers : {size_t{2}, size_t{8}, size_t{32}}) {
    auto track = NewTrack();
    const auto prefix = Samples(4, 6);
    track->Write(prefix.data(), 8, false);
    track->Start();
    std::vector<std::vector<int16_t>> inputs;
    inputs.reserve(writers);
    for (size_t i = 0; i < writers; ++i) inputs.push_back(Samples(i % 5 + 3, static_cast<int>(i + 40)));
    std::vector<std::future<ssize_t>> futures;
    std::vector<int16_t> expected = prefix;
    for (size_t i = 0; i < writers; ++i) {
      const unsigned waits = track->room_.waits.load();
      futures.push_back(std::async(std::launch::async, [&, i] {
        return track->Write(inputs[i].data(), inputs[i].size() * 2, true);
      }));
      WaitBlocked(track, waits + 1);
      expected.insert(expected.end(), inputs[i].begin(), inputs[i].end());
    }
    std::vector<float> output(expected.size(), 0);
    track->MixInto(output.data(), output.size(), 48000, 1);
    for (size_t i = 0; i < writers; ++i)
      Check(Finish(track, futures[i]) == static_cast<ssize_t>(inputs[i].size() * 2), "each blocked caller receives its own committed count");
    Check(Same(output.data(), expected.data(), expected.size()), "currently registered waiters are refilled in their list order");
    Check(NoPending(track) && track->underrun_frames() == 0, "all registered waiter links retire without a false underrun");
    track->Release();
  }
}
void PartialWaiters() {
  auto track = NewTrack();
  const auto one = Samples(7, 60), two = Samples(8, 91);
  std::promise<void> held, resume;
  auto resume_future = resume.get_future();
  track->Start();
  track->room_.before_reacquire = [&] { held.set_value(); resume_future.wait(); };
  auto first = std::async(std::launch::async, [&] { return track->Write(one.data(), one.size() * 2, true); });
  Check(held.get_future().wait_for(2s) == std::future_status::ready, "first partial writer is held outside the mutex");
  std::array<float, 2> start{};
  track->MixInto(start.data(), start.size(), 48000, 1);
  const unsigned waits = track->room_.waits.load();
  auto second = std::async(std::launch::async, [&] { return track->Write(two.data(), two.size() * 2, true); });
  WaitBlocked(track, waits + 1);
  std::vector<int16_t> expected(one.begin() + 2, one.begin() + 4);
  expected.insert(expected.end(), two.begin(), two.begin() + 4);
  expected.insert(expected.end(), one.begin() + 4, one.end());
  expected.insert(expected.end(), two.begin() + 4, two.end());
  std::vector<float> output(expected.size(), 0);
  track->MixInto(output.data(), output.size(), 48000, 1);
  resume.set_value();
  Check(Finish(track, first) == 14 && Finish(track, second) == 16,
        "two partially committed callers keep separate progress records");
  Check(Same(start.data(), one.data(), start.size()) && Same(output.data(), expected.data(), expected.size()),
        "pending FIFO preserves existing committed ring order across concurrent writes");
  Check(NoPending(track), "both partial caller records retire exactly once");
  track->Release();
}
void SpuriousWake() {
  auto track = NewTrack();
  auto input = Samples(17, 72);
  track->Start();
  int wakes = 0;
  std::vector<float> output(input.size(), 0);
  std::function<void()> hook;
  hook = [&] {
    ++wakes;
#if HAS_PENDING_WRITE
    {
      std::lock_guard<std::mutex> lock(track->mu_);
      auto* pending = track->pending_write_head_;
      Check(pending != nullptr && pending == track->pending_write_tail_ &&
            pending->previous == nullptr && pending->next == nullptr && pending->committed == 0,
            "spurious wake unregisters before the next borrowed registration");
    }
#endif
    if (wakes < 4) track->room_.before_reacquire = hook;
    else track->MixInto(output.data(), output.size(), 48000, 1);
  };
  track->room_.before_reacquire = hook;
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  Check(Finish(track, writer) == 34 && wakes == 4, "spurious wakeups do not duplicate or lose committed progress");
  Check(Same(output.data(), input.data(), input.size()) && NoPending(track), "spurious wakeups preserve every sample and caller retirement");
  track->Release();
}
void ReleaseWhileBorrowed() {
  auto track = NewTrack();
  auto input = Samples(20, 37);
  const auto expected = input;
  std::promise<void> held, resume, release_started;
  auto resume_future = resume.get_future();
  track->Start();
  track->room_.before_reacquire = [&] { held.set_value(); resume_future.wait(); };
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  Check(held.get_future().wait_for(2s) == std::future_status::ready, "release control holds the live blocking caller outside the mutex");
  std::array<float, 8> first{}, next{};
  track->MixInto(first.data(), first.size(), 48000, 1);
  std::unique_lock<std::mutex> lock(track->mu_);
  bool ended = false;
  Check(track->ReadSource(next.data(), 4, &ended) == 4 && !ended,
        "mixer reads real borrowed bytes while holding the common owner mutex");
  auto release = std::async(std::launch::async, [&] { release_started.set_value(); track->Release(); });
  Check(release_started.get_future().wait_for(2s) == std::future_status::ready,
        "release contender reaches the actual production operation");
  Check(release.wait_for(20ms) == std::future_status::timeout,
        "release cannot retire an input owner during the protected source access");
  Check(track->ReadSource(next.data() + 4, 4, &ended) == 4 && !ended,
        "already-owned mixer interval can finish its genuine source access");
  lock.unlock();
  Check(release.wait_for(2s) == std::future_status::ready, "release finishes once the source owner mutex is released");
  release.get();
  resume.set_value();
  Check(Finish(track, writer) == 32 && track->written_ == 16,
        "release reports exactly the prefix committed before its ownership transition");
  Check(Same(first.data(), expected.data(), first.size()) &&
        Same(next.data(), expected.data() + first.size(), next.size()) && NoPending(track),
        "release preserves the consumed prefix and retires the caller record");
  input.clear();
  input.shrink_to_fit();
  std::array<float, 8> after{};
  Check(!track->MixInto(after.data(), after.size(), 48000, 1) && Silence(after.data(), after.size()),
        "released track never reads caller storage after Write has returned");
}
void Cancellation() {
  auto track = NewTrack();
  auto input = Samples(20, 74);
  track->Start();
  struct Args { std::shared_ptr<Track> track; const std::vector<int16_t>* input; } args{track, &input};
  pthread_t worker{};
  Check(pthread_create(&worker, nullptr, +[](void* opaque) -> void* {
    auto& a = *static_cast<Args*>(opaque);
    a.track->Write(a.input->data(), a.input->size() * 2, true);
    return nullptr;
  }, &args) == 0, "native cancellation control creates its actual writer");
  WaitBlocked(track);
  Check(pthread_cancel(worker) == 0, "native cancellation interrupts the actual CV waiter");
  void* result = nullptr;
  Check(pthread_join(worker, &result) == 0 && result == PTHREAD_CANCELED, "cancelled waiter exits through real C++ scope cleanup");
  Check(NoPending(track), "cancelled writer unlinks borrowed input before caller storage can retire");
#if HAS_PENDING_WRITE
  // An unlink mutation must fail at the ownership assertion without deliberately
  // dereferencing its now-dead stack record in the remaining cleanup path.
  { std::lock_guard<std::mutex> lock(track->mu_);
    track->pending_write_head_ = track->pending_write_tail_ = nullptr; }
#endif
  input.clear();
  input.shrink_to_fit();
  track->Release();
}
void TrueUnderrunAndNonblocking() {
  for (bool fixed : {false, true}) {
    auto track = NewTrack(7, 2, PcmFormat::kS16, fixed);
    const auto input = Samples(24, 11);
    Check(track->Write(input.data(), 35, false) == 28, "nonblocking and static writes retain whole-frame truncation");
    Check(track->room_.waits.load() == 0 && NoPending(track), "nonblocking and static writes never publish borrowed input");
    if (fixed) {
      Check(track->Write(input.data(), 3, true) == 0, "partial static frame remains uncommitted");
    } else {
      track->Start();
      std::array<float, 14> output{};
      track->MixInto(output.data(), output.size(), 48000, 1);
      Check(track->underrun_frames() == 7 && track->underrun_count() == 1 &&
            Silence(output.data() + 7, 7), "genuine unprepared input still produces and reports an underrun");
      Check(track->Write(input.data(), 3, false) == 0 && track->Queued() == 0,
            "partial streaming frame remains uncommitted after a real underrun");
    }
    track->Release();
  }
  for (bool paused : {false, true}) {
    auto track = NewTrack();
    if (paused) { track->Start(); track->Pause(); }
    const auto input = Samples(9, 21);
    Check(track->Write(input.data(), input.size() * 2 + 1, true) == 8 &&
          track->room_.waits.load() == 0 && NoPending(track),
          "inactive blocking priming stays short and publishes no pending input");
    track->Release();
  }
}
void ReferenceStreams() {
  // The reference owns the entire source in its original ring before playback;
  // the candidate has only 17 ring slots and an active blocking caller. Complete
  // actual conversion/resampling/channel mapping/state/callbacks must agree.
  constexpr size_t frames = 1033, guard = 32;
  for (PcmFormat format : {PcmFormat::kU8, PcmFormat::kS16, PcmFormat::kS24Packed,
                           PcmFormat::kS32, PcmFormat::kFloat}) {
    for (uint32_t channels : {1u, 2u, 8u, 24u}) {
      for (uint32_t rate : {24000u, 48000u, 96000u}) {
        const size_t bps = BytesPerSample(format), frame_bytes = bps * channels;
        std::vector<uint8_t> input(guard + frames * frame_bytes + guard, 0xA7);
        for (size_t i = 0; i < frames * channels; ++i) {
          const int32_t sample = static_cast<int32_t>(i * 131 % 30001) - 15000;
          uint8_t* p = input.data() + guard + i * bps;
          if (format == PcmFormat::kU8) *p = static_cast<uint8_t>(128 + sample / 256);
          if (format == PcmFormat::kS16) { const int16_t v = static_cast<int16_t>(sample); std::memcpy(p, &v, 2); }
          if (format == PcmFormat::kS24Packed) {
            const uint32_t v = static_cast<uint32_t>(sample * 256);
            for (size_t b = 0; b < 3; ++b) p[b] = static_cast<uint8_t>(v >> (8 * b));
          }
          if (format == PcmFormat::kS32) { const int32_t v = sample * 65536; std::memcpy(p, &v, 4); }
          if (format == PcmFormat::kFloat) { const float v = sample / 32768.0f; std::memcpy(p, &v, 4); }
        }
        const auto original = input;
        auto track = NewTrack(17, channels, format);
        auto reference = NewTrack(frames, channels, format);
        track->SetSampleRate(rate);
        reference->SetSampleRate(rate);
        reference->Write(input.data() + guard, frames * frame_bytes, false);
        std::vector<uint64_t> events, expected_events;
        auto attach = [](const std::shared_ptr<Track>& t, std::vector<uint64_t>& e) {
          TrackEvents callbacks;
          callbacks.marker = [&](uint32_t p) { e.push_back((uint64_t{1} << 32) | p); };
          callbacks.new_position = [&](uint32_t p) { e.push_back((uint64_t{2} << 32) | p); };
          callbacks.end = [&] { e.push_back(uint64_t{3} << 32); };
          callbacks.underrun = [&] { e.push_back(uint64_t{4} << 32); };
          t->SetEvents(std::move(callbacks));
          t->SetMarker(317);
          t->SetUpdatePeriod(61);
        };
        attach(track, events);
        attach(reference, expected_events);
        track->Start();
        reference->Start();
        track->room_.before_reacquire = [&] {
          int64_t time_ns = 0;
          for (size_t chunk : {size_t{1}, size_t{31}, size_t{409}, size_t{4800}, size_t{17}}) {
            for (uint32_t out_channels : {1u, 2u}) {
              std::vector<float> actual(chunk * out_channels, 0), expected(actual.size(), 0);
              // The new starvation grace uses elapsed playback time. Give
              // both real mixers the same nominal clock, including empty
              // periods, instead of comparing separate wall-clock instants.
              gesher::fixture_playback_ns = time_ns;
              const bool a = track->MixInto(actual.data(), chunk, 48000, out_channels);
              const bool b = reference->MixInto(expected.data(), chunk, 48000, out_channels);
              time_ns += static_cast<int64_t>(chunk) * 1000000000 / 48000;
              Check(a == b && std::memcmp(actual.data(), expected.data(), actual.size() * sizeof(float)) == 0,
                    "full pending stream matches already-owned PCM across formats rates channels and chunks");
              Check(track->Position() == reference->Position() &&
                    track->underrun_frames() == reference->underrun_frames() &&
                    track->underrun_count() == reference->underrun_count() &&
                    track->Queued() <= 17 && track->read_ <= track->written_ &&
                    track->written_ <= frames && events == expected_events,
                    "pending transport preserves position underrun callbacks and its bounded ring state");
            }
          }
          gesher::fixture_playback_ns = -1;
        };
        auto writer = std::async(std::launch::async, [&] {
          return track->Write(input.data() + guard, frames * frame_bytes + frame_bytes - 1, true);
        });
        Check(Finish(track, writer) == static_cast<ssize_t>(frames * frame_bytes),
              "all source formats commit only whole caller frames");
        Check(input == original, "blocking refill never writes caller input or its guards");
        input.clear();
        input.shrink_to_fit();
        track->Stop();
        reference->Stop();
        std::array<float, 1024> actual{}, expected{};
        track->MixInto(actual.data(), 512, 48000, 2);
        reference->MixInto(expected.data(), 512, 48000, 2);
        Check(std::memcmp(actual.data(), expected.data(), sizeof actual) == 0 &&
              track->Position() == reference->Position() && events == expected_events,
              "source retirement and stop retain complete resampler tail and event parity");
        Check(NoPending(track) && track->data_.size() == 17 * frame_bytes,
              "reference workload releases all borrowed input without expanding ring storage");
        track->Release();
        reference->Release();
      }
    }
  }
}
void CapturePipeline() {
  Check(capture_path != nullptr, "capture fixture has a concrete output file");
  if (capture_path == nullptr) return;
  auto track = NewTrack(960);
  std::vector<int16_t> input(14400);
  for (size_t i = 0; i < input.size(); ++i)
    input[i] = static_cast<int16_t>(12345 * std::sin(2 * 3.14159265358979323846 * 750 * i / 48000));
  const auto original = input;
  class OneTrack final : public Mixer {
   public:
    explicit OneTrack(std::shared_ptr<Track> value) : track(std::move(value)) {}
    bool MixGroup(int group, float* output, size_t frames) override {
      std::fill(output, output + frames * 2, 0.0f);
      return group == GroupOfStream(3) && track->MixInto(output, frames, 48000, 2);
    }
    bool GroupWanted(int group) override { return group == GroupOfStream(3); }
    std::shared_ptr<Track> track;
  } mixer(track);
  class DrivenCapture final : public CaptureSink {
   public:
    using CaptureSink::CaptureSink;
    using CaptureSink::Render;
  };
  FILE* file = std::fopen(capture_path, "w+b");
  Check(file != nullptr, "capture fixture opens its real WAV file");
  if (!file) return;
  track->Start();
  auto writer = std::async(std::launch::async, [&] { return track->Write(input.data(), input.size() * 2, true); });
  WaitBlocked(track);
  {
    DrivenCapture sink(file, capture_path);
    // ClockedSink permits this request under its unchanged 4,800-frame cap.
    sink.Render(&mixer, 1406);
    bool stopped = false;
    for (size_t rendered = 1406; rendered < 14846;) {
      const auto deadline = std::chrono::steady_clock::now() + 2s;
      bool ready = false, complete = false;
      do {
        { std::lock_guard<std::mutex> lock(track->mu_);
          complete = track->written_ == input.size();
          ready = complete || track->written_ - track->read_ >= 256; }
        if (ready) break;
        std::this_thread::yield();
      } while (std::chrono::steady_clock::now() < deadline);
      Check(ready, "ordinary capture periods wait only in the fixture for the real producer");
      if (!ready) { track->Release(); break; }
      if (complete && !stopped) { track->Stop(); stopped = true; }
      const size_t chunk = std::min<size_t>(240, 14846 - rendered);
      sink.Render(&mixer, chunk);
      rendered += chunk;
    }
  }
  Check(Finish(track, writer) == 28800, "capture transfer reports all original source bytes");
  Check(input == original && NoPending(track), "capture leaves caller bytes intact and retires borrowed ownership");
  input.clear();
  input.shrink_to_fit();
  FILE* read = std::fopen(capture_path, "rb");
  Check(read != nullptr, "complete actual capture WAV can be reopened");
  if (read) {
    std::vector<uint8_t> bytes(44 + 14846 * 4);
    const size_t received = std::fread(bytes.data(), 1, bytes.size(), read);
    const bool end = std::fgetc(read) == EOF;
    std::fclose(read);
    Check(received == bytes.size() && end && std::memcmp(bytes.data(), "RIFF", 4) == 0,
          "actual capture retains its exact stereo PCM WAV length and header");
    bool equal = true;
    for (size_t i = 0; i < 14846; ++i) {
      // Independent integer rounding; this bounded amplitude has no half ties.
      // Actual capture uses float clamp/lrint.
      int64_t product = i < original.size() ? int64_t(original[i]) * 32767 : 0;
      const int16_t expected = static_cast<int16_t>(product < 0 ?
          -((-product + 16384) / 32768) : (product + 16384) / 32768);
      for (size_t channel = 0; channel < 2; ++channel) {
        int16_t actual;
        std::memcpy(&actual, bytes.data() + 44 + (i * 2 + channel) * 2, 2);
        equal &= actual == expected;
      }
    }
    Check(equal, "actual capture writes every prepared tone frame without an inserted interruption");
    Check(Analyze(capture_path) == 0, "unchanged production Analyze reads the actual capture output");
  }
  track->Release();
}
}

int main(int argc, char** argv) {
  const char* selected = argc > 1 ? argv[1] : "all";
  capture_path = argc > 2 ? argv[2] : nullptr;
  const std::pair<const char*, void (*)()> cases[] = {
      {"gap", Gap}, {"complete", RealWaitComplete}, {"retained", RetainedTail},
      {"interrupt", PartialAndInterrupt}, {"shrink", ShrinkAndWrap},
      {"epoch", EpochControl}, {"progress", ProgressControl},
      {"multiple", MultipleWaiters}, {"partial", PartialWaiters},
      {"spurious", SpuriousWake}, {"release", ReleaseWhileBorrowed}, {"cancel", Cancellation},
      {"unchanged", TrueUnderrunAndNonblocking}, {"reference", ReferenceStreams},
      {"capture", CapturePipeline}};
  bool found = false;
  for (auto [name, run] : cases) {
    if (std::strcmp(selected, "all") != 0 && std::strcmp(selected, name) != 0) continue;
    found = true;
    run();
  }
  if (!found) return 2;
  std::printf("blocked audio write contracts: %d checks, %d failures\n", checks, failures);
  return failures ? 1 : 0;
}
