from pathlib import Path
import hashlib, json, shlex, subprocess

root = Path(__file__).resolve().parent
repo = root / 'gesher-media-audio-refill'
base = 'bcfb5044029d486e17138dc417f3ced81524cf3f'
old = root / 'media-audio-refill-windows'
out = root / 'media-audio-refill-main-windows'
(out / 'baseline').mkdir(parents=True, exist_ok=True)
for name in ['engine.cc', 'engine.h', 'sink.h']:
    (out / 'baseline' / name).write_bytes(subprocess.check_output(
        ['git', 'show', base + ':compat/media/audio/' + name], cwd=repo))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = []
for previous in json.loads((old / 'receipt.json').read_text())['results']:
    command = [arg.replace(str(old), str(out)) for arg in previous['command']]
    path = Path(command[command.index('-c') + 1])
    obj = Path(command[command.index('-o') + 1])
    dep = Path(command[command.index('-MF') + 1])
    run = subprocess.run(command, cwd=repo, text=True, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, timeout=120)
    label = previous['arch'] + '-' + previous['variant']
    (out / (label + '.log')).write_text(run.stdout)
    actual = []
    if run.returncode == 0:
        paths = shlex.split(dep.read_text().split(':', 1)[1].replace('\\\n', ' '))
        for name in paths:
            p = Path(name).resolve()
            actual.append({'path': str(p), 'sha256': sha(p)})
            if previous['variant'] == 'baseline' and p.is_relative_to(repo):
                relative = str(p.relative_to(repo))
                expected = subprocess.check_output(['git', 'show', base + ':' + relative], cwd=repo)
                assert expected == p.read_bytes(), relative
    results.append({'arch': previous['arch'], 'variant': previous['variant'],
                    'source_sha256': sha(path), 'command': command,
                    'returncode': run.returncode, 'diagnostic': run.stdout,
                    'object_sha256': sha(obj) if obj.exists() else None,
                    'actual_inputs': actual})
    print(label, run.returncode, flush=True)
    assert run.returncode == 0, run.stdout
(out / 'receipt.json').write_text(json.dumps({
    'base': base, 'scope': 'Complete current-main engine.cc baseline and candidate, runtime logging branch; current-main media_probe.cc standalone. Strict Windows x64 and AArch64 compile only, no DLL or runtime claim.',
    'results': results}, indent=2) + '\n')
