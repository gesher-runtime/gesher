#include "pthread_key_measurement.h"
#include "pthread_cleanup.h"
#include <atomic>
#include <mutex>
#include <pthread.h>
#include <vector>
namespace gesher::bionic {
namespace {
uint64_t g_measure_locks = 0;
constexpr int kKeysMax = 128;         // bionic's PTHREAD_KEYS_MAX
constexpr int kDestructorPasses = 4;  // PTHREAD_DESTRUCTOR_ITERATIONS

std::mutex g_keys_mutex;
void (BIONIC_SYSV* g_key_dtors[kKeysMax])(void*) = {};
bool g_key_used[kKeysMax] = {};
// A reused key slot must not expose another generation's thread-local value.
// Retire a slot at UINT64_MAX rather than letting its generation wrap.
uint64_t g_key_generations[kKeysMax] = {};
thread_local void* t_key_values[kKeysMax] = {};
thread_local uint64_t t_key_generations[kKeysMax] = {};

struct ThreadAtExit {
  void (BIONIC_SYSV* dtor)(void*);
  void* obj;
};
thread_local std::vector<ThreadAtExit>* t_thread_atexit = nullptr;
thread_local CleanupStack t_cleanups;

// C++ thread_local destructors, last registered first (as bionic).
void RunThreadAtExit() {
  if (t_thread_atexit == nullptr) return;
  while (!t_thread_atexit->empty()) {
    ThreadAtExit e = t_thread_atexit->back();
    t_thread_atexit->pop_back();
    e.dtor(e.obj);
  }
  delete t_thread_atexit;
  t_thread_atexit = nullptr;
}

// One round of key destructors: each key set when the round reaches it, once.
// Returns whether any destructor ran.
bool RunKeyRound() {
  bool any = false;
  for (int k = 0; k < kKeysMax; ++k) {
    void* value = t_key_values[k];
    if (value == nullptr) continue;
    void (BIONIC_SYSV* dtor)(void*) = nullptr;
    {
      std::lock_guard<std::mutex> lock(g_keys_mutex);
      if (g_key_used[k] && t_key_generations[k] == g_key_generations[k]) {
        dtor = g_key_dtors[k];
      }
    }
    t_key_values[k] = nullptr;
    t_key_generations[k] = 0;
    if (dtor != nullptr) {
      dtor(value);
      any = true;
    }
  }
  return any;
}

void RunThreadExit() {
  t_cleanups.Run();
  RunThreadAtExit();
  for (int pass = 0; pass < kDestructorPasses; ++pass) {
    if (!RunKeyRound()) break;
  }
}


struct ThreadRecord {};
thread_local ThreadRecord* t_record = nullptr;
pthread_key_t g_host_exit_key;
std::once_flag g_host_exit_once;
thread_local int t_host_exit_rounds = -1;  // -1: not armed on this thread

void HostExitRound(void*) {
  ++t_host_exit_rounds;
  t_cleanups.Run();
  RunThreadAtExit();
  RunKeyRound();
}

void ArmHostExit() {
  if (t_record != nullptr) return;
  if (t_host_exit_rounds < 0) {
    std::call_once(g_host_exit_once,
                   [] { pthread_key_create(&g_host_exit_key, HostExitRound); });
    t_host_exit_rounds = 0;
  } else if (t_host_exit_rounds == 0 || t_host_exit_rounds >= kDestructorPasses) {
    return;
  }
  // Armed, or set again while the thread exits: its destructor runs next round.
  pthread_setspecific(g_host_exit_key, &t_host_exit_rounds);
}


}
extern "C" {
int BIONIC_SYSV gesher_bionic_pthread_key_create(bionic_pthread_key_t* key,
                                                void (BIONIC_SYSV* dtor)(void*)) {
  std::lock_guard<std::mutex> lock(g_keys_mutex);
  for (int i = 0; i < kKeysMax; ++i) {
    if (!g_key_used[i] && g_key_generations[i] != UINT64_MAX) {
      ++g_key_generations[i];
      g_key_used[i] = true;
      g_key_dtors[i] = dtor;
      *key = i;
      return 0;
    }
  }
  return kEAGAIN;
}

int BIONIC_SYSV gesher_bionic_pthread_key_delete(bionic_pthread_key_t key) {
  if (key < 0 || key >= kKeysMax) return kEINVAL;
  std::lock_guard<std::mutex> lock(g_keys_mutex);
  if (!g_key_used[key]) return kEINVAL;
  g_key_used[key] = false;
  g_key_dtors[key] = nullptr;
  return 0;
}

void* BIONIC_SYSV gesher_bionic_pthread_getspecific(bionic_pthread_key_t key) {
  if (key < 0 || key >= kKeysMax) return nullptr;
  std::lock_guard<std::mutex> lock(g_keys_mutex);
  if (!g_key_used[key] || t_key_generations[key] != g_key_generations[key]) {
    t_key_values[key] = nullptr;
    t_key_generations[key] = 0;
    return nullptr;
  }
  return t_key_values[key];
}

int BIONIC_SYSV gesher_bionic_pthread_setspecific(bionic_pthread_key_t key, const void* value) {
  if (key < 0 || key >= kKeysMax) return kEINVAL;
  {
    std::lock_guard<std::mutex> lock(g_keys_mutex);
    if (!g_key_used[key]) return kEINVAL;
    t_key_values[key] = const_cast<void*>(value);
    t_key_generations[key] = g_key_generations[key];
  }
  if (value != nullptr) ArmHostExit();
  return 0;
}

// C++ thread_local destructors (libc++abi calls this for every thread_local
// object with a destructor). Run when the thread ends, before its keys.
int BIONIC_SYSV gesher_bionic_cxa_thread_atexit_impl(void (BIONIC_SYSV* dtor)(void*), void* obj,
                                                    void* /*dso*/) {
  if (t_thread_atexit == nullptr) t_thread_atexit = new std::vector<ThreadAtExit>();
  t_thread_atexit->push_back({dtor, obj});
  ArmHostExit();
  return 0;
}


}
uint64_t KeyMeasureRegistryLocks() { return g_measure_locks; }
size_t KeyMeasureGlobalArrays() {
  return sizeof(g_key_dtors) + sizeof(g_key_generations) + sizeof(g_key_used);
}
size_t KeyMeasureLocalArrays() { return sizeof(t_key_values) + sizeof(t_key_generations); }
bool KeyMeasureInstrumented() { return false; }
// Keep the complete real explicit-exit body in this source unit as well.
void KeyMeasureExplicitExit() { RunThreadExit(); }
}
