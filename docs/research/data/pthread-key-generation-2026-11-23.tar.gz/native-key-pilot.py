#!/usr/bin/env python3
"""Exploratory complete key-lifecycle workload; not a release benchmark."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK / 'gesher-native-pthread-key'
OUT = WORK / 'native-key-pilot'
spec = importlib.util.spec_from_file_location('key_contract', ROOT / 'tools/test_bionic_key_contracts.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

BENCH = r'''
using MeasureGet = void* (*)(int32_t);
static MeasureGet volatile measured_get = gesher_bionic_pthread_getspecific;
struct alignas(64) ReaderResult { uint64_t verified = 0; bool ok = true; };
static uint64_t process_ns() {
  timespec now{};
  if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &now) != 0) std::abort();
  return uint64_t(now.tv_sec) * 1000000000 + uint64_t(now.tv_nsec);
}
static uint64_t wall_ns() {
  return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count());
}
static void measure_round(const char* name, int readers, bool distinct, size_t reads, bool churn, int groups) {
  const uint64_t cpu = process_ns(), wall = wall_ns();
  uint64_t verified = 0;
  for (int group = 0; group < groups; ++group) {
    const int key_count = distinct ? readers : 1;
    std::array<int32_t, 32> keys{};
    for (int k = 0; k < key_count; ++k)
      if (gesher_bionic_pthread_key_create(&keys[k], nullptr) != 0) std::abort();
    std::array<ReaderResult, 32> results{};
    std::array<std::thread, 32> threads;
    std::barrier start(readers + 1 + int(churn));
    for (int i = 0; i < readers; ++i) {
      threads[i] = std::thread([&, i] {
        auto& result = results[i];
        const auto key = keys[distinct ? i : 0];
        if (gesher_bionic_pthread_setspecific(key, &result) != 0) std::abort();
        start.arrive_and_wait();
        for (size_t n = 0; n < reads; ++n) {
          if (measured_get(key) != &result) result.ok = false;
          ++result.verified;
        }
      });
    }
    std::thread writer;
    if (churn) writer = std::thread([&] {
      start.arrive_and_wait();
      for (int n = 0; n < 2000; ++n) {
        int32_t key = -1;
        if (gesher_bionic_pthread_key_create(&key, nullptr) != 0 ||
            gesher_bionic_pthread_key_delete(key) != 0) std::abort();
      }
    });
    start.arrive_and_wait();
    for (int i = 0; i < readers; ++i) {
      threads[i].join();
      if (!results[i].ok || results[i].verified != reads) std::abort();
      verified += results[i].verified;
    }
    if (churn) writer.join();
    for (int k = 0; k < key_count; ++k)
      if (gesher_bionic_pthread_key_delete(keys[k]) != 0) std::abort();
  }
  const uint64_t cpu_elapsed = process_ns() - cpu, wall_elapsed = wall_ns() - wall;
  std::printf("KEY_PILOT %s readers=%d groups=%d verified=%llu cpu_ns=%llu wall_ns=%llu\n",
              name, readers, groups, (unsigned long long)verified,
              (unsigned long long)cpu_elapsed, (unsigned long long)wall_elapsed);
}
static void measure_key_pilot() {
  measure_round("single", 1, false, 250000, false, 1);
  measure_round("shared8", 8, false, 31250, false, 1);
  measure_round("distinct8", 8, true, 31250, false, 1);
  measure_round("distinct32", 32, true, 7812, false, 1);
  measure_round("churn8", 8, false, 31250, true, 1);
  measure_round("lifecycle-control", 8, true, 0, false, 32);
}
'''


def generate(source, target):
    template = (ROOT / 'tests/native/pthread_key_contract_host_test.cc.in').read_text()
    template = '#include <array>\n#include <atomic>\n#include <barrier>\n#include <chrono>\n#include <cstdlib>\n' + template
    parts = {
        '@KEY_STATE_AND_EXIT@': mod.section(source, 'constexpr int kKeysMax', '// --- threads'),
        '@KEY_HOST_EXIT@': mod.section(source, 'pthread_key_t g_host_exit_key;', 'struct StartArg'),
        '@KEY_API@': mod.section(source, 'int BIONIC_SYSV gesher_bionic_pthread_key_create(',
                                'int BIONIC_SYSV gesher_bionic_register_atfork('),
        '@KEY_REGISTRATIONS@': '\n'.join('  P(' + name + ');' for name in
            ('pthread_key_create', 'pthread_key_delete', 'pthread_getspecific', 'pthread_setspecific')),
    }
    for marker, value in parts.items():
        assert template.count(marker) == 1
        template = template.replace(marker, value)
    template = template.replace('int main(int argc, char** argv) {', BENCH + '\nint main(int argc, char** argv) {')
    template = template.replace('else return 2;\n  return failures',
                                'else if (std::strcmp(argv[1], "measure") == 0) measure_key_pilot();\n  else return 2;\n  return failures')
    target.write_text(template)


def main():
    OUT.mkdir(exist_ok=True)
    variants = [('before', (WORK / 'native-key-baseline/pthread_bionic.cc').read_text()),
                ('after', (ROOT / 'compat/bionic/pthread_bionic.cc').read_text())]
    receipts = []
    for name, source in variants:
        output = OUT / (name + '.cc')
        generate(source, output)
        command = ['g++', '-std=c++20', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
                   '-fno-exceptions', '-fno-builtin', '-pthread', '-DHAVE_KEY_GENERATIONS',
                   '-I', str(ROOT / 'compat/bionic'), '-I', str(ROOT / 'compat/arm64/include'),
                   '-I', str(ROOT / 'tests/native'), str(output), '-o', str(OUT / name)]
        subprocess.run(command, check=True)
        receipts.append({'variant': name, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
            'generated_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'command': command,
            'binary_sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()})
    (OUT / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')


if __name__ == '__main__':
    main()
