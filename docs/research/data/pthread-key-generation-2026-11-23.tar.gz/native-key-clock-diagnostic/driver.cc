// Complete source-component measurement: actual key creation, actual host
// pthread TLS exit, per-thread value checks and retirement are inside the clock.
// This does not execute Windows thread registration, ART or guest ELF loading.
#include "pthread_key_measurement.h"

#include <array>
#include <barrier>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <time.h>

using namespace gesher::bionic;

namespace {
struct Workload {
  const char* name;
  int readers;
  bool distinct;
  size_t reads;
  size_t churn;
  int groups;
  size_t mutations;
};

constexpr Workload kWorkloads[] = {
    {"cold-single", 1, false, 1, 0, 1, 0},
    {"single", 1, false, 1000000, 0, 1, 0},
    {"shared8", 8, false, 125000, 0, 1, 0},
    {"distinct8", 8, true, 125000, 0, 1, 0},
    {"distinct32", 32, true, 31250, 0, 1, 0},
    {"churn8", 8, false, 125000, 4000, 1, 0},
    {"tiny-lifecycle", 8, true, 1, 0, 64, 0},
    {"no-read-lifecycle", 8, true, 0, 0, 64, 0},
    {"mutation-control", 0, false, 0, 0, 0, 40000},
};

void Require(bool condition) {
  if (!condition) {
    std::fputs("pthread key measurement ownership/value assertion failed\n", stderr);
    std::abort();
  }
}

uint64_t ProcessNs() {
  timespec time{};
  Require(clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time) == 0);
  return uint64_t(time.tv_sec) * 1000000000 + uint64_t(time.tv_nsec);
}

uint64_t ThreadNs() {
  timespec value{};
  Require(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value) == 0);
  return uint64_t(value.tv_sec) * 1000000000 + uint64_t(value.tv_nsec);
}

uint64_t WallNs() {
  return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count());
}

struct alignas(64) ReaderResult {
  size_t verified = 0;
  unsigned exits = 0;
  uint64_t cpu_start = 0, cpu_to_destructor = 0;
  bool valid = true;
};

void BIONIC_SYSV ReaderExit(void* value) {
  ReaderResult& result = *static_cast<ReaderResult*>(value);
  ++result.exits;
  result.cpu_to_destructor = ThreadNs() - result.cpu_start;
}

void Run(const Workload& work, int sample) {
  // Counted and uninstrumented executables are separate. Never use the counted
  // binary's time as the CPU evidence for this change.
  const uint64_t locks_before = KeyMeasureRegistryLocks();
  const uint64_t cpu_start = ProcessNs(), wall_start = WallNs();
  uint64_t verified = 0, exits = 0, worker_cpu_ns = 0;
  for (int group = 0; group < work.groups; ++group) {
    const int key_count = work.distinct ? work.readers : 1;
    std::array<bionic_pthread_key_t, 32> keys{};
    for (int k = 0; k < key_count; ++k)
      Require(gesher_bionic_pthread_key_create(&keys[k], ReaderExit) == 0);
    std::array<ReaderResult, 32> results{};
    std::array<std::thread, 32> threads;
    std::barrier start(work.readers + 1 + int(work.churn != 0));
    for (int i = 0; i < work.readers; ++i) {
      threads[i] = std::thread([&, i] {
        ReaderResult& result = results[i];
        result.cpu_start = ThreadNs();
        const auto key = keys[work.distinct ? i : 0];
        Require(gesher_bionic_pthread_setspecific(key, &result) == 0);
        start.arrive_and_wait();
        errno = 123;
        for (size_t n = 0; n < work.reads; ++n) {
          if (gesher_bionic_pthread_getspecific(key) != &result) result.valid = false;
          ++result.verified;
        }
        if (errno != 123) result.valid = false;
      });
    }
    std::thread writer;
    if (work.churn) writer = std::thread([&] {
      start.arrive_and_wait();
      for (size_t n = 0; n < work.churn; ++n) {
        bionic_pthread_key_t key = -1;
        Require(gesher_bionic_pthread_key_create(&key, nullptr) == 0);
        Require(gesher_bionic_pthread_key_delete(key) == 0);
      }
    });
    start.arrive_and_wait();
    for (int i = 0; i < work.readers; ++i) {
      threads[i].join();
      Require(results[i].valid && results[i].verified == work.reads && results[i].exits == 1);
      verified += results[i].verified;
      exits += results[i].exits;
      worker_cpu_ns += results[i].cpu_to_destructor;
    }
    if (work.churn) writer.join();
    for (int k = 0; k < key_count; ++k)
      Require(gesher_bionic_pthread_key_delete(keys[k]) == 0);
  }
  for (size_t n = 0; n < work.mutations; ++n) {
    bionic_pthread_key_t key = -1;
    Require(gesher_bionic_pthread_key_create(&key, nullptr) == 0);
    Require(gesher_bionic_pthread_setspecific(key, &verified) == 0);
    Require(gesher_bionic_pthread_setspecific(key, nullptr) == 0);
    Require(gesher_bionic_pthread_key_delete(key) == 0);
  }
  const uint64_t cpu_ns = ProcessNs() - cpu_start, wall_ns = WallNs() - wall_start;
  const uint64_t locks = KeyMeasureRegistryLocks() - locks_before;
  Require(verified == work.reads * work.readers * work.groups);
  Require(exits == uint64_t(work.readers * work.groups));
  std::printf("{\"case\":\"%s\",\"sample\":%d,\"verified\":%llu,\"exits\":%llu,"
              "\"worker_cpu_ns\":%llu,\"cpu_ns\":%llu,\"wall_ns\":%llu,\"registry_locks\":%llu,"
              "\"global_array_bytes\":%zu,\"thread_array_bytes\":%zu,\"instrumented\":%s}\n",
              work.name, sample, static_cast<unsigned long long>(verified),
              static_cast<unsigned long long>(exits), static_cast<unsigned long long>(worker_cpu_ns), static_cast<unsigned long long>(cpu_ns),
              static_cast<unsigned long long>(wall_ns), static_cast<unsigned long long>(locks),
              KeyMeasureGlobalArrays(), KeyMeasureLocalArrays(),
              KeyMeasureInstrumented() ? "true" : "false");
  std::fflush(stdout);
}
}

int main(int argc, char** argv) {
  int samples = 10;
  if (argc == 2) {
    char* end = nullptr;
    const long requested = std::strtol(argv[1], &end, 10);
    if (end == argv[1] || *end != '\0' || requested < 1 || requested > 100) return 2;
    samples = static_cast<int>(requested);
  } else if (argc != 1) return 2;
  // The first stream is once per fresh process, before any warm-up. Every other
  // case retains sample0 and sample1 as declared warm-up observations.
  Run(kWorkloads[0], 0);
  for (size_t i = 1; i < std::size(kWorkloads); ++i)
    for (int sample = 0; sample < samples; ++sample) Run(kWorkloads[i], sample);
  return 0;
}
