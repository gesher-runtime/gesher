# pthread key evidence archive

Every path is relative to the original shared workspace. `current-source/`
contains the final measured/replayed source inputs. Build receipts identify the
compiler, complete commands, generated sources and binary hashes. Executable
binaries and object files are not shipped; rebuild the final benchmark using
the maintained helper in the PR. All final/original/pilot process stdout is
retained next to its JSON receipt. Each stdout hash can be checked against the
corresponding process record.

`native-key-observed-final-abba.json` is the final isolated-workload campaign.
`native-key-final-abba.json` is the earlier UNQUALIFIED process-only CPU campaign;
do not combine its numbers with the final CPU measurements. Its original C++
driver was recovered from the preserved diagnostic variant and verified byte
for byte against the original build receipt hash (`original-measurement.cc`).
The original Python orchestrator's hash and actual executed commands/order are
in its receipt; its old source is not represented as the final helper.

`native-key-clock-diagnostic/` retains the actual diagnostic C++ inputs and
stdout, including a longer complete 64-lifecycle observation. Those diagnostic
and pilot runs were not final quiet-window performance qualification. The
earliest pilot source and all four observations are retained under
`native-key-pilot/`; later complete-workload evidence supersedes it.

`MANIFEST.json` hashes all other members. The adjacent report JSON hashes this
complete archive. No member has been silently removed for an adverse result.
