param([string]$SourceRoot = (Join-Path $PSScriptRoot 'gesher-native-pr298-tsf'))
$ErrorActionPreference = 'Stop'
$root = $SourceRoot
Add-Type -Path @((Join-Path $root 'tools/windows4/TsfJobSupervisor.cs'), (Join-Path $root 'tools/windows4/TsfOutputMetadataChecks.cs'))
$tokens = $null
$errors = $null
[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'tools/windows4/test-tsf-job-supervisor.ps1'), [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw ($errors | Out-String) }
if ($env:GITHUB_ACTIONS -ceq 'true') { throw 'Host compile receipt must not impersonate GitHub Actions' }
$rejected = $false
try { [TsfOutputMetadataChecks]::Run('/unreachable-native-control') }
catch { $rejected = $_.Exception.InnerException -is [InvalidOperationException] -and $_.Exception.InnerException.Message -ceq 'CI only' }
if (-not $rejected) { throw 'Actual native control lacks its CI guard' }
if (-not $IsLinux) { throw 'Missing-kernel primary-error control requires this Linux host' }
$captured = [IO.StringWriter]::new()
$originalError = [Console]::Error
$primaryObserved = $false
$cleanupObserved = $false
$nativeFailure = $null
try {
  [Console]::SetError($captured)
  try {
    try {
      $probe = [TsfOutputMetadataChecks].GetMethod('Probe', [Reflection.BindingFlags]'NonPublic,Static')
      [void]$probe.Invoke($null, @('/unreachable-native-output', $false))
    } catch {
      $nativeFailure = $_.Exception
      while ($null -ne $nativeFailure.InnerException) { $nativeFailure = $nativeFailure.InnerException }
      $primaryObserved = $nativeFailure.StackTrace.Contains('TsfOutputMetadataChecks.CreateFile')
      throw
    } finally {
      # Only the outer cleanup error is modeled here. The primary exception
      # and its logging execute the complete current C# fixture unchanged.
      throw 'outer-cleanup-sentinel'
    }
  } catch { $cleanupObserved = $_.Exception.Message -ceq 'outer-cleanup-sentinel' }
} finally { [Console]::SetError($originalError) }
try {
  if (-not $primaryObserved -or -not $cleanupObserved -or
      -not $captured.ToString().Contains('TSF_SIZE_OBSERVER_FAILURE') -or
      $null -eq $nativeFailure -or
      -not $captured.ToString().Contains($nativeFailure.GetType().FullName) -or
      -not $captured.ToString().Contains($nativeFailure.Message)) {
    throw 'Original native failure evidence was hidden by a later cleanup failure'
  }
} finally { $captured.Dispose() }
Write-Output 'PASS complete supervisor and actual native control compile; original PowerShell entry parses; native CI-only guard rejects this host'
Write-Output ('PASS original host native-resolution primary exception remains logged when a modeled outer cleanup error replaces the thrown exception: ' + $nativeFailure.GetType().FullName)
Write-Output 'WINDOWS EXECUTION NOT PERFORMED: file-object pending-I/O controls require the existing Windows CI controller job'
