# TSF output observation evidence

Original Windows failure and paired success are retained unedited. Source-proof.json
pins their full controller inputs to public main and the exact candidate source.
The candidate C# files add real Windows controls but no local Windows result is claimed.

On Linux with PowerShell7.5.4, run `pwsh -NoProfile -NonInteractive -File test-host.ps1
-SourceRoot /absolute/path/to/the/candidate/checkout` to compile the complete types,
parse the entry and check diagnostic preservation across a modeled outer cleanup
failure. The current fixture's real missing native-library resolution is exercised;
this does not execute Win32 I/O. The mutant removes only the logged primary failure.
Earlier host-harness expectation errors are retained as rejected runs, not accepted
native evidence. Reproduce the real Windows controls through the unchanged required
controller job in a manually dispatched full ci.yml on the published branch.
