#!/usr/bin/env python3
"""Verify the exact TSF source-policy integration without changing its owners."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'gesher-native-tsf-common'
PARENT = '8d955bd7b6ec85b84fa31f7df685197ddb963276'
BASE = '3b2eaca95b5ddd9cee3c3db4e430460e512eb355'
POLICY = 'tools/net-tcp-priority/test-selected-policy.py'
QUALIFIED = 'tools/net-tcp-priority/qualified/'


def git(*args):
    return subprocess.check_output(['git', '-C', str(WORK), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


checks = 0
before = git('show', PARENT + ':' + POLICY)
after = (WORK / POLICY).read_bytes()
start = after.index(b'# The independently reviewed TSF repair gives output-size queries')
end = after.index(b'REVIEWED_PATHS=', start)
reconstructed = after[:start] + after[end:]
for addition in [b' preceding.update(preceding_tsf_metadata_sources())\n',
                 b"  runpy.run_path(str(ROOT/'tools/net-tcp-priority/test-tsf-metadata-policy.py'),run_name='__main__')\n"]:
    assert reconstructed.count(addition) == 1
    reconstructed = reconstructed.replace(addition, b'', 1)
assert reconstructed == before
checks += 3

original_files = git('ls-tree', '-r', '--name-only', PARENT, '--', QUALIFIED).decode().splitlines()
retained = {}
for name in original_files:
    original = git('show', PARENT + ':' + name)
    current = (WORK / name).read_bytes()
    assert current == original, name
    retained[name] = sha(current)
    checks += 1
assert not git('diff', PARENT, '--', 'tools/windows4', '.github/workflows', 'compat', 'app')
checks += 1

manifest = json.loads((WORK / (QUALIFIED + 'tsf-output-metadata-source.json')).read_text())
patch = (WORK / (QUALIFIED + 'tsf-output-metadata-source.patch')).read_bytes()
assert patch == git('diff', '--full-index', '--no-ext-diff', '--no-renames', BASE, PARENT,
                    '--', *manifest['paths'])
checks += 1
sources = {}
for name in [*manifest['paths'], *manifest['additional_sources']]:
    current = (WORK / name).read_bytes()
    assert current == git('show', PARENT + ':' + name)
    sources[name] = sha(current)
    checks += 1
index_path = 'docs/research/tsf-output-observation-2026-11-23.json'
old_index = json.loads(git('show', PARENT + ':' + index_path))
current_index = json.loads((WORK / index_path).read_bytes())
assert all(current_index[name] == value for name, value in old_index.items())
archive_path = 'docs/research/' + old_index['archive']['path']
assert (WORK / archive_path).read_bytes() == git('show', PARENT + ':' + archive_path)
assert sha((WORK / archive_path).read_bytes()) == old_index['archive']['sha256']
checks += len(old_index) + 2

result = {'parent': PARENT, 'baseline': BASE, 'checks': checks,
          'original_policy_sha256': sha(before), 'current_policy_sha256': sha(after),
          'original_policy_reconstructed_exactly': True,
          'runtime_windows_fixture_workflow_bytes_changed': False,
          'original_qualification_files': retained,
          'controller_and_windows_sources': sources,
          'patch_is_exact_published_feature_diff': True,
          'manifest_sha256': sha((WORK / (QUALIFIED + 'tsf-output-metadata-source.json')).read_bytes()),
          'patch_sha256': sha(patch),
          'original_index_fields_preserved': len(old_index),
          'original_archive_sha256': old_index['archive']['sha256'],
          'native_execution_or_runtime_approval': False}
(ROOT / 'pr393-policy-followup-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
