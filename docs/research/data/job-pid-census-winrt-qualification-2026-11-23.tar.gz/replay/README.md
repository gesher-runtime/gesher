# Actual WinRT source-gate replay

Use a checkout containing the published parent and the repaired workflow. The replay uses its real Git history and source files, then copies all twelve inputs into a temporary real Git repository for mutation controls.

```sh
python3 media_pr405_qualify_sources.py --repo /path/to/repaired-checkout --out /path/to/new-output --pwsh /path/to/pwsh
```

Expected: 48 checks, eight PowerShell invocations. The original gate must fail; the current and isolated current gates pass; four source mutations and wrong checkout identity must fail their exact existing predicates. This does not run Windows APIs. Original #360 remains unresolved. The retained early relative PowerShell-path setup failure was corrected in the replay runner only.
