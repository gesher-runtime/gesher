#!/usr/bin/env python3
"""Replay the actual WinRT identity step; mutate only isolated copied inputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "gesher-media-pid-census-ci"
OUT = ROOT / "media-pr405-winrt-qualification"
PWSH = ROOT / "toolchains/powershell-7.5.4/pwsh"
WORKFLOW = ".github/workflows/services-geocoder-worker-component.yml"
PUBLISHED = "218b735e6c9a67a50124f50063c9dc672d6393be"
HELPER = "tests/windows/helpers/geocoder-compile.ps1"
NEW = ("tests/windows/helpers/pid-census-exit-probe.ps1",
       "tests/windows/helpers/PidCensusExitProbe.cs")
checks = 0


def check(value, message):
    global checks
    checks += 1
    if not value:
        raise AssertionError(message)


def git(*args, cwd=None):
    return subprocess.check_output(["git", *args], cwd=REPO if cwd is None else cwd)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def gate(text):
    start = text.index("          if ((git rev-parse HEAD)")
    end = text.index("\n      - name: Exercise actual WinRT", start)
    return "\n".join(line[10:] for line in text[start:end].splitlines()) + "\n"


def pins(text):
    return dict(re.findall(r"^\s*'([^']+)' = '([0-9a-f]{40})'$", text, re.M))


def run(label, script, repo, identity, expected=None):
    path = OUT / (label + ".ps1")
    path.write_text(script)
    env = os.environ.copy()
    env["GITHUB_SHA"] = identity
    proc = subprocess.run([str(PWSH), "-NoProfile", "-File", str(path)],
                          cwd=repo, env=env, capture_output=True, text=True)
    log = proc.stdout + proc.stderr
    (OUT / (label + ".log")).write_text(log)
    if expected is None:
        check(proc.returncode == 0, label + " gate must pass")
        check(log.count("WINRT_SOURCE ") == 12, label + " checks all twelve inputs")
    else:
        check(proc.returncode != 0, label + " gate must reject")
        check(expected in log, label + " exact assertion")
    return {"label": label, "returncode": proc.returncode,
            "expected_failure": expected, "script_sha256": sha(script.encode()),
            "log": os.path.relpath(OUT / (label + ".log"), ROOT),
            "log_sha256": sha(log.encode())}


def main():
    global REPO, OUT, PWSH
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=REPO)
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--pwsh", type=Path, default=PWSH)
    args = parser.parse_args()
    REPO, OUT = args.repo.resolve(), args.out.resolve()
    PWSH = Path(shutil.which(str(args.pwsh)) or str(args.pwsh)).resolve()
    OUT.mkdir(exist_ok=True)
    old = git("show", PUBLISHED + ":" + WORKFLOW).decode()
    new = (REPO / WORKFLOW).read_text()
    old_pins, new_pins = pins(old), pins(new)
    check(len(old_pins) == 10 and len(new_pins) == 12, "ten original plus two diagnostic pins")
    check(set(new_pins) == set(old_pins) | set(NEW), "exact source inventory")
    check([p for p in old_pins if old_pins[p] != new_pins[p]] == [HELPER],
          "only the reviewed helper's original pin changes")
    for path, expected in new_pins.items():
        raw = (REPO / path).read_bytes()
        check(blob(raw) == expected, "exact actual Git blob " + path)
        if path in old_pins and path != HELPER:
            check(expected == old_pins[path], "preserved original pin " + path)
    helper = (REPO / HELPER).read_bytes()
    call = b"  & (Join-Path $PSScriptRoot 'pid-census-exit-probe.ps1')\n"
    check(helper.count(call) == 1, "sole reviewed diagnostic invocation")
    restored = helper.replace(call, b"", 1)
    check(blob(restored) == old_pins[HELPER], "exact original helper recovered")
    check(restored == git("show", "e505ad227523aaca566d05b8af6e466495c819cc:" + HELPER),
          "original helper equals published main baseline")

    # Ignore only literal pin rows and comments: all actual workflow steps,
    # checkout validation, hashes, logging and runtime invocation stay exact.
    def skeleton(text):
        return "\n".join(line for line in text.splitlines()
                         if not line.lstrip().startswith("#")
                         and not re.match(r"^\s*'[^']+' = '[0-9a-f]{40}'$", line))
    check(skeleton(old) == skeleton(new), "all original executable predicates and steps retained")
    for path in (*NEW, HELPER, "tools/windows4/TsfJobSupervisor.cs"):
        check((REPO/path).read_bytes() == git("show", PUBLISHED + ":" + path),
              "published runtime/diagnostic bytes unchanged " + path)

    identity = git("rev-parse", "HEAD").decode().strip()
    runs = [run("original-gate-negative", gate(old), REPO, identity,
                "WinRT source mismatch: " + HELPER),
            run("current-gate", gate(new), REPO, identity)]
    with tempfile.TemporaryDirectory(prefix="gesher-pid-census-source-") as temp:
        copy = Path(temp)
        for path in new_pins:
            (copy/path).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(REPO/path, copy/path)
        subprocess.run(["git", "init", "-q", str(copy)], check=True)
        subprocess.run(["git", "add", "."], cwd=copy, check=True)
        subprocess.run(["git", "-c", "user.name=Source qualification",
                        "-c", "user.email=source-qualification@example.invalid",
                        "commit", "-qm", "Exact isolated source inputs"], cwd=copy, check=True)
        head = git("rev-parse", "HEAD", cwd=copy).decode().strip()
        runs.append(run("isolated-current-gate", gate(new), copy, head))
        for index, path in enumerate((HELPER, *NEW, "tests/windows/tracks/geocoder-operation.ps1")):
            target = copy/path
            raw = target.read_bytes()
            try:
                target.write_bytes(raw + b"\nsource-drift-negative\n")
                runs.append(run(f"changed-input-{index}", gate(new), copy, head,
                                "WinRT source mismatch: " + path))
            finally:
                target.write_bytes(raw)
        runs.append(run("wrong-checkout", gate(new), copy, "0"*40,
                        "WinRT checkout identity mismatch"))

    proof = {"published_parent": PUBLISHED, "workflow": WORKFLOW,
             "original_workflow_sha256": sha(old.encode()), "current_workflow_sha256": sha(new.encode()),
             "original_pins": old_pins, "current_pins": new_pins,
             "unchanged_original_pins": 9, "new_diagnostic_pins": 2,
             "original_helper_git_blob": old_pins[HELPER],
             "current_helper_git_blob": new_pins[HELPER],
             "helper_changes_exactly_one_invocation": True, "executable_workflow_skeleton_identical": True,
             "runs": runs, "checks": checks,
             "limits": ["Actual PowerShell identity gate with real git/hash/filesystem operations.",
                        "Mutation controls use an isolated real Git repository; the source worktree is not mutated.",
                        "No Windows kernel/WinRT/provider execution occurs in this local qualification.",
                        "Original #360 PID-census failure remains unresolved; this corrects source qualification only."]}
    (OUT/"proof.json").write_text(json.dumps(proof, indent=2)+"\n")
    print(json.dumps({"checks": checks, "runs": len(runs), "proof": str(OUT/"proof.json")}, indent=2))


if __name__ == "__main__":
    main()
