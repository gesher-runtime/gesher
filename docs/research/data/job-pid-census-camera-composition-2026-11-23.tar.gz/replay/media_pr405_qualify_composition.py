#!/usr/bin/env python3
"""Qualify the exact PID-diagnostic/camera main source-pin composition."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

PUBLISHED = "904540e5c38cd87471a83668a9629da0a9788513"
MAIN = "d3076fc4d29d102ab633299d4654e85a6b261f79"
WORKFLOW = ".github/workflows/services-geocoder-worker-component.yml"
HELPER = "tests/windows/helpers/geocoder-compile.ps1"
TRACK = "tests/windows/tracks/58-devices.ps1"
NEW = ("tests/windows/helpers/pid-census-exit-probe.ps1",
       "tests/windows/helpers/PidCensusExitProbe.cs")
checks = 0


def check(value, message):
    global checks
    checks += 1
    if not value:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()


def pins(text):
    return dict(re.findall(r"^\s*'([^']+)' = '([0-9a-f]{40})'$", text, re.M))


def skeleton(text):
    return "\n".join(line for line in text.splitlines()
                     if not line.lstrip().startswith("#")
                     and not re.match(r"^\s*'[^']+' = '[0-9a-f]{40}'$", line))


def gate(text):
    start = text.index("          if ((git rev-parse HEAD)")
    end = text.index("\n      - name: Exercise actual WinRT", start)
    return "\n".join(line[10:] for line in text[start:end].splitlines()) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--pwsh", default="pwsh")
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    pwsh = Path(shutil.which(args.pwsh) or args.pwsh).resolve()
    out.mkdir(parents=True, exist_ok=True)

    def git(*arguments, cwd=None):
        return subprocess.check_output(["git", *arguments], cwd=repo if cwd is None else cwd)

    current = (repo / WORKFLOW).read_text()
    main_source = git("show", MAIN + ":" + WORKFLOW).decode()
    published = git("show", PUBLISHED + ":" + WORKFLOW).decode()
    current_pins, main_pins, old_pins = pins(current), pins(main_source), pins(published)
    expected = dict(main_pins)
    for path in (HELPER, *NEW):
        expected[path] = old_pins[path]
    check(current_pins == expected, "exact combined source inventory")
    check(len(current_pins) == 12, "all twelve real inputs qualified")
    check(skeleton(current) == skeleton(main_source), "main executable workflow retained")
    check(skeleton(current) == skeleton(published), "published executable workflow retained")
    for path, value in current_pins.items():
        check(blob((repo / path).read_bytes()) == value, "exact input " + path)
    for path in (HELPER, *NEW, "tools/windows4/TsfJobSupervisor.cs",
                 "tools/test_pid_census_exit_probe.ps1"):
        check((repo / path).read_bytes() == git("show", PUBLISHED + ":" + path),
              "diagnostic/controller source unchanged " + path)
    check((repo / TRACK).read_bytes() == git("show", MAIN + ":" + TRACK), "incoming complete device track retained")
    check((repo / ".github/workflows/ci.yml").read_bytes() == git("show", MAIN + ":.github/workflows/ci.yml"),
          "incoming complete CI and framework recipe retained")
    invocation = b"  & (Join-Path $PSScriptRoot 'pid-census-exit-probe.ps1')\n"
    helper = (repo / HELPER).read_bytes()
    check(helper.count(invocation) == 1, "one reviewed diagnostic invocation")
    check(helper.replace(invocation, b"", 1) == git("show", MAIN + ":" + HELPER),
          "exact incoming main helper recovered")

    def run(label, script, cwd, identity, expected_failure=None):
        script_path = out / (label + ".ps1")
        script_path.write_text(script)
        env = os.environ.copy()
        env["GITHUB_SHA"] = identity
        result = subprocess.run([str(pwsh), "-NoProfile", "-File", str(script_path)],
                                cwd=cwd, env=env, capture_output=True, text=True)
        log = result.stdout + result.stderr
        (out / (label + ".log")).write_text(log)
        if expected_failure is None:
            check(result.returncode == 0, label + " passes")
            check(log.count("WINRT_SOURCE ") == 12, label + " checks every input")
        else:
            check(result.returncode != 0, label + " rejects")
            check(expected_failure in log, label + " exact assertion")
        return {"label": label, "returncode": result.returncode,
                "expected_failure": expected_failure, "script_sha256": sha(script.encode()),
                "log_sha256": sha(log.encode())}

    identity = git("rev-parse", "HEAD").decode().strip()
    runs = [run("incoming-main-gate-negative", gate(main_source), repo, identity,
                "WinRT source mismatch: " + HELPER),
            run("previous-repair-gate-negative", gate(published), repo, identity,
                "WinRT source mismatch: " + TRACK),
            run("combined-current-gate", gate(current), repo, identity)]
    with tempfile.TemporaryDirectory(prefix="gesher-combined-winrt-source-") as directory:
        copy = Path(directory)
        for path in current_pins:
            (copy / path).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(repo / path, copy / path)
        subprocess.run(["git", "init", "-q", str(copy)], check=True)
        subprocess.run(["git", "add", "."], cwd=copy, check=True)
        subprocess.run(["git", "-c", "user.name=Source qualification",
                        "-c", "user.email=source-qualification@example.invalid",
                        "commit", "-qm", "Exact combined source inputs"], cwd=copy, check=True)
        head = git("rev-parse", "HEAD", cwd=copy).decode().strip()
        runs.append(run("isolated-combined-gate", gate(current), copy, head))
        for index, path in enumerate((HELPER, *NEW, TRACK, "tests/windows/tracks/geocoder-operation.ps1")):
            target = copy / path
            raw = target.read_bytes()
            try:
                target.write_bytes(raw + b"\nsource-drift-negative\n")
                runs.append(run(f"changed-input-{index}", gate(current), copy, head,
                                "WinRT source mismatch: " + path))
            finally:
                target.write_bytes(raw)
        runs.append(run("wrong-checkout", gate(current), copy, "0" * 40,
                        "WinRT checkout identity mismatch"))
    proof = {"ordered_parents": [PUBLISHED, MAIN], "workflow": WORKFLOW,
             "published_workflow_sha256": sha(published.encode()),
             "main_workflow_sha256": sha(main_source.encode()),
             "current_workflow_sha256": sha(current.encode()),
             "published_pins": old_pins, "main_pins": main_pins, "current_pins": current_pins,
             "all_executable_predicates_unchanged": True,
             "runs": runs, "checks": checks,
             "limits": ["Actual PowerShell/Git/source identity operations only; no Windows APIs execute.",
                        "Mutations affect only a temporary real Git repository.",
                        "Original #360 remains unresolved; neither this composition nor its gate replay proves a Windows runtime pass."]}
    (out / "proof.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps({"checks": checks, "runs": len(runs), "proof": str(out / "proof.json")}, indent=2))


if __name__ == "__main__":
    main()
