if ((git rev-parse HEAD) -cne $env:GITHUB_SHA -or $LASTEXITCODE -ne 0) { throw 'WinRT checkout identity mismatch' }
$expected = @{
  'tests/windows/tracks/geocoder-operation.ps1' = '75eb4cf6f9537c61ff27ec49d2a3a938c81b1618'
  'tests/windows/tracks/geocoder-probe-exit.cs' = '4927e87a71c41069bbed24be748cfd0b771583d5'
  'tests/windows/tracks/geocoder-winrt-supplier.cs' = '11da9f04efdbb98de30006b0c26e169bec6d8b19'
  'tests/windows/helpers/geocoder-provider-probe.ps1' = 'd02fc316ccaca1ac856eaeae64df6e4053da569c'
  'tests/windows/helpers/geocoder-winrt-fixture.ps1' = 'cbde2ac48b603f3cc12e544a3e42d744d9b58864'
  'tests/windows/helpers/geocoder-roslyn-worker.ps1' = '31491e2cb20bf72e78c49476c9ab874649fee6c9'
  'tests/windows/helpers/geocoder-compiler-host.ps1' = '43f5fc28e1c0a19e8d8c5e1df1a3d823f734f16f'
  'tests/windows/helpers/geocoder-compile.ps1' = '90fceedc449a2ec11dfa80809e05163c89bcf2fa'
  'tests/windows/helpers/run-geocoder-winrt-component.ps1' = '1277bcc858c9c52eb8b24476831aadb286831418'
  # The reviewed shared track includes sensor flush, current camera grant
  # admission, explicit fixture permissions and the camera callback-admission
  # gate. Its geocoder implementation and the other nine source pins are unchanged.
  'tests/windows/tracks/58-devices.ps1' = '0cddb9e852a5c96291a86255738727a27a3996cd'
}
foreach ($path in $expected.Keys) {
  $actual = git hash-object $path
  if ($LASTEXITCODE -ne 0 -or $actual -cne $expected[$path]) { throw "WinRT source mismatch: $path" }
  Write-Host "WINRT_SOURCE base=f0f52116 source=$env:GITHUB_SHA path=$path blob=$actual sha256=$((Get-FileHash $path -Algorithm SHA256).Hash)"
}
