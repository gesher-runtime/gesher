# Exact combined source gate

From this directory run `python3 media_pr405_qualify_composition.py --repo /path/to/combined-checkout --out /path/to/new-output --pwsh /path/to/pwsh`. Both ordered parent commits must be available in the checkout. Expected: 45 checks and ten actual PowerShell invocations. Each parent's stale source pin must fail, the combined and isolated copies must pass, and five input mutations plus wrong checkout identity must fail. This is source qualification, not Windows API execution or resolution of #360.
