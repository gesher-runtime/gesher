from pathlib import Path
import importlib.util,sys
root=Path('/workspace/scratch/aa09b1a0dc1f')
spec=importlib.util.spec_from_file_location('benchmark',root/'gesher-java-identity-hex/tools/benchmark_identity_digests.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.CASES={'appops-new-owner':(5000,512),'appops-cached':(250000,100000),'appops-unsigned':(250000,100000)}
sys.argv=[str(root/'gesher-java-identity-hex/tools/benchmark_identity_digests.py'),'--baseline-dir',str(root/'identity-hex-jit-preparation/baseline'),'--candidate-dir',str(root/'identity-hex-jit-preparation/candidate'),'--output',str(root/'identity-hex-jit-diagnostic'),'--rounds','1']
b.main()
