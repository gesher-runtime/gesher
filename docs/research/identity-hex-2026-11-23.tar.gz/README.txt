Identity hexadecimal serialization evidence, 2026-11-23.
All six frozen final ABBA datasets and logs are under final/0 through final/5.
Every final process has one first-call record and three steady samples. Per-JVM
steady summaries sum all three costs and divide by all calls. No sample is removed.
Recompute after extraction:
  python3 reproduce_summary.py --output recomputed.json final/0 final/1 final/2 final/3 final/4 final/5
Original command/source locations remain recorded verbatim; they describe the
measurement workspace. Compile fresh variants with the repository's maintained
test_identity_digests.py to run elsewhere. Final compiled class trees are retained.
Exploratory reflection/default-VM and -Xbatch observations remain separate, with
their original source/commands. They are not substituted for the final campaign.
Smoke counters are qualification observations, not performance acceptance.
The complete shared Android framework/app dependency JARs are not redistributed;
their hashes and the original source references are recorded in compiled manifests.
This archive establishes host source and receipt identity, not Windows/ART or
application-wide startup, memory, power or release-budget acceptance.
