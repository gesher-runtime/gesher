#!/usr/bin/env python3
"""Audit every identity receipt and summarize complete per-JVM sample costs."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

METRICS = ('caller_cpu_ns', 'caller_allocated_bytes', 'elapsed_ns')
COMPLETE = 'IDENTITY_DIGEST_COMPLETE outputs_validated=true owned_inputs_retired=true'

def percentile(values, p):
    values = sorted(values)
    position = (len(values) - 1) * p
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    return values[lower] + (values[upper] - values[lower]) * (position - lower)

def describe(values):
    return dict(n=len(values), median=statistics.median(values), mean=statistics.mean(values),
                minimum=min(values), maximum=max(values), p95=percentile(values, .95), values=values)

def delta(old, new):
    return None if old == 0 else (new / old - 1) * 100

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('directories', type=Path, nargs='+')
    args = parser.parse_args()
    processes, datasets, manifests = [], [], None
    log_count = record_count = 0
    for block, directory in enumerate(args.directories):
        data_path = directory / 'results.json'
        data = json.loads(data_path.read_text())
        assert data['rounds'] == 1 and data['samples'] == 3 and data['finished_utc']
        if manifests is None:
            manifests = data['variants']
            cases = data['cases']
        assert data['variants'] == manifests and data['cases'] == cases
        assert len(data['processes']) == 4 * len(cases)
        seen = set()
        for process in data['processes']:
            assert process['round'] == 0 and process['exit_code'] == 0
            assert process['variant'] == ('baseline', 'candidate', 'candidate', 'baseline')[process['position']]
            key = (process['position'], process['case'])
            assert key not in seen
            seen.add(key)
            log = directory / process['log']
            raw = log.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == process['log_sha256']
            text = raw.decode()
            assert COMPLETE in text
            observed = [json.loads(line.removeprefix('IDENTITY_DIGEST_SAMPLE '))
                        for line in text.splitlines() if line.startswith('IDENTITY_DIGEST_SAMPLE ')]
            assert observed == process['observations'] and len(observed) == 4
            assert [row['stage'] for row in observed] == ['first', 'steady', 'steady', 'steady']
            assert observed[0]['iterations'] == 1
            assert [row['sample'] for row in observed[1:]] == [0, 1, 2]
            assert all(row['case'] == process['case'] for row in observed)
            assert all(row['iterations'] > 0 and row['caller_cpu_ns'] > 0 and row['elapsed_ns'] > 0
                       and row['caller_allocated_bytes'] >= 0 for row in observed)
            steady = observed[1:]
            calls = sum(row['iterations'] for row in steady)
            # Retain every measured call/cost; a slow growth/JIT sample is not discarded.
            value = dict(block=block, position=process['position'], variant=process['variant'],
                         case=process['case'], log=str(log), log_sha256=process['log_sha256'],
                         first={metric: observed[0][metric] for metric in METRICS},
                         steady={metric: sum(row[metric] for row in steady) / calls for metric in METRICS},
                         measured_calls=calls)
            processes.append(value)
            log_count += 1
            record_count += len(observed)
        datasets.append(dict(path=str(data_path), sha256=hashlib.sha256(data_path.read_bytes()).hexdigest(),
                             started_utc=data['started_utc'], finished_utc=data['finished_utc']))
    tables = {}
    for stage in ('first', 'steady'):
        tables[stage] = {}
        for case in cases:
            tables[stage][case] = {}
            for metric in METRICS:
                variants = {variant: [p[stage][metric] for p in processes
                                      if p['case'] == case and p['variant'] == variant]
                            for variant in ('baseline', 'candidate')}
                summaries = {name: describe(values) for name, values in variants.items()}
                paired = []
                for block in range(len(datasets)):
                    means = {variant: statistics.mean(p[stage][metric] for p in processes
                             if p['block'] == block and p['case'] == case and p['variant'] == variant)
                             for variant in variants}
                    paired.append(dict(block=block, **means, delta_pct=delta(means['baseline'], means['candidate'])))
                tables[stage][case][metric] = dict(**summaries,
                    median_delta_pct=delta(summaries['baseline']['median'], summaries['candidate']['median']),
                    median_delta_absolute=summaries['candidate']['median'] - summaries['baseline']['median'],
                    paired_blocks=paired)
    result = dict(method='All three sample costs summed per JVM and divided by all measured calls; fresh-JVM distributions; no samples removed.',
                  datasets=datasets, process_count=log_count, observation_count=record_count,
                  manifests=manifests, processes=processes, tables=tables)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(processes=log_count, observations=record_count, cases=len(cases),
                          blocks=len(datasets), output=str(args.output))))
    for case in cases:
        metrics = tables['steady'][case]
        print(case, ' '.join(metric + '=' + str(round(metrics[metric]['median_delta_pct'], 3)) + '%'
              for metric in METRICS if metrics[metric]['median_delta_pct'] is not None))

if __name__ == '__main__':
    main()
