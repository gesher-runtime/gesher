#!/usr/bin/env python3
"""Freeze all final, exploratory and diagnostic identity receipts, without selecting samples."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/aa09b1a0dc1f')
REPO = ROOT / 'gesher-java-identity-hex'
TARGET = REPO / 'docs/research/identity-hex-2026-11-23.tar.gz'
entries = {}

def add(source, name):
    source = Path(source)
    assert source.is_file(), str(source)
    assert name not in entries, name
    entries[name] = source.read_bytes()

def tree(source, prefix, selected=lambda path: True):
    source = Path(source)
    assert source.is_dir(), str(source)
    for path in sorted(source.rglob('*')):
        if path.is_file() and selected(path):
            add(path, prefix + '/' + path.relative_to(source).as_posix())

for i in range(6):
    tree(ROOT / f'identity-hex-final-{i}', f'final/{i}', lambda p: p.name in ('results.json', 'run.log'))
    add(ROOT / f'identity-hex-final-{i}.log', f'final/{i}/orchestration.log')
add(ROOT / 'identity-hex-final-summary.json', 'final/summary.json')
add(ROOT / 'identity_hex_summarize.py', 'reproduce_summary.py')
for old, prefix in [('identity-hex-pilot', 'exploratory/default-reflection'),
                    ('identity-hex-jit-diagnostic', 'exploratory/xbatch-reflection'),
                    ('identity-hex-final-smoke', 'qualification/reflection-smoke'),
                    ('identity-hex-direct-smoke', 'qualification/direct-smoke')]:
    tree(ROOT / old, prefix, lambda p: p.suffix in ('.json', '.log'))
for old, prefix in [('identity-hex-pre-direct-source', 'exploratory/source'),
                    ('identity-hex-jit-preparation', 'exploratory/xbatch-preparation'),
                    ('identity-hex-cache-bytecode-proof', 'qualification/cache-bytecode'),
                    ('identity-hex-source-reference', 'reference/libcore')]:
    tree(ROOT / old, prefix)

for variant in ('baseline', 'candidate'):
    folder = ROOT / ('identity-hex-final-direct-' + variant)
    add(folder / 'compiled.json', f'compiled/{variant}/compiled.json')
    add(folder / 'libidentity_digest_host.so', f'compiled/{variant}/libidentity_digest_host.so')
    tree(folder / 'classes', f'compiled/{variant}/classes')
    if variant == 'baseline': tree(folder / 'source', 'source/baseline')
    for old in ('identity-hex-final-', 'identity-hex-direct-', 'identity-hex-'):
        folder = ROOT / (old + variant + ('-compiled' if old == 'identity-hex-' else ''))
        add(folder / 'compiled.json', f'qualification/earlier-manifests/{folder.name}.json')

for relative in ('app/java/com/gesher/app/shell/AppShell.java',
                 'app/java/com/gesher/server/NotificationManagerService.java',
                 'app/java/com/gesher/server/AppOpsModeStore.java',
                 'tests/dex-services/gesher/services/IdentityDigestContractTest.java',
                 'tests/java-performance/IdentityDigestHost.java',
                 'tests/java-performance/com/gesher/server/IdentitySignerHost.java',
                 'tools/test_identity_digests.py', 'tools/benchmark_identity_digests.py',
                 'tests/zygote/path_host.c', '.github/workflows/framework.yml',
                 'tests/windows/tracks/98-system-contracts.ps1'):
    add(REPO / relative, 'source/candidate/' + relative)

for name in ('key-uppercase', 'notification-uppercase', 'appops-uppercase'):
    for kind in ('identity-hex-mutant-', 'identity-hex-direct-mutant-'):
        folder = ROOT / (kind + name)
        add(folder / 'compiled.json', f'negative/{folder.name}/compiled.json')
        add(folder / 'mutation.log', f'negative/{folder.name}/mutation.log')
        tree(folder / 'source', f'negative/{folder.name}/source')

for path in sorted(ROOT.glob('identity-hex-*.log')):
    add(path, 'qualification/logs/' + path.name)
for name in ('identity-hex-main-d94-proof.json', 'identity-hex-final-overlap.json',
             'java-dns-hex-main-b2-proof.json', 'identity-hex-environment.json',
             'identity-hex-d94-bytecode-proof.json'):
    add(ROOT / name, 'qualification/' + name)
add(ROOT / 'identity-hex-d94-contracts/compiled.json', 'qualification/current-main-compiled.json')
add(ROOT / 'native-review-identity-hex.log', 'qualification/independent-contracts.log')
native_classes = ROOT / 'native-review-identity-hex/compiled.json'
if native_classes.is_file(): add(native_classes, 'qualification/independent-compiled.json')
add(Path(__file__), 'build_evidence.py')

entries['README.txt'] = b'''Identity hexadecimal serialization evidence, 2026-11-23.
All six frozen final ABBA datasets and logs are under final/0 through final/5.
Every final process has one first-call record and three steady samples. Per-JVM
steady summaries sum all three costs and divide by all calls. No sample is removed.
Recompute after extraction:
  python3 reproduce_summary.py --output recomputed.json final/0 final/1 final/2 final/3 final/4 final/5
Original command/source locations remain recorded verbatim; they describe the
measurement workspace. Compile fresh variants with the repository's maintained
test_identity_digests.py to run elsewhere. Final compiled class trees are retained.
Exploratory reflection/default-VM and -Xbatch observations remain separate, with
their original source/commands. They are not substituted for the final campaign.
Smoke counters are qualification observations, not performance acceptance.
The complete shared Android framework/app dependency JARs are not redistributed;
their hashes and the original source references are recorded in compiled manifests.
This archive establishes host source and receipt identity, not Windows/ART or
application-wide startup, memory, power or release-budget acceptance.
'''

manifest = {'members': [{'path': name, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in sorted(entries.items())]}
entries['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
TARGET.parent.mkdir(parents=True, exist_ok=True)
with TARGET.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data); info.mode = 0o644; info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
receipt = {'archive': str(TARGET), 'bytes': TARGET.stat().st_size,
           'sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(),
           'members': len(entries), 'declared_members': len(manifest['members'])}
(ROOT / 'identity-hex-evidence-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
