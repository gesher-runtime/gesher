from pathlib import Path
import hashlib,json,os,re,subprocess
ROOT=Path('/workspace/scratch/aa09b1a0dc1f/gesher-java-dns-peer-fix')
OUT=Path('/workspace/scratch/aa09b1a0dc1f/pr361-dns-peer-proof-final')
OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0'
rows=[]
def run(name, source, expected):
 d=OUT/name;d.mkdir(exist_ok=True); cpp=d/'probe.cc';cpp.write_text(source)
 command=['c++','-std=c++17','-Wall','-Wextra','-Werror','-O1','-g','-pthread','-fsanitize=address,undefined','-fno-sanitize-recover=all','-I'+str(d),'-I'+str(ROOT/'tests/native'),str(cpp),'-o',str(d/'probe')]
 subprocess.run(command,check=True)
 p=subprocess.run([str(d/'probe')],env=env,capture_output=True,text=True,timeout=15)
 (d/'run.log').write_text(p.stdout+p.stderr)
 assert p.returncode !=0 and expected in p.stdout+p.stderr,(name,p.returncode,p.stdout+p.stderr)
 rows.append({'name':name,'source_sha256':sha(cpp),'log_sha256':sha(d/'run.log'),'exit':p.returncode,'expected':expected,
              'command':command,'headers':{p.name:sha(p) for p in d.glob('*.h')}})
 (OUT/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name+' rejected for '+expected,flush=True)
old=subprocess.check_output(['git','show','4bb899914d9efb20b3b13067ad82acc323312722:tests/native/dns_admission_host.cc.in'],cwd=ROOT,text=True)
production=subprocess.check_output(['git','show','4bb899914d9efb20b3b13067ad82acc323312722:compat/posix/src/network_dns.cc'],cwd=ROOT,text=True)
old=old.replace('@PRODUCTION@',re.sub(r'^#include[^\n]*\n','',production,flags=re.M)).replace('@BOUNDED@','1')
needle='    server_port = ntohs(address.sin_port);'
assert old.count(needle)==1
collision='''
    NativeSocket collider = ::socket(AF_INET, SOCK_STREAM, 0);
    Check(collider != kInvalid, "controlled TCP collision socket");
    Check(::bind(collider, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0,
          "controlled TCP collider owns the selected UDP number");
    Check(::listen(collider, 1) == 0, "controlled actual TCP collider listens");
'''
old=old.replace(needle,needle+collision)
old=old.replace('if (!value) { std::fprintf(stderr, "FAIL DNS admission:',
                'if (!value) { int original_error = errno; std::fprintf(stderr, "CONTROLLED_OLD_NATIVE_ERROR=%d\\n", original_error); std::fprintf(stderr, "FAIL DNS admission:')
start=old.index('int main() {')
old=old[:start]+'''int main() {
  fixture::Peer peer;
  return 0;
}
'''
run('unchanged-setup-real-collision',old,'FAIL DNS admission: peer TCP bind/listen')
header=(ROOT/'tests/native/dns_peer_ports.h').read_text()
test=(ROOT/'tests/native/dns_peer_ports_test.h').read_text()
mutations={
 'no-collision-retry':('AddressInUse(error.code) && attempt < kPeerPortAttempts','AddressInUse(error.code) && false','real first TCP collision recovers'),
 'retry-other-errors':('AddressInUse(error.code) && attempt < kPeerPortAttempts','attempt < kPeerPortAttempts','non-collision errors are never retried'),
 'lost-udp-owner':('if (udp != kInvalidSocket) CloseSocket(std::exchange(udp, kInvalidSocket));','udp = kInvalidSocket;','failed attempt has no retained unowned socket'),
 'excess-attempts':('kPeerPortAttempts = 16','kPeerPortAttempts = 17','fixed retry ceiling preserves bounded fixture setup'),
}
for name,(before,after,message) in mutations.items():
 assert header.count(before)==1
 d=OUT/name;d.mkdir(exist_ok=True)
 (d/'dns_peer_ports.h').write_text(header.replace(before,after))
 (d/'dns_peer_ports_test.h').write_text(test)
 run(name,'#include "dns_peer_ports_test.h"\nint main(){dns_fixture::peer_port_test::Run();}\n',message)
print('Actual old-setup negative and all four ownership/error/budget controls passed')
