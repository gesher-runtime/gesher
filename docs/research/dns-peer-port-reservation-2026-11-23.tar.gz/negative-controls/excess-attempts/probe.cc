#include "dns_peer_ports_test.h"
int main(){dns_fixture::peer_port_test::Run();}
