// Complete production DNS owner/dispatcher with explicit platform boundaries.
// Real loopback UDP/TCP on both hosts; real Windows thread pool on Windows.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <new>
#include <string>
#include <thread>
#include <vector>
#include <cerrno>
#include <cstdlib>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <bcrypt.h>
#ifdef _MSC_VER
using ssize_t = SSIZE_T;
using socklen_t = int;
#endif
using NativeSocket = SOCKET;
constexpr NativeSocket kInvalid = INVALID_SOCKET;
#define SOCK_CLOEXEC 0x80000
#define F_GETFL 3
#define F_SETFL 4
#define O_NONBLOCK 04000
#define SHUT_RDWR SD_BOTH
#ifndef ENONET
#define ENONET 64
#endif
#ifndef EBADMSG
#define EBADMSG 74
#endif
#else
#include <arpa/inet.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
using NativeSocket = int;
constexpr NativeSocket kInvalid = -1;
using DWORD = unsigned long;
using HANDLE = void*;
#define WINAPI
#define CALLBACK
#define BCRYPT_USE_SYSTEM_PREFERRED_RNG 2

// Only the Linux host supplies a thread-pool boundary. Its callbacks run on real
// OS threads; all queue/admission/cancellation decisions are production code.
struct TestPool;
struct TestWork { void (*callback)(void*, void*, TestWork*); void* context; TestPool* pool; };
struct TestPool {
  std::mutex mutex;
  std::condition_variable wake;
  std::deque<TestWork*> pending;
  size_t maximum = 1;
  bool started = false;
};
using PTP_POOL = TestPool*;
using PTP_WORK = TestWork*;
using PTP_CALLBACK_INSTANCE = void*;
struct TP_CALLBACK_ENVIRON { PTP_POOL pool = nullptr; };
static inline PTP_POOL CreateThreadpool(void*) { return new TestPool; }
static inline void SetThreadpoolThreadMaximum(PTP_POOL pool, DWORD maximum) { pool->maximum = maximum; }
static inline bool SetThreadpoolThreadMinimum(PTP_POOL, DWORD minimum) { return minimum == 0; }
static inline void InitializeThreadpoolEnvironment(TP_CALLBACK_ENVIRON*) { }
static inline void SetThreadpoolCallbackPool(TP_CALLBACK_ENVIRON* environment, PTP_POOL pool) { environment->pool = pool; }
static inline void SetThreadpoolCallbackRunsLong(TP_CALLBACK_ENVIRON*) { }
static inline PTP_WORK CreateThreadpoolWork(void (*callback)(void*, void*, TestWork*), void* context,
                                         TP_CALLBACK_ENVIRON* environment) {
  return new TestWork{callback, context, environment->pool};
}
static inline void DestroyThreadpoolEnvironment(TP_CALLBACK_ENVIRON*) { }
static inline void CloseThreadpool(PTP_POOL pool) { delete pool; }
static inline void SubmitThreadpoolWork(PTP_WORK work) {
  auto* pool = work->pool;
  std::lock_guard<std::mutex> lock(pool->mutex);
  if (!pool->started) {
    pool->started = true;
    for (size_t i = 0; i < pool->maximum; ++i) std::thread([pool] {
      for (;;) {
        TestWork* next;
        {
          std::unique_lock<std::mutex> held(pool->mutex);
          pool->wake.wait(held, [pool] { return !pool->pending.empty(); });
          next = pool->pending.front(); pool->pending.pop_front();
        }
        next->callback(nullptr, next->context, next);
      }
    }).detach();
  }
  pool->pending.push_back(work); pool->wake.notify_one();
}
static inline HANDLE CreateThread(void*, size_t, DWORD (*callback)(void*), void* argument, DWORD, void*) {
  std::thread([callback, argument] { callback(argument); }).detach(); return reinterpret_cast<HANDLE>(1);
}
static inline void CloseHandle(HANDLE) { }
static inline int BCryptGenRandom(void*, uint8_t* bytes, size_t size, unsigned long) {
  static std::atomic<unsigned> next{123};
  for (size_t i = 0; i < size; ++i) bytes[i] = static_cast<uint8_t>(++next);
  return 0;
}
#endif

namespace fixture {
using Clock = std::chrono::steady_clock;
std::atomic<int> checks{0}, peak_held{0}, held{0}, pair_calls{0}, server_calls{0}, submissions{0};
std::atomic<int> slow_open_ms{0}, slow_connect_ms{0}, slow_nonblocking_ms{0};
std::atomic<int> connect_calls{0}, poll_calls{0}, last_poll_timeout{0};
std::atomic<bool> permitted{true}, fail_pair{false}, fail_servers{false}, fail_open{false};
std::atomic<bool> fail_pool{false}, fail_work{false}, hold_backend{false};
std::atomic<uint32_t> process_interface{7};
std::mutex gate_mutex;
std::condition_variable gate;
struct Endpoint { NativeSocket socket; bool network; int flags; };
std::mutex sockets_mutex;
std::map<int, Endpoint> sockets;
size_t peak_sockets = 0;
uint16_t server_port = 0;
uint16_t first_server_port = 0;
std::mutex interfaces_mutex;
std::vector<uint32_t> interfaces;

void Check(bool value, const char* message) {
  ++checks;
  if (!value) { int original_error = errno; std::fprintf(stderr, "CONTROLLED_OLD_NATIVE_ERROR=%d\n", original_error); std::fprintf(stderr, "FAIL DNS admission: %s\n", message); std::exit(1); }
}
template<class F> void Until(F condition, const char* message, int milliseconds = 5000) {
  auto end = Clock::now() + std::chrono::milliseconds(milliseconds);
  while (!condition() && Clock::now() < end) std::this_thread::sleep_for(std::chrono::milliseconds(2));
  Check(condition(), message);
}
int Error() {
#ifdef _WIN32
  int code = WSAGetLastError();
  switch (code) {
    case WSAEWOULDBLOCK: return errno = EINPROGRESS;
    case WSAETIMEDOUT: return errno = EAGAIN;
    case WSAECONNREFUSED: return errno = ECONNREFUSED;
    case WSAECONNRESET: case WSAESHUTDOWN: return errno = ECONNRESET;
    case WSAENOTSOCK: return errno = EBADF;
    default: return errno = EIO;
  }
#else
  return errno;
#endif
}
void NativeClose(NativeSocket socket) {
#ifdef _WIN32
  closesocket(socket);
#else
  ::close(socket);
#endif
}
ssize_t NativeSend(NativeSocket socket, const void* bytes, size_t size) {
#ifdef _WIN32
  int count = ::send(socket, static_cast<const char*>(bytes), static_cast<int>(size), 0);
#else
  ssize_t count = ::send(socket, bytes, size, MSG_NOSIGNAL);
#endif
  if (count < 0) Error();
  return count;
}
ssize_t NativeRecv(NativeSocket socket, void* bytes, size_t size) {
#ifdef _WIN32
  int count = ::recv(socket, static_cast<char*>(bytes), static_cast<int>(size), 0);
#else
  ssize_t count = ::recv(socket, bytes, size, 0);
#endif
  if (count < 0) Error();
  return count;
}
int Register(NativeSocket socket, bool network) {
  std::lock_guard<std::mutex> lock(sockets_mutex);
  int fd = 100; while (sockets.count(fd)) ++fd;
  sockets.emplace(fd, Endpoint{socket, network, 0});
  peak_sockets = std::max(peak_sockets, sockets.size());
  return fd;
}
Endpoint Get(int fd) {
  std::lock_guard<std::mutex> lock(sockets_mutex);
  auto found = sockets.find(fd);
  if (found == sockets.end()) { errno = EBADF; return {kInvalid, false, 0}; }
  return found->second;
}
size_t Live() { std::lock_guard<std::mutex> lock(sockets_mutex); return sockets.size(); }
int Close(int fd) {
  NativeSocket socket;
  {
    std::lock_guard<std::mutex> lock(sockets_mutex);
    auto found = sockets.find(fd);
    if (found == sockets.end()) return errno = EBADF, -1;
    socket = found->second.socket; sockets.erase(found);
  }
  NativeClose(socket); return 0;
}
int Shutdown(int fd, int how) { int result = ::shutdown(Get(fd).socket, how); if (result < 0) Error(); return result; }
ssize_t Send(int fd, const void* bytes, size_t size, int) { return NativeSend(Get(fd).socket, bytes, size); }
ssize_t Recv(int fd, void* bytes, size_t size, int) {
  auto endpoint = Get(fd);
  if (endpoint.network && hold_backend) {
    int count = ++held, before = peak_held.load();
    while (before < count && !peak_held.compare_exchange_weak(before, count)) { }
    std::unique_lock<std::mutex> lock(gate_mutex);
    gate.wait(lock, [] { return !hold_backend; });
    --held;
  }
  return NativeRecv(endpoint.socket, bytes, size);
}
int Pair(int, int, int, int output[2]) {
  ++pair_calls;
  if (fail_pair) return errno = EMFILE, -1;
  NativeSocket reader, writer;
#ifdef _WIN32
  NativeSocket listener = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  sockaddr_in address{}; address.sin_family = AF_INET; address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int size = sizeof(address);
  Check(::bind(listener, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0, "socketpair bind");
  Check(::getsockname(listener, reinterpret_cast<sockaddr*>(&address), &size) == 0 && ::listen(listener, 1) == 0,
        "socketpair listen");
  writer = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  Check(::connect(writer, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0, "socketpair connect");
  reader = ::accept(listener, nullptr, nullptr); NativeClose(listener);
#else
  int pair[2]; if (::socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, pair) != 0) return -1;
  reader = pair[0]; writer = pair[1];
#endif
  output[0] = Register(reader, false); output[1] = Register(writer, false); return 0;
}
int SetOption(int fd, int level, int name, const void* value, socklen_t size) {
#ifdef _WIN32
  DWORD milliseconds = 0;
  if (name == SO_RCVTIMEO || name == SO_SNDTIMEO) {
    const auto* time = static_cast<const timeval*>(value);
    milliseconds = static_cast<DWORD>(time->tv_sec * 1000 + time->tv_usec / 1000);
    value = &milliseconds; size = sizeof(milliseconds);
  }
  int result = ::setsockopt(Get(fd).socket, level, name, static_cast<const char*>(value), size);
#else
  int result = ::setsockopt(Get(fd).socket, level, name, value, size);
#endif
  if (result < 0) Error();
  return result;
}
int GetOption(int fd, int level, int name, void* value, socklen_t* size) {
#ifdef _WIN32
  int result = ::getsockopt(Get(fd).socket, level, name, static_cast<char*>(value), size);
  if (result == 0 && name == SO_ERROR && *static_cast<int*>(value) != 0) {
    WSASetLastError(*static_cast<int*>(value)); *static_cast<int*>(value) = Error();
  }
#else
  int result = ::getsockopt(Get(fd).socket, level, name, value, size);
#endif
  if (result < 0) Error();
  return result;
}
int Fcntl(int fd, int operation, int flags = 0) {
  if (operation == F_GETFL) return Get(fd).flags;
  if ((flags & O_NONBLOCK) != 0 && slow_nonblocking_ms > 0)
    std::this_thread::sleep_for(std::chrono::milliseconds(slow_nonblocking_ms.load()));
  auto endpoint = Get(fd);
#ifdef _WIN32
  u_long nonblocking = (flags & O_NONBLOCK) != 0;
  int result = ioctlsocket(endpoint.socket, FIONBIO, &nonblocking);
#else
  int result = ::fcntl(endpoint.socket, F_SETFL, flags);
#endif
  if (result < 0) { Error(); return -1; }
  std::lock_guard<std::mutex> lock(sockets_mutex); sockets.at(fd).flags = flags; return 0;
}
int Connect(int fd, const sockaddr* address, socklen_t size) {
  ++connect_calls;
  int result = ::connect(Get(fd).socket, address, size); if (result < 0) Error();
  int saved = errno;
  if (slow_connect_ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(slow_connect_ms.load()));
  errno = saved; return result;
}
struct PollDescriptor { int fd; short events, revents; };
int Poll(PollDescriptor* descriptors, size_t count, int timeout) {
  ++poll_calls; last_poll_timeout = timeout;
  std::vector<pollfd> real(count);
  for (size_t i = 0; i < count; ++i) {
    real[i].fd = Get(descriptors[i].fd).socket;
    real[i].events = descriptors[i].events;
  }
#ifdef _WIN32
  int result = WSAPoll(real.data(), static_cast<ULONG>(count), timeout);
#else
  int result = ::poll(real.data(), count, timeout);
#endif
  for (size_t i = 0; i < count; ++i) descriptors[i].revents = real[i].revents;
  if (result < 0) Error();
  return result;
}
static inline PTP_POOL NewPool(void* reserved) { return fail_pool ? nullptr : ::CreateThreadpool(reserved); }
static inline PTP_WORK NewWork(void (CALLBACK* callback)(PTP_CALLBACK_INSTANCE, void*, PTP_WORK),
                              void* context, TP_CALLBACK_ENVIRON* environment) {
  return fail_work ? nullptr : ::CreateThreadpoolWork(callback, context, environment);
}
static inline void Submit(PTP_WORK work) { ++submissions; ::SubmitThreadpoolWork(work); }
}  // namespace fixture

// Interface/server discovery and POSIX fd translation are the only networking
// boundary. Selection is recorded, and exchange uses actual local UDP/TCP.
namespace gesher {
namespace ws {
enum class Family { kInet };
enum class Type { kStream, kDgram };
using Socket = NativeSocket;
constexpr Socket kInvalidSocket = kInvalid;
struct Address { Family family = Family::kInet; sockaddr_in address{}; };
static inline uint32_t ProcessInterface() { return fixture::process_interface; }
static inline int DnsServers(uint32_t index, std::vector<Address>* servers, uint32_t* selected) {
  ++fixture::server_calls;
  if (fixture::fail_servers || index == 999) return errno = ENONET, -1;
  Address address; address.address.sin_family = AF_INET;
  address.address.sin_addr.s_addr = htonl(INADDR_LOOPBACK); address.address.sin_port = htons(fixture::server_port);
  if (fixture::first_server_port != 0) {
    Address first = address; first.address.sin_port = htons(fixture::first_server_port); servers->push_back(first);
  }
  servers->push_back(address); *selected = index; return 0;
}
static inline Socket Open(Family, Type type, int, bool) {
  if (fixture::fail_open) return errno = EMFILE, kInvalidSocket;
  if (fixture::slow_open_ms > 0)
    std::this_thread::sleep_for(std::chrono::milliseconds(fixture::slow_open_ms.load()));
  return ::socket(AF_INET, type == Type::kStream ? SOCK_STREAM : SOCK_DGRAM, 0);
}
static inline int BindInterface(Socket, uint32_t index) {
  std::lock_guard<std::mutex> lock(fixture::interfaces_mutex); fixture::interfaces.push_back(index); return 0;
}
static inline void Close(Socket socket) { fixture::NativeClose(socket); }
}  // namespace ws
struct SocketFd { ws::Socket socket = kInvalid; };
static inline int RegisterSocket(const SocketFd& state) { return fixture::Register(state.socket, true); }
namespace sock {
static inline void FromAddress(const ws::Address& source, sockaddr* target, socklen_t* length) {
  std::memcpy(target, &source.address, sizeof(source.address)); *length = sizeof(source.address);
}
}  // namespace sock
}  // namespace gesher
static inline bool gesher_inet_allowed() { return fixture::permitted; }
extern "C" void gesher_res_cancel(int);

#define socketpair fixture::Pair
#define close fixture::Close
#define shutdown fixture::Shutdown
#define send fixture::Send
#define recv fixture::Recv
#define setsockopt fixture::SetOption
#define getsockopt fixture::GetOption
#define fcntl fixture::Fcntl
#define connect fixture::Connect
#define poll fixture::Poll
#define pollfd fixture::PollDescriptor
#define CreateThreadpool fixture::NewPool
#define CreateThreadpoolWork fixture::NewWork
#define SubmitThreadpoolWork fixture::Submit
// Android NDK raw DNS queries over Windows' configured per-interface servers.
// A socketpair publishes one admitted request's result, including failures, so
// poll/epoll observes completion even when the DNS server times out. The
// query's real UDP/TCP socket is bound to the selected outgoing interface.



namespace {
namespace ws = gesher::ws;
using Clock = std::chrono::steady_clock;
// Android DnsResolver's res_nsend defaults (RES_TIMEOUT, RES_DFLRETRY):
// retry_count rounds over the servers, each server waiting the base timeout
// shifted by its index and divided by the server count (5s for the first),
// never less than one second. ANDROID_RESOLV_NO_RETRY makes one request to
// one server.
constexpr int kBaseTimeoutMs = 5000;
constexpr int kRetryCount = 2;
constexpr size_t kMaxServers = 3;
// Admit the issue #178 256-request workload, with the 32-request workload able
// to run concurrently. Larger bursts fail before allocating request resources.
constexpr size_t kMaxWorkers = 32;

int ServerTimeout(size_t server, size_t count) {
  int milliseconds = kBaseTimeoutMs << server;
  if (server > 0) milliseconds /= static_cast<int>(count);
  return std::max(milliseconds, 1000);
}

struct Query {
  static constexpr size_t kMaxOutstanding = 256;
  static std::atomic<size_t>& Outstanding() { static std::atomic<size_t> count{0}; return count; }
  static bool Reserve() {
    size_t count = Outstanding().load();
    while (count < kMaxOutstanding) {
      if (Outstanding().compare_exchange_weak(count, count + 1)) return true;
    }
    return false;
  }
  // Retain the lease through BOTH caller consumption/cancellation and worker
  // retirement. A canceled external call or unread answer still owns resources.
  bool admitted = false;
  ~Query() { if (admitted) --Outstanding(); }
  std::atomic<bool> cancelled{false};
  std::mutex mutex;
  int active = -1;  // shutdown may interrupt it; only its worker closes it
  int writer = -1;
  int error = -EIO;
  std::vector<uint8_t> answer;
};
std::mutex g_queries_mutex;
std::map<int, std::shared_ptr<Query>> g_queries;

struct Admission {
  bool owned = Query::Reserve();
  ~Admission() { if (owned) --Query::Outstanding(); }
};

bool Transfer(int fd, void* bytes, size_t size, bool writing) {
  auto* position = static_cast<uint8_t*>(bytes);
  while (size > 0) {
    ssize_t count = writing ? send(fd, position, size, 0) : recv(fd, position, size, 0);
    if (count <= 0) { if (count == 0) errno = ECONNRESET; return false; }
    position += count;
    size -= static_cast<size_t>(count);
  }
  return true;
}

void Timeout(int fd, int milliseconds) {
  timeval value{milliseconds / 1000, (milliseconds % 1000) * 1000};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &value, sizeof(value));
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &value, sizeof(value));
}

int Remaining(Clock::time_point deadline) {
  auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - Clock::now()).count();
  return static_cast<int>(std::max<int64_t>(0, remaining));
}

// A TCP peer cannot renew the request indefinitely by trickling one byte per
// socket timeout. The same monotonic request/exchange deadline covers all I/O.
bool TransferUntil(const std::shared_ptr<Query>& query, int fd, void* bytes, size_t size,
                   bool writing, Clock::time_point deadline) {
  auto* position = static_cast<uint8_t*>(bytes);
  while (size > 0) {
    if (query->cancelled) return errno = ECANCELED, false;
    int remaining = Remaining(deadline);
    if (remaining == 0) return errno = ETIMEDOUT, false;
    Timeout(fd, remaining);
    if (Remaining(deadline) == 0) return errno = ETIMEDOUT, false;
    ssize_t count = writing ? send(fd, position, size, 0) : recv(fd, position, size, 0);
    if (count <= 0) {
      if (count == 0) errno = ECONNRESET;
      if (errno == EAGAIN) errno = ETIMEDOUT;
      return false;
    }
    position += count;
    size -= static_cast<size_t>(count);
  }
  return true;
}

int Open(const std::shared_ptr<Query>& query, const ws::Address& server, uint32_t index, bool tcp,
         int timeout) {
  std::lock_guard<std::mutex> lock(query->mutex);
  if (query->cancelled) return errno = ECANCELED, -1;
  ws::Socket endpoint = ws::Open(server.family, tcp ? ws::Type::kStream : ws::Type::kDgram, 0, false);
  if (endpoint == ws::kInvalidSocket) return -1;
  if (index != 0 && ws::BindInterface(endpoint, index) != 0) {
    int saved = errno;
    ws::Close(endpoint);
    return errno = saved, -1;
  }
  gesher::SocketFd state;
  state.socket = endpoint;
  int fd = gesher::RegisterSocket(state);
  if (fd < 0) return -1;
  if (query->cancelled) { close(fd); return errno = ECANCELED, -1; }
  query->active = fd;
  Timeout(fd, timeout);
  return fd;
}

void Close(const std::shared_ptr<Query>& query, int fd) {
  std::lock_guard<std::mutex> lock(query->mutex);
  query->active = -1;
  close(fd);
}

int Connect(int fd, const ws::Address& server, bool tcp, Clock::time_point deadline) {
  sockaddr_storage address{};
  socklen_t length = sizeof(address);
  gesher::sock::FromAddress(server, reinterpret_cast<sockaddr*>(&address), &length);
  if (Remaining(deadline) == 0) return -ETIMEDOUT;
  if (!tcp) return connect(fd, reinterpret_cast<sockaddr*>(&address), length) == 0 ? 0 : -errno;
  int mode = fcntl(fd, F_GETFL);
  if (mode < 0 || fcntl(fd, F_SETFL, mode | O_NONBLOCK) != 0) return -errno;
  if (Remaining(deadline) == 0) { fcntl(fd, F_SETFL, mode); return -ETIMEDOUT; }
  int result = connect(fd, reinterpret_cast<sockaddr*>(&address), length);
  int error = result == 0 ? 0 : errno;
  if (result != 0 && error == EINPROGRESS) {
    pollfd pending{fd, POLLOUT, 0};
    int timeout = Remaining(deadline);
    int ready = timeout > 0 ? poll(&pending, 1, timeout) : 0;
    if (ready > 0) {
      socklen_t size = sizeof(error);
      if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &error, &size) != 0) error = errno;
    } else {
      error = ready == 0 ? ETIMEDOUT : errno;
    }
  }
  fcntl(fd, F_SETFL, mode);
  return -error;
}

int Exchange(const std::shared_ptr<Query>& query, const ws::Address& server, uint32_t index,
             const std::vector<uint8_t>& packet, std::vector<uint8_t>* answer, bool tcp, int timeout,
             Clock::time_point request_deadline) {
  auto deadline = std::min(request_deadline, Clock::now() + std::chrono::milliseconds(timeout));
  timeout = Remaining(deadline);
  if (timeout == 0) return -ETIMEDOUT;
  int fd = Open(query, server, index, tcp, timeout);
  if (fd < 0) return -errno;
  // Socket/interface setup can exhaust a queued request's remaining budget.
  // Carry the deadline through connect and refresh the UDP send timeout too.
  int error = Connect(fd, server, tcp, deadline);
  if (error == 0 && !tcp) {
    int remaining = Remaining(deadline);
    if (remaining == 0) error = -ETIMEDOUT;
    else Timeout(fd, remaining);
  }
  if (error == 0) {
    if (tcp) {
      uint8_t length[2] = {static_cast<uint8_t>(packet.size() >> 8), static_cast<uint8_t>(packet.size())};
      if (!TransferUntil(query, fd, length, 2, true, deadline) ||
          !TransferUntil(query, fd, const_cast<uint8_t*>(packet.data()), packet.size(), true, deadline) ||
          !TransferUntil(query, fd, length, 2, false, deadline)) {
        error = -(errno != 0 ? errno : EIO);
      } else {
        answer->resize(static_cast<size_t>(length[0]) << 8 | length[1]);
        if (!TransferUntil(query, fd, answer->data(), answer->size(), false, deadline))
          error = -(errno != 0 ? errno : EIO);
      }
    } else if (Remaining(deadline) == 0) {
      error = -ETIMEDOUT;
    } else if (send(fd, packet.data(), packet.size(), 0) != static_cast<ssize_t>(packet.size())) {
      error = -errno;
    } else {
      answer->resize(65535);
      while (true) {
        if (query->cancelled) { error = -ECANCELED; break; }
        int remaining = Remaining(deadline);
        if (remaining <= 0) { error = -ETIMEDOUT; break; }
        Timeout(fd, remaining);
        if (Remaining(deadline) == 0) { error = -ETIMEDOUT; break; }
        ssize_t size = recv(fd, answer->data(), answer->size(), 0);
        if (query->cancelled) { error = -ECANCELED; break; }
        if (size < 0) { error = errno == EAGAIN ? -ETIMEDOUT : -errno; break; }
        if (size >= 12 && (*answer)[0] == packet[0] && (*answer)[1] == packet[1] &&
            ((*answer)[2] & 0x80) != 0) {
          answer->resize(static_cast<size_t>(size));
          break;
        }
      }
    }
  }
  if (query->cancelled) error = -ECANCELED;
  if (error == 0 && (answer->size() < 12 || (*answer)[0] != packet[0] || (*answer)[1] != packet[1] ||
                    ((*answer)[2] & 0x80) == 0)) error = -EBADMSG;
  Close(query, fd);
  return error;
}

void Publish(const std::shared_ptr<Query>& query, int error, std::vector<uint8_t>& answer) {
  {
    std::lock_guard<std::mutex> lock(query->mutex);
    query->error = error;
    query->answer = std::move(answer);
  }
  // Only the completion byte uses the socket buffer. A full-size answer
  // remains available until the caller consumes it, without blocking the
  // worker or imposing a timeout on when the caller must read it.
  uint8_t complete = 1;
  Transfer(query->writer, &complete, 1, true);
  close(query->writer);
  query->writer = -1;
}

struct Job {
  std::shared_ptr<Query> query;
  std::vector<ws::Address> servers;
  uint32_t index;
  std::vector<uint8_t> packet;
  uint32_t flags;
  Clock::time_point deadline;
};

void QueryWorker(const Job& job) {
  std::vector<uint8_t> answer;
  int error = -EIO;
  bool single = (job.flags & 1) != 0;  // ANDROID_RESOLV_NO_RETRY
  size_t count = single ? std::min(job.servers.size(), size_t{1}) : job.servers.size();
  int attempts = single ? 1 : kRetryCount;
  for (int attempt = 0; attempt < attempts && error != 0 && !job.query->cancelled; ++attempt) {
    for (size_t i = 0; i < count && !job.query->cancelled; ++i) {
      int timeout = ServerTimeout(i, count);
      error = Exchange(job.query, job.servers[i], job.index, job.packet, &answer, false, timeout, job.deadline);
      if (error == 0 && (answer[2] & 2) != 0) {
        error = Exchange(job.query, job.servers[i], job.index, job.packet, &answer, true, timeout, job.deadline);
      }
      if (error == 0) break;
    }
  }
  Publish(job.query, job.query->cancelled ? -ECANCELED : error, answer);
}

class Dispatcher {
 public:
  static Dispatcher& Get() {
    // Process lifetime, like the DNS descriptor registry. Windows owns retirement
    // of idle pool threads; no permanent polling thread or callback per request.
    alignas(Dispatcher) static unsigned char storage[sizeof(Dispatcher)];
    static Dispatcher* instance = new (storage) Dispatcher;
    return *instance;
  }
  bool Submit(std::unique_ptr<Job>& job) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (work_ == nullptr) {
      pool_ = CreateThreadpool(nullptr);
      if (pool_ == nullptr) return false;
      SetThreadpoolThreadMaximum(pool_, static_cast<DWORD>(kMaxWorkers));
      if (!SetThreadpoolThreadMinimum(pool_, 0)) {
        CloseThreadpool(pool_); pool_ = nullptr; return false;
      }
      InitializeThreadpoolEnvironment(&environment_);
      SetThreadpoolCallbackPool(&environment_, pool_);
      SetThreadpoolCallbackRunsLong(&environment_); // DNS waits are blocking I/O
      work_ = CreateThreadpoolWork(Dispatch, this, &environment_);
      if (work_ == nullptr) {
        DestroyThreadpoolEnvironment(&environment_);
        CloseThreadpool(pool_);
        pool_ = nullptr;
        return false;
      }
    }
    jobs_.push_back(std::move(job));
    // At most kMaxWorkers scheduled/active callback tickets. Cancel/re-admit
    // churn must not build an unbounded Windows thread-pool callback queue.
    if (tickets_ < kMaxWorkers) {
      ++tickets_;
      SubmitThreadpoolWork(work_);
    }
    return true;
  }
  bool Cancel(const std::shared_ptr<Query>& query) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto found = std::find_if(jobs_.begin(), jobs_.end(),
        [&](const auto& job) { return job->query == query; });
    if (found == jobs_.end()) return false; // the worker owns retirement
    jobs_.erase(found);
    close(query->writer);
    query->writer = -1;
    return true;
  }
 private:
  static void CALLBACK Dispatch(PTP_CALLBACK_INSTANCE, void* context, PTP_WORK) {
    auto* self = static_cast<Dispatcher*>(context);
    for (;;) {
      std::unique_ptr<Job> job;
      {
        std::lock_guard<std::mutex> lock(self->mutex_);
        if (self->jobs_.empty()) { --self->tickets_; return; }
        job = std::move(self->jobs_.front());
        self->jobs_.pop_front();
      }
      QueryWorker(*job);
    }
  }
  std::mutex mutex_;
  std::deque<std::unique_ptr<Job>> jobs_;
  size_t tickets_ = 0;
  TP_CALLBACK_ENVIRON environment_{};
  PTP_POOL pool_ = nullptr;
  PTP_WORK work_ = nullptr;
};

bool CancelPendingQuery(const std::shared_ptr<Query>& query) { return Dispatcher::Get().Cancel(query); }

bool ValidQuestion(const char* name) {
  size_t size = 12;
  const char* label = name;
  while (*label != 0) {
    const char* end = label;
    while (*end != 0 && *end != '.' && end - label <= 63) ++end;
    size_t length = static_cast<size_t>(end - label);
    if (length == 0 && *end == '.' && end[1] == 0) break;
    if (length == 0 || length > 63 || size + length + 1 > 266) return false;
    size += length + 1;
    if (*end == 0) break;
    label = end + 1;
  }
  return true;
}

int SendAdmitted(uint32_t index, const uint8_t* bytes, size_t size, uint32_t flags,
                 Admission& admission, Clock::time_point submitted) {
  if (index == 0) index = ws::ProcessInterface();
  std::vector<ws::Address> servers;
  if (ws::DnsServers(index, &servers, &index) != 0) return -errno;
  if (servers.empty()) return -ENONET;
  if (servers.size() > kMaxServers) servers.resize(kMaxServers);
  size_t count = (flags & 1) != 0 ? 1 : servers.size();
  // The established retry/server budget, including one possible TCP fallback
  // per UDP exchange, now also covers queueing and all TCP transfers.
  int deadline_ms = 0;
  for (size_t i = 0; i < count; ++i) deadline_ms += 2 * ServerTimeout(i, count);
  if ((flags & 1) == 0) deadline_ms *= kRetryCount;
  auto query = std::make_shared<Query>();
  query->admitted = true;
  admission.owned = false;
  std::vector<uint8_t> packet(bytes, bytes + size);
  int pair[2];
  if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, pair) != 0) return -errno;
  query->writer = pair[1];
  {
    std::lock_guard<std::mutex> lock(g_queries_mutex);
    g_queries[pair[0]] = query;
  }
  std::unique_ptr<Job> job(new (std::nothrow) Job{query, std::move(servers), index, std::move(packet), flags,
      submitted + std::chrono::milliseconds(deadline_ms)});
  if (job == nullptr || !Dispatcher::Get().Submit(job)) {
    {
      std::lock_guard<std::mutex> lock(g_queries_mutex);
      g_queries.erase(pair[0]);
    }
    close(pair[0]);
    close(pair[1]);
    return job == nullptr ? -ENOMEM : -EAGAIN;
  }
  return pair[0];
}
}  // namespace

extern "C" int gesher_res_nsend(uint32_t index, const uint8_t* bytes, size_t size, uint32_t flags) {
  if (bytes == nullptr || size < 12 || size > 65535 || (flags & ~7U) != 0 || (bytes[2] & 0x80)) return -EINVAL;
  if (!gesher_inet_allowed()) return -EACCES;
  Admission admission;
  if (!admission.owned) return -EAGAIN;
  return SendAdmitted(index, bytes, size, flags, admission, Clock::now());
}

extern "C" int gesher_res_nquery(uint32_t index, const char* name, int dns_class, int type, uint32_t flags) {
  if (name == nullptr || *name == 0 || dns_class < 1 || dns_class > 65535 || type < 1 || type > 65535) return -EINVAL;
  if (!ValidQuestion(name)) return -EINVAL;
  if ((flags & ~7U) != 0) return -EINVAL;
  if (!gesher_inet_allowed()) return -EACCES;
  Admission admission;
  if (!admission.owned) return -EAGAIN;
  auto submitted = Clock::now();
  std::vector<uint8_t> packet(12);
  if (BCryptGenRandom(nullptr, packet.data(), 2, BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) return -EIO;
  packet[2] = 1;  // Recursion desired.
  packet[5] = 1;  // One question.
  const char* label = name;
  while (*label != 0) {
    const char* dot = std::strchr(label, '.');
    size_t length = dot != nullptr ? static_cast<size_t>(dot - label) : std::strlen(label);
    if (length == 0 && dot != nullptr && dot[1] == 0) break;  // Root name.
    if (length == 0 || length > 63 || packet.size() + length + 1 > 266) return -EINVAL;
    packet.push_back(static_cast<uint8_t>(length));
    packet.insert(packet.end(), label, label + length);
    if (dot == nullptr) break;
    label = dot + 1;
  }
  packet.push_back(0);
  packet.push_back(static_cast<uint8_t>(type >> 8)); packet.push_back(static_cast<uint8_t>(type));
  packet.push_back(static_cast<uint8_t>(dns_class >> 8)); packet.push_back(static_cast<uint8_t>(dns_class));
  return SendAdmitted(index, packet.data(), packet.size(), flags, admission, submitted);
}

extern "C" int gesher_res_nresult(int fd, int* rcode, uint8_t* answer, size_t capacity) {
  std::shared_ptr<Query> query;
  {
    std::lock_guard<std::mutex> lock(g_queries_mutex);
    auto found = g_queries.find(fd);
    if (found == g_queries.end()) return -EBADF;
    query = found->second;
    g_queries.erase(found);
  }
  uint8_t complete = 0;
  int error = 0;
  if (rcode == nullptr || answer == nullptr) error = -EINVAL;
  else if (!Transfer(fd, &complete, 1, false)) error = -EIO;
  close(fd);
  if (error != 0) return error;
  std::lock_guard<std::mutex> lock(query->mutex);
  if (query->error != 0) return query->error;
  if (query->answer.size() < 12 || query->answer.size() > 65535) return -EBADMSG;
  if (capacity < query->answer.size()) return -EMSGSIZE;
  std::memcpy(answer, query->answer.data(), query->answer.size());
  *rcode = answer[3] & 15;
  return static_cast<int>(query->answer.size());
}

extern "C" void gesher_res_cancel(int fd) {
  std::shared_ptr<Query> query;
  {
    std::lock_guard<std::mutex> lock(g_queries_mutex);
    auto found = g_queries.find(fd);
    if (found == g_queries.end()) return;
    query = found->second;
    g_queries.erase(found);
  }
  query->cancelled = true;
  CancelPendingQuery(query);
  {
    std::lock_guard<std::mutex> lock(query->mutex);
    if (query->active >= 0) shutdown(query->active, SHUT_RDWR);
  }
  close(fd);
}

#undef socketpair
#undef close
#undef shutdown
#undef send
#undef recv
#undef setsockopt
#undef getsockopt
#undef fcntl
#undef connect
#undef poll
#undef pollfd
#undef CreateThreadpool
#undef CreateThreadpoolWork
#undef SubmitThreadpoolWork

#define BOUNDED 1
namespace fixture {
enum class Mode { Reply, Drop, Truncated, Full, BadTcpId, Trickle };
struct Peer {
  NativeSocket udp, tcp;
  std::atomic<Mode> mode{Mode::Reply};
  std::atomic<bool> stopped{false};
  std::atomic<int> packets{0}, tcp_queries{0};
  std::thread datagrams, streams;
  Peer() {
    udp = ::socket(AF_INET, SOCK_DGRAM, 0); tcp = ::socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in address{}; address.sin_family = AF_INET; address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    Check(::bind(udp, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0, "peer UDP bind");
    socklen_t size = sizeof(address);
    Check(::getsockname(udp, reinterpret_cast<sockaddr*>(&address), &size) == 0, "peer port");
    server_port = ntohs(address.sin_port);
    NativeSocket collider = ::socket(AF_INET, SOCK_STREAM, 0);
    Check(collider != kInvalid, "controlled TCP collision socket");
    Check(::bind(collider, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0,
          "controlled TCP collider owns the selected UDP number");
    Check(::listen(collider, 1) == 0, "controlled actual TCP collider listens");

    Check(::bind(tcp, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0 && ::listen(tcp, 64) == 0,
          "peer TCP bind/listen");
    datagrams = std::thread([this] { Udp(); }); streams = std::thread([this] { Tcp(); });
  }
  ~Peer() {
    stopped = true;
    sockaddr_in address{}; address.sin_family = AF_INET; address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    address.sin_port = htons(server_port);
    NativeSocket wake = ::socket(AF_INET, SOCK_DGRAM, 0);
    ::sendto(wake, "x", 1, 0, reinterpret_cast<sockaddr*>(&address), sizeof(address)); NativeClose(wake);
    wake = ::socket(AF_INET, SOCK_STREAM, 0);
    ::connect(wake, reinterpret_cast<sockaddr*>(&address), sizeof(address)); NativeClose(wake);
    datagrams.join(); streams.join(); NativeClose(udp); NativeClose(tcp);
  }
  static bool Transfer(NativeSocket socket, void* data, size_t size, bool writing) {
    auto* position = static_cast<uint8_t*>(data);
    while (size) {
      ssize_t count = writing ? NativeSend(socket, position, size) : NativeRecv(socket, position, size);
      if (count <= 0) return false;
      position += count; size -= static_cast<size_t>(count);
    }
    return true;
  }
  void Udp() {
    std::vector<uint8_t> packet(65535);
    for (;;) {
      sockaddr_storage sender{}; socklen_t size = sizeof(sender);
#ifdef _WIN32
      int count = ::recvfrom(udp, reinterpret_cast<char*>(packet.data()), static_cast<int>(packet.size()), 0,
                             reinterpret_cast<sockaddr*>(&sender), &size);
#else
      ssize_t count = ::recvfrom(udp, packet.data(), packet.size(), 0, reinterpret_cast<sockaddr*>(&sender), &size);
#endif
      if (stopped) return;
      if (count < 12) continue;
      ++packets;
      Mode current = mode;
      if (current == Mode::Drop) continue;
      packet[2] |= 0x80;
      if (current != Mode::Reply) packet[2] |= 2;
      ::sendto(udp, reinterpret_cast<const char*>(packet.data()), static_cast<int>(count), 0,
               reinterpret_cast<sockaddr*>(&sender), size);
    }
  }
  void Tcp() {
    for (;;) {
      NativeSocket client = ::accept(tcp, nullptr, nullptr);
      if (stopped) { if (client != kInvalid) NativeClose(client); return; }
      if (client == kInvalid) continue;
      ++tcp_queries;
      uint8_t length[2];
      if (!Transfer(client, length, 2, false)) { NativeClose(client); continue; }
      std::vector<uint8_t> packet(static_cast<size_t>(length[0]) << 8 | length[1]);
      if (!Transfer(client, packet.data(), packet.size(), false) || packet.size() < 12) {
        NativeClose(client); continue;
      }
      packet[2] = static_cast<uint8_t>((packet[2] | 0x80) & ~2);
      Mode current = mode;
      if (current == Mode::Full) packet.resize(65535, 0x5a);
      if (current == Mode::BadTcpId) ++packet[1];
      length[0] = static_cast<uint8_t>(packet.size() >> 8); length[1] = static_cast<uint8_t>(packet.size());
      if (Transfer(client, length, 2, true)) {
        if (current == Mode::Trickle) {
          for (uint8_t byte : packet) {
            if (NativeSend(client, &byte, 1) != 1) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(600));
          }
        } else Transfer(client, packet.data(), packet.size(), true);
      }
      NativeClose(client);
    }
  }
};

std::vector<uint8_t> Packet() { return {0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0}; }
int SendQuery(uint32_t index = 0, uint32_t flags = 1) {
  auto packet = Packet(); return gesher_res_nsend(index, packet.data(), packet.size(), flags);
}
int Result(int fd, std::vector<uint8_t>* output = nullptr, int* output_rcode = nullptr) {
  Check(fd >= 0, "request admitted");
  PollDescriptor pending{fd, POLLIN, 0};
  Check(Poll(&pending, 1, 20'000) > 0, "accepted completion observable");
  std::vector<uint8_t> answer(65535); int rcode = 99;
  int count = gesher_res_nresult(fd, &rcode, answer.data(), answer.size());
  if (count >= 0) answer.resize(static_cast<size_t>(count));
  if (output) *output = std::move(answer);
  if (output_rcode) *output_rcode = rcode;
  return count;
}
void Empty() {
#if BOUNDED
  Until([] { return Query::Outstanding() == 0 && Live() == 0; }, "all request leases and descriptors retired");
#else
  Until([] { return Live() == 0; }, "all baseline descriptors retired");
#endif
}
void Failures() {
  auto packet = Packet();
  Check(gesher_res_nsend(0, nullptr, 12, 0) == -EINVAL && gesher_res_nsend(0, packet.data(), 11, 0) == -EINVAL,
        "invalid packet remains EINVAL");
  permitted = false;
  Check(SendQuery() == -EACCES, "internet permission remains EACCES"); permitted = true;
  fail_servers = true; Check(SendQuery() == -ENONET, "server discovery failure preserved"); fail_servers = false; Empty();
  fail_pair = true; Check(SendQuery() == -EMFILE, "completion socket allocation failure preserved"); fail_pair = false; Empty();
#if BOUNDED
  fail_pool = true; Check(SendQuery() == -EAGAIN, "pool initialization failure releases admission and sockets");
  fail_pool = false; Empty();
  fail_work = true; Check(SendQuery() == -EAGAIN, "work initialization failure releases admission and sockets");
  fail_work = false; Empty();
#endif
  fail_open = true; Check(Result(SendQuery()) == -EMFILE, "worker socket failure completes accepted caller");
  fail_open = false; Empty();
}
void Wire(Peer& peer) {
  std::vector<uint8_t> answer; int rcode;
  int fd = SendQuery(17, 7);
  process_interface = 23;
  Check(Result(fd, &answer, &rcode) == 12 && rcode == 0 && answer[0] == 0x12 && answer[1] == 0x34,
        "raw response bytes, ID and rcode preserved"); Empty();
  { std::lock_guard<std::mutex> lock(interfaces_mutex); Check(interfaces.back() == 17, "selected network captured before queued dispatch"); }
  fd = gesher_res_nquery(17, "wire.example", 1, 16, 1);
  Check(Result(fd, &answer) > 12 && answer[answer.size() - 3] == 16, "nquery retains non-address question type"); Empty();
  peer.mode = Mode::Full;
  Check(Result(SendQuery(), &answer) == 65535 && answer[0] == 0x12 && answer.back() == 0x5a,
        "UDP truncation falls back to exact maximum-size TCP answer"); Empty();
  peer.mode = Mode::BadTcpId;
  Check(Result(SendQuery()) == -EBADMSG, "TCP mismatched response ID remains EBADMSG"); Empty();
  peer.mode = Mode::Reply;
}
void Burst(Peer& peer, size_t count) {
  peer.mode = Mode::Drop; hold_backend = true; peak_held = 0;
  { std::lock_guard<std::mutex> lock(sockets_mutex); peak_sockets = 0; }
  int initial_pairs = pair_calls, initial_servers = server_calls;
  std::vector<int> accepted; size_t rejected = 0;
  for (size_t i = 0; i < count; ++i) {
    int fd = SendQuery();
    if (fd >= 0) accepted.push_back(fd);
    else { Check(fd == -EAGAIN, "saturated request receives EAGAIN"); ++rejected; }
  }
#if BOUNDED
  size_t admitted = std::min(count, size_t{256});
  size_t workers = std::min(count, size_t{32});
#else
  size_t admitted = count, workers = count;
#endif
  Check(accepted.size() == admitted && rejected == count - admitted, "documented admission budget");
  Until([&] { return held == static_cast<int>(workers); }, "bounded work reaches blocked backend");
  Check(pair_calls - initial_pairs == static_cast<int>(admitted) && server_calls - initial_servers == static_cast<int>(admitted),
        "rejection precedes descriptor allocation and server lookup");
  Check(Live() == admitted * 2 + workers, "live descriptor bound includes completion pairs and active sockets");
  for (int fd : accepted) gesher_res_cancel(fd);
#if BOUNDED
  Check(Query::Outstanding() == workers, "canceled running work keeps admission until actual return");
  Check(Live() == workers * 2, "queued cancellation immediately retires both completion sockets");
  if (count == 1024) {
    int tickets = submissions;
    for (int i = 0; i < 1024; ++i) { int fd = SendQuery(); Check(fd >= 0, "queued cancel churn admitted"); gesher_res_cancel(fd); }
    Check(submissions == tickets && Query::Outstanding() == workers,
          "cancel/re-admit churn cannot grow Windows callback queue or lose running leases");
  }
#endif
  std::printf("DNS_BURST submitted=%zu admitted=%zu rejected=%zu blocked_workers=%d peak_descriptors=%zu\n",
              count, accepted.size(), rejected, peak_held.load(), peak_sockets);
  hold_backend = false; gate.notify_all(); Empty(); peer.mode = Mode::Reply;
}
void Unconsumed(Peer& peer) {
#if BOUNDED
  peer.mode = Mode::Full;
  std::vector<int> pending;
  for (size_t i = 0; i < 256; ++i) pending.push_back(SendQuery());
  for (int fd : pending) { PollDescriptor ready{fd, POLLIN, 0}; Check(fd >= 0 && Poll(&ready, 1, 5000) > 0, "unconsumed completion ready"); }
  Check(Query::Outstanding() == 256 && SendQuery() == -EAGAIN,
        "completed-unconsumed answers retain total admission budget");
  size_t retained = 0;
  {
    std::lock_guard<std::mutex> registry(g_queries_mutex);
    for (const auto& entry : g_queries) {
      std::lock_guard<std::mutex> request(entry.second->mutex);
      retained += entry.second->answer.size();
    }
  }
  Check(retained == 256 * size_t{65535}, "maximum-size unread answers stay inside the admitted byte budget");
  std::printf("DNS_UNCONSUMED requests=256 answer_bytes=%zu\n", retained);
  for (int fd : pending) Check(Result(fd) == 65535, "all admitted maximum-size completions remain consumable");
  Empty();
  peer.mode = Mode::Reply;
  Check(Result(SendQuery()) == 12, "new valid work progresses after unread replies consumed"); Empty();
#else
  (void)peer;
#endif
}
void Deadlines(Peer& peer) {
#if BOUNDED
  peer.mode = Mode::Drop; hold_backend = true;
  int before = peer.packets;
  std::vector<int> active;
  for (int i = 0; i < 32; ++i) active.push_back(SendQuery());
  Until([] { return held == 32; }, "all deadline fixture workers occupied");
  Until([&] { return peer.packets >= before + 32; }, "all blocked worker datagrams reached peer");
  int queued = SendQuery(); int sent = peer.packets;
  // NO_RETRY's existing maximum is one 5s UDP exchange plus one 5s TCP fallback.
  std::this_thread::sleep_for(std::chrono::milliseconds(10'100));
  for (int fd : active) gesher_res_cancel(fd);
  hold_backend = false; gate.notify_all();
  Check(Result(queued) == -ETIMEDOUT, "queue delay consumes the same request deadline");
  Check(peer.packets == sent, "expired queued request does not open a backend socket"); Empty();
  peer.mode = Mode::Trickle;
  auto begin = Clock::now();
  Check(Result(SendQuery()) == -ETIMEDOUT, "TCP trickle cannot renew the exchange deadline");
  Check(Clock::now() - begin < std::chrono::seconds(8), "TCP deadline remains bounded across partial reads"); Empty();
  peer.mode = Mode::Reply;
#else
  (void)peer;
#endif
}
void SetupDeadlines(Peer& peer) {
#if BOUNDED
  peer.mode = Mode::Reply;
  std::vector<gesher::ws::Address> servers; uint32_t index = 17;
  Check(gesher::ws::DnsServers(index, &servers, &index) == 0, "setup-deadline fixture server discovery");
  auto packet = Packet();
  int packets_before = peer.packets;
  // Delay declared OS edges, never production code or its monotonic clock.
  for (bool tcp : {false, true}) {
    auto query = std::make_shared<Query>(); std::vector<uint8_t> answer;
    int connected = connect_calls;
    slow_open_ms = 90;
    int result = Exchange(query, servers[0], index, packet, &answer, tcp, 20,
                          Clock::now() + std::chrono::milliseconds(20));
    slow_open_ms = 0;
    Check(result == -ETIMEDOUT && query->active == -1 && Live() == 0,
          "expired socket setup retires UDP/TCP descriptor");
    Check(connect_calls == connected, "expired socket setup cannot begin UDP/TCP connect");
  }
  {
    auto query = std::make_shared<Query>(); std::vector<uint8_t> answer;
    int connected = connect_calls;
    slow_nonblocking_ms = 90;
    int result = Exchange(query, servers[0], index, packet, &answer, true, 20,
                          Clock::now() + std::chrono::milliseconds(20));
    slow_nonblocking_ms = 0;
    Check(result == -ETIMEDOUT && query->active == -1 && Live() == 0 && connect_calls == connected,
          "expired TCP mode setup cannot begin connect");
  }
  for (bool tcp : {false, true}) {
    auto query = std::make_shared<Query>(); std::vector<uint8_t> answer;
    int polled = poll_calls;
    slow_connect_ms = 90;
    int result = Exchange(query, servers[0], index, packet, &answer, tcp, 20,
                          Clock::now() + std::chrono::milliseconds(20));
    slow_connect_ms = 0;
    Check(result == -ETIMEDOUT && query->active == -1 && Live() == 0 && poll_calls == polled,
          "expired connect cannot send data or renew TCP poll timeout");
  }
  std::this_thread::sleep_for(std::chrono::milliseconds(30));
  Check(peer.packets == packets_before, "no UDP packet reaches the peer after setup consumed the deadline");
  {
    auto query = std::make_shared<Query>(); std::vector<uint8_t> answer;
    int polled = poll_calls;
    slow_connect_ms = 75;
    int result = Exchange(query, servers[0], index, packet, &answer, true, 200,
                          Clock::now() + std::chrono::milliseconds(200));
    slow_connect_ms = 0;
    Check((result == 0 || result == -ETIMEDOUT) && query->active == -1 && Live() == 0,
          "TCP setup delay preserves reply or genuine timeout and retires ownership");
    Check(poll_calls == polled || last_poll_timeout <= 125,
          "TCP readiness wait uses remaining budget after connect, not the original timeout");
  }
#else
  (void)peer;
#endif
}
void QueuedIdentity(Peer& peer) {
#if BOUNDED
  peer.mode = Mode::Drop; hold_backend = true;
  std::vector<int> active;
  for (int i = 0; i < 32; ++i) active.push_back(SendQuery());
  Until([] { return held == 32; }, "identity fixture workers occupied");
  process_interface = 41;
  auto input = Packet(); input.push_back(0xa7);
  int queued = gesher_res_nsend(0, input.data(), input.size(), 1);
  input[0] = 0x99; input.back() = 0xff; process_interface = 43;
  for (int fd : active) gesher_res_cancel(fd);
  peer.mode = Mode::Reply; hold_backend = false; gate.notify_all();
  std::vector<uint8_t> answer;
  Check(Result(queued, &answer) == 13 && answer[0] == 0x12 && answer.back() == 0xa7,
        "queued request owns immutable raw input bytes"); Empty();
  { std::lock_guard<std::mutex> lock(interfaces_mutex); Check(interfaces.back() == 41, "queued default-network identity cannot change at dispatch"); }
#else
  (void)peer;
#endif
}
void ServerFallback(Peer& peer) {
#if BOUNDED
  // An owned bound UDP socket with no receiver supplies a genuinely unavailable
  // first server. The configured backup uses the real TCP-truncation peer.
  NativeSocket unavailable = ::socket(AF_INET, SOCK_DGRAM, 0);
  sockaddr_in address{}; address.sin_family = AF_INET; address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  Check(::bind(unavailable, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0, "unavailable server bind");
  socklen_t size = sizeof(address);
  Check(::getsockname(unavailable, reinterpret_cast<sockaddr*>(&address), &size) == 0, "unavailable server port");
  first_server_port = ntohs(address.sin_port); peer.mode = Mode::Full;
  int before = peer.tcp_queries;
  auto begin = Clock::now();
  Check(Result(SendQuery(0, 0)) == 65535 && peer.tcp_queries > before,
        "unavailable first server leaves time for succeeding backup and TCP fallback");
  auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - begin).count();
  Check(elapsed >= 4000 && elapsed < 12'000, "first-server timeout actually occurred before backup success");
  std::printf("DNS_FALLBACK first_server_timeout_ms=%lld tcp_answer_bytes=65535\n", static_cast<long long>(elapsed));
  Empty(); first_server_port = 0; peer.mode = Mode::Reply; NativeClose(unavailable);
#else
  (void)peer;
#endif
}
}  // namespace fixture

int main() {
  fixture::Peer peer;
  return 0;
}
