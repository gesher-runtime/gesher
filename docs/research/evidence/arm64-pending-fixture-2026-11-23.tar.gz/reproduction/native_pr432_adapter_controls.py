#!/usr/bin/env python3
"""Compile bounded controls against the retained actual pending-rollback TU."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--generated', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
repo, original, out = args.repo.resolve(), args.generated.resolve(), args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
source = original.read_text()
assert source.count('int main() {') == 1
before_main = source[:source.index('int main() {')]
targeted = before_main + '''int main() {
  fixture::Env env;
  env.JitAt(0);
  env.icache_start_ = kPage;
  env.icache_end_ = 2 * kPage;
  env.FlushIcache();
  return 0;
}
'''
unregister = '    for (const auto& jit : jits_) UnregisterJit(jit.get());\n'
guard = '  void InvalidateCacheRange(uint64_t, uint64_t) { REQUIRE(false); }'
assert source.count(unregister) == 1 and targeted.count(guard) == 1
cases = [
    ('unregister-omitted', source.replace(unregister, ''), False, 'g_live_jits.empty()'),
    ('targeted-invalidation-guard', targeted, False, ': false'),
    ('targeted-invalidation-noop-negative', targeted.replace(guard,
        '  void InvalidateCacheRange(uint64_t, uint64_t) {}'), True, None),
]
receipts = []
for name, code, success, diagnostic in cases:
    directory = out / name
    directory.mkdir()
    cpp, binary = directory / 'test.cc', directory / 'test'
    cpp.write_text(code)
    command = ['c++', '-std=c++20', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
               '-fno-exceptions', '-pthread', '-I', str(repo / 'compat/arm64/include'),
               '-I', str(repo / 'compat/arm64/dll'), str(cpp), '-o', str(binary)]
    built = subprocess.run(command, capture_output=True, timeout=120)
    (directory / 'compile.log').write_bytes(built.stdout + built.stderr)
    assert built.returncode == 0, (name, 'compilation did not reach designated control')
    ran = subprocess.run([str(binary)], capture_output=True, timeout=60)
    raw = ran.stdout + ran.stderr
    (directory / 'run.log').write_bytes(raw)
    assert (ran.returncode == 0) == success, (name, ran.returncode, raw)
    if diagnostic is not None: assert diagnostic.encode() in raw, (name, raw)
    receipts.append({'name': name, 'command': command, 'compile_returncode': built.returncode,
                     'returncode': ran.returncode, 'expected_success': success,
                     'designated_diagnostic': diagnostic,
                     'source_sha256': hashlib.sha256(cpp.read_bytes()).hexdigest(),
                     'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                     'log_sha256': hashlib.sha256(raw).hexdigest()})
    print(json.dumps(receipts[-1]), flush=True)
(out / 'receipts.json').write_text(json.dumps({
    'generated_source': str(original), 'generated_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
    'cases': receipts,
    'scope': 'Fixture Jit ownership and fail-closed untested targeted-invalidation boundary only. The no-op negative must be rejected by the guard expectation; no successful guest cache coherence is modeled or claimed.'
}, indent=2) + '\n')
