#!/usr/bin/env python3
"""Replay the maintained actual-source helper, retaining only its temporary output."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--sanitize',action='store_true')
a=p.parse_args();root=a.repo.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
generated=out/'generated';generated.mkdir(exist_ok=True)
code='''import contextlib,runpy,sys,tempfile
from unittest.mock import patch
from pathlib import Path
@contextlib.contextmanager
def retained(*args,**kwargs):
 yield sys.argv[1]
helper=sys.argv[2]; flags=sys.argv[3:]
sys.argv=[helper,*flags]
with patch.object(tempfile,'TemporaryDirectory',retained):
 runpy.run_path(helper,run_name='__main__')
'''
# The context manager must retain the path before the helper changes sys.argv.
code=code.replace("helper=sys.argv[2]; flags=sys.argv[3:]", "folder=sys.argv[1]; helper=sys.argv[2]; flags=sys.argv[3:]").replace('yield sys.argv[1]','yield folder')
command=[sys.executable,'-c',code,str(generated),str(root/'tools/test_arm64_pending_rollback.py')]
if a.sanitize:command.append('--sanitize')
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
run=subprocess.run(command,cwd=root,env=env,capture_output=True);raw=run.stdout+run.stderr;(out/'run.log').write_bytes(raw)
sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['tools/test_arm64_pending_rollback.py','tests/native/arm64_pending_rollback_host.cc.in','tests/native/arm64_native_rollback_host.cc.in','compat/arm64/dll/translator.cc','compat/arm64/dll/translator.h']}
receipt=dict(command=command,returncode=run.returncode,sanitize=a.sanitize,sources=sources,log_sha256=hashlib.sha256(raw).hexdigest(),generated={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in generated.iterdir() if p.is_file()},boundary='only TemporaryDirectory replaced by an owned retained path; actual extractor/compiler/executable unchanged')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));sys.exit(run.returncode)
