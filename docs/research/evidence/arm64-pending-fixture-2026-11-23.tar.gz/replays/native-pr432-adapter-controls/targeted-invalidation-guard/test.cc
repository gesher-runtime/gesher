// Production translator methods are inserted verbatim. The Win32/Jit adapter
// below does not execute guest instructions or generated stubs. Its Jit retains
// instruction bytes until ClearCache, making missing retirement observable.
// Targeted guest instruction-cache invalidation is outside this rollback
// fixture: reaching that Jit boundary fails instead of simulating coherence.
#include "translator.h"
#include <sys/mman.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <barrier>
#include <cfenv>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <unordered_map>
#include <vector>

void Require(bool ok, const char* expression, int line) {
  if (!ok) {
    std::fprintf(stderr, "FAIL ARM64 pending rollback line %d: %s\n", line, expression);
    std::abort();
  }
}
#define REQUIRE(expression) Require((expression), #expression, __LINE__)

// Win32 boundary: pages are writable, never executed. Exact-address remapping
// is used only for a fixture mapping that has just been released.
using DWORD = uint32_t;
using BOOL = int;
using HANDLE = void*;
constexpr DWORD MEM_COMMIT = 0x1000, MEM_RESERVE = 0x2000, MEM_RELEASE = 0x8000;
constexpr DWORD PAGE_READWRITE = 4, PAGE_EXECUTE_READWRITE = 0x40;
constexpr DWORD DUPLICATE_SAME_ACCESS = 2;
constexpr BOOL FALSE = 0;
constexpr size_t kPage = 4096;
std::mutex allocation_mutex;
std::unordered_map<void*, size_t> allocations;
size_t allocation_calls = 0;
std::atomic<DWORD> next_thread_id{1};
thread_local DWORD thread_id = next_thread_id.fetch_add(1);
DWORD GetCurrentThreadId() { return thread_id; }
HANDLE GetCurrentProcess() { return nullptr; }
HANDLE GetCurrentThread() { return nullptr; }
DWORD GetEnvironmentVariableA(const char*, char*, DWORD) { return 0; }
BOOL FlushInstructionCache(HANDLE, const void*, size_t) { return 1; }
BOOL DuplicateHandle(HANDLE, HANDLE, HANDLE, HANDLE*, DWORD, BOOL, DWORD) {
  REQUIRE(false);  // Profiling is disabled.
  return 0;
}
void* VirtualAlloc(void* address, size_t size, DWORD flags, DWORD protect) {
  REQUIRE(flags == (MEM_COMMIT | MEM_RESERVE));
  REQUIRE(protect == PAGE_READWRITE || protect == PAGE_EXECUTE_READWRITE);
  REQUIRE(size != 0 && size % kPage == 0);
  const int fixed = address == nullptr ? 0 : MAP_FIXED_NOREPLACE;
  void* result = mmap(address, size, PROT_READ | PROT_WRITE,
                      MAP_PRIVATE | MAP_ANONYMOUS | fixed, -1, 0);
  if (result == MAP_FAILED) return nullptr;
  REQUIRE(address == nullptr || result == address);
  std::lock_guard<std::mutex> lock(allocation_mutex);
  REQUIRE(allocations.emplace(result, size).second);
  ++allocation_calls;
  return result;
}
BOOL VirtualFree(void* address, size_t size, DWORD flags) {
  REQUIRE(flags == MEM_RELEASE && size == 0);
  std::lock_guard<std::mutex> lock(allocation_mutex);
  auto entry = allocations.find(address);
  REQUIRE(entry != allocations.end());
  REQUIRE(munmap(address, entry->second) == 0);
  allocations.erase(entry);
  return 1;
}
size_t AllocationCalls() {
  std::lock_guard<std::mutex> lock(allocation_mutex);
  return allocation_calls;
}

namespace Dynarmic {
enum class HaltReason : unsigned { UserDefined1 = 1, UserDefined2 = 2, CacheInvalidation = 4 };
HaltReason operator|(HaltReason a, HaltReason b) {
  return static_cast<HaltReason>(static_cast<unsigned>(a) | static_cast<unsigned>(b));
}
bool Has(HaltReason reason, HaltReason flag) {
  return (static_cast<unsigned>(reason) & static_cast<unsigned>(flag)) != 0;
}
namespace A64 {
class UserCallbacks {
 public:
  virtual ~UserCallbacks() = default;
  virtual void CallSVC(uint32_t) = 0;
};
class Jit {
 public:
  bool running = false;
  unsigned clear_count = 0;
  std::function<void(Jit&)> run;
  std::unordered_map<uintptr_t, uint32_t> code;
  std::array<uint64_t, 31> registers{};
  uint64_t pc = 0;
  unsigned halt = 0;
  HaltReason Run() {
    REQUIRE(!running && static_cast<bool>(run));
    running = true;
    run(*this);
    running = false;
    return static_cast<HaltReason>(halt);
  }
  void InvalidateCacheRange(uint64_t, uint64_t) { REQUIRE(false); }
  void ClearCache() {
    REQUIRE(!running);
    code.clear();
    ++clear_count;
  }
  uint32_t Instruction(const void* address) {
    REQUIRE(running);
    const uintptr_t key = reinterpret_cast<uintptr_t>(address);
    auto entry = code.find(key);
    if (entry != code.end()) return entry->second;
    uint32_t value;
    std::memcpy(&value, address, sizeof(value));
    code.emplace(key, value);
    return value;
  }
  void ClearHalt(Dynarmic::HaltReason reason) { halt &= ~static_cast<unsigned>(reason); }
  void HaltExecution(Dynarmic::HaltReason reason = Dynarmic::HaltReason::UserDefined1) {
    halt |= static_cast<unsigned>(reason);
  }
  uint64_t GetPC() const { return pc; }
  uint64_t GetRegister(size_t index) const { return registers.at(index); }
  void SetRegister(size_t index, uint64_t value) { registers.at(index) = value; }
};
}  // namespace A64
}  // namespace Dynarmic
namespace A64 = Dynarmic::A64;

// Reaching any unexercised guest/ABI path fails the fixture.
[[noreturn]] void GuestCrash(int, int, const char*, uint64_t, const char*) { std::abort(); }
int64_t GuestRawSyscall(uint64_t, const uint64_t*) { std::abort(); }
extern "C" void gesher_guest_entry_shim() { std::abort(); }

namespace fixture {
constexpr int kSigSys = 31;
using gesher_arm64::kSigIll;
const gesher_arm64_host* g_host = nullptr;
thread_local int t_guest_running = 0;
std::shared_mutex g_host_pages_mutex;
std::unordered_map<uintptr_t, bool> g_host_pages;
class HostFenvScope {
 public:
  HostFenvScope() { std::fegetenv(&saved_); }
  ~HostFenvScope() { std::fesetenv(&saved_); }
 private:
  std::fenv_t saved_;
};


int ProfilePeriodMs() {
  static const int period = [] {
    char v[16] = {};
    DWORD n = GetEnvironmentVariableA("GESHER_ARM64_PROFILE", v, sizeof(v));
    if (n == 0 || n >= sizeof(v)) return 0;
    int ms = std::atoi(v);
    return ms <= 0 ? 0 : (ms < 500 ? 500 : ms);
  }();
  return period;
}

struct CodeRegion {
  uintptr_t start;
  uintptr_t end;
};
std::shared_mutex g_regions_mutex;
std::vector<CodeRegion> g_regions;
// Each classifier and Jit independently observes pending-load retirement.
std::atomic<uint64_t> g_code_generation{1};

// Called outside Jit::Run on every dispatch, also after a nested host call.
// Pooled Envs retain their generations and invalidate on their next dispatch.
void RefreshCodeCache(A64::Jit* jit, uint64_t* seen) {
  const uint64_t generation = g_code_generation.load(std::memory_order_acquire);
  if (*seen != generation) {
    jit->ClearCache();
    *seen = generation;
  }
}

// --- guest instruction cache maintenance -----------------------------------
// A guest that writes instructions (an inline hook a packer places on a
// function, a JIT's code) makes them visible to execution as on ARM: with
// IC IVAU for each cache line written, then ISB. Each Jit has translated
// copies of guest code: an invalidation goes to every live Jit at once, as
// IC IVAU is broadcast to every PE on ARM. dynarmic's InvalidateCacheRange is
// thread-safe and halts a Jit running guest code at its next block boundary
// (the halt check of a linked block included), so a thread spinning in guest
// code drops the copies promptly; a Jit that is not running (an outer Jit
// paused under a host call, a pooled Env's) drops them when it next runs.
struct LiveJit {
  A64::Jit* jit;
  std::atomic<uint32_t>* posted;  // ranges posted since its last dispatch
};
std::mutex g_live_jits_mutex;
std::vector<LiveJit> g_live_jits;
// A Jit that does not run for a while (a pooled Env's) accumulates posted
// ranges in its invalidation set: beyond this many it clears its whole cache.
constexpr uint32_t kMaxPostedRanges = 256;

void RegisterJit(A64::Jit* jit, std::atomic<uint32_t>* posted) {
  std::lock_guard<std::mutex> lock(g_live_jits_mutex);
  g_live_jits.push_back({jit, posted});
}

void UnregisterJit(A64::Jit* jit) {
  std::lock_guard<std::mutex> lock(g_live_jits_mutex);
  std::erase_if(g_live_jits, [jit](const LiveJit& j) { return j.jit == jit; });
}

void InvalidateEveryJit(uintptr_t start, uintptr_t end) {
  if (end <= start) return;
  std::lock_guard<std::mutex> lock(g_live_jits_mutex);
  for (const LiveJit& j : g_live_jits) {
    if (j.posted->fetch_add(1, std::memory_order_relaxed) < kMaxPostedRanges) {
      j.jit->InvalidateCacheRange(start, end - start);
    } else {
      j.jit->ClearCache();
    }
  }
}

// --- guest page protection ---------------------------------------------------
// The pages the guest mapped executable and not writable (mmap or mprotect),
// whose translations are therefore current: page-aligned, disjoint, coalesced
// [start, end) ranges. An mprotect that makes a range executable drops the
// translations of every page outside them (written while writable, or not
// guest code before), not of a range that stays R-X.
std::mutex g_clean_exec_mutex;
std::map<uintptr_t, uintptr_t> g_clean_exec;  // start -> end

void EraseCleanExec(uintptr_t first, uintptr_t end) {
  auto it = g_clean_exec.upper_bound(first);
  if (it != g_clean_exec.begin()) --it;
  while (it != g_clean_exec.end() && it->first < end) {
    const uintptr_t s = it->first, e = it->second;
    if (e <= first) {
      ++it;
      continue;
    }
    it = g_clean_exec.erase(it);
    if (s < first) g_clean_exec.emplace(s, first);
    if (e > end) {
      g_clean_exec.emplace(end, e);
      break;
    }
  }
}

void InsertCleanExec(uintptr_t first, uintptr_t end) {
  EraseCleanExec(first, end);
  auto next = g_clean_exec.lower_bound(first);
  if (next != g_clean_exec.end() && next->first == end) {
    end = next->second;
    g_clean_exec.erase(next);
  }
  auto prev = g_clean_exec.lower_bound(first);
  if (prev != g_clean_exec.begin() && std::prev(prev)->second == first) {
    std::prev(prev)->second = end;
    return;
  }
  g_clean_exec.emplace(first, end);
}

// The parts of [first, end) outside g_clean_exec.
std::vector<CodeRegion> UncleanParts(uintptr_t first, uintptr_t end) {
  std::vector<CodeRegion> parts;
  uintptr_t cursor = first;
  auto it = g_clean_exec.upper_bound(first);
  if (it != g_clean_exec.begin()) --it;
  for (; it != g_clean_exec.end() && it->first < end && cursor < end; ++it) {
    if (it->second <= cursor) continue;
    if (it->first > cursor) parts.push_back({cursor, it->first});
    cursor = std::max(cursor, it->second);
  }
  if (cursor < end) parts.push_back({cursor, end});
  return parts;
}

bool PageRange(const void* start, size_t size, uintptr_t* first, uintptr_t* end) {
  const uintptr_t s = reinterpret_cast<uintptr_t>(start);
  if (size == 0 || s > UINTPTR_MAX - size - 0xFFF) return false;
  *first = s & ~uintptr_t{0xFFF};
  *end = (s + size + 0xFFF) & ~uintptr_t{0xFFF};
  return true;
}

void AddRegion(uintptr_t start, size_t size) {
  if (size == 0 || start > UINTPTR_MAX - size) return;
  std::unique_lock<std::shared_mutex> lock(g_regions_mutex);
  g_regions.push_back({start, start + size});
}

// --- guest code pages for trampolines and guest-side helpers ------------------
// Readable, not executable: the host never runs guest code (a host call into
// one of these faults and is redirected like any other guest function).
std::mutex g_code_mutex;
uint8_t* g_code_page = nullptr;
size_t g_code_used = 0;
constexpr size_t kCodePage = 0x10000;
std::vector<uint8_t*> g_code_pages;  // every one so far

uint32_t* AllocGuestCode(size_t words) {
  std::lock_guard<std::mutex> lock(g_code_mutex);
  size_t bytes = words * 4;
  if (g_code_page == nullptr || g_code_used + bytes > kCodePage) {
    g_code_page = static_cast<uint8_t*>(
        VirtualAlloc(nullptr, kCodePage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    g_code_used = 0;
    if (g_code_page == nullptr) return nullptr;
    g_code_pages.push_back(g_code_page);
    AddRegion(reinterpret_cast<uintptr_t>(g_code_page), kCodePage);
  }
  auto* p = reinterpret_cast<uint32_t*>(g_code_page + g_code_used);
  g_code_used += (bytes + 15) & ~size_t{15};
  return p;
}

// --- guest trampolines for host imports --------------------------------------
// `SVC #n; RET` with n = index + 1 into g_tramps. SVC #0 is a raw Linux
// syscall made by guest code; SVC #0xFFFF is the return stub.
constexpr uint32_t kRet = 0xD65F03C0;
constexpr uint32_t Svc(uint32_t imm) { return 0xD4000001u | (imm << 5); }
constexpr uint32_t kReturnSvc = 0xFFFF;
constexpr size_t kMaxTramps = 0xFFFE;
// Each trampoline has 32 bytes to itself, the rest BRK: an in-place hook of a
// libc function (WhatsApp's libessential) overwrites its first instructions
// with a jump and a literal address, 20 bytes and more. In a 16-byte slot
// that address landed on the next function's trampoline (abort's), and the
// guest's next call there ran half an address as code.
constexpr size_t kTrampWords = 8;
constexpr uint32_t kBrk = 0xD4200000;

struct Trampoline {
  void* host_fn;
  int va_list_index;
  int pointer_variadic_fixed = -1;
  uint32_t* guest_code = nullptr;
};
// Writers remain serialized by g_tramp_mutex. Readers copy one coherent
// signature without taking that process-wide mutex on every imported call.
// Every field is atomic: a seqlock over ordinary fields would still have C++
// data races during retirement or variadic-signature replacement. Sequential
// consistency gives the version and field accesses one order, so matching even
// versions cannot enclose a partially published signature. No record is freed.
class TrampolineSlot {
 public:
  void Publish(const Trampoline& value) {
    const uint64_t before = sequence_.load();
    // Saturation leaves an odd version forever. Such a slot uses the mutex
    // fallback, rather than eventually accepting an ancient version after ABA.
    if (before != UINT64_MAX) sequence_.store(before + 1);
    host_fn_.store(value.host_fn);
    va_list_index_.store(value.va_list_index);
    pointer_variadic_fixed_.store(value.pointer_variadic_fixed);
    guest_code_.store(value.guest_code);
    if (before < UINT64_MAX - 1) sequence_.store(before + 2);
  }

  bool TryRead(Trampoline* value) const {
    const uint64_t before = sequence_.load();
    if ((before & 1) != 0) return false;
    *value = ReadLocked();
    return sequence_.load() == before;
  }

  // Either the caller owns g_tramp_mutex, or TryRead validates this copy.
  Trampoline ReadLocked() const {
    return {host_fn_.load(), va_list_index_.load(),
            pointer_variadic_fixed_.load(), guest_code_.load()};
  }

 private:
  std::atomic<uint64_t> sequence_{0};
  std::atomic<void*> host_fn_{nullptr};
  std::atomic<int> va_list_index_{-1};
  std::atomic<int> pointer_variadic_fixed_{-1};
  std::atomic<uint32_t*> guest_code_{nullptr};
};
static_assert(std::atomic<uint64_t>::is_always_lock_free &&
              std::atomic<void*>::is_always_lock_free && std::atomic<int>::is_always_lock_free);
TrampolineSlot g_tramps[kMaxTramps];
std::atomic<size_t> g_tramp_count{0};
std::mutex g_tramp_mutex;
std::unordered_map<void*, size_t> g_tramp_by_fn;
std::vector<size_t> g_free_tramps;  // reuse both the index and its code slot

Trampoline ReadTrampoline(size_t index) {
  Trampoline value{};
  for (unsigned attempt = 0; attempt < 8; ++attempt) {
    if (g_tramps[index].TryRead(&value)) return value;
  }
  // Bound retries if a publishing thread is descheduled, or the same slot is
  // being changed repeatedly. Ordinary calls to stable slots take no mutex.
  std::lock_guard<std::mutex> lock(g_tramp_mutex);
  return g_tramps[index].ReadLocked();
}

// --- va_list host functions --------------------------------------------------
std::mutex g_va_mutex;
std::unordered_map<const void*, int> g_va_functions;
std::unordered_map<const void*, Trampoline> g_pointer_variadic_functions;

Trampoline HostSignature(void* fn, int va_list_index = -2) {
  std::lock_guard<std::mutex> lock(g_va_mutex);
  auto direct = g_pointer_variadic_functions.find(fn);
  if (direct != g_pointer_variadic_functions.end()) return direct->second;
  if (va_list_index != -2) return {fn, va_list_index};
  auto it = g_va_functions.find(fn);
  return {fn, it == g_va_functions.end() ? -1 : it->second};
}


constexpr size_t kTcbSize = 64;
constexpr size_t kTlsBlockSize = 256 * 1024;  // per thread
std::mutex g_tls_mutex;
size_t g_tls_offset = kTcbSize;  // highest live extent; gaps below it can be reused
size_t g_tls_clear_size = kTcbSize;  // pooled blocks can retain a rolled-back tail
struct TlsImage {
  int64_t offset;
  const void* image;
  size_t image_size;
  size_t total_size;
  DWORD owner_thread;
  bool prepared;
  bool published;
};
struct TlsBlock {
  uint8_t* base;
  DWORD owner_thread;
};
std::vector<TlsImage> g_tls_images;
std::vector<TlsBlock> g_tls_blocks;  // every live thread's block (its TP)

void InitializeTlsImage(const TlsImage& image, uint8_t* base) {
  std::memset(base + image.offset, 0, image.total_size);
  if (image.image_size != 0) {
    std::memcpy(base + image.offset, image.image, image.image_size);
  }
}

int64_t ApiTlsRegister(size_t total_size, size_t align) {
  std::lock_guard<std::mutex> lock(g_tls_mutex);
  if (align < 1) align = 1;
  if ((align & (align - 1)) != 0 || align > kTlsBlockSize) return -1;
  // Zero-size modules still need distinct tokens while pending.
  const size_t reserved = std::max(total_size, size_t{1});
  if (reserved > kTlsBlockSize - kTcbSize) return -1;
  // Rollback can leave an interior gap below a nested committed module.
  // Derive occupied intervals without reordering the publication registry or
  // adding a second mutable allocation registry. Both pending and published
  // reservations retain their offsets and block reuse of their full extent.
  std::vector<const TlsImage*> ordered;
  ordered.reserve(g_tls_images.size());
  for (const TlsImage& entry : g_tls_images) ordered.push_back(&entry);
  std::sort(ordered.begin(), ordered.end(), [](const TlsImage* a, const TlsImage* b) {
    return a->offset < b->offset;
  });
  size_t off = (kTcbSize + align - 1) & ~(align - 1);
  for (const TlsImage* entry : ordered) {
    const size_t start = static_cast<size_t>(entry->offset);
    if (off <= start && reserved <= start - off) break;
    const size_t end = start + std::max(entry->total_size, size_t{1});
    off = (end + align - 1) & ~(align - 1);
  }
  if (off > kTlsBlockSize || reserved > kTlsBlockSize - off) return -1;
  g_tls_images.push_back({static_cast<int64_t>(off), nullptr, 0, total_size,
                          GetCurrentThreadId(), false, false});
  g_tls_offset = std::max(g_tls_offset, off + reserved);
  g_tls_clear_size = std::max(g_tls_clear_size, g_tls_offset);
  return static_cast<int64_t>(off);
}

int ApiTlsPrepare(int64_t offset, const void* image, size_t image_size, size_t total_size) {
  std::lock_guard<std::mutex> lock(g_tls_mutex);
  auto entry = std::find_if(g_tls_images.begin(), g_tls_images.end(),
      [offset](const TlsImage& ti) { return ti.offset == offset; });
  if (entry == g_tls_images.end() || entry->published || entry->total_size != total_size ||
      entry->owner_thread != GetCurrentThreadId() || image_size > total_size ||
      (image_size != 0 && image == nullptr)) return 0;
  if (entry->prepared) return entry->image == image && entry->image_size == image_size;
  entry->image = image;
  entry->image_size = image_size;
  entry->prepared = true;
  for (const TlsBlock& block : g_tls_blocks) {
    if (block.owner_thread == entry->owner_thread) InitializeTlsImage(*entry, block.base);
  }
  return 1;
}

void ApiTlsPublish(int64_t offset, const void* image, size_t image_size, size_t total_size) {
  std::lock_guard<std::mutex> lock(g_tls_mutex);
  auto entry = std::find_if(g_tls_images.begin(), g_tls_images.end(),
      [offset](const TlsImage& ti) { return ti.offset == offset; });
  if (entry == g_tls_images.end() || entry->published || entry->total_size != total_size ||
      entry->owner_thread != GetCurrentThreadId() || image_size > total_size ||
      (image_size != 0 && image == nullptr) ||
      (entry->prepared && (entry->image != image || entry->image_size != image_size))) return;
  entry->image = image;
  entry->image_size = image_size;
  entry->published = true;
  for (const TlsBlock& block : g_tls_blocks) {
    if (entry->prepared && block.owner_thread == entry->owner_thread) continue;
    InitializeTlsImage(*entry, block.base);
  }
}

int ApiTlsRollback(int64_t offset, size_t total_size) {
  std::lock_guard<std::mutex> lock(g_tls_mutex);
  auto entry = std::find_if(g_tls_images.begin(), g_tls_images.end(),
      [offset](const TlsImage& ti) { return ti.offset == offset; });
  if (entry == g_tls_images.end() || entry->published || entry->total_size != total_size ||
      entry->owner_thread != GetCurrentThreadId()) return 0;
  for (const TlsBlock& block : g_tls_blocks) {
    std::memset(block.base + offset, 0, std::max(total_size, size_t{1}));
  }
  g_tls_images.erase(entry);
  // A nested independent load may already have committed a newer extent.
  g_tls_offset = kTcbSize;
  for (const TlsImage& live : g_tls_images) {
    g_tls_offset = std::max(g_tls_offset, static_cast<size_t>(live.offset) +
                                            std::max(live.total_size, size_t{1}));
  }
  return 1;
}


std::mutex g_entry_mutex;
std::unordered_map<const void*, void*> g_entries;
uint8_t* g_entry_page = nullptr;
size_t g_entry_used = 0;
size_t g_entry_cap = 0;
constexpr size_t kEntryStub = 24;
std::vector<uint8_t*> g_free_entries;

void* MakeHostEntry(const void* fn) {
  std::lock_guard<std::mutex> lock(g_entry_mutex);
  auto it = g_entries.find(fn);
  if (it != g_entries.end()) return it->second;
  uint8_t* p;
  if (!g_free_entries.empty()) {
    p = g_free_entries.back();
    g_free_entries.pop_back();
  } else {
    if (g_entry_page == nullptr || g_entry_used + kEntryStub > g_entry_cap) {
      g_entry_cap = 0x10000;
      g_entry_page = static_cast<uint8_t*>(
          VirtualAlloc(nullptr, g_entry_cap, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
      g_entry_used = 0;
      if (g_entry_page == nullptr) return nullptr;
    }
    p = g_entry_page + g_entry_used;
    g_entry_used += kEntryStub;
  }
  uint64_t f = reinterpret_cast<uint64_t>(fn);
  uint64_t shim = reinterpret_cast<uint64_t>(&gesher_guest_entry_shim);
  p[0] = 0x49; p[1] = 0xBA;              // mov r10, imm64(fn)
  std::memcpy(p + 2, &f, 8);
  p[10] = 0x48; p[11] = 0xB8;            // mov rax, imm64(shim)
  std::memcpy(p + 12, &shim, 8);
  p[20] = 0xFF; p[21] = 0xE0;            // jmp rax
  p[22] = 0x90; p[23] = 0x90;
  FlushInstructionCache(GetCurrentProcess(), p, kEntryStub);
  g_entries[fn] = p;
  return p;
}


void ForgetGuestProtection(const void* start, size_t size) {
  uintptr_t first, end;
  if (!PageRange(start, size, &first, &end)) return;
  std::lock_guard<std::mutex> lock(g_clean_exec_mutex);
  EraseCleanExec(first, end);
}


void ApiRemoveCode(const void* mapping_base, size_t mapping_size) {
  const uintptr_t first = reinterpret_cast<uintptr_t>(mapping_base);
  if (mapping_size == 0 || first > UINTPTR_MAX - mapping_size) return;
  const uintptr_t end = first + mapping_size;
  ForgetGuestProtection(mapping_base, mapping_size);
  {
    std::unique_lock<std::shared_mutex> lock(g_regions_mutex);
    // A guest mprotect registration may span more than the aborted mapping.
    // Keep outside prefixes/suffixes without retaining a stale overlap.
    std::vector<CodeRegion> survivors;
    survivors.reserve(g_regions.size() + 1);
    for (const CodeRegion& region : g_regions) {
      if (region.end <= first || region.start >= end) survivors.push_back(region);
      else {
        if (region.start < first) survivors.push_back({region.start, first});
        if (region.end > end) survivors.push_back({end, region.end});
      }
    }
    g_regions.swap(survivors);
  }
  {
    std::lock_guard<std::mutex> lock(g_entry_mutex);
    for (auto entry = g_entries.begin(); entry != g_entries.end();) {
      const uintptr_t guest = reinterpret_cast<uintptr_t>(entry->first);
      if (guest >= first && guest < end) {
        auto* stub = static_cast<uint8_t*>(entry->second);
        std::memset(stub, 0xcc, kEntryStub);  // erase every embedded guest pointer
        FlushInstructionCache(GetCurrentProcess(), stub, kEntryStub);
        g_free_entries.push_back(stub);
        entry = g_entries.erase(entry);
      } else ++entry;
    }
  }
  g_code_generation.fetch_add(1, std::memory_order_release);
}

void ApiUnbindHostFunction(void* fn) {
  if (fn == nullptr) return;
  {
    std::lock_guard<std::mutex> lock(g_tramp_mutex);
    auto entry = g_tramp_by_fn.find(fn);
    if (entry == g_tramp_by_fn.end()) return;
    const size_t index = entry->second;
    uint32_t* code = g_tramps[index].ReadLocked().guest_code;
    g_tramps[index].Publish({nullptr, -1, -1, code});
    std::fill(code, code + kTrampWords, kBrk);
    g_tramp_by_fn.erase(entry);
    g_free_tramps.push_back(index);
  }
  {
    std::lock_guard<std::mutex> lock(g_va_mutex);
    g_va_functions.erase(fn);
  }
  {
    std::unique_lock<std::shared_mutex> lock(g_host_pages_mutex);
    g_host_pages.erase(reinterpret_cast<uintptr_t>(fn) & ~uintptr_t{0xfff});
  }
  // Live and pooled Jits may have translated the slot. Retire those copies
  // before their next dispatch, after all instruction writes are complete.
  g_code_generation.fetch_add(1, std::memory_order_release);
}


bool InGuestCode(uintptr_t addr) {
  static thread_local CodeRegion last{0, 0};
  static thread_local uint64_t seen = 0;
  const uint64_t generation = g_code_generation.load(std::memory_order_acquire);
  if (seen == generation && addr >= last.start && addr < last.end) return true;
  std::shared_lock<std::shared_mutex> lock(g_regions_mutex);
  last = {0, 0};
  seen = g_code_generation.load(std::memory_order_relaxed);
  for (const CodeRegion& r : g_regions) {
    if (addr >= r.start && addr < r.end) {
      last = r;
      return true;
    }
  }
  return false;
}


void AddVaListFunction(const void* fn, int index) {
  if (fn == nullptr) return;
  {
    std::lock_guard<std::mutex> lock(g_va_mutex);
    g_va_functions[fn] = index;
  }
  // A trampoline already bound to it picks the index up.
  std::lock_guard<std::mutex> lock(g_tramp_mutex);
  auto it = g_tramp_by_fn.find(const_cast<void*>(fn));
  if (it != g_tramp_by_fn.end()) {
    Trampoline signature = g_tramps[it->second].ReadLocked();
    signature.va_list_index = index;
    g_tramps[it->second].Publish(signature);
  }
}

void AddPointerVariadicFunction(const void* fn, void* va_fn, int fixed_arguments) {
  // The va_list must fit after the fixed arguments in the host GP registers.
  if (fn == nullptr || va_fn == nullptr || fixed_arguments < 0 || fixed_arguments >= 6) return;
  Trampoline signature{va_fn, -1, fixed_arguments};
  {
    std::lock_guard<std::mutex> lock(g_va_mutex);
    g_pointer_variadic_functions[fn] = signature;
  }
  std::lock_guard<std::mutex> lock(g_tramp_mutex);
  auto it = g_tramp_by_fn.find(const_cast<void*>(fn));
  if (it != g_tramp_by_fn.end()) {
    signature.guest_code = g_tramps[it->second].ReadLocked().guest_code;
    g_tramps[it->second].Publish(signature);
  }
}

void* BindHost(void* fn, int va_list_index) {
  if (fn == nullptr) return nullptr;
  Trampoline signature = HostSignature(fn, va_list_index);
  std::lock_guard<std::mutex> lock(g_tramp_mutex);
  auto it = g_tramp_by_fn.find(fn);
  if (it != g_tramp_by_fn.end()) return g_tramps[it->second].ReadLocked().guest_code;
  size_t index = g_free_tramps.empty() ? g_tramp_count.load(std::memory_order_relaxed)
                                      : g_free_tramps.back();
  if (index >= kMaxTramps) return nullptr;
  uint32_t* p = g_free_tramps.empty() ? AllocGuestCode(kTrampWords) : g_tramps[index].ReadLocked().guest_code;
  if (p == nullptr) return nullptr;
  if (!g_free_tramps.empty()) g_free_tramps.pop_back();
  signature.guest_code = p;
  g_tramps[index].Publish(signature);
  p[0] = Svc(static_cast<uint32_t>(index + 1));
  p[1] = kRet;
  for (size_t i = 2; i < kTrampWords; ++i) p[i] = kBrk;
  if (index == g_tramp_count.load(std::memory_order_relaxed)) {
    g_tramp_count.store(index + 1, std::memory_order_release);
  }
  g_tramp_by_fn[fn] = index;
  return p;
}


struct Counter {
  std::atomic<uint64_t> v{0};
  void Bump() { v.store(v.load(std::memory_order_relaxed) + 1, std::memory_order_relaxed); }
  uint64_t Get() const { return v.load(std::memory_order_relaxed); }
};
struct ThreadCounters {
  Counter host_calls, syscalls, excl_reads, excl_writes, excl_cas_failed, hints, waits, runs;
};

class Env;
std::mutex g_envs_mutex;
std::vector<Env*> g_envs;  // every Env with a live thread (for the profiler)



// Adapter around the real dispatch/SVC/Attach methods. Host ABI marshalling
// and Jit construction are represented by controllable callbacks.
class Env final : public A64::UserCallbacks {
 public:
  static constexpr size_t kStackSize = 8 << 20, kGuardSize = 0x10000;
  uint8_t* tls_block_ = static_cast<uint8_t*>(
      VirtualAlloc(nullptr, kTlsBlockSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
  uint8_t* stack_base_ = nullptr;
  uint64_t stack_top_ = 0, stack_cur_ = 0, tls_pointer_ = 0, wait_pc_ = 0;
  size_t depth_ = 0;
  uint32_t fpcr_ = 0, fpsr_ = 0;
  DWORD tid_ = 0;
  HANDLE thread_ = nullptr;
  bool used_before_ = false, event_ = false;
  std::vector<std::unique_ptr<A64::Jit>> jits_;
  std::vector<uint64_t> code_generations_;
  std::vector<std::unique_ptr<std::atomic<uint32_t>>> posted_;
  uintptr_t icache_start_ = 0, icache_end_ = 0;
  std::atomic<A64::Jit*> running_jit_{nullptr};
  std::atomic<uint64_t> last_syscall_{0};
  ThreadCounters counters_;
  std::function<void(A64::Jit*, void*, int, int)> host_call;
  Env() { REQUIRE(tls_block_ != nullptr); }
  ~Env() override {
    UnattachForTest();
    for (const auto& jit : jits_) UnregisterJit(jit.get());
    REQUIRE(VirtualFree(tls_block_, 0, MEM_RELEASE));
  }
  void UnattachForTest() {
    std::lock_guard<std::mutex> lock(g_tls_mutex);
    std::erase_if(g_tls_blocks, [this](const TlsBlock& block) { return block.base == tls_block_; });
  }
  A64::Jit* JitAt(size_t depth) {
    while (jits_.size() <= depth) {
      jits_.push_back(std::make_unique<A64::Jit>());
      code_generations_.push_back(g_code_generation.load(std::memory_order_acquire));
      posted_.push_back(std::make_unique<std::atomic<uint32_t>>(0));
      RegisterJit(jits_.back().get(), posted_.back().get());
    }
    return jits_[depth].get();
  }
  A64::Jit* CurrentJit() { return depth_ == 0 ? nullptr : jits_[depth_ - 1].get(); }
  void Dispatch(size_t depth, std::function<void(A64::Jit&)> run) {
    A64::Jit* jit = JitAt(depth);
    jit->run = std::move(run);
    const size_t previous_depth = depth_;
    depth_ = depth + 1;
    RunGuest(jit);
    depth_ = previous_depth;
  }
  void CallHost(A64::Jit* jit, void* fn, int index, int pointer_variadic_fixed) {
    REQUIRE(!jit->running && t_guest_running == 0 && static_cast<bool>(host_call));
    host_call(jit, fn, index, pointer_variadic_fixed);
  }
  void Attach() {
    {
      std::lock_guard<std::mutex> lock(g_tls_mutex);
      // A failed Park decommit can retain the last thread's bytes, including
      // a tail rolled back while parked. Clear the historical assigned extent;
      // a fresh block is zero anyway. The allocation cursor can still shrink.
      if (used_before_) std::memset(tls_block_, 0, g_tls_clear_size);
      const DWORD owner = GetCurrentThreadId();
      g_tls_blocks.push_back({tls_block_, owner});
      for (const TlsImage& ti : g_tls_images) {
        if (!ti.published && !(ti.prepared && ti.owner_thread == owner)) continue;
        InitializeTlsImage(ti, tls_block_);
      }
    }
    used_before_ = true;
    tls_pointer_ = reinterpret_cast<uint64_t>(tls_block_);  // a guest MSR TPIDR_EL0 may have moved it
    stack_cur_ = stack_top_;
    depth_ = 0;
    fpcr_ = fpsr_ = 0;
    event_ = false;
    wait_pc_ = 0;
    tid_ = GetCurrentThreadId();
    // This private guest allocation differs from the native callback stack.
    // Only values cross the boundary; the host registry owns pthread lifetime.
    using PublishStack = int(GESHER_SYSV*)(void*, uint64_t, uint64_t);
    static auto publish_stack = reinterpret_cast<PublishStack>(
        g_host != nullptr && g_host->resolve != nullptr
            ? g_host->resolve("__gesher_arm64_set_thread_stack") : nullptr);
    if (publish_stack) publish_stack(stack_base_, kStackSize, kGuardSize);
    if (ProfilePeriodMs() > 0) {
      // Publish only a live profiling handle: Detach removes exactly these
      // entries before closing the handle or returning the Env to the pool.
      if (DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &thread_, 0,
                          FALSE, DUPLICATE_SAME_ACCESS)) {
        std::lock_guard<std::mutex> lock(g_envs_mutex);
        g_envs.push_back(this);
      }
    }
  }


  void FlushIcache() {
    if (icache_end_ == 0) return;
    const uintptr_t start = icache_start_, end = icache_end_;
    icache_start_ = icache_end_ = 0;
    InvalidateEveryJit(start, end);
  }


  void CallSVC(std::uint32_t swi) override {
    A64::Jit* jit = CurrentJit();
    if (swi == kReturnSvc) {  // the guest returned to the host
      jit->HaltExecution();
      return;
    }
    if (swi == 0) {  // a raw Linux syscall in guest code: x8 = number
      pending_call_ = {nullptr, -1, true};
      jit->HaltExecution(Dynarmic::HaltReason::UserDefined2);
      return;
    }
    Trampoline trampoline{};
    if (swi - 1 < g_tramp_count.load(std::memory_order_acquire)) {
      trampoline = ReadTrampoline(swi - 1);
    }
    if (trampoline.host_fn == nullptr) {
      GuestCrash(kSigSys, 1, "SYS_SECCOMP", jit->GetPC() - 4, "SVC with an unknown number");
    }
    QueueHostCall(jit, trampoline);
  }


  struct PendingHostCall {
    void* fn = nullptr;
    int va_index = -1;
    bool syscall = false;
    int pointer_variadic_fixed = -1;
    bool undefined = false;  // IC IALLU(IS) at EL0
  };

  void QueueHostCall(A64::Jit* jit, const Trampoline& signature) {
    pending_call_ = {signature.host_fn, signature.va_list_index, false,
                     signature.pointer_variadic_fixed};
    jit->HaltExecution(Dynarmic::HaltReason::UserDefined2);
  }

  void RunGuest(A64::Jit* jit) {
    for (;;) {
      // A host call can abort a nested load while this outer Jit is paused.
      // Nested Jit creation may grow the vector: keep no reference across Run.
      RefreshCodeCache(jit, &code_generations_[depth_ - 1]);
      // Run drops the ranges posted so far before it dispatches.
      posted_[depth_ - 1]->store(0, std::memory_order_relaxed);
      pending_call_ = {};
      jit->ClearHalt(Dynarmic::HaltReason::UserDefined1 | Dynarmic::HaltReason::UserDefined2);
      int saved_running = t_guest_running;
      t_guest_running = 1;
      counters_.runs.Bump();
      A64::Jit* saved_jit = running_jit_.exchange(jit, std::memory_order_relaxed);
      const Dynarmic::HaltReason halt = jit->Run();
      running_jit_.store(saved_jit, std::memory_order_relaxed);
      t_guest_running = saved_running;
      // Lines this thread invalidated without an ISB yet: before it leaves
      // guest code (the host function may wait for another guest thread).
      FlushIcache();
      // SVC saves its following PC; NoExecuteFault saves X30. Returning from
      // Run restores host MXCSR before executing arbitrary native host code.
      // A fresh dispatch then uses the actual (possibly changed) guest FPCR.
      PendingHostCall pending = pending_call_;
      if (pending.undefined) {
        // The SYS instruction is at PC - 4 (dynarmic set PC past it).
        const uint64_t pc = jit->GetPC() - 4;
        uint32_t insn = 0;
        if (InGuestCode(pc)) std::memcpy(&insn, reinterpret_cast<void*>(pc), 4);
        char detail[112];
        std::snprintf(detail, sizeof(detail),
                      "undefined instruction 0x%08x (IC IALLU/IALLUIS: EL1 only, UNDEFINED at EL0)",
                      insn);
        GuestCrash(kSigIll, 1, "ILL_ILLOPC", pc, detail);
      }
      if (pending.syscall) {
        HostFenvScope host_fenv;
        uint64_t args[6];
        for (int i = 0; i < 6; ++i) args[i] = jit->GetRegister(i);
        counters_.syscalls.Bump();
        last_syscall_.store(jit->GetRegister(8), std::memory_order_relaxed);
        int64_t result = GuestRawSyscall(jit->GetRegister(8), args);
        jit->SetRegister(0, static_cast<uint64_t>(result));
      } else if (pending.fn != nullptr) {
        CallHost(jit, pending.fn, pending.va_index, pending.pointer_variadic_fixed);
      } else if (Dynarmic::Has(halt, Dynarmic::HaltReason::CacheInvalidation) &&
                 !Dynarmic::Has(halt, Dynarmic::HaltReason::UserDefined1)) {
        // Stopped only to drop translations an IC IVAU (of this thread or
        // another) invalidated (Run has dropped them): the guest carries on.
        continue;
      } else {
        return;
      }
    }
  }


  PendingHostCall pending_call_;
};

void TestTls() {
  std::array<uint8_t, kTlsBlockSize> live{};
  std::array<uint8_t, kTlsBlockSize> second{};
  g_tls_blocks = {{live.data(), GetCurrentThreadId()}, {second.data(), GetCurrentThreadId()}};
  static const uint8_t image[] = {0x13, 0x24, 0x35, 0x46};
  static const uint8_t replacement[] = {0xee, 0xdd};
  REQUIRE(ApiTlsRegister(64, 3) == -1);
  REQUIRE(ApiTlsRegister(64, SIZE_MAX) == -1);
  REQUIRE(ApiTlsRegister(SIZE_MAX, 16) == -1);
  REQUIRE(ApiTlsRegister(kTlsBlockSize, 1) == -1);
  REQUIRE(g_tls_offset == kTcbSize && g_tls_images.empty());
  REQUIRE(!ApiTlsRollback(-1, 64));
  ApiTlsPublish(64, image, sizeof(image), 64);
  REQUIRE(g_tls_images.empty());

  const int64_t empty_a = ApiTlsRegister(0, 1);
  const int64_t empty_b = ApiTlsRegister(0, 1);
  REQUIRE(empty_a == static_cast<int64_t>(kTcbSize) && empty_b == empty_a + 1);
  REQUIRE(ApiTlsRollback(empty_a, 0) && g_tls_offset == static_cast<size_t>(empty_b + 1));
  REQUIRE(ApiTlsRollback(empty_b, 0) && g_tls_offset == kTcbSize);
  REQUIRE(!ApiTlsRollback(empty_b, 0) && g_tls_images.empty());
  std::puts("PASS ARM64 pending rollback: invalid extents and distinct empty reservations");

  const int64_t stable = ApiTlsRegister(64, 64);
  REQUIRE(stable == static_cast<int64_t>(kTcbSize));
  ApiTlsPublish(stable, image, sizeof(image), 64);
  REQUIRE(std::memcmp(live.data() + stable, image, sizeof(image)) == 0);
  REQUIRE(std::memcmp(second.data() + stable, image, sizeof(image)) == 0);
  live[stable] = 0xa1;
  second[stable] = 0xb2;
  ApiTlsPublish(stable, replacement, sizeof(replacement), 64);
  REQUIRE(!ApiTlsRollback(stable, 64));
  REQUIRE(live[stable] == 0xa1 && second[stable] == 0xb2);
  std::puts("PASS ARM64 pending rollback: publication initializes live blocks and protects committed state");

  const int64_t pending = ApiTlsRegister(100, 16);
  REQUIRE(pending >= 0);
  ApiTlsPublish(pending, image, 101, 100);
  ApiTlsPublish(pending, nullptr, 1, 100);
  ApiTlsPublish(pending, image, sizeof(image), 99);
  REQUIRE(!g_tls_images.back().published);
  std::memset(live.data() + pending, 0xcc, 100);
  std::memset(second.data() + pending, 0xdd, 100);
  std::thread foreign([&] {
    REQUIRE(!ApiTlsRollback(pending, 100));
    ApiTlsPublish(pending, image, sizeof(image), 100);
  });
  foreign.join();
  REQUIRE(!g_tls_images.back().published && live[pending] == 0xcc && second[pending] == 0xdd);
  REQUIRE(!ApiTlsRollback(pending, 99));
  REQUIRE(ApiTlsRollback(pending, 100));
  REQUIRE(!ApiTlsRollback(pending, 100));
  for (size_t i = 0; i < 100; ++i) REQUIRE(live[pending + i] == 0 && second[pending + i] == 0);
  REQUIRE(live[stable] == 0xa1 && second[stable] == 0xb2);
  REQUIRE(g_tls_images.size() == 1 && g_tls_offset == static_cast<size_t>(stable) + 64);
  std::puts("PASS ARM64 pending rollback: ownership, exact reservation identity, clearing and repeat rejection");

  const int64_t outer = ApiTlsRegister(4096, 64);
  const int64_t nested = ApiTlsRegister(64, 64);
  REQUIRE(outer >= 0 && nested >= outer + 4096);
  std::memset(live.data() + outer, 0x75, 4096);
  ApiTlsPublish(nested, image, sizeof(image), 64);
  live[nested] = 0xe3;
  second[nested] = 0xf4;
  const size_t nested_extent = g_tls_offset;
  REQUIRE(ApiTlsRollback(outer, 4096));
  REQUIRE(g_tls_offset == nested_extent && live[nested] == 0xe3 && second[nested] == 0xf4);
  REQUIRE(!ApiTlsRollback(nested, 64));
  const int64_t reused = ApiTlsRegister(200, 1);
  REQUIRE(reused == outer);
  REQUIRE(g_tls_offset == nested_extent);
  REQUIRE(ApiTlsRollback(reused, 200) && g_tls_offset == nested_extent);
  REQUIRE(g_tls_images.size() == 2);
  // Reservations arrive out of address order when alignment leaves a gap.
  const int64_t unaligned = ApiTlsRegister(13, 1);
  const int64_t aligned = ApiTlsRegister(17, 64);
  const int64_t padding = ApiTlsRegister(9, 1);
  REQUIRE(unaligned == outer && aligned == outer + 64 && padding == outer + 13);
  REQUIRE(ApiTlsRollback(aligned, 17) && ApiTlsRollback(unaligned, 13));
  REQUIRE(ApiTlsRollback(padding, 9) && g_tls_images.size() == 2);
  REQUIRE(g_tls_offset == nested_extent && live[nested] == 0xe3 && second[nested] == 0xf4);
  std::puts("PASS ARM64 pending rollback: aligned interior gaps are reusable without moving committed offsets");

  for (int attempt = 0; attempt < 64; ++attempt) {
    const int64_t interior = ApiTlsRegister(4096, 1);
    REQUIRE(interior == outer && g_tls_offset == nested_extent);
    const size_t remaining = kTlsBlockSize - g_tls_offset;
    const int64_t full = ApiTlsRegister(remaining, 1);
    REQUIRE(full >= 0 && g_tls_offset == kTlsBlockSize);
    REQUIRE(ApiTlsRegister(1, 1) == -1);
    REQUIRE(ApiTlsRollback(interior, 4096) && g_tls_offset == kTlsBlockSize);
    REQUIRE(ApiTlsRollback(full, remaining));
    REQUIRE(g_tls_offset == nested_extent && g_tls_images.size() == 2);
  }
  REQUIRE(live[stable] == 0xa1 && second[stable] == 0xb2);
  REQUIRE(live[nested] == 0xe3 && second[nested] == 0xf4);
  g_tls_blocks.clear();
  std::puts("PASS ARM64 pending rollback: 64 full-budget failure/retry cycles retain no pending records");
}

void TestTlsInteriorReuse() {
  REQUIRE(g_tls_blocks.empty());
  std::array<uint8_t, kTlsBlockSize> live{};
  std::array<uint8_t, kTlsBlockSize> peer{};
  const size_t committed_before = g_tls_images.size();
  // These explicit blocks represent already attached threads. Their older
  // committed modules contain different mutations which rollback must keep.
  for (const TlsImage& entry : g_tls_images) {
    REQUIRE(entry.published && entry.total_size != 0);
    live[entry.offset] = 0xa5;
    peer[entry.offset] = 0x5a;
  }
  g_tls_blocks = {{live.data(), GetCurrentThreadId()}, {peer.data(), GetCurrentThreadId()}};
  static const uint8_t image[] = {0x42, 0x73};
  std::array<int64_t, 128> nested{};
  for (size_t attempt = 0; attempt < nested.size(); ++attempt) {
    const size_t outer_size = 64 * 1024;
    const int64_t outer = ApiTlsRegister(outer_size, 512);
    if (outer < 0 || static_cast<size_t>(outer) > kTlsBlockSize - outer_size) {
      std::fprintf(stderr, "FAIL repeated TLS allocation: attempt %zu, offset %lld\n",
                   attempt, static_cast<long long>(outer));
      std::abort();
    }
    REQUIRE(outer % 512 == 0);
    const size_t outer_offset = static_cast<size_t>(outer);
    std::memset(live.data() + outer_offset, 0xcc, outer_size);
    std::memset(peer.data() + outer_offset, 0xdd, outer_size);
    nested[attempt] = ApiTlsRegister(64, 64);
    REQUIRE(nested[attempt] >= 0 && nested[attempt] % 64 == 0);
    ApiTlsPublish(nested[attempt], image, sizeof(image), 64);
    live[nested[attempt]] = static_cast<uint8_t>(attempt + 1);
    peer[nested[attempt]] = static_cast<uint8_t>(255 - attempt);
    REQUIRE(ApiTlsRollback(outer, outer_size));
    REQUIRE(live[outer] == 0 && peer[outer] == 0);
    REQUIRE(live[outer + outer_size - 1] == 0 && peer[outer + outer_size - 1] == 0);
    REQUIRE(g_tls_images.size() == committed_before + attempt + 1);
    for (size_t i = 0; i <= attempt; ++i) {
      REQUIRE(live[nested[i]] == static_cast<uint8_t>(i + 1));
      REQUIRE(peer[nested[i]] == static_cast<uint8_t>(255 - i));
    }
    for (size_t i = 0; i < committed_before; ++i) {
      REQUIRE(live[g_tls_images[i].offset] == 0xa5);
      REQUIRE(peer[g_tls_images[i].offset] == 0x5a);
    }
  }
  g_tls_blocks.clear();
  std::puts("PASS ARM64 pending rollback: 128 failed 64KiB outer loads preserve distinct nested commits and reclaim interior capacity");
}

void TestTlsPreparation() {
  REQUIRE(g_tls_blocks.empty());
  std::array<uint8_t, kTlsBlockSize> owner{};
  std::array<uint8_t, kTlsBlockSize> foreign{};
  DWORD foreign_id = 0;
  std::thread identify([&] { foreign_id = GetCurrentThreadId(); });
  identify.join();
  // As in TestTls, these blocks are an explicit attachment boundary, with
  // identities obtained from two different host fixture threads.
  g_tls_blocks = {{owner.data(), GetCurrentThreadId()}, {foreign.data(), foreign_id}};
  static const uint32_t initial = 37, different = 42;
  const auto read = [](const auto& block, int64_t off) {
    uint32_t value;
    std::memcpy(&value, block.data() + off, sizeof(value));
    return value;
  };
  const auto mutate = [](auto& block, int64_t off) {
    const uint32_t value = 93;
    std::memcpy(block.data() + off, &value, sizeof(value));
  };
  const int64_t abandoned = ApiTlsRegister(16, 4);
  REQUIRE(abandoned >= 0);
  REQUIRE(!ApiTlsPrepare(abandoned, nullptr, sizeof(initial), 16));
  REQUIRE(!ApiTlsPrepare(abandoned, &initial, 17, 16));
  REQUIRE(!ApiTlsPrepare(abandoned, &initial, sizeof(initial), 15));
  std::thread non_owner([&] {
    REQUIRE(!ApiTlsPrepare(abandoned, &initial, sizeof(initial), 16));
  });
  non_owner.join();
  REQUIRE(ApiTlsPrepare(abandoned, &initial, sizeof(initial), 16));
  REQUIRE(read(owner, abandoned) == 37 && read(foreign, abandoned) == 0);
  mutate(owner, abandoned);
  REQUIRE(ApiTlsPrepare(abandoned, &initial, sizeof(initial), 16));
  REQUIRE(read(owner, abandoned) == 93 && read(foreign, abandoned) == 0);
  REQUIRE(!ApiTlsPrepare(abandoned, &different, sizeof(different), 16));
  REQUIRE(ApiTlsRollback(abandoned, 16));
  REQUIRE(read(owner, abandoned) == 0 && read(foreign, abandoned) == 0);
  const int64_t committed = ApiTlsRegister(16, 4);
  REQUIRE(committed == abandoned);
  REQUIRE(ApiTlsPrepare(committed, &initial, sizeof(initial), 16));
  mutate(owner, committed);
  ApiTlsPublish(committed, &different, sizeof(different), 16);
  REQUIRE(read(owner, committed) == 93 && read(foreign, committed) == 0);
  ApiTlsPublish(committed, &initial, sizeof(initial), 16);
  REQUIRE(read(owner, committed) == 93 && read(foreign, committed) == 37);
  ApiTlsPublish(committed, &initial, sizeof(initial), 16);
  REQUIRE(read(owner, committed) == 93 && read(foreign, committed) == 37);
  REQUIRE(!ApiTlsPrepare(committed, &initial, sizeof(initial), 16));
  REQUIRE(!ApiTlsRollback(committed, 16));
  g_tls_blocks.clear();
  std::puts("PASS ARM64 pending rollback: private TLS preparation preserves IFUNC writes while publication initializes foreign blocks");
}


void TestClassificationAndEntries() {
  auto* image = static_cast<uint8_t*>(
      VirtualAlloc(nullptr, 4 * kPage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
  REQUIRE(image != nullptr);
  const uintptr_t base = reinterpret_cast<uintptr_t>(image);
  AddRegion(base, 4 * kPage);
  void* stable_fn = image + 16;
  void* pending_fn = image + kPage + 16;
  auto* stable_entry = static_cast<uint8_t*>(MakeHostEntry(stable_fn));
  auto* entry = static_cast<uint8_t*>(MakeHostEntry(pending_fn));
  REQUIRE(stable_entry != nullptr && entry != nullptr && entry != stable_entry);
  const size_t calls = AllocationCalls(), used = g_entry_used;
  std::barrier barrier(2);
  std::thread classifier([&] {
    REQUIRE(InGuestCode(reinterpret_cast<uintptr_t>(pending_fn)));
    REQUIRE(InGuestCode(reinterpret_cast<uintptr_t>(pending_fn)));  // Prime cached hit.
    barrier.arrive_and_wait();
    barrier.arrive_and_wait();
    REQUIRE(!InGuestCode(reinterpret_cast<uintptr_t>(pending_fn)));
    REQUIRE(InGuestCode(base + 1) && InGuestCode(base + 3 * kPage));
  });
  barrier.arrive_and_wait();
  REQUIRE(InGuestCode(reinterpret_cast<uintptr_t>(pending_fn)));
  ApiRemoveCode(image + kPage, 2 * kPage);
  barrier.arrive_and_wait();
  classifier.join();
  REQUIRE(!InGuestCode(reinterpret_cast<uintptr_t>(pending_fn)));
  REQUIRE(g_entries.count(pending_fn) == 0 && g_entries.at(stable_fn) == stable_entry);
  REQUIRE(stable_entry[0] == 0x49);
  for (size_t i = 0; i < kEntryStub; ++i) REQUIRE(entry[i] == 0xcc);
  for (unsigned retry = 0; retry < 128; ++retry) {
    AddRegion(base + kPage, 2 * kPage);
    REQUIRE(MakeHostEntry(pending_fn) == entry);
    uint64_t embedded = 0;
    std::memcpy(&embedded, entry + 2, sizeof(embedded));
    REQUIRE(embedded == reinterpret_cast<uintptr_t>(pending_fn));
    ApiRemoveCode(image + kPage, 2 * kPage);
    REQUIRE(g_entries.count(pending_fn) == 0 && g_entries.at(stable_fn) == stable_entry);
    for (size_t i = 0; i < kEntryStub; ++i) REQUIRE(entry[i] == 0xcc);
  }
  REQUIRE(AllocationCalls() == calls && g_entry_used == used && g_free_entries.size() == 1);
  REQUIRE(InGuestCode(base) && !InGuestCode(base + kPage) && InGuestCode(base + 3 * kPage));
  const size_t regions_before = g_regions.size();
  ApiRemoveCode(image, 0);
  ApiRemoveCode(reinterpret_cast<void*>(UINTPTR_MAX - 1), 4);
  AddRegion(base, 0);
  AddRegion(UINTPTR_MAX - 1, 4);
  REQUIRE(g_regions.size() == regions_before);
  ApiRemoveCode(image, 4 * kPage);
  REQUIRE(g_entries.empty() && !InGuestCode(base));
  REQUIRE(VirtualFree(image, 0, MEM_RELEASE));
  std::puts("PASS ARM64 pending rollback: cached classification, split regions and bounded recycled host entries");
}

void StableHost() {}
void NestedHost() {}

void TestNestedAndPooledDispatch() {
  auto* image = static_cast<uint32_t*>(
      VirtualAlloc(nullptr, kPage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
  REQUIRE(image != nullptr);
  *image = 17;
  AddRegion(reinterpret_cast<uintptr_t>(image), kPage);
  auto* trampoline = static_cast<uint32_t*>(BindHost(reinterpret_cast<void*>(&NestedHost), -1));
  REQUIRE(trampoline != nullptr);
  const uint32_t service = (trampoline[0] >> 5) & 0xffff;
  Env env;
  env.Dispatch(0, [&](A64::Jit& jit) { REQUIRE(jit.Instruction(image) == 17); });
  A64::Jit* outer = env.jits_[0].get();
  REQUIRE(env.code_generations_.capacity() == 1);
  const unsigned old_clears = outer->clear_count;
  unsigned outer_runs = 0, callbacks = 0;
  env.host_call = [&](A64::Jit* jit, void* fn, int index, int pointer_variadic_fixed) {
    REQUIRE(jit == outer && fn == reinterpret_cast<void*>(&NestedHost) && index == -1);
    REQUIRE(pointer_variadic_fixed == -1);
    REQUIRE(!outer->running && env.depth_ == 1);
    ++callbacks;
    ApiRemoveCode(image, kPage);
    REQUIRE(VirtualFree(image, 0, MEM_RELEASE));
    REQUIRE(VirtualAlloc(image, kPage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE) == image);
    *image = 29;
    AddRegion(reinterpret_cast<uintptr_t>(image), kPage);
    env.Dispatch(1, [&](A64::Jit& inner) { REQUIRE(inner.Instruction(image) == 29); });
    REQUIRE(env.depth_ == 1 && env.code_generations_.size() == 2);
  };
  env.Dispatch(0, [&](A64::Jit& jit) {
    if (outer_runs++ == 0) {
      REQUIRE(jit.Instruction(image) == 17);
      env.CallSVC(service);
    } else {
      REQUIRE(jit.Instruction(image) == 29);
      env.CallSVC(kReturnSvc);
    }
  });
  REQUIRE(callbacks == 1 && outer_runs == 2 && outer->clear_count == old_clears + 1);
  REQUIRE(env.code_generations_[0] == g_code_generation.load());
  const unsigned pooled_clears = outer->clear_count;
  const unsigned inner_clears = env.jits_[1]->clear_count;
  ApiRemoveCode(image, kPage);
  REQUIRE(VirtualFree(image, 0, MEM_RELEASE));
  REQUIRE(VirtualAlloc(image, kPage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE) == image);
  *image = 43;
  AddRegion(reinterpret_cast<uintptr_t>(image), kPage);
  // An idle Env/Jit pair transfers to another thread with its old cache and
  // generation. Each nesting depth must refresh at its next dispatch.
  std::thread new_owner([&] {
    env.Dispatch(0, [&](A64::Jit& jit) { REQUIRE(jit.Instruction(image) == 43); });
    env.Dispatch(1, [&](A64::Jit& jit) { REQUIRE(jit.Instruction(image) == 43); });
  });
  new_owner.join();
  REQUIRE(outer->clear_count == pooled_clears + 1 && env.jits_[1]->clear_count == inner_clears + 1);
  ApiRemoveCode(image, kPage);
  REQUIRE(VirtualFree(image, 0, MEM_RELEASE));
  ApiUnbindHostFunction(reinterpret_cast<void*>(&NestedHost));
  std::puts("PASS ARM64 pending rollback: paused outer dispatch and pooled Jits refresh safely after remapping");
}

void TestTrampolineReuse() {
  void* stable_fn = reinterpret_cast<void*>(&StableHost);
  auto* stable = static_cast<uint32_t*>(BindHost(stable_fn, -1));
  auto* owned = VirtualAlloc(nullptr, kPage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
  REQUIRE(stable != nullptr && owned != nullptr);
  AddVaListFunction(owned, 3);
  auto* slot = static_cast<uint32_t*>(BindHost(owned, -2));
  REQUIRE(slot != nullptr && slot != stable);
  const size_t index = g_tramp_by_fn.at(owned);
  const uint32_t expected_svc = Svc(static_cast<uint32_t>(index + 1));
  REQUIRE(ReadTrampoline(index).va_list_index == 3);
  g_host_pages[reinterpret_cast<uintptr_t>(owned) & ~uintptr_t{0xfff}] = true;
  Env env;
  slot[0] = kRet;  // A guest-installed in-place hook must not survive reuse.
  env.Dispatch(0, [&](A64::Jit& jit) { REQUIRE(jit.Instruction(slot) == kRet); });
  const unsigned previous_clears = env.jits_[0]->clear_count;
  ApiUnbindHostFunction(owned);
  REQUIRE(g_tramp_by_fn.count(owned) == 0 && ReadTrampoline(index).host_fn == nullptr);
  REQUIRE(g_va_functions.count(owned) == 0 && g_host_pages.count(reinterpret_cast<uintptr_t>(owned)) == 0);
  for (size_t i = 0; i < kTrampWords; ++i) REQUIRE(slot[i] == kBrk);
  REQUIRE(BindHost(owned, -1) == slot);
  env.Dispatch(0, [&](A64::Jit& jit) { REQUIRE(jit.Instruction(slot) == expected_svc); });
  REQUIRE(env.jits_[0]->clear_count == previous_clears + 1);
  ApiUnbindHostFunction(owned);
  const size_t count = g_tramp_count.load(), calls = AllocationCalls(), used = g_code_used;
  const size_t pages = g_code_pages.size();
  for (size_t retry = 0; retry < kMaxTramps + 257; ++retry) {
    REQUIRE(BindHost(owned, -1) == slot && g_tramp_by_fn.at(owned) == index);
    REQUIRE(slot[0] == expected_svc && slot[1] == kRet);
    ApiUnbindHostFunction(owned);
    REQUIRE(g_tramp_by_fn.count(owned) == 0 && ReadTrampoline(index).host_fn == nullptr);
    for (size_t i = 0; i < kTrampWords; ++i) REQUIRE(slot[i] == kBrk);
  }
  REQUIRE(g_tramp_count.load() == count && AllocationCalls() == calls);
  REQUIRE(g_code_used == used && g_code_pages.size() == pages && g_free_tramps.size() == 1);
  REQUIRE(BindHost(stable_fn, -1) == stable && ReadTrampoline(g_tramp_by_fn.at(stable_fn)).host_fn == stable_fn);
  const uint64_t generation = g_code_generation.load();
  ApiUnbindHostFunction(owned);
  REQUIRE(g_code_generation.load() == generation);
  REQUIRE(VirtualFree(owned, 0, MEM_RELEASE));
  std::puts("PASS ARM64 pending rollback: trampoline retirement erases pointers/hooks and recycles past kMaxTramps");
}

void TestSvcSnapshot() {
  void* fn = reinterpret_cast<void*>(&StableHost);
  AddVaListFunction(fn, 0);
  auto* trampoline = static_cast<uint32_t*>(BindHost(fn, -2));
  REQUIRE(trampoline != nullptr);
  const uint32_t service = (trampoline[0] >> 5) & 0xffff;
  std::barrier barrier(2);
  constexpr unsigned iterations = 12000;
  std::atomic<unsigned> calls{0};
  std::thread reader([&] {
    Env env;
    unsigned runs = 0;
    env.host_call = [&](A64::Jit*, void* target, int index, int pointer_variadic_fixed) {
      REQUIRE(target == fn && (index == 0 || index == 1) && pointer_variadic_fixed == -1);
      calls.fetch_add(1, std::memory_order_relaxed);
    };
    barrier.arrive_and_wait();
    env.Dispatch(0, [&](A64::Jit&) {
      if (runs++ < iterations) env.CallSVC(service);
      else env.CallSVC(kReturnSvc);
    });
  });
  barrier.arrive_and_wait();
  for (unsigned i = 0; i < iterations; ++i) AddVaListFunction(fn, static_cast<int>(i & 1));
  reader.join();
  REQUIRE(calls.load() == iterations);

  // Register a pointer-variadic target after binding and dispatch the same SVC.
  // The changed signature must reach the host callback without replacing the slot.
  void* variadic_target = reinterpret_cast<void*>(&NestedHost);
  AddPointerVariadicFunction(fn, variadic_target, 2);
  REQUIRE(BindHost(fn, -2) == trampoline);
  Env env;
  unsigned runs = 0, pointer_calls = 0;
  env.host_call = [&](A64::Jit*, void* target, int index, int pointer_variadic_fixed) {
    REQUIRE(target == variadic_target && index == -1 && pointer_variadic_fixed == 2);
    ++pointer_calls;
  };
  env.Dispatch(0, [&](A64::Jit&) {
    env.CallSVC(runs++ == 0 ? service : kReturnSvc);
  });
  REQUIRE(pointer_calls == 1);
  ApiUnbindHostFunction(fn);
  std::puts("PASS ARM64 pending rollback: real CallSVC snapshots synchronized metadata during va_list updates");
}

void TestAttachAfterRollback() {
  REQUIRE(!g_tls_images.empty() && g_tls_blocks.empty());
  const int64_t stable = g_tls_images.front().offset;
  const uint8_t initial = static_cast<const uint8_t*>(g_tls_images.front().image)[0];
  Env existing;
  existing.Attach();
  REQUIRE(existing.tls_block_[stable] == initial && g_tls_blocks.size() == 1);
  existing.tls_block_[stable] = 0xa5;
  const int64_t pending = ApiTlsRegister(128, 16);
  REQUIRE(pending >= 0);
  Env late;
  late.Attach();
  REQUIRE(late.tls_block_[stable] == initial && late.tls_block_[pending] == 0);
  std::memset(existing.tls_block_ + pending, 0xcc, 128);
  std::memset(late.tls_block_ + pending, 0xdd, 128);
  REQUIRE(ApiTlsRollback(pending, 128));
  for (size_t i = 0; i < 128; ++i) {
    REQUIRE(existing.tls_block_[pending + i] == 0 && late.tls_block_[pending + i] == 0);
  }
  REQUIRE(existing.tls_block_[stable] == 0xa5 && late.tls_block_[stable] == initial);
  static const uint8_t image[] = {0x81, 0x92, 0xa3};
  const int64_t next = ApiTlsRegister(128, 16);
  REQUIRE(next == pending);
  ApiTlsPublish(next, image, sizeof(image), 128);
  REQUIRE(std::memcmp(existing.tls_block_ + next, image, sizeof(image)) == 0);
  REQUIRE(std::memcmp(late.tls_block_ + next, image, sizeof(image)) == 0);
  late.UnattachForTest();
  std::memset(late.tls_block_, 0xee, g_tls_offset);
  late.Attach();
  for (size_t i = 0; i < kTcbSize; ++i) REQUIRE(late.tls_block_[i] == 0);
  REQUIRE(late.tls_block_[stable] == initial && late.tls_block_[next] == image[0]);
  REQUIRE(existing.tls_block_[stable] == 0xa5 && g_tls_blocks.size() == 2);

  // Park may fail to decommit a detached block. Rollback visits live blocks
  // only; Attach must still clear this detached block's reclaimed dirty tail.
  const size_t before = g_tls_offset;
  const int64_t tail = ApiTlsRegister(3 * kPage, 16);
  REQUIRE(tail >= 0);
  late.UnattachForTest();
  std::memset(late.tls_block_ + tail, 0x77, 3 * kPage);
  REQUIRE(ApiTlsRollback(tail, 3 * kPage) && g_tls_offset == before);
  REQUIRE(late.tls_block_[tail + 3 * kPage - 1] == 0x77);
  late.Attach();
  for (size_t i = 0; i < 3 * kPage; ++i) REQUIRE(late.tls_block_[tail + i] == 0);
  REQUIRE(late.tls_block_[stable] == initial && existing.tls_block_[stable] == 0xa5);
  std::puts("PASS ARM64 pending rollback: actual Attach restores images and clears retained pooled tails after reclaim");
}

void TestPreparedAttach() {
  REQUIRE(g_tls_blocks.empty());
  static const uint32_t initial = 37;
  const int64_t offset = ApiTlsRegister(16, 4);
  REQUIRE(offset >= 0 && ApiTlsPrepare(offset, &initial, sizeof(initial), 16));
  const auto read = [offset](const Env& env) {
    uint32_t value;
    std::memcpy(&value, env.tls_block_ + offset, sizeof(value));
    return value;
  };
  Env owner;
  owner.Attach();
  REQUIRE(read(owner) == 37);
  const uint32_t changed = 93;
  std::memcpy(owner.tls_block_ + offset, &changed, sizeof(changed));
  REQUIRE(ApiTlsPrepare(offset, &initial, sizeof(initial), 16) && read(owner) == 93);
  std::barrier rendezvous(2);
  std::thread foreign([&] {
    Env other;
    other.Attach();
    REQUIRE(read(other) == 0);
    rendezvous.arrive_and_wait();
    rendezvous.arrive_and_wait();
    REQUIRE(read(other) == 37);
  });
  rendezvous.arrive_and_wait();
  ApiTlsPublish(offset, &initial, sizeof(initial), 16);
  REQUIRE(read(owner) == 93);
  rendezvous.arrive_and_wait();
  foreign.join();
  std::thread late([&] {
    Env other;
    other.Attach();
    REQUIRE(read(other) == 37);
  });
  late.join();
  REQUIRE(read(owner) == 93 && !ApiTlsRollback(offset, 16));
  std::puts("PASS ARM64 pending rollback: owner Attach sees private prepared TLS, foreign threads see only committed images");
}

void Cleanup() {
  REQUIRE(g_tls_blocks.empty());
  REQUIRE(g_live_jits.empty());
  g_entries.clear();
  g_free_entries.clear();
  g_regions.clear();
  g_tramp_by_fn.clear();
  g_free_tramps.clear();
  g_va_functions.clear();
  g_host_pages.clear();
  g_tls_images.clear();
  g_code_pages.clear();
  std::vector<void*> pages;
  for (const auto& entry : allocations) pages.push_back(entry.first);
  for (void* page : pages) REQUIRE(VirtualFree(page, 0, MEM_RELEASE));
  REQUIRE(allocations.empty());
}
}  // namespace fixture

int main() {
  fixture::Env env;
  env.JitAt(0);
  env.icache_start_ = kPage;
  env.icache_end_ = 2 * kPage;
  env.FlushIcache();
  return 0;
}
