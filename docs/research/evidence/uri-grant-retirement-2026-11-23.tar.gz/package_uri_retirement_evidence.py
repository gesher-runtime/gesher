import gzip
import hashlib
import io
import json
import os
import platform
import subprocess
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root / 'gesher-java-uri-grants'
out = repo / 'docs/research/evidence/uri-grant-retirement-2026-11-23.tar.gz'
out.parent.mkdir(parents=True, exist_ok=True)
members = {}

def digest(content):
    return hashlib.sha256(content).hexdigest()

def add(path, name=None):
    name = name or str(path.relative_to(root))
    content = path.read_bytes()
    assert name not in members
    members[name] = content

excluded = {'uri-grants-baseline-build', 'uri-grants-candidate-build',
            'uri-grants-main5882-build', 'uri-grants-services', 'uri-grants-main5882-services'}
for path in sorted(root.glob('uri-grants*')):
    if path.name in excluded:
        continue
    if path.is_file():
        add(path)
    elif path.is_dir():
        for file in sorted(path.rglob('*')):
            if file.is_file():
                add(file)
for pattern in ('*uri*retire*.py', 'verify_uri_main5882_composition.py',
                'java-uri-main*-composition.json', 'native-review-uri-retirement-proof.json',
                'native-review-uri-retirement.log', 'media-review-uri-main5882.json',
                'media-review-uri-main5882.log'):
    for path in sorted(root.glob(pattern)):
        if str(path.relative_to(root)) not in members:
            add(path)

compiled = json.loads((root / 'uri-grants-candidate-final/compiled.json').read_text())
for relative, sha in compiled['production_and_fixtures'].items():
    if relative.startswith('app/'):
        path = root / 'uri-grants-candidate-final/production' / Path(relative).name
    else:
        path = repo / relative
    assert digest(path.read_bytes()) == sha, relative
    add(path, 'frozen-candidate-inputs/' + relative)
for relative in ('tools/test_uri_retirement.py', 'tests/uri/intent_framework_host.c',
                 'tests/uri/aosp/README.md', 'tools/test_uri_retirement_report.py'):
    add(repo / relative, 'frozen-candidate-inputs/' + relative)
for relative in ('app/java/com/gesher/server/PackageManagerService.java',
                 'app/java/com/gesher/server/UriGrants.java',
                 'app/java/com/gesher/server/ContentProviders.java',
                 'app/java/com/gesher/server/ApkPackage.java',
                 'AGENTS.md', 'CONTRIBUTING.md'):
    add(repo / relative, 'integrated-inputs/' + relative)

identities = {}
for directory in sorted(excluded):
    for path in sorted((root / directory).glob('*')):
        if path.is_file():
            content = path.read_bytes()
            identities[str(path.relative_to(root))] = {'bytes': len(content), 'sha256': digest(content)}
environment = {
    'platform': platform.platform(), 'machine': platform.machine(),
    'logical_cpus': os.cpu_count(),
    'cpu_model': next((line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                       if line.startswith('model name')), 'unavailable'),
    'java_version': subprocess.run([str(root / 'toolchains/jdk-21.0.13.1+2/bin/java'), '-version'],
                                   capture_output=True, text=True, check=True).stderr.strip(),
    'limits': 'Shared Linux host; other agent lanes explicitly idle during each declared block, but no claim of exclusive physical hardware or Windows/ART performance.',
}
members['build-artifact-identities.json'] = (json.dumps(identities, indent=2) + '\n').encode()
members['environment.json'] = (json.dumps(environment, indent=2) + '\n').encode()
members['README.txt'] = b'''URI grant retirement evidence, 2026-11-23

The final fixed campaign is uri-grants-final-block1 through block6 and
uri-grants-final-combined: 312 JVMs / 1248 records, no retries or exclusions.
The pilot, ordinary smokes, four-JVM PrintCompilation diagnostic, source mutants,
storage/work counters and earlier developmental fixture logs are retained in
separate named directories. Developmental logs are not final passing evidence.

All frozen final inputs, complete compiled classes and manifest hashes are
included. Large app/services build outputs are identified by bytes/SHA256 in
build-artifact-identities.json, not duplicated as binary deliveries here. The
declared external framework/JDK dependencies are not contained in this archive.
Current integration inputs and validation remain separate from measured inputs.

inventory.json authenticates every other member's name, byte length and SHA256.
No tar extraction or executable action is required to inspect the evidence.
'''
inventory = {name: {'bytes': len(content), 'sha256': digest(content)}
             for name, content in sorted(members.items())}
members['inventory.json'] = (json.dumps(inventory, indent=2) + '\n').encode()
with out.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, content in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(content))
archive = {'path': str(out.relative_to(repo)), 'bytes': out.stat().st_size,
           'sha256': digest(out.read_bytes()), 'members': len(members),
           'inventory_members': len(inventory)}
(root / 'uri-retirement-archive-receipt.json').write_text(json.dumps(archive, indent=2) + '\n')
print(json.dumps(archive, indent=2))
