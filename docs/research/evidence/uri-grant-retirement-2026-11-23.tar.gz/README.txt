URI grant retirement evidence, 2026-11-23

The final fixed campaign is uri-grants-final-block1 through block6 and
uri-grants-final-combined: 312 JVMs / 1248 records, no retries or exclusions.
The pilot, ordinary smokes, four-JVM PrintCompilation diagnostic, source mutants,
storage/work counters and earlier developmental fixture logs are retained in
separate named directories. Developmental logs are not final passing evidence.

All frozen final inputs, complete compiled classes and manifest hashes are
included. Large app/services build outputs are identified by bytes/SHA256 in
build-artifact-identities.json, not duplicated as binary deliveries here. The
declared external framework/JDK dependencies are not contained in this archive.
Current integration inputs and validation remain separate from measured inputs.

inventory.json authenticates every other member's name, byte length and SHA256.
No tar extraction or executable action is required to inspect the evidence.
