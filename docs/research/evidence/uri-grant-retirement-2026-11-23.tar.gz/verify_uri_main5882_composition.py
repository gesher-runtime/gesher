import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root / 'gesher-java-uri-grants'
feature = 'f5c3d2fef37c889cdc5673e850c7c8088cda2ddf'
incoming = '5882d0a44765be56562ba25443b8572b6466712a'
head = 'eb49c574eabf176730feb26bdd01267a85e3a4b5'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)

def tree(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not row:
            continue
        meta, name = row.split(b'\t', 1)
        result[name.decode()] = meta.decode()
    return result

base = git('merge-base', feature, incoming).decode().strip()
canonical = git('merge-tree', '--write-tree', feature, incoming).decode().splitlines()[0]
actual = git('rev-parse', head + '^{tree}').decode().strip()
assert canonical == actual
assert git('show', '-s', '--format=%P', head).decode().strip().split() == [feature, incoming]
b, f, m, h = map(tree, (base, feature, incoming, head))
feature_paths = {p for p in b.keys() | f.keys() if b.get(p) != f.get(p)}
main_paths = {p for p in b.keys() | m.keys() if b.get(p) != m.get(p)}
for p in feature_paths - main_paths:
    assert h.get(p) == f.get(p), p
for p in main_paths - feature_paths:
    assert h.get(p) == m.get(p), p
overlap = feature_paths & main_paths
pms = 'app/java/com/gesher/server/PackageManagerService.java'
assert overlap == {pms}, overlap
source = git('show', head + ':' + pms).decode()
chunks = [
    '    // Registry publication identity without retaining the registry or retired APKs.\n'
    '    // Read and written under this monitor; null before the first publication.\n'
    '    private Object mPackageGeneration;\n',
    '    /** Registry identity only; callers must hold this monitor and check live policy separately. */\n'
    '    Object packageGeneration() { return mPackageGeneration; }\n\n',
    '        // Allocate before changing the published registry. This token carries no\n'
    '        // package references and cannot keep removed code alive in a consumer.\n'
    '        mPackageGeneration = new Object();\n',
]
for chunk in chunks:
    assert source.count(chunk) == 1
    source = source.replace(chunk, '')
assert source.encode() == git('show', incoming + ':' + pms)
uri = 'app/java/com/gesher/server/UriGrants.java'
assert git('show', head + ':' + uri) == git('show', feature + ':' + uri)
proof = {
    'head': head, 'tree': actual, 'parents': [feature, incoming], 'merge_base': base,
    'canonical_automatic_tree': canonical,
    'all_paths_modes_blobs_equal_canonical': len(h),
    'feature_only_preserved': sorted(feature_paths - main_paths),
    'incoming_only_preserved': sorted(main_paths - feature_paths),
    'overlap': sorted(overlap),
    'pms_remove_exact_three_feature_additions_recovers_incoming_byte_for_byte': True,
    'pms_sha256': hashlib.sha256(git('show', head + ':' + pms)).hexdigest(),
    'uri_sha256': hashlib.sha256(git('show', head + ':' + uri)).hexdigest(),
    'validation_boundary': 'Source composition only; performance remains the frozen d307-derived source campaign. Incoming #325 provider authority selection and #387 camera metadata are unmodified and require separate current-source runtime replay.',
}
(root / 'java-uri-main5882-composition.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if not isinstance(v, list)}, indent=2))
