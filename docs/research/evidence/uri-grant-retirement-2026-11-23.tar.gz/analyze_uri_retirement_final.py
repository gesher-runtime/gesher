import itertools,json,statistics
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent/'uri-grants-final-combined'; data=json.loads((p/'summary.json').read_text()); raw=json.loads((p/'receipts.json').read_text()); indices=np.array(list(itertools.product(range(6),repeat=6)),dtype=np.int8); metrics=['caller_cpu_ns','elapsed_ns','caller_allocated_bytes','process_cpu_ns']
for row in data['rows']:
 pairs=[]
 for rnd in range(6):
  pair={}
  for v in ['baseline','candidate']:
   runs=[r for r in raw if r['case']==row['case'] and r['round']==rnd and r['variant']==v]; assert len(runs)==2; phases={}
   for phase in ['first','steady']:
    costs=[]
    for r in runs:
     s=[x for x in r['records'] if x['phase']==phase]; n=sum(x['operations'] for x in s); costs.append({m:sum(x[m] for x in s)/n for m in metrics})
    phases[phase]={m:statistics.mean(c[m] for c in costs) for m in metrics}
   pair[v]=phases
  pairs.append(pair)
 row['paired_blocks']=pairs; row['paired_summary']={}
 for m in metrics[:3]:
  b=np.array([q['baseline']['steady'][m] for q in pairs]); c=np.array([q['candidate']['steady'][m] for q in pairs]); effects=100*(c[indices].sum(axis=1)/b[indices].sum(axis=1)-1)
  row['paired_summary'][m]={'pooled_change_pct':float(100*(c.mean()/b.mean()-1)),'exact_paired_bootstrap_95_pct':[float(x) for x in np.percentile(effects,[2.5,97.5])],'replicates':46656,'independent_blocks':6}
 for v in ['baseline','candidate']:
  for phase in ['first','steady']:
   obs=row['variants'][v][phase]['jvm_costs']; row['variants'][v][phase]['descriptive_p95']={m:float(np.percentile([o[m] for o in obs],95)) for m in metrics}
data['statistical_limits']='Twelve independent JVMs/variant/case; three correlated steady intervals/JVM. Six fixed paired ABBA blocks. Exact empirical paired bootstrap has six independent blocks; first p95 has twelve observations and is not a production tail guarantee.'
(p/'analysis.json').write_text(json.dumps(data,indent=2)+'\n'); print('All13 cases, complete first/steady tails and six paired-block effects saved.')
