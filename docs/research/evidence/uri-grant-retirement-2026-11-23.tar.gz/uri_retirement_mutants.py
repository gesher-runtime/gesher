#!/usr/bin/env python3
"""Compile complete production variants and require the intended service assertion."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

BASE=Path('/workspace/scratch/aa09b1a0dc1f')
ROOT=BASE/'gesher-java-uri-grants'
OUT=BASE/'uri-grants-mutants'
OUT.mkdir(exist_ok=True)
cases={
 'no-generation-rotation':'Replaced provider retained a transient grant',
 'global-retirement-token':'One UID sweep validated another UID',
 'ignore-hosted':'Hosted metadata rollback resurrected retired modes',
 'skip-null':'Null publication identity suppressed retirement',
}
common=[sys.executable,str(ROOT/'tools/test_uri_retirement.py'),
 '--java-home',str(BASE/'toolchains/jdk-21.0.13.1+2'),
 '--framework-classes',str(BASE/'framework-main-d2ebbdfd/classes'),
 '--core-classes',str(BASE/'framework-main-d2ebbdfd/coremod'),
 '--apksig',str(BASE/'toolchains/apksig.jar'),
 '--app-classes',str(BASE/'uri-grants-candidate-build/gesher-app-classes.jar')]
receipts=[]
for mutation,assertion in cases.items():
 work=OUT/mutation
 command=common+['--work-dir',str(work),'--mutation',mutation]
 run=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=110)
 log=OUT/(mutation+'.log');log.write_bytes(run.stdout)
 compiled=work/'compiled.json'
 if run.returncode==0 or assertion.encode() not in run.stdout or not compiled.is_file():
  raise AssertionError((mutation,run.returncode,run.stdout.decode(errors='replace')))
 receipts.append({'mutation':mutation,'expected_service_assertion':assertion,'returncode':run.returncode,
                  'log':str(log),'log_sha256':hashlib.sha256(run.stdout).hexdigest(),
                  'compiled_receipt':str(compiled),'compiled_sha256':hashlib.sha256(compiled.read_bytes()).hexdigest()})
 (OUT/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('URI_RETIREMENT_MUTANT_PASS '+mutation,flush=True)
