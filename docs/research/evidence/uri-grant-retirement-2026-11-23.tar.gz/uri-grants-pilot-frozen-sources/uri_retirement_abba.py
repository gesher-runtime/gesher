#!/usr/bin/env python3
import argparse,datetime,hashlib,json,os,subprocess
from pathlib import Path
CASES='exact1 exact8 exact128 exact512 missing128 prefix128 hosted1 mixed_hosted128 owned_cycle1 owned_cycle128 owned_cycle512 publish_registry empty_control'.split()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d): p.write_text(json.dumps(d,indent=2)+'\n')
p=argparse.ArgumentParser(); p.add_argument('--root',type=Path,required=True); p.add_argument('--output',type=Path,required=True); p.add_argument('--rounds',type=int,default=1); p.add_argument('--round-start',type=int,default=0); a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
compiled={v:json.loads((a.root/f'uri-grants-{v}-frozen/compiled.json').read_text()) for v in ['baseline','candidate']}
def verify():
 for v,c in compiled.items():
  assert c['count_work'] is None and c['mutation'] is None and not any('javaagent' in x for x in c['java'])
  for name,h in c['classes'].items(): assert sha(a.root/f'uri-grants-{v}-frozen/classes'/name)==h,(v,name)
  assert sha(a.root/f'uri-grants-{v}-build/gesher-app-classes.jar')==c['app_classes_sha256']
verify(); order=['baseline','candidate','candidate','baseline']; total=13*4*a.rounds
save(a.output/'declaration.json',dict(created=utc(),cases=CASES,order=order,rounds=a.rounds,round_start=a.round_start,expected_processes=total,compiled=compiled,script_sha256=sha(Path(__file__)),boundary='Actual service calls, owned creation/prepare/publish/readback/retirement inside timing; setup/final fixture cleanup outside; no counter, agent or reference oracle in clock.'))
rows=[]; started=utc(); print('START '+started,flush=True)
for rnd in range(a.round_start,a.round_start+a.rounds):
 for case in CASES:
  for pos,v in enumerate(order):
   i=len(rows); w=a.output/f'{i:04d}-{v}-{case}'; w.mkdir(); b=a.root/f'uri-grants-{v}-frozen'; cmd=compiled[v]['java']+['UriRetirementHost',str(b/'liburi_retirement_host.so'),'--benchmark',case]; env=os.environ.copy(); env.update(ANDROID_DATA=str(w/'data'),GESHER_MICROG_SPOOF='1'); begin=utc()
   try:
    r=subprocess.run(cmd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90); output=r.stdout; code=r.returncode
   except subprocess.TimeoutExpired as ex:
    output=ex.stdout or b''; output=output.decode(errors='replace') if isinstance(output,bytes) else output; code='timeout'
   end=utc(); log=w/'run.log'; log.write_text(output); samples=[json.loads(s.split(' ',1)[1]) for s in output.splitlines() if s.startswith('URI_RETIREMENT_SAMPLE ')]
   complete=f'URI_RETIREMENT_BENCH_COMPLETE case={case} complete_results=true real_owner_retirement=true reference_inside_timing=false' in output
   rows.append(dict(index=i,round=rnd,abba_position=pos,variant=v,case=case,started_utc=begin,finished_utc=end,exit=code,command=cmd,log=str(log.relative_to(a.output)),log_sha256=sha(log),records=samples,complete=complete)); save(a.output/'receipts.json',rows)
   assert code==0 and complete and len(samples)==4,rows[-1]
   assert [s['phase'] for s in samples]==['first','steady','steady','steady'] and [s['sample'] for s in samples]==[0,0,1,2]
   expected=0 if case in ['missing128','empty_control'] else int(case[11:]) if case.startswith('owned_cycle') else 1
   for s in samples:
    assert s['case']==case and s['checksum']==s['operations']*expected,s
    assert all(s[k]>=0 for k in ['elapsed_ns','caller_cpu_ns','caller_allocated_bytes','process_cpu_ns'])
   print(f'DONE {i+1}/{total} {v} {case}',flush=True)
finished=utc(); verify(); save(a.output/'completion.json',dict(started_utc=started,finished_utc=finished,processes=len(rows),records=sum(len(r['records']) for r in rows),all_complete=True)); print('FINISH '+finished,flush=True)
