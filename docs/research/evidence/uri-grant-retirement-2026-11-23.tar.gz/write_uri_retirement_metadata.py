import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root / 'gesher-java-uri-grants'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

source_paths = [
    'app/java/com/gesher/server/PackageManagerService.java',
    'app/java/com/gesher/server/UriGrants.java',
    'app/java/com/gesher/server/ContentProviders.java',
    'app/java/com/gesher/server/ApkPackage.java',
    'app/java/com/gesher/server/UriPermissionModes.java',
    'tools/test_uri_retirement.py',
    'tools/test_uri_retirement_report.py',
]
compiled = read(root / 'uri-grants-candidate-final/compiled.json')
source_paths += [p for p in compiled['production_and_fixtures'] if p.startswith('tests/')]
validation_specs = {
    'uri-grants-baseline-frozen.log': ['all passed: 154 checks', 'passed: 28 checks', 'all passed: 99 checks',
        'passed: 27326 assertions', '6211 checks passed', 'owner_tables_retired=true'],
    'uri-grants-candidate-frozen.log': ['all passed: 154 checks', 'passed: 28 checks', 'all passed: 99 checks',
        'passed: 27326 assertions', '6211 checks passed', 'owner_tables_retired=true'],
    'uri-grants-baseline-work1.log': ['case=exact128 visits=16384 expected=16384',
        'case=retired128 visits=128 expected=128', 'case=owned_batch128 visits=8128 expected=8128',
        'case=mixed_hosted128 visits=16512 expected=16512'],
    'uri-grants-candidate-work1.log': ['case=exact128 visits=0 expected=0',
        'case=retired128 visits=128 expected=128', 'case=owned_batch128 visits=0 expected=0',
        'case=mixed_hosted128 visits=16512 expected=16512'],
    'uri-grants-main5882-complete.log': ['all passed: 154 checks', 'passed: 28 checks', 'all passed: 99 checks',
        'passed: 27326 assertions', '6211 checks passed', 'owner_tables_retired=true'],
    'uri-grants-main5882-work.log': ['case=exact128 visits=0 expected=0',
        'case=retired128 visits=128 expected=128', 'case=owned_batch128 visits=0 expected=0',
        'case=mixed_hosted128 visits=16512 expected=16512'],
    'uri-grants-candidate-build.log': ['292 framework references', '0 unresolved', 'gesher-app written to'],
    'uri-grants-baseline-build.log': ['292 framework references', '0 unresolved', 'gesher-app written to'],
    'uri-grants-main5882-build.log': ['292 framework references', '0 unresolved', 'gesher-app written to'],
    'uri-grants-services.log': ['services-tests.dex written to'],
    'uri-grants-main5882-services.log': ['services-tests.dex written to'],
    'uri-grants-main5882-policy.log': ['SHARED_STDIO_SOURCE_POLICY_PASS'],
    'uri-grants-main5882-supplier.log': ['TCP_SELECTED_SUPPLIER_METADATA_PASS'],
    'uri-grants-main5882-vector.log': ['vector/fcntl source policy: positive source and nine negative controls passed'],
    'uri-grants-main5882-bundle.log': ['Ran 16 tests', 'OK'],
}
validation = []
for name, markers in validation_specs.items():
    path = root / name
    text = path.read_text()
    for marker in markers:
        assert marker in text, (name, marker)
    validation.append({'log': name, 'sha256': sha(path), 'required_markers': markers,
                       'outcome': 'pass', 'boundary': 'Local declared host/build/source gate, not full Windows CI'})

markdown = 'docs/research/uri-grant-retirement-2026-11-23.md'
report = {
    'schema': 1,
    'title': 'URI grant retirement by package-publication identity',
    'roadmap': ['#56 F10', '#56 F11', '#56 T12', '#178'],
    'baseline_commit': 'd3076fc4d29d102ab633299d4654e85a6b261f79',
    'measured_feature_commit': '3a9fb1bf80c7446bef022aef68bbaee970deafdf',
    'measured_feature_tree': '9aa5097ef9f857e996746a02c326577d7b4b599e',
    'integrated_production_commit': 'eb49c574eabf176730feb26bdd01267a85e3a4b5',
    'integrated_production_tree': 'ce526ff81f1916d5ceba25a0647ca82e913190fe',
    'integrated_main': '5882d0a44765be56562ba25443b8572b6466712a',
    'integrated_sources': {p: sha(repo / p) for p in sorted(set(source_paths))},
    'measured_production': compiled['original_production'],
    'measurement_unchanged_after_freeze': True,
    'integrated_source_not_retimed': True,
    'archive': read(root / 'uri-retirement-archive-receipt.json'),
    'markdown': {'path': markdown, 'sha256': sha(repo / markdown)},
    'statistics': read(root / 'uri-grants-final-combined/analysis.json'),
    'predeclaration': read(root / 'uri-grants-final-predeclaration.json'),
    'composition': read(root / 'java-uri-main5882-composition.json'),
    'dependencies': read(root / 'uri-grants-dependency-identities.json'),
    'validation': validation,
    'release_budget_accepted': False,
    'windows_art_performance_measured': False,
    'full_current_head_fork_ci': 'Must be dispatched and reported separately after exact-tree publication',
    'limits': [
        'First call follows fixture construction and seeding; not application startup or fully cold VM.',
        'Three correlated steady intervals aggregate within each JVM;12 JVMs/variant/case and6 paired blocks.',
        'First p95 is descriptive over12 observations, not a production tail bound.',
        'Process CPU is coarse and includes compiler/VM threads; caller CPU is the primary operation metric.',
        'Caller allocated bytes are neither retained heap nor process-tree private commit.',
        'Shared Linux host, controlled native identity/init and APK metadata; no remote Binder/Windows/ART claim.',
        'Publication CPU and complete-batch allocation regressions require explicit release budgets.',
        'Original pilot, compilation diagnostic and every adverse observation are retained.',
        'Incoming main provider semantics are separately correctness-qualified; frozen timing does not measure them.',
    ],
}
path = repo / 'docs/research/uri-grant-retirement-2026-11-23.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(path)
