import json,statistics,sys
from pathlib import Path
p=Path(sys.argv[1]); rs=json.loads((p/'receipts.json').read_text()); dec=json.loads((p/'declaration.json').read_text()); comp=json.loads((p/'completion.json').read_text()); out=[]
ms=['caller_cpu_ns','elapsed_ns','caller_allocated_bytes','process_cpu_ns']
for case in dec['cases']:
 row={'case':case,'variants':{}}
 for v in ['baseline','candidate']:
  runs=[r for r in rs if r['case']==case and r['variant']==v]; phases={}
  for phase in ['first','steady']:
   obs=[]
   for r in runs:
    samples=[x for x in r['records'] if x['phase']==phase]; n=sum(x['operations'] for x in samples); obs.append({m:sum(x[m] for x in samples)/n for m in ms})
   phases[phase]={'independent_jvms':len(obs),'medians':{m:statistics.median(x[m] for x in obs) for m in ms},'jvm_costs':obs}
  row['variants'][v]=phases
 row['change_pct']={s:{m:100*(row['variants']['candidate'][s]['medians'][m]/row['variants']['baseline'][s]['medians'][m]-1) if row['variants']['baseline'][s]['medians'][m] else None for m in ms} for s in ['first','steady']}; out.append(row)
(p/'summary.json').write_text(json.dumps({'completion':comp,'rows':out},indent=2)+'\n'); print(comp)
for r in out:
 b=r['variants']['baseline']; c=r['variants']['candidate']; d=r['change_pct']; print(r['case'], 'CPU',round(b['steady']['medians']['caller_cpu_ns'],2),'->',round(c['steady']['medians']['caller_cpu_ns'],2),'CPU%',round(d['steady']['caller_cpu_ns'],2),'wall%',round(d['steady']['elapsed_ns'],2),'alloc',round(b['steady']['medians']['caller_allocated_bytes'],2),'->',round(c['steady']['medians']['caller_allocated_bytes'],2),'firstCPU',b['first']['medians']['caller_cpu_ns'],'->',c['first']['medians']['caller_cpu_ns'],'firstWall',b['first']['medians']['elapsed_ns'],'->',c['first']['medians']['elapsed_ns'])
