import json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent; out=r/'uri-grants-final-combined'; out.mkdir(exist_ok=False); rows=[]; intervals=[]; first=None
for number in range(1,7):
 p=r/f'uri-grants-final-block{number}'; d=json.loads((p/'declaration.json').read_text()); c=json.loads((p/'completion.json').read_text()); rs=json.loads((p/'receipts.json').read_text())
 assert c['all_complete'] and c['processes']==52 and c['records']==208 and len(rs)==52
 if first is None: first=d
 else: assert d['compiled']==first['compiled'] and d['script_sha256']==first['script_sha256'] and d['cases']==first['cases'] and d['order']==first['order']
 for row in rs:
  assert row['round']==number-1 and row['complete'] and row['exit']==0
  log=p/row['log']; assert hashlib.sha256(log.read_bytes()).hexdigest()==row['log_sha256']
  row['log']=str(log.relative_to(r)); rows.append(row)
 intervals.append(c)
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
save(out/'declaration.json',dict(first,rounds=6,round_start=0,expected_processes=312))
save(out/'receipts.json',rows); save(out/'completion.json',dict(started_utc=intervals[0]['started_utc'],finished_utc=intervals[-1]['finished_utc'],processes=312,records=1248,all_complete=True,intervals=intervals))
print('Verified312 JVMs/1248 records, source/class identity, six complete fixed blocks and every raw-log digest.')
