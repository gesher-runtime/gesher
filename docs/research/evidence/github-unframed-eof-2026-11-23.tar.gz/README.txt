This is historical host transport-boundary evidence, not a live GitHub/Windows recovery result.
At the repair checkout run the unchanged CI unittest entries and the exact helper metadata gate.
For the old-reader negative and seven isolated mutants:
  python3 reproduction/native_github_eof_controls.py --repo /path/to/repair --output /tmp/eof-controls
The script copies actual current modules into temporary directories and loads the public baseline
5882d0a44765be56562ba25443b8572b6466712a only for the unchanged-reader negative. It never writes the checkout.
The original full failure logs do not retain the failed subprocess stdout or HTTP headers. Their
remote cause is unproved; no quota recovery is inferred. Initial fixture exception/message and
subtest cleanup development failures are retained separately, without being counted as passing gates.
No original producer, source, artifact digest, post-download, role, timeout or event predicate changed.
