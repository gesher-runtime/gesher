#!/usr/bin/env python3
"""Source-bound old-reader negative and isolated assertion-specific controls."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args(); repo = args.repo.resolve(); output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
base = '5882d0a44765be56562ba25443b8572b6466712a'
reader_path = 'tools/ci/github_read.py'; context_path = 'tools/ci/producer_context.py'
current = (repo / reader_path).read_text(); context = (repo / context_path).read_text()
old = subprocess.check_output(['git','show',base+':'+reader_path],cwd=repo,text=True)
ordinary = ['test_github_eof'] + ['test_component_producer.ComponentConsumers.'+name for name in (
    'test_post_download_eof_restarts_complete_original_and_current_snapshots',
    'test_post_download_eof_does_not_accept_changed_or_missing_provenance',
    'test_post_download_eof_cannot_hide_changed_execution_or_role_bytes',
    'test_post_download_eof_exhausts_existing_inventory_fallback_budget',
    'test_post_download_eof_still_rejects_framed_json_and_inventory_errors')]

def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

predicate = """stderr in (
            'unexpected end of JSON input',
            'unexpected end of JSON input\\n',
            'unexpected end of JSON input\\r\\n')"""
mutants = [
    ('exit_code', reader_path, replace(current, 'result.returncode == 1 and status is None',
                                     'result.returncode != 0 and status is None'),
     'test_github_eof.ExactEofRead.test_other_exit_codes_are_not_an_eof_retry_or_inventory_fallback'),
    ('http_framing', reader_path, replace(current, 'status is None and stderr in (',
                                        'True and stderr in ('),
     'test_github_eof.ExactEofRead.test_http_framing_prevents_the_unframed_eof_exception'),
    ('mixed_diagnostic', reader_path, replace(current, predicate,
                                            "'unexpected end of JSON input' in stderr"),
     'test_github_eof.ExactEofRead.test_mixed_or_different_diagnostics_do_not_enter_the_eof_policy'),
    ('transport_deadline', reader_path, replace(current,
        '_MAX_ELAPSED_SECONDS = 4 * 60 + sum(_BACKOFF_SECONDS)', '_MAX_ELAPSED_SECONDS = 3600'),
     'test_github_eof.ExactEofRead.test_eof_does_not_extend_the_247_second_transport_deadline'),
    ('inventory_no_retry', reader_path, replace(current, 'if not retry_transient:',
                                               'if False and not retry_transient:'),
     'test_github_eof.ExactEofRead.test_inventory_caller_gets_one_transient_failure_without_sleep'),
    ('framed_json_acceptance', reader_path, replace(current,
        "raise GitHubReadError('GitHub GET returned invalid JSON') from error", 'return {}'),
     'test_github_eof.ExactEofRead.test_successful_framed_malformed_json_is_never_retried'),
    ('post_download_snapshot', context_path, replace(context,
        'after = snapshot(current, earlier, artifact_name, producer_name)', 'after = before'),
     'test_component_producer.ComponentConsumers.test_post_download_eof_restarts_complete_original_and_current_snapshots'),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

start_sources = {p.relative_to(repo).as_posix():sha(p.read_bytes()) for p in
                 (repo/'tools/ci').glob('*.py')}
rows = []
cases = [('unchanged_reader',reader_path,old,[ordinary[0],ordinary[1]],'negative'),
         ('candidate',reader_path,current,ordinary,'pass')]
cases += [(name,path,source,[test],'mutant') for name,path,source,test in mutants]
for name, path, source, tests, kind in cases:
    ast.parse(source)
    out = output/name; out.mkdir(exist_ok=True)
    (out/Path(path).name).write_text(source)
    with tempfile.TemporaryDirectory(prefix='gesher-gh-eof-') as temporary:
        work = Path(temporary)
        shutil.copytree(repo/'tools/ci',work/'tools/ci',ignore=shutil.ignore_patterns('__pycache__'))
        (work/'tools/surface').mkdir(parents=True)
        shutil.copy2(repo/'tools/surface/download-verified-artifact.py',
                     work/'tools/surface/download-verified-artifact.py')
        (work/path).write_text(source)
        command = [sys.executable,'-m','unittest','-v',*tests]
        run = subprocess.run(command,cwd=work,env=dict(os.environ,PYTHONPATH=str(work/'tools/ci')),
                             capture_output=True,text=True)
    raw = run.stdout+run.stderr; (out/'run.log').write_text(raw)
    if kind == 'pass':
        assert run.returncode == 0 and 'Ran 17 tests' in raw, raw[-3000:]
    elif kind == 'negative':
        assert run.returncode != 0 and 'GitHub GET failed after 1 attempt(s)' in raw, raw
        assert 'ModuleNotFoundError' not in raw and 'SyntaxError' not in raw, raw
    else:
        assert run.returncode != 0 and re.search(r'^FAIL:',raw,re.M), raw
        assert not re.search(r'^ERROR:',raw,re.M), raw
        assert tests[0].rsplit('.',1)[-1] in raw, raw
    row=dict(name=name,path=path,kind=kind,source_sha256=sha(source.encode()),command=command,
             returncode=run.returncode,log=str(out/'run.log'),log_sha256=sha(raw.encode()),
             designated_assertion=(tests[0] if kind=='mutant' else None))
    rows.append(row); print(name,kind,'qualified',flush=True)
    (output/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
assert start_sources == {p.relative_to(repo).as_posix():sha(p.read_bytes()) for p in
                         (repo/'tools/ci').glob('*.py')}, 'Working source changed during isolated controls'
(output/'source.json').write_text(json.dumps(dict(base=base,source=start_sources),indent=2)+'\n')
print('Qualified unchanged-reader negative, candidate17 tests and seven assertion-specific mutants.')
