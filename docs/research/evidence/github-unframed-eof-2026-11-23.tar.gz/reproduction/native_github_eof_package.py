#!/usr/bin/env python3
"""Package the exact bounded EOF repair and retained failure/qualification evidence."""
import ast
import gzip
import hashlib
import io
import json
import platform
from pathlib import Path
import re
import subprocess
import sys
import tarfile

workspace = Path(__file__).resolve().parent
root = workspace/'gesher-native-github-eof'
base = '5882d0a44765be56562ba25443b8572b6466712a'
checkpoint = '3d1599f130906aa3778699209690db7c8a3d5854'
changed = ['tools/ci/github_read.py','tools/ci/test_github_eof.py',
           'tools/ci/test_component_producer.py','tools/net-tcp-priority/run-component.ps1',
           'tools/net-tcp-priority/test-helper-metadata.ps1']
unchanged = ['tools/ci/github_jobs.py','tools/ci/producer_context.py','tools/ci/artifact_receipt.py',
             'tools/ci/component_producer.py','tools/ci/source_identity.py','tools/ci/artifact_candidates.py',
             'tools/surface/download-verified-artifact.py','.github/workflows/ci.yml',
             'tools/net-tcp-priority/qualified/ofd-stream-source.json',
             'tools/net-tcp-priority/test-selected-policy.py']
data = {}

def sha(content):
    return hashlib.sha256(content).hexdigest()

def add(name, content):
    assert name not in data
    data[name] = content

def addfile(name, path):
    add(name,Path(path).read_bytes())

def before(path):
    return subprocess.check_output(['git','show',base+':'+path],cwd=root)

def js(name, value):
    add(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == checkpoint
actual_changes = subprocess.check_output(['git','diff','--name-only',base,checkpoint],cwd=root,text=True).splitlines()
assert set(actual_changes) == set(changed)
for path in changed:
    addfile('current/'+path,root/path)
    if path != 'tools/ci/test_github_eof.py':
        add('baseline/'+path,before(path))
for path in unchanged:
    assert before(path) == (root/path).read_bytes(), path
    addfile('unchanged/'+path,root/path)
current = (root/'tools/ci/github_read.py').read_text()
addition = """        # This sole observed gh diagnostic does not identify the underlying
        # cause. Discard all unframed output and retry only the exact failed
        # read; successful framed JSON parsing above remains fail-closed.
        unframed_eof = result.returncode == 1 and status is None and stderr in (
            'unexpected end of JSON input',
            'unexpected end of JSON input\\n',
            'unexpected end of JSON input\\r\\n')
"""
assert current.count(addition) == 1
reversed_reader = current.replace(addition,'').replace('elif _transient(stderr) or unframed_eof:',
                                                       'elif _transient(stderr):')
assert reversed_reader.encode() == before('tools/ci/github_read.py')
component = (root/'tools/ci/test_component_producer.py').read_text()
start = component.index('    def post_download_eof(')
end = component.index('    def test_all_fixed_consumers_stage_original_archive_without_relabeling(', start)
assert (component[:start]+component[end:]).replace('import github_read\n','').encode() == before('tools/ci/test_component_producer.py')
workflow = before('.github/workflows/ci.yml').decode()
assert "python3 -m unittest discover -s tools/ci -p 'test_github*.py'" in workflow
assert 'python3 -m unittest discover -s tools/ci -p test_component_producer.py' in workflow

def functions(content):
    parsed=ast.parse(content)
    result={}
    for node in parsed.body:
        if isinstance(node,ast.FunctionDef):
            if node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
                node.body.pop(0)
            result[node.name]=ast.dump(node,include_attributes=False)
    return result

base_functions = functions(before('tools/ci/github_read.py'))
failures = [
    dict(pr=309,run=45249096332,attempt=3,job=138010494677,
         head='35083c4736b4753079e79ac7fa002625abf07950',
         checkout='58082d0502332a63bd09baa1ae1d77f17c76606d',
         log='native-pr309-job138010494677.log',source_dir='native-pr309-sg-exact-source/tools/ci',
         boundary='after authentication archive; current-attempt jobs snapshot'),
    dict(pr=330,run=45271588999,attempt=1,job=138033554385,
         head='6ed97f62c136268d93153c7d6dc9c3875306052c',
         checkout='c60df45e35b5e98a1c4ffefbaefb835e1a65f77a',
         log='root-new-ci-2202-138033554385.log',source_dir='native-github-eof-failed-sources/pr330',
         boundary='after authentication archive; current-attempt jobs snapshot'),
    dict(pr=429,run=45273973618,attempt=1,job=138043743970,
         head='036a7fb6a1e44019f18295cb4bd849eae170e1b0',
         checkout='2c3b462d2ea3a07ca35941b7dddb4eefa1ce46b0',
         log='root-new-ci-2202-138043743970.log',source_dir='native-github-eof-failed-sources/pr429',
         boundary='after staged batch archive; original-attempt pre-authentication snapshot'),
]
for failure in failures:
    raw = (workspace/failure['log']).read_bytes(); clean=re.sub(rb'\x1b\[[0-9;]*m',b'',raw)
    assert b'unexpected end of JSON input' in clean
    assert b'GitHub GET failed after 1 attempt(s) (gh exit 1)' in clean
    assert failure['head'].encode() in clean and failure['checkout'].encode() in clean
    failure['log_sha256']=sha(raw); failure['log_bytes']=len(raw)
    failure['url']=f"https://github.com/gesher-runtime/gesher/actions/runs/{failure['run']}/job/{failure['job']}"
    add(f"failures/pr{failure['pr']}/job-{failure['job']}.log",raw)
    sources={}
    for name in ('github_read.py','github_jobs.py','producer_context.py'):
        path=workspace/failure['source_dir']/name
        content=path.read_bytes(); add(f"failures/pr{failure['pr']}/{name}",content)
        sources[name]={'sha256':sha(content),'bytes':len(content)}
        if name=='github_read.py':
            f=functions(content)
            equal={name:f[name]==base_functions[name] for name in ('_transient','_http_response','get_json')}
            assert all(equal.values()),equal
            sources[name]['functions_equal_current_baseline_ignoring_docstrings']=equal
        else:
            assert content == before('tools/ci/'+name),name
            sources[name]['whole_file_equal_current_baseline']=True
    failure['sources']=sources
    failure['stdout_not_archived']=True
    failure['remote_cause_proven']=False
    failure['quota_cause_proven_for_this_read']=False
js('failure-source-proof.json',failures)

for folder in ('native-github-eof-final-gates','native-github-eof-final-controls',
               'native-github-eof-baseline-controls','native-github-eof-current','native-github-eof-controls'):
    for path in sorted((workspace/folder).rglob('*')):
        if path.is_file():addfile(folder+'/'+path.relative_to(workspace/folder).as_posix(),path)
for name in ('native_github_eof_controls.py','native_github_eof_package.py',
             'native-github-eof-baseline.json','native-pr309-sg-transport-source-proof.json',
             'media-review-eof-replay.json','media-review-eof-reader.log','media-review-eof-component.log'):
    path=workspace/name
    if path.exists():addfile('reproduction/'+name,path)
js('environment.json',dict(python=sys.version,platform=platform.platform(),machine=platform.machine(),
                          powershell=subprocess.check_output([str(workspace/'toolchains/powershell-7.5.4/pwsh'),'--version'],text=True).strip()))
gate_rows=json.loads((workspace/'native-github-eof-final-gates/receipts.json').read_text())
for row in gate_rows:
    log=data['native-github-eof-final-gates/'+row['name']+'.log']
    assert row['returncode']==0 and sha(log)==row['log_sha256']
    row['unittest_count']=[int(n) for n in re.findall(rb'Ran (\d+) tests?',log)]
assert sum(sum(row['unittest_count']) for row in gate_rows)==211
controls=json.loads((workspace/'native-github-eof-final-controls/receipts.json').read_text())
assert len(controls)==9 and sum(c['kind']=='mutant' for c in controls)==7
for row in controls:
    log=data['native-github-eof-final-controls/'+row['name']+'/run.log']
    assert sha(log)==row['log_sha256']
    assert row['returncode']==0 if row['kind']=='pass' else row['returncode']!=0

js('qualification-source-proof.json',dict(base=base,checkpoint=checkpoint,
    source_tree=subprocess.check_output(['git','rev-parse',checkpoint+'^{tree}'],cwd=root,text=True).strip(),
    changed=changed,unchanged={p:sha((root/p).read_bytes()) for p in unchanged},
    complete_reader_reversal_to_baseline=True,all_old_component_test_bytes_preserved=True,
    existing_ci_entries_unchanged=True,production_get_budget=4,transport_seconds=247,
    backoff_seconds=[1,2,4],quota_wait_seconds=3660,inventory_fallback_unchanged=True))
add('README.txt',b'''This is historical host transport-boundary evidence, not a live GitHub/Windows recovery result.
At the repair checkout run the unchanged CI unittest entries and the exact helper metadata gate.
For the old-reader negative and seven isolated mutants:
  python3 reproduction/native_github_eof_controls.py --repo /path/to/repair --output /tmp/eof-controls
The script copies actual current modules into temporary directories and loads the public baseline
5882d0a44765be56562ba25443b8572b6466712a only for the unchanged-reader negative. It never writes the checkout.
The original full failure logs do not retain the failed subprocess stdout or HTTP headers. Their
remote cause is unproved; no quota recovery is inferred. Initial fixture exception/message and
subtest cleanup development failures are retained separately, without being counted as passing gates.
No original producer, source, artifact digest, post-download, role, timeout or event predicate changed.
''')
inventory={name:dict(bytes=len(content),sha256=sha(content)) for name,content in sorted(data.items())}
js('inventory.json',inventory)
archive_rel='docs/research/evidence/github-unframed-eof-2026-11-23.tar.gz'
archive=root/archive_rel;archive.parent.mkdir(parents=True,exist_ok=True)
with archive.open('wb') as target:
    with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,content in sorted(data.items()):
                entry=tarfile.TarInfo(name);entry.size=len(content);entry.mode=0o644;entry.mtime=0
                tar.addfile(entry,io.BytesIO(content))
report=dict(schema=1,base=base,source_checkpoint=checkpoint,
            sources={p:sha((root/p).read_bytes()) for p in changed},
            unchanged_sources={p:sha((root/p).read_bytes()) for p in unchanged},
            failures=failures,gates=gate_rows,controls=controls,
            archive=dict(path=archive_rel,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(data)),
            limitations=['Subprocess/HTTP/storage boundaries supplied by host fixtures; actual receipt, ZIP digest, extraction, authentication and publication execute.',
                         'No live GitHub transport, quota recovery, Windows or native runtime result claimed.',
                         'Failed subprocess stdout and root cause were not captured in the original logs.',
                         'The intentional stacked-base authority rejection in #429 is unrelated and unchanged.'])
report_path=root/'docs/research/github-unframed-eof-2026-11-23.json'
report_path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['archive'],indent=2));print('unit tests',211,'mutants',7,'failed source identities',3)
