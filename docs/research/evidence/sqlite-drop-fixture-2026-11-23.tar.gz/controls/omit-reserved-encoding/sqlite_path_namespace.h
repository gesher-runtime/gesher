
#pragma once
#include <algorithm>
#include <cerrno>
#include <codecvt>
#include <cstdint>
#include <cstring>
#include <cwchar>
#include <cwctype>
#include <locale>
#include <string>
#include <string_view>
#include "reserved_names.h"
#include "unc_paths.h"
using DWORD = uint32_t;
constexpr unsigned MAX_PATH = 260;
// Windows lexical resolution only; no filesystem IO is simulated here.
static DWORD GetFullPathNameW(const wchar_t* input, DWORD size, wchar_t* out, wchar_t**) {
  std::wstring full(input);
  std::replace(full.begin(), full.end(), L'/', L'\\');
  if (full.rfind(L"\\\\", 0) != 0 && !(full.size() >= 3 && full[1] == L':' && full[2] == L'\\'))
    full = (full.starts_with(L'\\') ? L"D:" : L"D:\\work\\") + full;
  if (size <= full.size()) return static_cast<DWORD>(full.size() + 1);
  std::copy(full.begin(), full.end(), out);
  out[full.size()] = L'\0';
  return static_cast<DWORD>(full.size());
}
namespace gesher {
std::wstring Widen(const char* input) {
  if (!input) return {};
  return std::wstring_convert<std::codecvt_utf8<wchar_t>>{}.from_bytes(input);
}
std::string Narrow(const wchar_t* input) {
  if (!input) return {};
  return std::wstring_convert<std::codecvt_utf8<wchar_t>>{}.to_bytes(input);
}
static bool BinderDeviceExists() { return false; }
static int SystemFontPath(const char*, std::wstring*) { return 0; }
namespace procfs { static unsigned Type(const std::wstring&) { return 0; } }
namespace drop_mount {
inline constexpr char kAndroidPrefix[] = "/mnt/gesher/drop/";
// No authenticated Windows Channel::Attach runs in this portable fixture.
// Keep the same unavailable backend as a process with no attached channel.
static bool Enabled() { return false; }
}
namespace storage_root {
struct Selection {
  int error = 0;
  explicit operator bool() const { return false; }
};
static Selection Lookup(const std::wstring&) { return {}; }
}
enum class PathKind {
  kFile,     // a file system path, in `windows`
  kNull,     // /dev/null
  kZero,     // /dev/zero
  kRandom,   // /dev/random, /dev/urandom
  kVirtual,  // a name under /proc, or /etc/timezone: procfs.cc, by `windows`
             // (the normalized name, e.g. "proc/self/status", as UTF-16)
  kBinder,   // /dev/binder, when a binderd serves $GESHER_BINDER (binder.cc)
  kMissing,  // any other name under /dev or /sys
};
bool IsDriveLetter(char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'); }

std::string_view NextPart(std::string_view* path) {
  while (!path->empty()) {
    size_t end = path->find('/');
    std::string_view part = path->substr(0, end);
    path->remove_prefix(end == std::string_view::npos ? path->size() : end + 1);
    if (!part.empty() && part != ".") return part;
  }
  return {};
}

PathKind VirtualKind(std::string_view path, std::wstring* name) {
  // Ordinary file paths need only their first component. Do not allocate a
  // component vector for every open/stat, or retain any path between calls.
  const auto root = NextPart(&path);
  if (root == "etc") {
    const auto leaf = NextPart(&path);
    if (leaf == "timezone" && NextPart(&path).empty()) {
      *name = L"etc/timezone";
      return PathKind::kVirtual;
    }
    return PathKind::kFile;
  }
  if (root == "proc") {
    std::string joined(root);
    for (auto part = NextPart(&path); !part.empty(); part = NextPart(&path)) {
      joined += '/';
      joined += part;
    }
    *name = Widen(joined.c_str());
    return PathKind::kVirtual;
  }
  // /sys/devices/system/cpu/{possible,present,online}: the CPU lists cpuinfo
  // (XNNPACK, onnxruntime) reads first, served like /proc's files.
  if (root == "sys") {
    if (NextPart(&path) == "devices" && NextPart(&path) == "system" &&
        NextPart(&path) == "cpu") {
      const auto leaf = NextPart(&path);
      if ((leaf == "possible" || leaf == "present" || leaf == "online") && NextPart(&path).empty()) {
        *name = leaf == "possible" ? L"sys/devices/system/cpu/possible" :
                leaf == "present"  ? L"sys/devices/system/cpu/present" :
                                     L"sys/devices/system/cpu/online";
        return PathKind::kVirtual;
      }
    }
    return PathKind::kMissing;
  }
  if (root != "dev") return PathKind::kFile;
  const auto leaf = NextPart(&path);
  if (NextPart(&path).empty()) {
    if (leaf == "null") return PathKind::kNull;
    if (leaf == "zero") return PathKind::kZero;
    if (leaf == "random" || leaf == "urandom") return PathKind::kRandom;
    if (leaf == "binder") return BinderDeviceExists() ? PathKind::kBinder : PathKind::kMissing;
  }
  return PathKind::kMissing;
}

bool DrivePath(const char* path, std::wstring* windows) {
  if (strncmp(path, "/mnt/", 5) != 0 || !IsDriveLetter(path[5]) ||
      (path[6] != '\0' && path[6] != '/')) {
    return false;
  }
  std::wstring rest = Widen(path + 6);
  for (wchar_t& c : rest) {
    if (c == L'/') c = L'\\';
  }
  *windows = std::wstring(1, static_cast<wchar_t>(towupper(path[5]))) + L":" +
             (rest.empty() ? L"\\" : rest);
  return true;
}

void Lengthen(std::wstring* path) {
  if (path->rfind(L"\\\\?\\", 0) == 0) return;
  const bool drive_absolute = path->size() >= 3 &&
      (((*path)[0] >= L'A' && (*path)[0] <= L'Z') || ((*path)[0] >= L'a' && (*path)[0] <= L'z')) &&
      (*path)[1] == L':' && ((*path)[2] == L'\\' || (*path)[2] == L'/');
  const bool unc_absolute = path->rfind(L"\\\\", 0) == 0 || path->rfind(L"//", 0) == 0;
  if (path->size() < MAX_PATH - 12 && (drive_absolute || unc_absolute)) return;
  // A short relative name can already cross MAX_PATH once its current-directory
  // prefix is included. Resolve its size before deciding that ordinary syntax is
  // sufficient; waiting for the relative string itself to grow is too late.
  DWORD n = GetFullPathNameW(path->c_str(), 0, nullptr, nullptr);
  if (n == 0 || (path->size() < MAX_PATH - 12 && n <= MAX_PATH - 12)) return;
  std::wstring full(n, L'\0');
  n = GetFullPathNameW(path->c_str(), n, full.data(), nullptr);
  if (n == 0 || n >= full.size()) return;
  full.resize(n);
  *path = full.rfind(L"\\\\", 0) == 0 ? L"\\\\?\\UNC\\" + full.substr(2) : L"\\\\?\\" + full;
}

PathKind MapPath(const char* path, std::wstring* windows) {

  if (std::string_view(path).starts_with(drop_mount::kAndroidPrefix) && drop_mount::Enabled()) {
    *windows = Widen(path);
    std::replace(windows->begin(), windows->end(), L'/', L'\\');
    return PathKind::kFile;
  }
  // "//name" is left to Windows as a UNC path; POSIX lets an implementation
  // give a leading "//" its own meaning. A name with a character Windows
  // reserves (':' and the like) is stored encoded (gesher/reserved_names.h).
  if (path[0] == '/' && path[1] != '/') {
    auto unc = unc_paths::ToWindows(Widen(path), windows);
    if (unc == unc_paths::Match::kInvalid) {
      windows->clear();
      return PathKind::kMissing;
    }
    if (unc == unc_paths::Match::kMapped) {
      reserved_names::Encode(windows);
      Lengthen(windows);
      return PathKind::kFile;
    }
    PathKind kind = VirtualKind(path, windows);
    if (kind != PathKind::kFile) return kind;
    int font = SystemFontPath(path, windows);
    if (font != 0) return font > 0 ? PathKind::kFile : PathKind::kMissing;
    if (DrivePath(path, windows)) {
      reserved_names::Encode(windows);
      Lengthen(windows);
      return PathKind::kFile;
    }
  }
  *windows = Widen(path);
  Lengthen(windows);
  return PathKind::kFile;
}

bool DiskPath(const char* path, std::wstring* windows, int special, bool allow_broker) {
  if (path == nullptr) return errno = EFAULT, false;
  if (path[0] == '\0') return errno = ENOENT, false;
  switch (MapPath(path, windows)) {
    case PathKind::kFile:
      if (!allow_broker) {
        const auto rooted = storage_root::Lookup(*windows);
        if (rooted) return errno = rooted.error != 0 ? rooted.error : EOPNOTSUPP, false;
      }
      return true;
    case PathKind::kMissing:
      return errno = ENOENT, false;
    case PathKind::kVirtual:
      return errno = procfs::Type(*windows) == 0 ? ENOENT : special, false;
    default:
      return errno = special, false;
  }
}

}
