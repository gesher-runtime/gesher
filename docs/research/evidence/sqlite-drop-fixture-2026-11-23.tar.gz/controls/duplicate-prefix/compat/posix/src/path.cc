// gesher-base: Linux paths on Windows (docs/decisions/0010-paths.md), and
// the calls where paths enter: open, openat, fstatat, mkdir, mkdirat,
// getcwd. stat (stat.cc) maps its path with MapPath too.
//
// open, mkdir and getcwd are defined here under the CRT's own names, like
// close and read in fd.cc: gesher-base is linked before the CRT, so every
// caller gets these. open takes Linux's O_* values
// (<fcntl.h>) and opens files with CreateFileW, sharing delete access as
// Linux allows unlinking an open file.
#include <direct.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <windows.h>
#include <winternl.h>
#include <shellapi.h>
#include <gesher/font_paths.h>
#include <gesher/font_environment.h>
#include <gesher/reserved_names.h>
#include <gesher/unc_paths.h>

#include "startup_null.h"
#include "standalone_input.h"
#include "rooted_storage_client.h"
#include <gesher/drop_mount.h>

#include <string>
#include <limits>
#include <cstdlib>
#include <string_view>

#include "binder_internal.h"
#include "internal.h"
#include "ofd_internal.h"
#include "record_lock_descriptors.h"
#include "revocable_internal.h"

namespace gesher {
namespace {

bool IsDriveLetter(char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'); }

// Linux's absolute paths start with '/'; Windows' with a drive or '\'.
bool IsAbsolute(const char* path) {
  return path[0] == '/' || path[0] == '\\' || reserved_names::DriveRoot(path);
}

// The parts of an absolute path, without empty and "." components.
std::string_view NextPart(std::string_view* path) {
  while (!path->empty()) {
    size_t end = path->find('/');
    std::string_view part = path->substr(0, end);
    path->remove_prefix(end == std::string_view::npos ? path->size() : end + 1);
    if (!part.empty() && part != ".") return part;
  }
  return {};
}

// /dev, /proc and /sys are Linux's virtual file systems: their names never
// reach the disk; nor does /etc/timezone, which libcore reads for the default
// time zone. Returns kFile for any other path. For kVirtual, *name is the
// normalized name ("proc/self/status").
PathKind VirtualKind(std::string_view path, std::wstring* name) {
  // Ordinary file paths need only their first component. Do not allocate a
  // component vector for every open/stat, or retain any path between calls.
  const auto root = NextPart(&path);
  if (root == "etc") {
    const auto leaf = NextPart(&path);
    if (leaf == "timezone" && NextPart(&path).empty()) {
      *name = L"etc/timezone";
      return PathKind::kVirtual;
    }
    return PathKind::kFile;
  }
  if (root == "proc") {
    std::string joined(root);
    for (auto part = NextPart(&path); !part.empty(); part = NextPart(&path)) {
      joined += '/';
      joined += part;
    }
    *name = Widen(joined.c_str());
    return PathKind::kVirtual;
  }
  // /sys/devices/system/cpu/{possible,present,online}: the CPU lists cpuinfo
  // (XNNPACK, onnxruntime) reads first, served like /proc's files.
  if (root == "sys") {
    if (NextPart(&path) == "devices" && NextPart(&path) == "system" &&
        NextPart(&path) == "cpu") {
      const auto leaf = NextPart(&path);
      if ((leaf == "possible" || leaf == "present" || leaf == "online") && NextPart(&path).empty()) {
        *name = leaf == "possible" ? L"sys/devices/system/cpu/possible" :
                leaf == "present"  ? L"sys/devices/system/cpu/present" :
                                     L"sys/devices/system/cpu/online";
        return PathKind::kVirtual;
      }
    }
    return PathKind::kMissing;
  }
  if (root != "dev") return PathKind::kFile;
  const auto leaf = NextPart(&path);
  if (NextPart(&path).empty()) {
    if (leaf == "null") return PathKind::kNull;
    if (leaf == "zero") return PathKind::kZero;
    if (leaf == "random" || leaf == "urandom") return PathKind::kRandom;
    if (leaf == "binder") return BinderDeviceExists() ? PathKind::kBinder : PathKind::kMissing;
  }
  return PathKind::kMissing;
}

// /mnt/<drive>[/...] is that drive's path (ADR 0045): "D:\..." for "/mnt/d/...".
// False if `path` is not such a name.
bool DrivePath(const char* path, std::wstring* windows) {
  if (strncmp(path, "/mnt/", 5) != 0 || !IsDriveLetter(path[5]) ||
      (path[6] != '\0' && path[6] != '/')) {
    return false;
  }
  std::wstring rest = Widen(path + 6);
  for (wchar_t& c : rest) {
    if (c == L'/') c = L'\\';
  }
  *windows = std::wstring(1, static_cast<wchar_t>(towupper(path[5]))) + L":" +
             (rest.empty() ? L"\\" : rest);
  return true;
}

// Paths from MAX_PATH on need the \\?\ form, which takes only full paths
// with backslashes. (CreateDirectoryW stops 12 characters short of it.)
void Lengthen(std::wstring* path) {
  if (path->rfind(L"\\\\?\\", 0) == 0) return;
  const bool drive_absolute = path->size() >= 3 &&
      (((*path)[0] >= L'A' && (*path)[0] <= L'Z') || ((*path)[0] >= L'a' && (*path)[0] <= L'z')) &&
      (*path)[1] == L':' && ((*path)[2] == L'\\' || (*path)[2] == L'/');
  const bool unc_absolute = path->rfind(L"\\\\", 0) == 0 || path->rfind(L"//", 0) == 0;
  if (path->size() < MAX_PATH - 12 && (drive_absolute || unc_absolute)) return;
  // A short relative name can already cross MAX_PATH once its current-directory
  // prefix is included. Resolve its size before deciding that ordinary syntax is
  // sufficient; waiting for the relative string itself to grow is too late.
  DWORD n = GetFullPathNameW(path->c_str(), 0, nullptr, nullptr);
  if (n == 0 || (path->size() < MAX_PATH - 12 && n <= MAX_PATH - 12)) return;
  std::wstring full(n, L'\0');
  n = GetFullPathNameW(path->c_str(), n, full.data(), nullptr);
  if (n == 0 || n >= full.size()) return;
  full.resize(n);
  *path = full.rfind(L"\\\\", 0) == 0 ? L"\\\\?\\UNC\\" + full.substr(2) : L"\\\\?\\" + full;
}

DWORD Access(int flags) {
  if ((flags & O_PATH) != 0) return 0;
  DWORD access = 0;
  switch (flags & O_ACCMODE) {
    case O_RDONLY: access = GENERIC_READ; break;
    case O_WRONLY: access = GENERIC_WRITE; break;
    default: access = GENERIC_READ | GENERIC_WRITE; break;
  }
  return (flags & O_TRUNC) != 0 ? access | GENERIC_WRITE : access;
}

// The CRT fd for a new handle; closes the handle if there is none.
int FdFromHandle(HANDLE h, int flags, const std::wstring* drop_path = nullptr) {
  record_locks::DescriptorGuard descriptor_guard;
  int crt_flags = _O_BINARY |
                  ((flags & O_ACCMODE) == O_RDONLY ? _O_RDONLY : 0) |
                  ((flags & O_CLOEXEC) != 0 ? _O_NOINHERIT : 0);
  int fd = CrtResult(_open_osfhandle(reinterpret_cast<intptr_t>(h), crt_flags));
  if (fd < 0) {
    CloseHandle(h);
    return -1;
  }
  if (RegisterOfd(fd, flags) < 0) {
    int saved = errno;
    _close(fd);
    return errno = saved, -1;
  }
  if (drop_path != nullptr) {
    std::shared_ptr<OpenFileDescription> ofd;
    if (!LookupOfd(fd, &ofd)) {
      close(fd);
      return errno = EIO, -1;
    }
    std::lock_guard<std::mutex> guard(ofd->mutex);
    ofd->drop_path = *drop_path;
  }
  return fd;
}

int OpenFile(const std::wstring& path, int flags, mode_t mode) {
  if ((flags & O_TMPFILE) == O_TMPFILE) return errno = EOPNOTSUPP, -1;
  // This filesystem backend has no direct-I/O implementation. Linux permits
  // EINVAL for O_DIRECT on such a filesystem; never report buffered I/O as
  // direct I/O. O_PATH ignores I/O flags because it opens no data access.
  if ((flags & O_DIRECT) != 0 && (flags & O_PATH) == 0) return errno = EINVAL, -1;
  if ((flags & O_NOATIME) != 0 && (flags & O_PATH) == 0) return errno = EOPNOTSUPP, -1;
  if ((flags & O_PATH) == 0) flags |= O_LARGEFILE;
  auto& selected = standalone_input::Current();
  if (selected.Matches(path)) {
    const bool metadata_only = (flags & O_PATH) != 0;
    if ((flags & O_DIRECTORY) != 0) return errno = ENOTDIR, -1;
    if (!metadata_only) {
      if ((flags & (O_CREAT | O_EXCL)) == (O_CREAT | O_EXCL)) return errno = EEXIST, -1;
      if ((Access(flags) & GENERIC_WRITE) != 0) return errno = EACCES, -1;
    }
    HANDLE owned = selected.Open(metadata_only, (flags & O_CLOEXEC) == 0);
    if (owned == INVALID_HANDLE_VALUE) return errno = EACCES, -1;
    return FdFromHandle(owned, flags);
  }
  if (const auto bootstrap = storage_root::LookupBootstrap(path)) {
    if ((flags & O_DIRECTORY) != 0) return errno = ENOTDIR, -1;
    if ((flags & (O_CREAT | O_TRUNC)) != 0 || (Access(flags) & GENERIC_WRITE) != 0) {
      return errno = EACCES, -1;
    }
    HANDLE owned;
    const int error = storage_root::OpenBootstrap(*bootstrap, &owned);
    if (error != 0) return errno = error, -1;
    if ((flags & O_CLOEXEC) == 0 && !SetHandleInformation(owned, HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT)) {
      const int result = FailWithLastError();
      CloseHandle(owned);
      return result;
    }
    return FdFromHandle(owned, flags);
  }
  if (const auto rooted = storage_root::Lookup(path)) {
    namespace wire = rooted_storage_wire;
    uint32_t access = wire::kMetadata;
    if ((flags & O_PATH) == 0) {
      switch (flags & O_ACCMODE) {
        case O_RDONLY: access = (flags & O_TRUNC) != 0 ? wire::kReadWrite : wire::kRead; break;
        case O_WRONLY: access = wire::kWrite; break;
        default: access = wire::kReadWrite; break;
      }
      if ((flags & O_CREAT) != 0) {
        access |= wire::kCreate;
        if ((flags & O_EXCL) != 0) access |= wire::kExclusive;
        if ((mode & 0200) == 0) access |= wire::kReadOnlyCreate;
      }
      if ((flags & O_TRUNC) != 0) access |= wire::kTruncate;
      if ((flags & O_DSYNC) != 0) access |= wire::kWriteThrough;
    }
    if ((flags & O_DIRECTORY) != 0) access |= wire::kDirectory;
    HANDLE owned;
    const int error = storage_root::Open(rooted, access, &owned);
    if (error != 0) return errno = error, -1;
    if ((flags & O_CLOEXEC) == 0 && !SetHandleInformation(owned, HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT)) {
      const int result = FailWithLastError();
      CloseHandle(owned);
      return result;
    }
    return FdFromHandle(owned, flags, rooted.drop_alias ? &path : nullptr);
  }
  DWORD disposition;
  if ((flags & O_PATH) != 0) {
    disposition = OPEN_EXISTING;
  } else if ((flags & O_CREAT) != 0) {
    disposition = (flags & O_EXCL) != 0 ? CREATE_NEW : (flags & O_TRUNC) != 0 ? CREATE_ALWAYS : OPEN_ALWAYS;
  } else {
    disposition = (flags & O_TRUNC) != 0 ? TRUNCATE_EXISTING : OPEN_EXISTING;
  }
  // Backup semantics open directories too, as Linux does for reading. A new
  // file without the owner's write permission is read-only, as chmod makes
  // it (fsops.cc); the fd itself may still write, as on Linux. O_NOFOLLOW
  // opens a symbolic link itself, to refuse it below (or, with O_PATH, to
  // return it).
  DWORD attributes = FILE_FLAG_BACKUP_SEMANTICS |
                     ((flags & O_CREAT) != 0 && (mode & 0200) == 0 ? FILE_ATTRIBUTE_READONLY
                                                                   : FILE_ATTRIBUTE_NORMAL) |
                     ((flags & O_NOFOLLOW) != 0 ? FILE_FLAG_OPEN_REPARSE_POINT : 0) |
                     ((flags & O_DSYNC) != 0 ? FILE_FLAG_WRITE_THROUGH : 0);
  SECURITY_ATTRIBUTES inherit = {sizeof(inherit), nullptr, (flags & O_CLOEXEC) == 0};
  DWORD access = Access(flags);
  HANDLE h = INVALID_HANDLE_VALUE;
  // A brief open that denies sharing (a scanner, inotify.cc's check for
  // writers) is waited out.
  for (int attempt = 0; attempt < 20; ++attempt) {
    h = CreateFileW(path.c_str(), access, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                    &inherit, disposition, attributes, nullptr);
    if (h != INVALID_HANDLE_VALUE || GetLastError() != ERROR_SHARING_VIOLATION) break;
    Sleep(1);
  }
  if (h == INVALID_HANDLE_VALUE) {
    DWORD error = GetLastError();
    DWORD existing = GetFileAttributesW(path.c_str());
    if (error == ERROR_ACCESS_DENIED && existing != INVALID_FILE_ATTRIBUTES &&
        (existing & FILE_ATTRIBUTE_DIRECTORY) != 0) {
      return errno = EISDIR, -1;
    }
    SetLastError(error);
    return FailWithLastError();
  }
  if ((flags & (O_NOFOLLOW | O_PATH)) == O_NOFOLLOW && IsSymlinkHandle(h)) {
    CloseHandle(h);
    return errno = ELOOP, -1;
  }
  BY_HANDLE_FILE_INFORMATION info;
  bool directory = GetFileInformationByHandle(h, &info) &&
                   (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
  if ((flags & O_DIRECTORY) != 0 && !directory) {
    CloseHandle(h);
    return errno = ENOTDIR, -1;
  }
  if (directory && (access & GENERIC_WRITE) != 0) {
    CloseHandle(h);
    return errno = EISDIR, -1;
  }
  return FdFromHandle(h, flags);
}

// /dev/null, and /dev/zero and /dev/random over it.
int OpenDevice(PathKind kind, int flags) {
  record_locks::DescriptorGuard descriptors;
  if ((flags & O_PATH) == 0 && (flags & O_DIRECT) != 0) return errno = EINVAL, -1;
  if ((flags & O_PATH) == 0 && (flags & O_NOATIME) != 0) return errno = EOPNOTSUPP, -1;
  if ((flags & O_DIRECTORY) != 0) return errno = ENOTDIR, -1;
  if ((flags & (O_CREAT | O_EXCL)) == (O_CREAT | O_EXCL)) return errno = EEXIST, -1;
  HANDLE h = OpenNullDevice(Access(flags), (flags & O_CLOEXEC) == 0);
  if (h == INVALID_HANDLE_VALUE) return FailWithLastError();
  int fd = FdFromHandle(h, flags);
  if (fd >= 0 && kind == PathKind::kZero) RegisterDevice(fd, Device::kZero);
  if (fd >= 0 && kind == PathKind::kRandom) RegisterDevice(fd, Device::kRandom);
  return fd;
}

int OpenPath(const char* path, int flags, mode_t mode) {
  if (path == nullptr) return errno = EFAULT, -1;
  if (*path == '\0') return errno = ENOENT, -1;
  std::wstring windows;
  PathKind kind = MapPath(path, &windows);
  switch (kind) {
    case PathKind::kFile: return OpenFile(windows, flags, mode);
    case PathKind::kNull:
    case PathKind::kZero:
    case PathKind::kRandom: return OpenDevice(kind, flags);
    case PathKind::kVirtual: return procfs::Open(windows, flags);
    case PathKind::kBinder: return OpenBinder(flags);
    case PathKind::kMissing: break;
  }
  return errno = (flags & O_CREAT) != 0 ? EACCES : ENOENT, -1;
}

}  // namespace

// Joins a path relative to dirfd onto that directory's path; absolute paths
// and AT_FDCWD pass unchanged. False (errno set) if dirfd is not a directory.
bool ResolveAt(int dirfd, const char* path, std::string* out) {
  if (path == nullptr) return errno = EFAULT, false;
  if (dirfd == AT_FDCWD || IsAbsolute(path)) {
    *out = path;
    return true;
  }
  const auto descriptor = CaptureDescriptor(dirfd);
  if (!descriptor) return errno = EBADF, false;
  HANDLE h = descriptor->handle;
  BY_HANDLE_FILE_INFORMATION info;
  if (!GetFileInformationByHandle(h, &info) ||
      (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0) {
    return errno = ENOTDIR, false;
  }
  auto dir = DropDescriptorPath(descriptor);
  if (dir.empty()) dir = storage_root::DescriptorPath(h);
  if (dir.empty()) {
    DWORD n = GetFinalPathNameByHandleW(h, nullptr, 0, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
    dir.resize(n);
    n = GetFinalPathNameByHandleW(h, dir.data(), n, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
    if (n == 0 || n >= dir.size()) return FailWithLastError(), false;
    dir.resize(n);
  }
  *out = LinuxPath(dir.c_str());
  if (out->back() != '/') *out += '/';
  *out += path;
  return true;
}

NativeFontFiles SystemFontFiles() {
  auto root = ReadFontEnvironment(FontEnvironmentKey::kAndroidRoot);
  if (root.state == FontEnvironmentValue::State::kError) return {};
  if (root.state == FontEnvironmentValue::State::kValue && !root.value().empty())
    return {std::string(root.value()) + "/etc/fonts.xml", std::string(root.value()) + "/fonts"};
  std::wstring image(512, L'\0');
  for (;;) {
    DWORD size = GetModuleFileNameW(nullptr, image.data(), static_cast<DWORD>(image.size()));
    if (size == 0) return {};
    if (size < image.size()) { image.resize(size); break; }
    if (image.size() >= 32768) return {};
    image.resize(image.size() * 2);
  }
  size_t slash = image.find_last_of(L"\\/");
  if (slash == std::wstring::npos) return {};
  std::string directory = LinuxPath((image.substr(0, slash + 1) + L"fonts").c_str());
  return {directory + "/fonts.xml", directory};
}

// Returns unrelated/file/invalid. Never let a malformed virtual font suffix
// escape through Win32 separators, drive/ADS syntax or parent components.
static int SystemFontPath(const char* path, std::wstring* windows) {
  std::string_view p(path), suffix;
  constexpr std::string_view config = "/system/etc/fonts.xml";
  bool xml = p == config;
  if (!xml) {
    if (p.starts_with(config) && p.size() > config.size() &&
        (p[config.size()] == '/' || p[config.size()] == '\\' || p[config.size()] == ':')) return -1;
    constexpr std::string_view prefix = "/system/fonts";
    if (!p.starts_with(prefix) || (p.size() > prefix.size() &&
        p[prefix.size()] != '/' && p[prefix.size()] != '\\')) return 0;
    suffix = p.substr(prefix.size());
    if (suffix.find_first_of("\\:") != std::string_view::npos) return -1;
    auto remaining = suffix;
    for (auto part = NextPart(&remaining); !part.empty(); part = NextPart(&remaining)) {
      if (part.back() == '.' || part.back() == ' ') return -1;
      // Win32 treats these basenames as devices, even with an extension.
      std::string stem(part.substr(0, part.find('.')));
      for (char& c : stem) if (c >= 'a' && c <= 'z') c -= 'a' - 'A';
      if (stem == "CON" || stem == "PRN" || stem == "AUX" || stem == "NUL" ||
          stem == "CONIN$" || stem == "CONOUT$" ||
          (stem.size() == 4 && (stem.starts_with("COM") || stem.starts_with("LPT")) &&
           stem[3] >= '1' && stem[3] <= '9') ||
          (stem.size() == 5 && (stem.starts_with("COM") || stem.starts_with("LPT")) &&
           static_cast<unsigned char>(stem[3]) == 0xc2 &&
           (static_cast<unsigned char>(stem[4]) == 0xb9 ||
            static_cast<unsigned char>(stem[4]) == 0xb2 ||
            static_cast<unsigned char>(stem[4]) == 0xb3))) return -1;
    }
  }
  auto files = SystemFontFiles();
  if (files.xml.empty() || files.directory.empty()) return -1;
  std::string target = xml ? files.xml : files.directory + std::string(suffix);
  if (target.empty()) return -1;
  // Resolve the configured/install path directly, without re-entering this
  // namespace mapping when an explicit root happens to be literal /system.
  auto unc = unc_paths::ToWindows(Widen(target.c_str()), windows);
  if (unc == unc_paths::Match::kInvalid) return -1;
  if (unc == unc_paths::Match::kUnrelated && !DrivePath(target.c_str(), windows))
    *windows = Widen(target.c_str());
  reserved_names::Encode(windows);
  Lengthen(windows);
  return 1;
}

PathKind MapPath(const char* path, std::wstring* windows) {

  if (std::string_view(path).starts_with(drop_mount::kAndroidPrefix) && drop_mount::Enabled()) {
    *windows = Widen(path);
    std::replace(windows->begin(), windows->end(), L'/', L'\\');
    return PathKind::kFile;
  }
  // "//name" is left to Windows as a UNC path; POSIX lets an implementation
  // give a leading "//" its own meaning. A name with a character Windows
  // reserves (':' and the like) is stored encoded (gesher/reserved_names.h).
  if (path[0] == '/' && path[1] != '/') {
    auto unc = unc_paths::ToWindows(Widen(path), windows);
    if (unc == unc_paths::Match::kInvalid) {
      windows->clear();
      return PathKind::kMissing;
    }
    if (unc == unc_paths::Match::kMapped) {
      reserved_names::Encode(windows);
      Lengthen(windows);
      return PathKind::kFile;
    }
    PathKind kind = VirtualKind(path, windows);
    if (kind != PathKind::kFile) return kind;
    int font = SystemFontPath(path, windows);
    if (font != 0) return font > 0 ? PathKind::kFile : PathKind::kMissing;
    if (DrivePath(path, windows)) {
      reserved_names::Encode(windows);
      Lengthen(windows);
      return PathKind::kFile;
    }
  }
  *windows = Widen(path);
  reserved_names::Encode(windows);
  Lengthen(windows);
  return PathKind::kFile;
}

std::wstring NativeFontWindowsPath(const std::string& path) {
  std::wstring windows;
  return MapPath(path.c_str(), &windows) == PathKind::kFile ? windows : std::wstring();
}

bool DiskPath(const char* path, std::wstring* windows, int special, bool allow_broker) {
  if (path == nullptr) return errno = EFAULT, false;
  if (path[0] == '\0') return errno = ENOENT, false;
  switch (MapPath(path, windows)) {
    case PathKind::kFile:
      if (!allow_broker) {
        const auto rooted = storage_root::Lookup(*windows);
        if (rooted) return errno = rooted.error != 0 ? rooted.error : EOPNOTSUPP, false;
      }
      return true;
    case PathKind::kMissing:
      return errno = ENOENT, false;
    case PathKind::kVirtual:
      return errno = procfs::Type(*windows) == 0 ? ENOENT : special, false;
    default:
      return errno = special, false;
  }
}

// The current directory's drive, 1 for A:; 0 when it has none (UNC). Unlike
// _getdrive, it also reads a \\?\ current directory.
int CurrentDrive() {
  wchar_t cwd[8];
  DWORD n = GetCurrentDirectoryW(8, cwd);
  std::wstring head;
  if (n >= 8) {
    std::wstring full(n, L'\0');
    n = GetCurrentDirectoryW(n, full.data());
    head = full.substr(0, n);
  } else {
    head.assign(cwd, n);
  }
  if (head.rfind(L"\\\\?\\", 0) == 0) head = head.substr(4);
  if (head.size() >= 2 && head[1] == L':' && iswalpha(head[0])) return towupper(head[0]) - L'A' + 1;
  return 0;
}

std::string LinuxPath(const wchar_t* windows) {
  // Decode only names under the native root, before UNC namespace conversion.
  std::wstring path = windows;
  reserved_names::DecodePath(&path);
  std::wstring unc;
  if (unc_paths::FromWindows(path, &unc)) return Narrow(unc.c_str());
  if (path.rfind(L"\\\\?\\UNC\\", 0) == 0) {
    path = L"\\\\" + path.substr(8);
  } else if (path.rfind(L"\\\\?\\", 0) == 0) {
    path = path.substr(4);
  }
  for (wchar_t& c : path) {
    if (c == L'\\') c = L'/';
  }
  int drive = CurrentDrive();
  if (path.size() >= 2 && path[1] == L':' && iswalpha(path[0]) && (path.size() == 2 || path[2] == L'/')) {
    if (drive > 0 && towupper(path[0]) == static_cast<wchar_t>(L'A' + drive - 1)) {
      path.erase(0, 2);
      if (path.empty()) path = L"/";
    } else {
      // Another drive: /mnt/<drive>, so the path needs no colon either.
      std::wstring rest = path.substr(2);
      if (rest == L"/") rest.clear();
      path = std::wstring(L"/mnt/") + static_cast<wchar_t>(towlower(path[0])) + rest;
    }
  }
  return Narrow(path.c_str());
}

// Linux's unlink and rmdir remove the name at once, even while the file is
// open; Windows' DeleteFile and RemoveDirectory may leave it in place (delete
// pending) until the last handle closes. The POSIX-semantics delete gives
// Linux's behaviour where the volume has it, the classic one otherwise; a
// scanner's brief open of a new file is waited out. A symbolic link is
// removed itself, by unlink, also when it points to a directory.
int PosixDelete(const std::wstring& windows, bool directory) {
  if (const auto rooted = storage_root::Lookup(windows)) {
    const int error = storage_root::Remove(rooted, directory);
    return error != 0 ? (errno = error, -1) : 0;
  }
  HANDLE h = INVALID_HANDLE_VALUE;
  for (int attempt = 0; attempt < 20; ++attempt) {
    h = CreateFileW(windows.c_str(), DELETE | FILE_READ_ATTRIBUTES | FILE_WRITE_ATTRIBUTES,
                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
                    FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS, nullptr);
    if (h != INVALID_HANDLE_VALUE || GetLastError() != ERROR_SHARING_VIOLATION) break;
    Sleep(10);
  }
  if (h == INVALID_HANDLE_VALUE) return FailWithLastError();
  FILE_BASIC_INFO basic;
  bool is_directory = GetFileInformationByHandleEx(h, FileBasicInfo, &basic, sizeof(basic)) &&
                      (basic.FileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0 &&
                      !IsSymlinkHandle(h);
  if (is_directory != directory) {
    CloseHandle(h);
    return errno = directory ? ENOTDIR : EISDIR, -1;
  }
  FILE_DISPOSITION_INFO_EX posix = {FILE_DISPOSITION_FLAG_DELETE |
                                    FILE_DISPOSITION_FLAG_POSIX_SEMANTICS |
                                    FILE_DISPOSITION_FLAG_IGNORE_READONLY_ATTRIBUTE};
  // FileDispositionInfoEx (21), which older SDK headers declare only for
  // newer _WIN32_WINNT values.
  BOOL ok = SetFileInformationByHandle(h, static_cast<FILE_INFO_BY_HANDLE_CLASS>(21), &posix,
                                       sizeof(posix));
  DWORD error = GetLastError();
  if (!ok && error != ERROR_DIR_NOT_EMPTY) {
    // Linux removes read-only files; the classic delete does not.
    if ((basic.FileAttributes & FILE_ATTRIBUTE_READONLY) != 0) {
      basic.FileAttributes &= ~FILE_ATTRIBUTE_READONLY;
      SetFileInformationByHandle(h, FileBasicInfo, &basic, sizeof(basic));
    }
    FILE_DISPOSITION_INFO classic = {TRUE};
    ok = SetFileInformationByHandle(h, FileDispositionInfo, &classic, sizeof(classic));
    error = GetLastError();
  }
  CloseHandle(h);
  if (!ok) {
    SetLastError(error);
    return FailWithLastError();
  }
  return 0;
}

}  // namespace gesher

using gesher::PathKind;

extern "C" {

// Of the mode, only the owner's write permission is kept: without it a new
// file is read-only.
int open(const char* path, int flags, ...) {
  mode_t mode = 0666;
  if ((flags & O_CREAT) != 0) {
    va_list args;
    va_start(args, flags);
    mode = static_cast<mode_t>(va_arg(args, int));
    va_end(args);
  }
  return gesher::OpenPath(path, flags, mode);
}

int openat(int dirfd, const char* path, int flags, ...) {
  mode_t mode = 0666;
  if ((flags & O_CREAT) != 0) {
    va_list args;
    va_start(args, flags);
    mode = static_cast<mode_t>(va_arg(args, int));
    va_end(args);
  }
  std::string resolved;
  if (!gesher::ResolveAt(dirfd, path, &resolved)) return -1;
  return gesher::OpenPath(resolved.c_str(), flags, mode);
}

int creat(const char* path, int mode) {
  return gesher::OpenPath(path, O_CREAT | O_WRONLY | O_TRUNC, static_cast<mode_t>(mode));
}

// stat, fstat and lstat are in stat.cc.

int fstatat(int dirfd, const char* path, struct stat* buf, int flags) {
  if ((flags & AT_EMPTY_PATH) != 0 && path != nullptr && path[0] == '\0') return fstat(dirfd, buf);
  std::string resolved;
  if (!gesher::ResolveAt(dirfd, path, &resolved)) return -1;
  return (flags & AT_SYMLINK_NOFOLLOW) != 0 ? lstat(resolved.c_str(), buf)
                                            : stat(resolved.c_str(), buf);
}

// --- file times ---------------------------------------------------------------

namespace {

// 100 ns intervals between 1601-01-01 and 1970-01-01.
constexpr long long kEpochDifference = 116444736000000000LL;

bool BothTimesOmitted(const struct timespec times[2]) {
  return times != nullptr && times[0].tv_nsec == UTIME_OMIT && times[1].tv_nsec == UTIME_OMIT;
}

bool ValidTimeNanoseconds(const struct timespec times[2]) {
  if (times == nullptr) return true;
  for (int i = 0; i < 2; ++i) {
    auto ns = times[i].tv_nsec;
    if (ns != UTIME_NOW && ns != UTIME_OMIT && (ns < 0 || ns >= 1000000000)) {
      return errno = EINVAL, false;
    }
  }
  return true;
}

void CloseTimeHandle(HANDLE h) {
  const int error = errno;
  const DWORD last = GetLastError();
  CloseHandle(h);
  SetLastError(last);
  errno = error;
}

// Sets access and modification times (times[0], times[1]) as utimensat
// does: null means now, as do UTIME_NOW entries; UTIME_OMIT leaves one as
// it is. The handle needs FILE_WRITE_ATTRIBUTES.
int SetTimes(HANDLE h, const struct timespec times[2]) {
  if (!ValidTimeNanoseconds(times)) return -1;
  FILETIME now;
  GetSystemTimePreciseAsFileTime(&now);
  FILETIME values[2];
  FILETIME* set[2];
  for (int i = 0; i < 2; ++i) {
    if (times == nullptr || times[i].tv_nsec == UTIME_NOW) {
      values[i] = now;
      set[i] = &values[i];
    } else if (times[i].tv_nsec == UTIME_OMIT) {
      set[i] = nullptr;
    } else {
      const __int128 ticks = static_cast<__int128>(times[i].tv_sec) * 10000000 +
                             times[i].tv_nsec / 100 + kEpochDifference;
      // Win32's zero FILETIME means "leave unchanged", not the 1601 epoch.
      // Keep within the signed NT absolute-time range used by our stat layer,
      // rather than wrapping into a no-change/suppression sentinel.
      if (ticks <= 0 || ticks > std::numeric_limits<long long>::max()) return errno = EOVERFLOW, -1;
      const auto value = static_cast<unsigned long long>(ticks);
      values[i].dwLowDateTime = static_cast<DWORD>(value);
      values[i].dwHighDateTime = static_cast<DWORD>(value >> 32);
      set[i] = &values[i];
    }
  }
  return SetFileTime(h, nullptr, set[0], set[1]) ? 0 : gesher::FailWithLastError();
}

// The borrowed handle identifies the object even after a rename/unlink. Validate
// after lookup, but before requesting write access, as Linux's vfs_utimes does.
int SetHandleTimes(HANDLE h, const struct timespec times[2]) {
  if (!ValidTimeNanoseconds(times)) return -1;
  if (GetFileType(h) != FILE_TYPE_DISK) return 0;  // non-disk metadata is not modelled
  // ReOpenFile can reject directory objects even with backup semantics. An
  // empty native name reopens the object identified by h, including a directory
  // reparse point, without resolving a name that could have been renamed/replaced.
  using Open = LONG(WINAPI*)(HANDLE*, ACCESS_MASK, POBJECT_ATTRIBUTES,
                             PIO_STATUS_BLOCK, ULONG, ULONG);
  using Error = ULONG(WINAPI*)(LONG);
  HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
  if (!ntdll) return errno = EOPNOTSUPP, -1;
  auto open = reinterpret_cast<Open>(reinterpret_cast<void*>(GetProcAddress(ntdll, "NtOpenFile")));
  auto error = reinterpret_cast<Error>(reinterpret_cast<void*>(GetProcAddress(ntdll, "RtlNtStatusToDosError")));
  if (!open || !error) return errno = EOPNOTSUPP, -1;
  wchar_t empty = L'\0';
  UNICODE_STRING name{0, sizeof(empty), &empty};
  OBJECT_ATTRIBUTES attributes{};
  attributes.Length = sizeof(attributes);
  attributes.RootDirectory = h;
  attributes.ObjectName = &name;
  IO_STATUS_BLOCK io{};
  HANDLE writable = INVALID_HANDLE_VALUE;
  LONG status = open(&writable, FILE_WRITE_ATTRIBUTES | SYNCHRONIZE, &attributes, &io,
                     FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                     FILE_OPEN_FOR_BACKUP_INTENT | FILE_OPEN_REPARSE_POINT |
                         FILE_SYNCHRONOUS_IO_NONALERT);
  if (status < 0) {
    SetLastError(error(status));
    return gesher::FailWithLastError();
  }
  const int result = SetTimes(writable, times);
  CloseTimeHandle(writable);
  return result;
}

bool ToTimespecs(const struct timeval tv[2], struct timespec ts[2]) {
  for (int i = 0; i < 2; ++i) {
    if (tv[i].tv_usec < 0 || tv[i].tv_usec >= 1000000) return errno = EINVAL, false;
    ts[i].tv_sec = tv[i].tv_sec;
    ts[i].tv_nsec = tv[i].tv_usec * 1000;
  }
  return true;
}

}  // namespace

int utimensat(int dirfd, const char* path, const struct timespec times[2], int flags) {
  // Linux returns before inspecting flags, fd or path for this exact no-op.
  if (BothTimesOmitted(times)) return 0;
  if (path == nullptr && dirfd != AT_FDCWD) {
    if (flags != 0) return errno = EINVAL, -1;
    return futimens(dirfd, times);
  }
  if ((flags & ~(AT_SYMLINK_NOFOLLOW | AT_EMPTY_PATH)) != 0) return errno = EINVAL, -1;
  if (path == nullptr) return errno = EFAULT, -1;
  if (path[0] == '\0') {
    if ((flags & AT_EMPTY_PATH) == 0) return errno = ENOENT, -1;
    if (dirfd != AT_FDCWD) return futimens(dirfd, times);
    path = ".";
  }
  std::string resolved;
  if (!gesher::ResolveAt(dirfd, path, &resolved)) return -1;
  if (resolved.empty()) return errno = ENOENT, -1;
  std::wstring windows;
  switch (gesher::MapPath(resolved.c_str(), &windows)) {
    case PathKind::kFile: {
      if (const auto rooted = gesher::storage_root::Lookup(windows)) {
        HANDLE h;
        const int error = gesher::storage_root::Open(rooted, gesher::rooted_storage_wire::kMetadataWrite, &h);
        if (error != 0) return errno = error, -1;
        const int result = SetTimes(h, times);
        CloseTimeHandle(h);
        return result;
      }
      HANDLE h = CreateFileW(windows.c_str(), 0,
                             FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
                             OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS |
                                 ((flags & AT_SYMLINK_NOFOLLOW) != 0 ? FILE_FLAG_OPEN_REPARSE_POINT : 0),
                             nullptr);
      if (h == INVALID_HANDLE_VALUE) return gesher::FailWithLastError();
      const int result = SetHandleTimes(h, times);
      CloseTimeHandle(h);
      return result;
    }
    case PathKind::kMissing:
      return errno = ENOENT, -1;
    default:
      return errno = EPERM, -1;  // devices and /proc files
  }
}

// Linux lets the owner set times through any fd, a read-only one included,
// so this works on a second handle with the access it needs.
int futimens(int fd, const struct timespec times[2]) {
  if (BothTimesOmitted(times)) return 0;
  auto snapshot = gesher::CaptureDescriptor(fd);
  if (!snapshot) return -1;
  gesher::FileOperationLease operation(snapshot);
  if (operation.Error()) return errno = operation.Error(), -1;
  return SetHandleTimes(snapshot->handle, times);
}

int utimes(const char* path, const struct timeval tv[2]) {
  struct timespec ts[2];
  if (tv != nullptr && !ToTimespecs(tv, ts)) return -1;
  return utimensat(AT_FDCWD, path, tv != nullptr ? ts : nullptr, 0);
}

int lutimes(const char* path, const struct timeval tv[2]) {
  struct timespec ts[2];
  if (tv != nullptr && !ToTimespecs(tv, ts)) return -1;
  return utimensat(AT_FDCWD, path, tv != nullptr ? ts : nullptr, AT_SYMLINK_NOFOLLOW);
}

int futimes(int fd, const struct timeval tv[2]) {
  struct timespec ts[2];
  if (tv != nullptr && !ToTimespecs(tv, ts)) return -1;
  return futimens(fd, tv != nullptr ? ts : nullptr);
}

int mkdir(const char* path) {
  if (path == nullptr) return errno = EFAULT, -1;
  std::wstring windows;
  switch (path[0] != '\0' ? gesher::MapPath(path, &windows) : PathKind::kMissing) {
    case PathKind::kFile: {
      if (const auto rooted = gesher::storage_root::Lookup(windows)) {
        const int error = gesher::storage_root::MakeDirectory(rooted);
        return error != 0 ? (errno = error, -1) : 0;
      }
      return CreateDirectoryW(windows.c_str(), nullptr) ? 0 : gesher::FailWithLastError();
    }
    case PathKind::kMissing:
      return errno = ENOENT, -1;
    default:
      return errno = EEXIST, -1;
  }
}

int unlink(const char* path) {
  std::wstring windows;
  if (!gesher::DiskPath(path, &windows, EACCES, true)) return -1;  // EACCES: /dev and /proc names
  return gesher::PosixDelete(windows, false);
}

int mkdirat(int dirfd, const char* path, mode_t) {
  std::string resolved;
  if (!gesher::ResolveAt(dirfd, path, &resolved)) return -1;
  return mkdir(resolved.c_str());
}

// Linux paths, without the drive when it is the current one, so that the
// result can go in a ':'-separated list. A null buf is allocated (glibc).
char* getcwd(char* buf, int size) {
  DWORD n = GetCurrentDirectoryW(0, nullptr);
  std::wstring cwd(n, L'\0');
  n = GetCurrentDirectoryW(n, cwd.data());
  if (n == 0 || n >= cwd.size()) {
    gesher::FailWithLastError();
    return nullptr;
  }
  cwd.resize(n);
  std::string path = gesher::LinuxPath(cwd.c_str());
  size_t needed = path.size() + 1;
  if (buf == nullptr) {
    if (size > 0 && needed > static_cast<size_t>(size)) return errno = ERANGE, nullptr;
    return _strdup(path.c_str());
  }
  if (size <= 0) return errno = EINVAL, nullptr;
  if (needed > static_cast<size_t>(size)) return errno = ERANGE, nullptr;
  memcpy(buf, path.c_str(), needed);
  return buf;
}

}  // extern "C"
