cmake_minimum_required(VERSION 3.24)
project(gesher LANGUAGES C CXX ASM)

# AOSP sources come from tools/fetch-aosp.sh, never from this repository.
set(AOSP_DIR "${CMAKE_SOURCE_DIR}/third_party/aosp" CACHE PATH "AOSP checkout (tools/fetch-aosp.sh)")
if(NOT EXISTS "${AOSP_DIR}/art/libartbase")
  message(FATAL_ERROR "AOSP sources not found in ${AOSP_DIR}; run tools/fetch-aosp.sh")
endif()

if(NOT WIN32)
  message(FATAL_ERROR "Gesher targets Windows; configure with -DCMAKE_TOOLCHAIN_FILE=cmake/toolchain-llvm-mingw.cmake")
endif()

find_package(Python3 REQUIRED COMPONENTS Interpreter)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS ON)    # AOSP builds with -std=gnu++20
set(CMAKE_C_STANDARD 17)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE RelWithDebInfo)
endif()

# Flags Soong applies to every Windows host module.
add_compile_definitions(
  GESHER USE_MINGW WIN32_LEAN_AND_MEAN NOMINMAX NOGDI _USE_MATH_DEFINES
  __STDC_FORMAT_MACROS __STDC_CONSTANT_MACROS __STDC_LIMIT_MACROS
  _WIN32_WINNT=0x0A00 WINVER=0x0A00 _FILE_OFFSET_BITS=64
  _POSIX_THREAD_SAFE_FUNCTIONS)
add_compile_options(-mno-ms-bitfields -fno-exceptions
  $<$<COMPILE_LANGUAGE:CXX>:-fsized-deallocation>)
# Everything links statically: one self-contained .exe per tool. Executables
# are stripped by default; objects keep their debug info. Local builds that
# need symbols (addr2line on crash reports) turn GESHER_STRIP off.
option(GESHER_STRIP "Strip executables" ON)
add_link_options(-static)
if(GESHER_STRIP)
  add_link_options(-s)
endif()

# gesher-base: POSIX/Linux interfaces implemented on Win32.
include(compat/posix/posix.cmake)

add_executable(rooted_storage_probe tests/sandbox/rooted-storage-probe.cc)
target_compile_options(rooted_storage_probe PRIVATE -Wall -Wextra -Werror)
target_link_options(rooted_storage_probe PRIVATE -municode)
target_link_libraries(rooted_storage_probe PRIVATE gesher_posix)

# gesher: the ELF loader for x86-64 Android .so files (Phase 6).
include(compat/elf/elf.cmake)
# gesher: the bionic shim the loaded .so files link against (Phase 6).
include(compat/bionic/bionic.cmake)

include(cmake/aosp/third_party.cmake)
include(cmake/aosp/system.cmake)
include(cmake/aosp/art.cmake)
include(cmake/aosp/art_runtime.cmake)
# dex2oat, for Gesher's boot image (docs/boot-image.md).
include(cmake/aosp/dex2oat.cmake)
include(cmake/aosp/icu.cmake)
# BoringSSL, for libcore's NativeBN and Conscrypt (docs/network.md).
include(cmake/aosp/boringssl.cmake)
include(cmake/aosp/libcore_native.cmake)
# Conscrypt's libjavacrypto and compat/net: TLS, Windows' trusted roots (docs/network.md).
include(cmake/aosp/conscrypt.cmake)
include(cmake/aosp/binder.cmake)
include(cmake/aosp/servicemanager.cmake)
include(cmake/aosp/framework.cmake)
include(compat/credentials/credentials.cmake)
include(compat/install/install.cmake)
# Framework natives real apps need: SQLite, android.database, animators (docs/e2e.md).
include(cmake/aosp/framework_e2e.cmake)
# gesher: Start menu shortcuts and AppUserModelIDs for installed apps (shell track).
include(cmake/aosp/shell.cmake)
# gesher: the device-state services' Windows side: alarms, clipboard, toasts, power (devsvc track).
include(cmake/aosp/devsvc.cmake)
# gesher: System.loadLibrary of an app's ELF .so in dalvikvm (Phase 6).
include(compat/bionic/jni.cmake)
include(cmake/aosp/googletest.cmake)
include(cmake/aosp/core_libs_tests.cmake)
# ART's own gtests for libartbase and libdexfile (docs/posix.md).
include(cmake/aosp/art_gtests.cmake)
include(cmake/aosp/graphics.cmake)
# gesher: Windows desktop integration (desktop polish track: drag & drop, rich clipboard, notifications).
include(compat/windows/windows.cmake)
# Input (docs/input.md): libinput, the input natives, Win32 messages to Android events.
include(cmake/aosp/input.cmake)
# Media (docs/media.md): the audio engine and the framework's media natives.
include(cmake/aosp/media.cmake)
# Link Windows audio and video APIs when building media components.
target_link_libraries(dalvikvm PRIVATE ole32 mmdevapi)
# Devices (docs/devices.md): location, sensors and cameras over Windows' APIs.
include(compat/devices/devices.cmake)
# Camera (compat/camera): Media Foundation webcam capture and Camera2 delivery
include(compat/camera/camera.cmake)
target_link_libraries(framework_runtime PUBLIC mfplat mfreadwrite mfuuid)
target_link_libraries(dalvikvm PRIVATE mfplat mfreadwrite mfuuid)
# android.webkit.WebView on WebView2 (docs/webview.md): libgesher_webview.so, builtin.
include(cmake/webview.cmake)

# Link Windows desktop integration libraries: ole32, shell32, user32.
target_link_libraries(dalvikvm PRIVATE ole32 shell32 user32)

# Phase 0 probe: Windows primitives ART relies on.
add_executable(platform_probe probes/platform/platform_probe.c)
target_compile_options(platform_probe PRIVATE -Wall -Wextra -Werror)
target_link_libraries(platform_probe PRIVATE synchronization)

# gesher-base's socket layer and fd overrides, run in CI on Windows.
add_executable(socket_probe probes/posix/socket_probe.cc)
target_compile_options(socket_probe PRIVATE -Wall -Wextra -Werror)

# Exact current-source TCP and guarded UDP contracts, isolated CI targets.
add_executable(net_tcp_priority_probe tests/net-tcp-priority/contract.cc tests/net-tcp-priority/native_udp_control.cc)
target_compile_options(net_tcp_priority_probe PRIVATE -Wall -Wextra -Werror)
target_link_options(net_tcp_priority_probe PRIVATE "-Wl,-Map,tcp-priority-link.map")
add_executable(net_udp_guarded_probe tests/native2/net_udp_trunc.cpp)
target_compile_options(net_udp_guarded_probe PRIVATE -Wall -Wextra -Werror)
add_executable(net_udp_guarded_fault_probe tests/native2/net_udp_fault_observer.c)
target_compile_options(net_udp_guarded_fault_probe PRIVATE -Wall -Wextra -Werror)
set_target_properties(net_udp_guarded_fault_probe PROPERTIES LINKER_LANGUAGE CXX)

# gesher-base's mmap layer: placeholder mappings, executable file views
# (stack track, docs/decisions/0036); run in CI on Windows.
add_executable(mman_probe probes/posix/mman_probe.cc)
target_compile_options(mman_probe PRIVATE -Wall -Wextra -Werror)
add_executable(madvise_probe tests/native/madvise_contract.c)
target_compile_definitions(madvise_probe PRIVATE GESHER_MADVISE_MAIN)
target_compile_options(madvise_probe PRIVATE -Wall -Wextra -Werror)
set_target_properties(madvise_probe PROPERTIES LINKER_LANGUAGE CXX)

# eventfd and epoll, for libutils' Looper; also run in CI on Windows.
add_executable(epoll_probe probes/posix/epoll_probe.cc)
target_compile_options(epoll_probe PRIVATE -Wall -Wextra -Werror)

# gesher-base's paths, /proc, /etc/timezone, inotify and process model
# (docs/posix.md); also run in CI on Windows.
add_executable(posix_probe probes/posix/posix_probe.cc)
target_compile_options(posix_probe PRIVATE -Wall -Wextra -Werror)

# Virtual procfs and sysfs contracts (Roadmap N04, Issue #56).
add_executable(procfs_sysfs_contract_test tests/native/procfs_sysfs_contract_test.cc)
target_compile_options(procfs_sysfs_contract_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(procfs_sysfs_contract_test PRIVATE gesher_posix)

# The same metadata contract runs through host POSIX and both guest ABI shims.
add_executable(filesystem_metadata_host_test tests/native/filesystem_metadata_host_test.cc)
target_compile_options(filesystem_metadata_host_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(filesystem_metadata_host_test PRIVATE gesher_posix)

add_executable(xattr_fd_host_test tests/native/xattr_fd_host_test.cc)
target_compile_options(xattr_fd_host_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(xattr_fd_host_test PRIVATE gesher_posix advapi32)

add_executable(sqlite_path_test tests/native/sqlite_path_test.cc)
target_compile_options(sqlite_path_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(sqlite_path_test PRIVATE sqlite)

add_executable(timerfd_windows_test tests/native/timerfd_windows_test.cc)
target_compile_options(timerfd_windows_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(timerfd_windows_test PRIVATE gesher_posix)

# Synthetic clipboard-denial actor; built before the timed Windows fixture.
# The installer lists its production executables explicitly and excludes this.
add_executable(clipboard_foreground tests/windows/clipboard/foreground_helper.cc)
target_compile_options(clipboard_foreground PRIVATE -Wall -Wextra -Werror)
target_link_options(clipboard_foreground PRIVATE -municode)
target_link_libraries(clipboard_foreground PRIVATE user32)
add_executable(file_flags_ofd_test tests/native/file_flags_ofd_test.cc)
target_compile_options(file_flags_ofd_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(file_flags_ofd_test PRIVATE gesher_posix)

add_executable(stdio_ofd_test tests/native/stdio_ofd_test.cc)
target_compile_options(stdio_ofd_test PRIVATE -Wall -Wextra -Werror -fno-builtin)
target_link_libraries(stdio_ofd_test PRIVATE gesher_posix)

add_executable(pipe_kernel_test tests/native/pipe_kernel_test.cc)
target_compile_options(pipe_kernel_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(pipe_kernel_test PRIVATE gesher_posix)

add_executable(revocable_file_test tests/native/revocable_file_test.cc)
target_compile_options(revocable_file_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(revocable_file_test PRIVATE gesher_posix)

add_executable(boottime_resume_windows_test tests/native/boottime_resume_windows_test.cc)
target_compile_options(boottime_resume_windows_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(boottime_resume_windows_test PRIVATE gesher_bionic gesher_elf gesher_posix)

# libutils' Looper over gesher-base's epoll and eventfd, RefBase, String8;
# also run in CI on Windows.
add_executable(libutils_probe probes/system/libutils_probe.cc)
target_compile_options(libutils_probe PRIVATE -Wall -Wextra -Werror)
target_link_libraries(libutils_probe PRIVATE utils)

# Phase 6: can Windows user code use %fs for bionic's TLS (WRFSBASE)?
add_executable(fsbase_probe probes/elf/fsbase_probe.cc)
if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|AMD64")
  target_compile_options(fsbase_probe PRIVATE -Wall -Wextra -Werror -mfsgsbase)
else()
  target_compile_options(fsbase_probe PRIVATE -Wall -Wextra -Werror)
endif()

# ART x86-64 native JIT: low-4GiB executable allocation, SEH unwinding, ABI calling convention bridge
add_executable(jit_windows_probe probes/art/jit_windows_probe.cc compat/art/jit_windows.cc)
target_compile_options(jit_windows_probe PRIVATE -Wall -Wextra -Werror)
target_include_directories(jit_windows_probe PRIVATE compat/art compat/art/include)

# Focused CI fixture; no new production track or generic environment API.
add_executable(font_environment_test EXCLUDE_FROM_ALL tests/native/font_environment_test.cc)
target_link_libraries(font_environment_test PRIVATE gesher_posix)
target_compile_options(font_environment_test PRIVATE -Wall -Wextra -Werror)
target_link_options(font_environment_test PRIVATE
  "-Wl,-Map,${CMAKE_BINARY_DIR}/font_environment_test.map")

# Phase 6: the ELF loader loads an x86-64 Android .so and calls its exports.
add_executable(elf_load_test tests/native/elf_load_test.cc)
target_compile_options(elf_load_test PRIVATE -Wall -Wextra -Werror)
# gesher_media_drm: the production NDK MediaDrm/MediaCrypto entries, for
# media_drm_test.so (they have no dependency beyond the bionic shim).
target_link_libraries(elf_load_test PRIVATE gesher_bionic gesher_elf gesher_media_drm)

# Original dependency graphs exercise the actual loader, including concurrent
# publication and constructor reentry. The failure target redirects only its
# private copy of mprotect; production gesher_elf has no injection mechanism.
add_executable(elf_load_transaction_test tests/native/elf_load_transaction_test.cc)
target_compile_options(elf_load_transaction_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(elf_load_transaction_test PRIVATE gesher_elf)
get_target_property(_elf_transaction_sources gesher_elf SOURCES)
get_target_property(_elf_transaction_includes gesher_elf INCLUDE_DIRECTORIES)
add_library(gesher_elf_transaction_failure STATIC ${_elf_transaction_sources})
target_include_directories(gesher_elf_transaction_failure PUBLIC ${_elf_transaction_includes})
target_compile_options(gesher_elf_transaction_failure PRIVATE -Wall -Wextra -Werror)
target_compile_definitions(gesher_elf_transaction_failure PRIVATE
  mprotect=gesher_elf_test_mprotect)
add_executable(elf_load_transaction_failure_test tests/native/elf_load_transaction_test.cc)
target_compile_options(elf_load_transaction_failure_test PRIVATE -Wall -Wextra -Werror)
target_compile_definitions(elf_load_transaction_failure_test PRIVATE GESHER_ELF_TRANSACTION_FAILURE)
target_link_libraries(elf_load_transaction_failure_test PRIVATE gesher_elf_transaction_failure)

# Compare guest pthread metadata with independently observed Win32 target stacks.
add_executable(pthread_attributes_target_test tests/native/pthread_attributes_target_test.cc)
target_compile_options(pthread_attributes_target_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(pthread_attributes_target_test PRIVATE gesher_bionic gesher_elf)

# ADR 0086: the stand-in libart.so as a packer's shell finds and hooks it
# (tests/native/art_hook_test.so, built with the NDK by native-libs.yml).
add_executable(art_shim_test tests/native/art_shim_test.cc)
target_compile_options(art_shim_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(art_shim_test PRIVATE gesher_bionic gesher_elf)

# Actual Bionic truncate exports, access rights and shared cursor contracts.
add_executable(bionic_ftruncate_test tests/native/bionic_ftruncate_test.cc)
target_compile_options(bionic_ftruncate_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(bionic_ftruncate_test PRIVATE gesher_bionic gesher_elf)

# creat and creat64 through the actual Bionic exports (issue #320).
add_executable(bionic_creat_test tests/native/bionic_creat_test.cc)
target_compile_options(bionic_creat_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(bionic_creat_test PRIVATE gesher_bionic gesher_elf)

# Real Bionic stream locks and wide I/O through the exported FILE APIs.
add_executable(bionic_stdio_contract_test tests/native/bionic_stdio_contract_test.cc)
target_compile_options(bionic_stdio_contract_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(bionic_stdio_contract_test PRIVATE gesher_bionic gesher_elf)

# Raw system calls and code made at run time (ADR 0084), on hand-assembled
# code through the loader's rewriter; no NDK library needed.
add_executable(elf_deferred_code_test tests/native/elf_deferred_code_test.cc)
target_include_directories(elf_deferred_code_test PRIVATE compat/elf)
target_compile_options(elf_deferred_code_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(elf_deferred_code_test PRIVATE gesher_elf)

# Live CRT environment storage after host and guest mutations (exec4).
add_executable(exec4_environment_test tests/exec/environment-host-test.cc)
target_compile_options(exec4_environment_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(exec4_environment_test PRIVATE gesher_bionic gesher_elf)

# All-code-point comparison with the independent pinned ICU4X reference.
add_executable(native3_unicode_test tests/native/native3_unicode_test.cc)
target_compile_options(native3_unicode_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(native3_unicode_test PRIVATE gesher_bionic gesher_elf icuuc)

add_executable(binary128_parsing_test tests/native/binary128_parsing_test.cc)
target_compile_options(binary128_parsing_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(binary128_parsing_test PRIVATE gesher_bionic gesher_elf)
add_executable(binary128_records tests/binary128/backend_records.cc)
target_compile_options(binary128_records PRIVATE -Wall -Wextra -Werror)
target_link_libraries(binary128_records PRIVATE gesher_bionic_binary128)
add_executable(binary128_concurrency tests/binary128/concurrency_contracts.cc)
target_compile_options(binary128_concurrency PRIVATE -Wall -Wextra -Werror)
target_link_libraries(binary128_concurrency PRIVATE gesher_bionic_binary128)

add_executable(clock_domains_windows_test tests/native/clock_domains_windows_test.cc)
target_compile_options(clock_domains_windows_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(clock_domains_windows_test PRIVATE gesher_posix)

add_executable(native3_cpu_clock_test tests/native/native3_cpu_clock_test.cc)
target_compile_options(native3_cpu_clock_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(native3_cpu_clock_test PRIVATE artbase gesher_posix)

add_executable(host_pthread_authority_test tests/native/host_pthread_authority_test.cc)
target_link_libraries(host_pthread_authority_test PRIVATE gesher_posix)
target_compile_options(host_pthread_authority_test PRIVATE -Wall -Wextra -Werror)
option(GESHER_HOST_CPU_CLOCK_TEST_FAULTS "Build isolated host clock fault fixture role" OFF)
if(GESHER_HOST_CPU_CLOCK_TEST_FAULTS)
  target_compile_definitions(gesher_posix PRIVATE GESHER_HOST_CPU_CLOCK_TEST_FAULTS=1)
  add_executable(host_pthread_authority_fault_test tests/native/host_pthread_authority_fault_test.cc)
  target_link_libraries(host_pthread_authority_fault_test PRIVATE gesher_posix)
  target_compile_options(host_pthread_authority_fault_test PRIVATE -Wall -Wextra -Werror)
endif()

add_executable(pthread_cpu_clock_target_test tests/native/pthread_cpu_clock_target_test.cc)
target_compile_options(pthread_cpu_clock_target_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(pthread_cpu_clock_target_test PRIVATE gesher_bionic gesher_elf)

# The bionic shim's key and thread_local destructors on threads it did not
# start, in the rounds of ART's winpthreads key (tracks/40-native-libs.ps1).
add_executable(bionic_key_exit_test tests/native/bionic_key_exit_test.cc)
target_compile_options(bionic_key_exit_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(bionic_key_exit_test PRIVATE gesher_bionic gesher_elf)

add_executable(traversal_test tests/native/traversal_test.cc)
target_compile_options(traversal_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(traversal_test PRIVATE gesher_posix)

add_executable(futex_test tests/native/futex_test.cc)
target_compile_options(futex_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(futex_test PRIVATE gesher_posix)

add_executable(realtime_signals_test tests/native/realtime_signals_test.cc)
target_compile_options(realtime_signals_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(realtime_signals_test PRIVATE gesher_posix)

add_executable(realtime_signal_contract_test tests/exec/realtime_signals_contract.c)
target_compile_options(realtime_signal_contract_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(realtime_signal_contract_test PRIVATE gesher_posix)

add_library(futex_test_module SHARED tests/native/futex_test_module.cc)
set_target_properties(futex_test_module PROPERTIES PREFIX "")
target_compile_options(futex_test_module PRIVATE -Wall -Wextra -Werror)
target_link_libraries(futex_test_module PRIVATE gesher_posix)

add_executable(futex_bridge_test tests/native/futex_bridge_test.cc)
target_compile_options(futex_bridge_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(futex_bridge_test PRIVATE gesher_bionic gesher_elf futex_test_module)

add_executable(futex_owner_link_test tests/native/futex_owner_link_test.cc)
target_compile_options(futex_owner_link_test PRIVATE -Wall -Wextra -Werror)
# Replace the inherited directory link_libraries list: the import library must
# precede the POSIX archive, or the executable's direct reference hides the bug.
set_target_properties(futex_owner_link_test PROPERTIES
  LINK_LIBRARIES "futex_test_module;gesher_posix")

# The same source calls actual Linux fcntl in the independent reference job.
# This Windows target links the actual common POSIX fd/stdio/lock code.
add_executable(native3_lock_command_worker EXCLUDE_FROM_ALL tests/native3-locks/command_worker.cc)
target_compile_options(native3_lock_command_worker PRIVATE -Wall -Wextra -Werror)
target_link_libraries(native3_lock_command_worker PRIVATE gesher_posix)

add_executable(native3_lock_duplicate_test EXCLUDE_FROM_ALL tests/native3-locks/duplicate_windows_test.cc)
target_compile_options(native3_lock_duplicate_test PRIVATE -Wall -Wextra -Werror
  "SHELL:-idirafter ${AOSP_DIR}/bionic/libc/kernel/uapi")
target_link_libraries(native3_lock_duplicate_test PRIVATE gesher_posix)

# Internal finite wait checkpoint: public blocking commands remain unsupported.
add_executable(native3_lock_blocking_worker EXCLUDE_FROM_ALL tests/native3-locks/blocking_worker.cc)
# Compile the real transaction/wait sources into this executable only. Static
# archive counterparts are not extracted; production gesher_posix has no hooks.
target_sources(native3_lock_blocking_worker PRIVATE
  compat/posix/src/record_lock_registry.cc compat/posix/src/record_lock_wait.cc)
target_compile_definitions(native3_lock_blocking_worker PRIVATE GESHER_RECORD_WAIT_TEST=1)
target_compile_options(native3_lock_blocking_worker PRIVATE -Wall -Wextra -Werror)
target_link_libraries(native3_lock_blocking_worker PRIVATE gesher_posix)

# Phase 7: the ELF loader loads an arm64-v8a Android .so and the arm64
# translator (gesher_arm64.dll) runs it (docs/arm64.md, ADR 0047).
add_executable(arm64_elf_test tests/native/arm64_elf_test.cc)
target_compile_options(arm64_elf_test PRIVATE -Wall -Wextra -Werror)
target_link_libraries(arm64_elf_test PRIVATE gesher_bionic gesher_elf)

# Ordinary public numeric API qualification through the x64 translator.
if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|AMD64")
  add_executable(arm64_numeric_return_host EXCLUDE_FROM_ALL tests/native/arm64_numeric_return_host.cc)
  target_compile_options(arm64_numeric_return_host PRIVATE -Wall -Wextra -Werror)
  target_link_libraries(arm64_numeric_return_host PRIVATE gesher_bionic gesher_elf)
  add_executable(arm64_numeric_fenv_test EXCLUDE_FROM_ALL tests/native/arm64_numeric_fenv_test.cc)
  target_compile_options(arm64_numeric_fenv_test PRIVATE -Wall -Wextra -Werror -frounding-math)
endif()

# BEGIN FILE_MREMAP_SOURCE_QUALIFICATION
# Explicit CI qualification targets; no fixture is part of the default product.
add_subdirectory(tests/file_mremap EXCLUDE_FROM_ALL)
# END FILE_MREMAP_SOURCE_QUALIFICATION

# BEGIN FONT_RESOURCE_CHARACTERIZATION_ADDITIVE
add_executable(font_environment_resource_characterization EXCLUDE_FROM_ALL
  tests/native/font_environment_resource_characterization.cc)
target_link_libraries(font_environment_resource_characterization PRIVATE gesher_posix)
target_compile_options(font_environment_resource_characterization PRIVATE -Wall -Wextra -Werror)
target_link_options(font_environment_resource_characterization PRIVATE
  "-Wl,-Map,${CMAKE_BINARY_DIR}/font_environment_resource_characterization.map")
# END FONT_RESOURCE_CHARACTERIZATION_ADDITIVE
