#!/usr/bin/env python3
"""Package immutable #427 fixture inputs, generated sources and actual receipts."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ws=Path(__file__).resolve().parent;repo=ws/'gesher-native-pr427-sqlite'
parent='b1962c3be9f484da7b1272e2c4f909c5df68a8e6'
source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip()
sha=lambda x:hashlib.sha256(x).hexdigest()
members={}
def add(name,data):
 assert name not in members
 members[name]=data
proof=json.loads((ws/'native-pr427-sqlite-proof.json').read_text())
for path in proof['inputs']:
 add('inputs/parent/'+path,subprocess.check_output(['git','show',parent+':'+path],cwd=repo))
for path in ['tools/test_sqlite_paths.py','tests/native/sqlite_path_namespace_test.cc']:
 add('inputs/current/'+path,(repo/path).read_bytes())
for name in ['sqlite3.c','sqlite3.h']:
 add('supplier/'+name,(ws/'native-pr427-sqlite-pinned'/name).read_bytes())
for label in ['baseline','current']:
 base=ws/('native-pr427-sqlite-'+label)
 add('replays/'+label+'/receipt.json',(base/'receipt.json').read_bytes())
 add('replays/'+label+'/run.log',(ws/(base.name+'.log')).read_bytes())
 add('replays/'+label+'/test_sqlite_paths.py',(base/'test_sqlite_paths.py').read_bytes())
 for name in ['original-negative.stdout','original-negative.stderr','original-negative-replay.json']:
  path=base/name
  if path.exists():add('replays/'+label+'/'+name,path.read_bytes())
 for name in ['sqlite_path_namespace.h','sqlite_path.cc','reserved_names.h','unc_paths.h','sqlite_path_host.h']:
  path=base/'generated'/name
  if path.exists():add('replays/'+label+'/generated/'+name,path.read_bytes())
 old=(base/'generated/dist/sqlite-autoconf-3500400/sqlite3.c').read_bytes()
 if label=='baseline':add('supplier/sqlite3-patched.c',old)
 else:assert old==members['supplier/sqlite3-patched.c']
control_root=ws/'native-pr427-sqlite-controls'
for path in sorted(control_root.rglob('*')):
 if path.is_file() and path.name!='namespace-boundary':
  add('controls/'+str(path.relative_to(control_root)),path.read_bytes())
for name in ['native_pr427_sqlite_replay.py','native_pr427_sqlite_controls.py','native_pr427_sqlite_proof.py',
             'native_pr427_sqlite_package.py']:
 add('scripts/'+name,(ws/name).read_bytes())
for name in ['native-pr427-sqlite-proof.json','native-pr427-sqlite-download-tests.log']:
 add('proof/'+name,(ws/name).read_bytes())
for path in sorted((ws/'media-review-pr427-namespace').iterdir()):
 if path.is_file() and path.name!='namespace-boundary':
  add('independent/'+path.name,path.read_bytes())
add('scripts/media_review_pr427_namespace.py',(ws/'media_review_pr427_namespace.py').read_bytes())
add('failure/original-artifact-preflight.log',(ws/'root-new-ci-2326-138082634530.log').read_bytes())
manifest={'schema':1,'source_head':source_head,'source_tree':source_tree,'parent':parent,
 'members':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())},
 'exclusions':'Compiled executables and SQLite object files remain identified by SHA256 in raw replay/control receipts; exact generated inputs, original/patched pinned supplier and commands are included.'}
add('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode())
archive=repo/'docs/research/evidence/sqlite-drop-fixture-2026-11-23.tar.gz';archive.parent.mkdir(parents=True,exist_ok=True)
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as tar:
 for name,data in sorted(members.items()):
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
  tar.addfile(item,io.BytesIO(data))
archive.write_bytes(gzip.compress(raw.getvalue(),mtime=0))
report={'schema':1,'title':'Restore the unattached drop backend boundary in the #427 SQLite host fixture',
 'parent':parent,'source_head':source_head,'source_tree':source_tree,
 'failed_run':45285898943,'failed_job':138082634530,'failed_generated_merge':'d6364d131e5586e3c3b0cf309cbed7621c1fb885',
 'changed_source_paths':['tools/test_sqlite_paths.py','tests/native/sqlite_path_namespace_test.cc'],
 'input_proof':proof,
 'validation':{'namespace_checks':13,'actual_sqlite_checks':259,'old_callback_checks':132,'old_callback_expected_failures':35,
  'old_callback_required_negative_predicates':4,'compiled_boundary_mutants':6,'prefix_extraction_negatives':2,'download_tests':9},
 'independent_namespace_review':{'checks':20,'namespace_checks':13,'receipt':'independent/proof.json'},
 'archive':{'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
  'regular_members':len(members),'manifest_members':len(manifest['members'])},
 'limits':proof['limits']}
(repo/'docs/research/sqlite-drop-fixture-2026-11-23.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'source_head':source_head,'source_tree':source_tree,'archive':report['archive']},indent=2))
