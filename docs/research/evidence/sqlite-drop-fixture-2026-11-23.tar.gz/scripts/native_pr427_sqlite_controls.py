#!/usr/bin/env python3
"""Compile exact generated SQLite namespace boundaries and isolated negatives."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--sanitize', action='store_true')
a = p.parse_args()
repo, out = a.repo.resolve(), a.output.resolve()
out.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location('sqlite_paths', repo / 'tools/test_sqlite_paths.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
source = m.namespace_fixture()
test = (repo / 'tests/native/sqlite_path_namespace_test.cc').read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()
def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)
variants = [
    ('current', source, None),
    ('attached-without-channel', replace_once(source, 'static bool Enabled() { return false; }',
        'static bool Enabled() { return true; }'), 'portable fixture has no attached drop channel'),
    ('wrong-prefix', replace_once(source, 'inline constexpr char kAndroidPrefix[] = "/mnt/gesher/drop/";',
        'inline constexpr char kAndroidPrefix[] = "/mnt/gesher/dropped/";'), 'drop prefix comes from the actual declared namespace'),
    ('omit-backend-admission', replace_once(source, '&& drop_mount::Enabled()', '&& true'),
        'unattached drop spelling retains ordinary lexical mapping'),
    ('omit-reserved-encoding', replace_once(source,
        '  reserved_names::Encode(windows);\n  Lengthen(windows);\n  return PathKind::kFile;',
        '  Lengthen(windows);\n  return PathKind::kFile;'),
        'unattached drop spelling still encodes reserved characters'),
    ('omit-long-path', replace_once(source,
        '  reserved_names::Encode(windows);\n  Lengthen(windows);\n  return PathKind::kFile;',
        '  reserved_names::Encode(windows);\n  return PathKind::kFile;'),
        'unattached drop spelling retains existing long-path handling'),
    ('admit-virtual-device', replace_once(source, 'return errno = special, false;', 'return true;'),
        'allow-broker filename mapping does not admit virtual devices'),
]
flags = ['c++', '-O1', '-g', '-fno-omit-frame-pointer', '-std=c++20', '-Wall', '-Wextra', '-Werror', '-fno-exceptions']
if a.sanitize:
    flags += ['-fsanitize=address,undefined', '-fno-sanitize-recover=all']
rows = []
for label, generated, expected in variants:
    work = out / label; work.mkdir()
    (work / 'sqlite_path_namespace.h').write_text(generated)
    (work / 'sqlite_path_namespace_test.cc').write_bytes(test)
    for name in ('reserved_names.h', 'unc_paths.h'):
        shutil.copyfile(repo / 'compat/posix/include/gesher' / name, work / name)
    exe = work / 'namespace-boundary'
    command = flags + ['-I', str(work), str(work / 'sqlite_path_namespace_test.cc'), '-o', str(exe)]
    compile_result = subprocess.run(command, text=True, capture_output=True, timeout=180)
    (work / 'compile.log').write_text(compile_result.stdout + compile_result.stderr)
    assert compile_result.returncode == 0, (label, compile_result.stderr)
    run = subprocess.run([str(exe)], text=True, capture_output=True, timeout=60)
    (work / 'run.log').write_text(run.stdout + run.stderr)
    assert run.returncode == (1 if expected else 0), (label, run.returncode, run.stdout, run.stderr)
    assert (('FAIL: ' + expected) in run.stderr) if expected else '13 checks, 0 failures' in run.stdout
    rows.append({'case': label, 'command': command, 'compiled': True, 'exit_code': run.returncode,
                 'expected_assertion': expected, 'generated_sha256': sha(generated.encode()),
                 'executable_sha256': sha(exe.read_bytes()), 'run_sha256': sha((run.stdout + run.stderr).encode())})
    print(label + ': PASS', flush=True)
header_path = Path('compat/posix/include/gesher/drop_mount.h')
header = (repo / header_path).read_text()
line = 'inline constexpr char kAndroidPrefix[] = "/mnt/gesher/drop/";'
for label, changed in [('missing-prefix', replace_once(header, line, '')),
                       ('duplicate-prefix', replace_once(header, line, line + '\n' + line))]:
    work = out / label; work.mkdir()
    for path in ['compat/posix/src/path.cc', 'compat/posix/src/internal.h']:
        target = work / path; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(repo / path, target)
    target = work / header_path; target.parent.mkdir(parents=True, exist_ok=True); target.write_text(changed)
    old_root = m.ROOT; m.ROOT = work
    try:
        try:
            m.namespace_fixture()
            raise AssertionError('missing extraction rejection: ' + label)
        except ValueError as error:
            assert str(error) == 'production drop-mount prefix declaration changed'
            rows.append({'case': label, 'expected_error': str(error), 'header_sha256': sha(changed.encode())})
    finally:
        m.ROOT = old_root
    print(label + ': PASS', flush=True)
(out / 'receipts.json').write_text(json.dumps({'sanitize': a.sanitize, 'repo': str(repo),
    'helper_sha256': sha((repo / 'tools/test_sqlite_paths.py').read_bytes()),
    'test_sha256': sha(test), 'cases': rows,
    'scope': 'Exact mapper extraction with an explicitly unattached backend. No Windows authenticated channel, rooted storage, ACL, device, or ART execution.'}, indent=2) + '\n')
