#!/usr/bin/env python3
"""Retain the maintained SQLite runner's actual generated inputs and commands."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback
import types

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--sqlite-source', type=Path, required=True)
p.add_argument('--ref')
p.add_argument('--sanitize', action='store_true')
a = p.parse_args()
repo = a.repo.resolve()
out = a.output.resolve()
out.mkdir(parents=True, exist_ok=False)
helper = repo / 'tools/test_sqlite_paths.py'
source = (subprocess.check_output(['git', 'show', a.ref + ':tools/test_sqlite_paths.py'], cwd=repo)
          if a.ref else helper.read_bytes())
(out / 'test_sqlite_paths.py').write_bytes(source)
module = types.ModuleType('retained_sqlite_runner')
module.__file__ = str(helper)
exec(compile(source, str(out / 'test_sqlite_paths.py'), 'exec'), module.__dict__)
commands = []
original_run = module.run
def run(command, **kwargs):
    row = {'command': [str(v) for v in command], 'cwd': str(kwargs.get('cwd', repo))}
    commands.append(row)
    try:
        result = original_run(command, **kwargs)
        row['exit_code'] = result.returncode
        return result
    except subprocess.CalledProcessError as e:
        row['exit_code'] = e.returncode
        raise
module.run = run
class RetainedDirectory:
    def __init__(self, **kwargs):
        self.path = out / 'generated'
        self.path.mkdir()
    def __enter__(self):
        return str(self.path)
    def __exit__(self, *args):
        return False
original_temporary = module.tempfile.TemporaryDirectory
module.tempfile.TemporaryDirectory = RetainedDirectory
sys.argv = [str(helper), '--sqlite-source', str(a.sqlite_source.resolve()), '--negative-control']
if a.sanitize:
    sys.argv.append('--sanitize')
status = 0
try:
    module.main()
except BaseException:
    status = 1
    traceback.print_exc()
finally:
    module.tempfile.TemporaryDirectory = original_temporary
    sha = lambda b: hashlib.sha256(b).hexdigest()
    files = {str(f.relative_to(out)): {'bytes': f.stat().st_size, 'sha256': sha(f.read_bytes())}
             for f in sorted(out.rglob('*')) if f.is_file()}
    receipt = {'repo': str(repo), 'source_ref': a.ref, 'sanitize': a.sanitize,
               'helper_sha256': sha(source), 'commands': commands, 'exit_code': status,
               'files': files,
               'boundary': 'Only TemporaryDirectory cleanup is replaced to retain generated inputs; maintained extraction, compiler flags, timeout, actual SQLite IO and original-negative predicates are unchanged.'}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
sys.exit(status)
