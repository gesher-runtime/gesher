#!/usr/bin/env python3
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess
ROOT=Path(__file__).resolve().parent; REPO=ROOT/'gesher-native-pr427-sqlite'; OUT=ROOT/'media-review-pr427-namespace';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper=REPO/'tools/test_sqlite_paths.py'; fixture=REPO/'tests/native/sqlite_path_namespace_test.cc'
assert sha(helper)=='dfdd91bba9c5dd57ee7ff3a71b07b4226fa97c666f7dddc0cffb8f4444cfd7af'
assert sha(fixture)=='339a35d329cace9c59a4f9de62897bf42b0153ef1ab2e7950341d8e550554685'
spec=importlib.util.spec_from_file_location('sqlite_fixture',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
generated=m.namespace_fixture();(OUT/'sqlite_path_namespace.h').write_text(generated)
for n in ['reserved_names.h','unc_paths.h']:shutil.copyfile(REPO/'compat/posix/include/gesher'/n,OUT/n)
shutil.copyfile(fixture,OUT/fixture.name)
# Every actual mapper function remains a verbatim independent extraction of the author source.
source=(REPO/'compat/posix/src/path.cc').read_text(); signatures=['bool IsDriveLetter(','std::string_view NextPart(','PathKind VirtualKind(','bool DrivePath(','void Lengthen(','PathKind MapPath(','bool DiskPath(']
checks=2
for name in signatures:
 exact=m.function(source,name);assert generated.count(exact)==1;checks+=1
assert 'static bool Enabled() { return false; }' in generated;checks+=1
header=(REPO/'compat/posix/include/gesher/drop_mount.h').read_text();prefix=[l for l in header.splitlines() if l.startswith('inline constexpr char kAndroidPrefix[] = ')];assert len(prefix)==1 and generated.count(prefix[0])==1;checks+=1
for p in ['compat/posix/src/path.cc','compat/posix/src/sqlite_path.cc','compat/posix/src/drop_mount.cc','compat/posix/include/gesher/drop_mount.h','tests/native/sqlite_path_test.cc','tests/native/sqlite_path_host.h.in','patches/external/sqlite/0001-win32-guest-paths.patch','.github/workflows/ci.yml']:
 assert (REPO/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p],cwd=REPO);checks+=1
cmd=['c++','-std=c++20','-O1','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-fno-exceptions','-fsanitize=address,undefined','-fno-sanitize-recover=all','-I',str(OUT),str(OUT/fixture.name),'-o',str(OUT/'namespace-boundary')]
b=subprocess.run(cmd,capture_output=True,text=True);(OUT/'compile.log').write_text(b.stdout+b.stderr);assert b.returncode==0
r=subprocess.run([str(OUT/'namespace-boundary')],env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'},capture_output=True,text=True);(OUT/'run.log').write_text(r.stdout+r.stderr);assert r.returncode==0 and '13 checks, 0 failures' in r.stdout;checks+=1
receipt={'checks':checks,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),'input_hashes':{str(p.relative_to(REPO)):sha(p) for p in [helper,fixture,REPO/'compat/posix/src/path.cc',REPO/'compat/posix/include/gesher/drop_mount.h']},'generated_sha256':sha(OUT/'sqlite_path_namespace.h'),'compile_command':cmd,'exit_code':r.returncode,'stdout':r.stdout,'binary_sha256':sha(OUT/'namespace-boundary'),'scope':'Scope/source and independent exact-mapper ASan/UBSan boundary replay only. Unattached Enabled=false state is explicit; no authenticated drop channel, broker grants, Windows ACL/Win32 VFS/ART execution, or whole-author-PR approval. The native lane owns the full pinned SQLite 259-check/old-callback negative and six mutant replays.'}
(OUT/'proof.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
