#!/usr/bin/env python3
"""Source/actual-entry proof for the narrow #427 portable fixture repair."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--workspace',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();repo=a.repo.resolve();ws=a.workspace.resolve();checks=0
parent='b1962c3be9f484da7b1272e2c4f909c5df68a8e6'
failed='d6364d131e5586e3c3b0cf309cbed7621c1fb885'
sha=lambda x:hashlib.sha256(x).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
paths=['tools/test_sqlite_paths.py','tests/native/sqlite_path_test.cc',
 'tests/native/sqlite_path_host.h.in','compat/posix/src/sqlite_path.cc',
 'compat/posix/src/path.cc','compat/posix/src/internal.h',
 'compat/posix/include/gesher/drop_mount.h','compat/posix/src/drop_mount.cc',
 'compat/posix/include/gesher/reserved_names.h','compat/posix/include/gesher/unc_paths.h',
 'patches/external/sqlite/0001-win32-guest-paths.patch']
inputs={}
for path in paths:
 old=git('show',parent+':'+path);bad=git('show',failed+':'+path);current=(repo/path).read_bytes()
 check(old==bad,'failed merge has the actual author input '+path)
 if path!='tools/test_sqlite_paths.py':check(current==old,'unchanged input '+path)
 inputs[path]={'parent_sha256':sha(old),'failed_merge_sha256':sha(bad),'current_sha256':sha(current)}
for path in ['.github/workflows/ci.yml','CMakeLists.txt','tools/net-tcp-priority/test-selected-policy.py',
 'tools/net-tcp-priority/qualified/ofd-stream-source.json','AGENTS.md','CONTRIBUTING.md']:
 old=git('show',parent+':'+path);current=(repo/path).read_bytes()
 check(old==current,'unchanged gate/instruction '+path);inputs[path]={'parent_sha256':sha(old),'current_sha256':sha(current)}
changed=git('diff','--name-only',parent).decode().splitlines()
check(set(changed)<= {'tools/test_sqlite_paths.py','tests/native/sqlite_path_namespace_test.cc'} or
      all(x in {'tools/test_sqlite_paths.py','tests/native/sqlite_path_namespace_test.cc'} or x.startswith('docs/research/') for x in changed),
      'only declared fixture/evidence paths changed')
baseline=json.loads((ws/'native-pr427-sqlite-baseline/receipt.json').read_text())
current=json.loads((ws/'native-pr427-sqlite-current/receipt.json').read_text())
check(baseline['exit_code']==1 and current['exit_code']==0,'actual old/new outcomes')
check(current['sanitize'] and baseline['sanitize'],'both actual entries use sanitizers')
check(baseline['helper_sha256']==inputs['tools/test_sqlite_paths.py']['parent_sha256'],'baseline compiled exact old helper')
check(current['helper_sha256']==inputs['tools/test_sqlite_paths.py']['current_sha256'],'candidate compiled exact new helper')
for prefix,receipt in [('native-pr427-sqlite-baseline',baseline),('native-pr427-sqlite-current',current)]:
 for path,value in receipt['files'].items():
  data=(ws/prefix/path).read_bytes();check(len(data)==value['bytes'] and sha(data)==value['sha256'],'actual retained generated file '+prefix+'/'+path)
old_ns=(ws/'native-pr427-sqlite-baseline/generated/sqlite_path_namespace.h').read_text()
new_ns=(ws/'native-pr427-sqlite-current/generated/sqlite_path_namespace.h').read_text()
addition='''namespace drop_mount {
inline constexpr char kAndroidPrefix[] = "/mnt/gesher/drop/";
// No authenticated Windows Channel::Attach runs in this portable fixture.
// Keep the same unavailable backend as a process with no attached channel.
static bool Enabled() { return false; }
}
'''
check(new_ns.count(addition)==1 and new_ns.replace(addition,'')==old_ns,'complete original namespace reconstructed exactly')
spec=importlib.util.spec_from_file_location('sqlite_paths',repo/'tools/test_sqlite_paths.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
check(m.namespace_fixture()==new_ns,'current generator exactly replays measured namespace')
source=(repo/'compat/posix/src/path.cc').read_text()
for signature in ['bool IsDriveLetter(','std::string_view NextPart(','PathKind VirtualKind(',
                  'bool DrivePath(','void Lengthen(','PathKind MapPath(','bool DiskPath(']:
 body=m.function(source,signature);check(new_ns.count(body)==1 and old_ns.count(body)==1,'actual unchanged function '+signature)
drop=(repo/'compat/posix/src/drop_mount.cc').read_text()
check('std::atomic<bool> enabled{false};' in drop,'actual unattached process starts unavailable')
check(m.function(drop,'bool Enabled() {')=='bool Enabled() { return Global().enabled.load(std::memory_order_acquire); }\n','actual availability predicate identified')
check(drop.count('enabled.store(true, std::memory_order_release)')==1,'only attachment publishes availability')
check(drop.index('reply.magic != wire::kMagic || reply.status != 0 || reply.handle) return {};')<
      drop.index('Global().enabled.store(true, std::memory_order_release);'),'actual attachment validates reply before availability')
old_log=(ws/'native-pr427-sqlite-baseline.log').read_text();new_log=(ws/'native-pr427-sqlite-current.log').read_text()
check('drop_mount' in old_log and 'has not been declared' in old_log,'same original compiler failure')
for output in ['sqlite-namespace-boundary: 13 checks, 0 failures','sqlite-paths: 259 checks, 0 failures',
 'sqlite-paths: 132 checks, 35 failures','Unpatched callback compiled and failed guest-open, ATTACH, VACUUM and bounded-output gates as expected.']:
 check(output in new_log,'actual maintained output '+output)
controls=json.loads((ws/'native-pr427-sqlite-controls/receipts.json').read_text())
check(controls['helper_sha256']==inputs['tools/test_sqlite_paths.py']['current_sha256'],'control helper identity')
check(controls['test_sha256']==sha((repo/'tests/native/sqlite_path_namespace_test.cc').read_bytes()),'control caller identity')
check(len(controls['cases'])==9,'current plus six compiled mutants and two extraction negatives')
for row in controls['cases']:
 if 'compiled' in row:
  check(row['compiled'] and row['exit_code']==(0 if row['case']=='current' else 1),'qualified compiled outcome '+row['case'])
  work=ws/'native-pr427-sqlite-controls'/row['case']
  check(sha((work/'run.log').read_bytes())==row['run_sha256'],'control log identity '+row['case'])
  if row['expected_assertion']:check('FAIL: '+row['expected_assertion'] in (work/'run.log').read_text(),'precise assertion '+row['case'])
original_test=git('show',parent+':tests/native/sqlite_path_test.cc')
receipt={'checks':checks,'parent':parent,'failed_merge':failed,'failure_run':45285898943,'failure_job':138082634530,
 'inputs':inputs,'original_sqlite_check_sites':original_test.count(b'Check(')-1,
 'new_namespace_test_sha256':controls['test_sha256'],'generated_namespace_sha256':sha(new_ns.encode()),
 'actual_results':{'old_entry':'same undeclared drop_mount compile failure','current_entry':'13 namespace +259 actual SQLite checks',
  'retained_original_callback':'132 checks/35 failures; all four original negative predicates required',
  'negative_controls':'six compiled assertion-specific mutants and two extraction rejection controls'},
 'limits':['Explicitly unattached drop/rooted-storage backend, not authenticated Windows broker access.',
 'UTF conversion and Windows lexical canonicalization remain declared adapters; actual SQL/pager/journal/WAL/URI/file IO uses pinned SQLite Unix VFS.',
 'The baseline Python traceback was emitted after the current helper was edited, so displayed traceback source snippets can reflect the later working file; its archived code bytes, compiler command, generated TU and actual compiler diagnostic are independently bound above.',
 'No Windows/ART/AppContainer/permission/lifetime result or whole-PR approval is inferred.']}
a.output.write_text(json.dumps(receipt,indent=2)+'\n');print('PR427_SQLITE_PROOF_PASS',checks)
