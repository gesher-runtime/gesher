import hashlib
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/aa09b1a0dc1f')
REPO = ROOT / 'gesher-wide-ascii'
TOOLCHAIN = ROOT / 'toolchains/llvm-mingw-20261006-ucrt-ubuntu-22.04-x86_64/bin'
SOURCE = 'compat/bionic/locale_bionic.cc'
OUT = ROOT / 'wide-ascii-extra-qualification-v2'
OUT.mkdir(exist_ok=False)
baseline = subprocess.check_output(['git', 'show', '73bf018b8c02228ac1e5ad4ce4656296674b07ed:' + SOURCE], cwd=REPO, text=True)
candidate = (REPO / SOURCE).read_text()
rows = []
for variant, source in [('baseline', baseline), ('candidate', candidate)]:
    path = OUT / (variant + '.cc')
    path.write_text(source)
    for target in ['x86_64', 'aarch64']:
        label = variant + '-' + target
        command = [str(TOOLCHAIN / (target + '-w64-mingw32-clang++')), '-std=c++20', '-O2', '-g', '-Wall', '-Wextra', '-Werror', '-fstack-usage', '-MMD', '-I', 'compat/bionic', '-I', 'compat/bionic/include', '-I', 'compat/arm64/include', '-c', str(path), '-o', str(OUT / (label + '.o'))]
        r = subprocess.run(command, cwd=REPO, text=True, capture_output=True, timeout=120)
        (OUT / (label + '.stdout')).write_text(r.stdout)
        (OUT / (label + '.stderr')).write_text(r.stderr)
        rows.append({'label': label, 'command': command, 'exit': r.returncode})
        (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
        assert r.returncode == 0, r.stderr[-4000:]

start = candidate.index('size_t BIONIC_SYSV Wcsnrtombs(')
end = candidate.index('\nsize_t BIONIC_SYSV Wcsrtombs(', start)
body = candidate[start:end]
controls = [
    ('ascii-boundary', 'if (*w < 0x80)', 'if (*w <= 0x80)'),
    ('ascii-count', '      ++count;', '      count += 0;'),
    ('ascii-source-progress', '      continue;', '      break;'),
    ('pending-state', 'if (!Initial(ps)) return Fail(ps);', 'if (false) return Fail(ps);'),
    ('reserved-state', 'if (*w < 0x80) {', 'if (*w < 0x80) {\n      std::memset(ps, 0, sizeof(*ps));'),
    ('nul-consumption', '*src = nullptr;', '*src = w;'),
    ('measurement-source', 'if (dst != nullptr) *src = w;', '*src = w;'),
    ('encoder-asymmetry', 'size_t r = Encode(*w, buf);', 'size_t r = *w > 0x10ffff ? kInvalid : Encode(*w, buf);'),
    ('partial-sequence', 'if (r > len - count) break;', 'if (false) break;'),
    ('output-bound', '(dst == nullptr || count < len)', 'true'),
]
for label, old, new in controls:
    # measurement-source deliberately changes both assignments in this one
    # function (invalid path and final bounded path), never other APIs.
    assert body.count(old) == (2 if label == 'measurement-source' else 1), label
    mutant = candidate[:start] + body.replace(old, new) + candidate[end:]
    path = OUT / (label + '.cc')
    path.write_text(mutant)
    work = OUT / label
    command = [sys.executable, 'tools/test_wide_ascii_contracts.py', '--compiler', str(TOOLCHAIN / 'clang++'), '--source-file', str(path), '--out-dir', str(work)]
    r = subprocess.run(command, cwd=REPO, text=True, capture_output=True, timeout=120)
    (OUT / (label + '.stdout')).write_text(r.stdout)
    (OUT / (label + '.stderr')).write_text(r.stderr)
    recorded = json.loads((work / 'commands.json').read_text())
    compiled = [x for x in recorded if x['stdout'] == 'compile.stdout']
    executed = [x for x in recorded if x['stdout'] == 'run.stdout']
    assert len(compiled) == 1 and compiled[0]['exit'] == 0, label
    assert len(executed) == 1 and executed[0]['exit'] != 0, label
    diagnostic = (work / 'run.stderr').read_text()
    assert 'WIDE_ASCII_FAIL ' in diagnostic, (label, diagnostic)
    rows.append({'label': label, 'command': command, 'exit': r.returncode,
                 'compiled': True, 'actual_failure': diagnostic.strip(),
                 'mutant_sha256': hashlib.sha256(mutant.encode()).hexdigest()})
    (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, diagnostic.strip(), flush=True)
(OUT / 'receipt.json').write_text(json.dumps({'observed_utc': datetime.now(timezone.utc).isoformat(), 'rows': rows, 'baseline_sha256': hashlib.sha256(baseline.encode()).hexdigest(), 'candidate_sha256': hashlib.sha256(candidate.encode()).hexdigest(), 'boundary': 'Whole production TU cross-compilation for Windows x64/ARM64, not execution; ten compiled actual-source negative controls on Linux.'}, indent=2) + '\n')
print('WIDE_EXTRA_QUALIFIED', len(rows), flush=True)
