#include <algorithm>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "abi_types.h"
namespace gesher::bionic {
using wchar32 = uint32_t;
using wint32 = uint32_t;
constexpr wint32 kWEOF = 0xffffffffu;
constexpr int kEILSEQ = 84, kEINVAL = 22;
constexpr size_t kInvalid = size_t(-1), kIncomplete = size_t(-2);
struct BionicMbstate {
  uint8_t seq[4];       // pending bytes of a sequence
  uint8_t reserved[4];  // bionic does not read or modify these bytes
};
static_assert(sizeof(BionicMbstate) == 8);

size_t BIONIC_SYSV Wcsnrtombs(char*, const wchar32**, size_t, size_t, BionicMbstate*);
size_t BIONIC_SYSV Wcsrtombs(char*, const wchar32**, size_t, BionicMbstate*);
size_t BIONIC_SYSV Wcstombs(char*, const wchar32*, size_t);
}
