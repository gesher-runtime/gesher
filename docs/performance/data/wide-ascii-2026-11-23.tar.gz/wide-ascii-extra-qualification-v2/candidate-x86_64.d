/workspace/scratch/aa09b1a0dc1f/wide-ascii-extra-qualification-v2/candidate-x86_64.o: \
  /workspace/scratch/aa09b1a0dc1f/wide-ascii-extra-qualification-v2/candidate.cc \
  compat/bionic/binary128_parse.h compat/bionic/shim_internal.h \
  compat/bionic/abi_types.h compat/arm64/include/gesher/arm64_va_list.h \
  compat/arm64/include/gesher/symbol_table.h \
  compat/bionic/unicode_bionic.h \
  compat/bionic/include/gesher/bionic_shim.h
