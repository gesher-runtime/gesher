// Copyright (C) 2026 The Gesher Authors
// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <sys/mman.h>
#include <unistd.h>
#include "abi_types.h"

// The existing reference generator preserves all supplier function bodies.
#define main PinnedWideContractsMain
#include "reference.cpp"
#undef main

namespace gesher::bionic {
namespace {
using wchar32 = uint32_t;
using wint32 = uint32_t;
constexpr wint32 kWEOF = 0xffffffffu;
constexpr int kEILSEQ = 84, kEINVAL = 22;
constexpr size_t kInvalid = size_t(-1), kIncomplete = size_t(-2);
struct BionicMbstate {
  uint8_t seq[4];       // pending bytes of a sequence
  uint8_t reserved[4];  // bionic does not read or modify these bytes
};
static_assert(sizeof(BionicMbstate) == 8);

bool Initial(const BionicMbstate* ps) {
  return ps->seq[0] == 0 && ps->seq[1] == 0 && ps->seq[2] == 0 && ps->seq[3] == 0;
}

void Reset(BionicMbstate* ps) { std::memset(ps->seq, 0, sizeof(ps->seq)); }

int SequenceLength(uint8_t b) {
  if (b < 0x80) return 1;
  if ((b & 0xE0) == 0xC0) return 2;
  if ((b & 0xF0) == 0xE0) return 3;
  if ((b & 0xF8) == 0xF0) return 4;
  return -1;
}

size_t Fail(BionicMbstate* ps, int error = kEILSEQ) {
  Reset(ps);
  errno = error;
  return kInvalid;
}

size_t Mbrtowc(wchar32* pwc, const char* s, size_t n, BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  if (ps->seq[3] != 0) return Fail(ps, kEINVAL);
  if (s == nullptr) {
    s = "";
    n = 1;
    pwc = nullptr;
  }
  if (n == 0) return kIncomplete;
  size_t have = ps->seq[2] != 0 ? 3 : ps->seq[1] != 0 ? 2 : ps->seq[0] != 0 ? 1 : 0;
  size_t used = 0;
  if (have == 0 && static_cast<uint8_t>(*s) < 0x80) {
    if (pwc != nullptr) *pwc = static_cast<uint8_t>(*s);
    return *s == 0 ? 0 : 1;
  }
  int len = SequenceLength(have == 0 ? static_cast<uint8_t>(*s) : ps->seq[0]);
  if (len < 2) return Fail(ps);
  while (have < static_cast<size_t>(len) && used < n) {
    uint8_t b = static_cast<uint8_t>(s[used++]);
    if (have != 0 && (b & 0xC0) != 0x80) return Fail(ps);
    ps->seq[have++] = b;
  }
  if (have < static_cast<size_t>(len)) return kIncomplete;
  wchar32 c = ps->seq[0] & (0x7fu >> len);
  for (int i = 1; i < len; ++i) c = (c << 6) | (ps->seq[i] & 0x3fu);
  static const wchar32 kMin[] = {0, 0, 0x80, 0x800, 0x10000};
  if (c < kMin[len] || c > 0x10FFFF || (c >= 0xD800 && c <= 0xDFFF)) return Fail(ps);
  Reset(ps);
  if (pwc != nullptr) *pwc = c;
  return c == 0 ? 0 : used;
}

// Encodes `c` into buf; the length, or kInvalid.
size_t Encode(wchar32 c, char* buf) {
  if (c < 0x80) {
    buf[0] = static_cast<char>(c);
    return 1;
  }
  if (c < 0x800) {
    buf[0] = static_cast<char>(0xC0 | (c >> 6));
    buf[1] = static_cast<char>(0x80 | (c & 0x3F));
    return 2;
  }
  if (c < 0x10000) {
    buf[0] = static_cast<char>(0xE0 | (c >> 12));
    buf[1] = static_cast<char>(0x80 | ((c >> 6) & 0x3F));
    buf[2] = static_cast<char>(0x80 | (c & 0x3F));
    return 3;
  }
  // Preserve the pinned c32rtomb encoder's asymmetric acceptance: decoding
  // rejects surrogates and values above U+10FFFF; encoding accepts <= 0x1FFFFF.
  if (c <= 0x1FFFFF) {
    buf[0] = static_cast<char>(0xF0 | (c >> 18));
    buf[1] = static_cast<char>(0x80 | ((c >> 12) & 0x3F));
    buf[2] = static_cast<char>(0x80 | ((c >> 6) & 0x3F));
    buf[3] = static_cast<char>(0x80 | (c & 0x3F));
    return 4;
  }
  return kInvalid;
}

size_t BIONIC_SYSV MbrtowcSysv(wchar32* pwc, const char* s, size_t n, BionicMbstate* ps) {
  return Mbrtowc(pwc, s, n, ps);
}

size_t BIONIC_SYSV Mbrlen(const char* s, size_t n, BionicMbstate* ps) {
  static BionicMbstate internal;
  return Mbrtowc(nullptr, s, n, ps != nullptr ? ps : &internal);
}

int BIONIC_SYSV Mbtowc(wchar32* pwc, const char* s, size_t n) {
  static BionicMbstate st{};
  if (s == nullptr) {
    std::memset(&st, 0, sizeof(st));
    return 0;
  }
  size_t r = Mbrtowc(pwc, s, n, &st);
  if (r == kInvalid || r == kIncomplete) {
    errno = kEILSEQ;
    return -1;
  }
  return static_cast<int>(r);
}

size_t BIONIC_SYSV Wcrtomb(char* s, wchar32 wc, BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  if (s == nullptr || wc == 0) {
    if (s != nullptr) *s = 0;
    Reset(ps);
    return 1;
  }
  if (!Initial(ps)) return Fail(ps);
  size_t r = Encode(wc, s);
  if (r == kInvalid) errno = kEILSEQ;
  return r;
}

size_t BIONIC_SYSV Mbrtoc32(wchar32* pc, const char* s, size_t n, BionicMbstate* ps) {
  static BionicMbstate internal;
  return Mbrtowc(pc, s, n, ps != nullptr ? ps : &internal);
}

size_t BIONIC_SYSV Mbrtoc16(uint16_t* pc, const char* s, size_t n, BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  uint16_t ignored;
  if (pc == nullptr) pc = &ignored;
  if (ps->seq[3] != 0) {
    *pc = static_cast<uint16_t>((ps->seq[1] << 8) | ps->seq[0]);
    Reset(ps);
    return static_cast<size_t>(-3);
  }
  wchar32 c;
  size_t result = Mbrtowc(&c, s, n, ps);
  if (result == kInvalid || result == kIncomplete) return result;
  // The pinned implementation returns zero without writing pc16 for NUL.
  if (result == 0) return 0;
  if (c < 0x10000) {
    *pc = static_cast<uint16_t>(c);
  } else {
    c -= 0x10000;
    uint16_t trail = static_cast<uint16_t>((c & 0x3ff) | 0xdc00);
    ps->seq[0] = static_cast<uint8_t>(trail);
    ps->seq[1] = static_cast<uint8_t>(trail >> 8);
    ps->seq[3] = static_cast<uint8_t>(result);
    *pc = static_cast<uint16_t>((c >> 10) | 0xd800);
  }
  return result;
}

size_t BIONIC_SYSV C32rtomb(char* s, wchar32 c, BionicMbstate* ps) {
  static BionicMbstate internal;
  return Wcrtomb(s, c, ps != nullptr ? ps : &internal);
}

size_t BIONIC_SYSV C16rtomb(char* s, uint16_t c, BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  bool low = c >= 0xdc00 && c < 0xe000;
  if (Initial(ps)) {
    if (c >= 0xd800 && c < 0xdc00) {
      // Match bionic's byte representation, including its U+D800 quirk:
      // its zero payload leaves the state initial, so the next low fails.
      wchar32 payload = (c & 0x3ffu) << 10;
      ps->seq[2] = static_cast<uint8_t>(payload >> 8);
      ps->seq[3] = static_cast<uint8_t>(payload >> 16);
      return 0;
    }
    if (low) return Fail(ps, kEINVAL);
    return Wcrtomb(s, c, ps);
  }
  if (!low) return Fail(ps, kEINVAL);
  wchar32 scalar = ((ps->seq[3] << 16) | (ps->seq[2] << 8) | (c & 0x3ffu)) + 0x10000;
  size_t result = Wcrtomb(s, scalar, nullptr);
  Reset(ps);
  return result;
}

int BIONIC_SYSV Mbsinit(const BionicMbstate* ps) { return ps == nullptr || Initial(ps); }

wint32 BIONIC_SYSV Btowc(int c) {
  return c != EOF && static_cast<unsigned>(c) < 0x80 ? static_cast<wint32>(c) : kWEOF;
}

int BIONIC_SYSV Wctob(wint32 c) { return c < 0x80 ? static_cast<int>(c) : EOF; }

size_t BIONIC_SYSV Mbsnrtowcs(wchar32* dst, const char** src, size_t nms, size_t len,
                              BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  const char* s = *src;
  // bionic checks pending/ASCII before considering the output bound.
  if (nms > 0 && (ps->seq[0] != 0 || ps->seq[1] != 0 || ps->seq[2] != 0) &&
      static_cast<uint8_t>(*s) < 0x80) return Fail(ps);
  size_t count = 0;
  while (dst == nullptr || count < len) {
    if (nms == 0) break;
    wchar32 c;
    size_t r;
    if (static_cast<uint8_t>(*s) < 0x80) {
      c = static_cast<uint8_t>(*s);
      r = c == 0 ? 0 : 1;
    } else {
      r = Mbrtowc(&c, s, nms, ps);
    }
    if (r == kInvalid) {
      if (dst != nullptr) *src = s;
      return Fail(ps);
    }
    if (r == kIncomplete) {
      if (dst != nullptr) *src = s + nms;
      return Fail(ps);
    }
    if (r == 0) {
      if (dst != nullptr) {
        dst[count] = 0;
        *src = nullptr;
      }
      Reset(ps);
      return count;
    }
    if (dst != nullptr) dst[count] = c;
    s += r;
    nms -= r;
    ++count;
  }
  if (dst != nullptr) *src = s;
  Reset(ps);
  return count;
}

size_t BIONIC_SYSV Mbsrtowcs(wchar32* dst, const char** src, size_t len, BionicMbstate* ps) {
  return Mbsnrtowcs(dst, src, SIZE_MAX, len, ps);
}

size_t BIONIC_SYSV Wcsnrtombs(char* dst, const wchar32** src, size_t nwc, size_t len,
                              BionicMbstate* ps) {
  static BionicMbstate internal;
  if (ps == nullptr) ps = &internal;
  if (!Initial(ps)) return Fail(ps);
  const wchar32* w = *src;
  size_t count = 0;
  char buf[4];
  for (; nwc > 0 && (dst == nullptr || count < len); ++w, --nwc) {
    if (*w == 0) {
      if (dst != nullptr) {
        if (count < len) dst[count] = '\0';
        *src = w;
      }
      return count;
    }
    // The loop already guarantees one output byte. Keep ASCII on the
    // direct path instead of copying it through the multibyte buffer.
    if (*w < 0x80) {
      if (dst != nullptr) dst[count] = static_cast<char>(*w);
      ++count;
      continue;
    }
    size_t r = Encode(*w, buf);
    if (r == kInvalid) {
      if (dst != nullptr) *src = w;
      errno = kEILSEQ;
      return kInvalid;
    }
    if (dst != nullptr) {
      if (r > len - count) break;
      std::memcpy(dst + count, buf, r);
    }
    count += r;
  }
  if (dst != nullptr) *src = w;
  return count;
}

size_t BIONIC_SYSV Wcsrtombs(char* dst, const wchar32** src, size_t len, BionicMbstate* ps) {
  return Wcsnrtombs(dst, src, SIZE_MAX, len, ps);
}

size_t BIONIC_SYSV Mbstowcs(wchar32* dst, const char* src, size_t len) {
  BionicMbstate state{};
  return Mbsrtowcs(dst, &src, len, &state);
}

size_t BIONIC_SYSV Wcstombs(char* dst, const wchar32* src, size_t len) {
  BionicMbstate state{};
  return Wcsrtombs(dst, &src, len, &state);
}

int BIONIC_SYSV Wctomb(char* dst, wchar32 c) {
  static BionicMbstate state{};
  if (dst == nullptr) {
    std::memset(&state, 0, sizeof(state));
    return 0;
  }
  return static_cast<int>(Wcrtomb(dst, c, &state));
}

int BIONIC_SYSV Mblen(const char* src, size_t len) {
  BionicMbstate state{};
  // The pinned mblen returns the mbrlen result as int, including -2.
  return static_cast<int>(Mbrlen(src, len, &state));
}


}  // namespace
}  // namespace gesher::bionic

namespace {
uint64_t checks = 0;
void Check(bool ok, const char* message) {
  ++checks;
  if (!ok) { std::fprintf(stderr, "WIDE_ASCII_FAIL %s check=%llu\n", message,
                         static_cast<unsigned long long>(checks)); std::exit(1); }
}
struct Pages {
  size_t page = static_cast<size_t>(sysconf(_SC_PAGESIZE));
  unsigned char* base = static_cast<unsigned char*>(
      mmap(nullptr, page * 3, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0));
  Pages() {
    Check(base != MAP_FAILED, "allocate real guard pages");
    Check(mprotect(base + page, page, PROT_READ | PROT_WRITE) == 0, "enable middle page");
  }
  ~Pages() { Check(munmap(base, page * 3) == 0, "release guard pages"); }
  unsigned char* end() { return base + page * 2; }
};

void Compare(const std::vector<uint32_t>& input, size_t limit, size_t cap,
             bool measure, unsigned pending = 0) {
  namespace g = gesher::bionic;
  std::vector<wchar_t> reference_input(input.begin(), input.end());
  std::vector<char> actual(cap + 4, '\x55'), expected(cap + 4, '\x55');
  g::BionicMbstate state{};
  pinned::mbstate_t reference_state{};
  auto* raw = reinterpret_cast<unsigned char*>(&state);
  auto* reference_raw = reinterpret_cast<unsigned char*>(&reference_state);
  for (size_t i = 0; i < 8; ++i) raw[i] = reference_raw[i] = i < 4 ? 0 : 0xa5;
  if (pending) raw[pending - 1] = reference_raw[pending - 1] = 0xc2;
  const uint32_t* cursor = input.data();
  const wchar_t* reference_cursor = reference_input.data();
  errno = 17;
  size_t result = g::Wcsnrtombs(measure ? nullptr : actual.data() + 2, &cursor, limit, cap, &state);
  int error = errno;
  errno = 17;
  size_t reference_result = pinned::wcsnrtombs(measure ? nullptr : expected.data() + 2,
                                              &reference_cursor, limit, cap, &reference_state);
  Check(result == reference_result && error == errno, "pinned result and errno");
  Check((cursor == nullptr) == (reference_cursor == nullptr), "pinned NUL consumption");
  if (cursor) Check(cursor - input.data() == reference_cursor - reference_input.data(), "pinned source position");
  Check(actual == expected, "pinned complete output and guard bytes");
  Check(std::memcmp(&state, &reference_state, 8) == 0, "pinned all state bytes");
}

void GuardPages() {
  namespace g = gesher::bionic;
  Pages input, output;
  auto* word = reinterpret_cast<uint32_t*>(input.end()) - 1;
  char* byte = reinterpret_cast<char*>(output.end()) - 1;
  g::BionicMbstate state{};
  const uint32_t* cursor = word;
  *word = 'A'; *byte = '!';
  Check(g::Wcsnrtombs(byte, &cursor, 1, 1, &state) == 1 && *byte == 'A' && cursor == word + 1,
        "bounded ASCII never reads or writes past the last mapped unit");
  cursor = word; *word = 0; *byte = '!';
  Check(g::Wcsnrtombs(byte, &cursor, SIZE_MAX, 1, &state) == 0 && *byte == 0 && cursor == nullptr,
        "terminating NUL at a guard-page edge");
  cursor = reinterpret_cast<const uint32_t*>(input.end());
  Check(g::Wcsnrtombs(byte, &cursor, 0, 1, &state) == 0 && cursor == reinterpret_cast<const uint32_t*>(input.end()),
        "zero source bound does not read the protected page");
  cursor = word; *word = 'A';
  Check(g::Wcsnrtombs(reinterpret_cast<char*>(output.end()), &cursor, 1, 0, &state) == 0 && cursor == word,
        "zero output bound does not read or write beyond it");
  cursor = word;
  Check(g::Wcsnrtombs(nullptr, &cursor, 1, 0, nullptr) == 1 && cursor == word,
        "internal-state measurement stops at its exact source bound");
  auto* sequence = word - 1; sequence[0] = 'A'; sequence[1] = 0x1f642;
  cursor = sequence;
  char* two = byte - 1; two[0] = two[1] = '!';
  Check(g::Wcsnrtombs(two, &cursor, 2, 2, &state) == 1 && cursor == sequence + 1 &&
            two[0] == 'A' && two[1] == '!', "incomplete multibyte output never enters the guard page");
}
}  // namespace

int main() {
  Check(PinnedWideContractsMain() == 0, "complete maintained pinned wide corpus");
  namespace g = gesher::bionic;
  WideAsciiContracts<uint32_t, g::BionicMbstate>(g::Wcsnrtombs, g::Wcsrtombs, g::Wcstombs, Check);
  const uint32_t boundaries[] = {0, 1, 0x7f, 0x80, 0x7ff, 0x800, 0xd7ff, 0xd800, 0xdfff,
      0xe000, 0xffff, 0x10000, 0x10ffff, 0x110000, 0x1fffff, 0x200000,
      0x7fffffff, 0x80000000, 0xffffffff};
  for (uint32_t c : boundaries) {
    for (size_t prefix : {0u, 1u, 7u, 16u}) {
      std::vector<uint32_t> input(prefix, 'A');
      input.insert(input.end(), {c, 'Z', 0});
      for (size_t limit = 0; limit <= input.size() + 1; ++limit)
        for (size_t cap = 0; cap <= prefix + 7; ++cap)
          for (bool measure : {false, true}) Compare(input, limit, cap, measure);
    }
  }
  for (unsigned pending = 1; pending <= 4; ++pending)
    for (size_t cap : {0u, 1u, 8u})
      for (size_t limit : {0u, 1u, 8u})
        for (bool measure : {false, true}) Compare({'A', 0}, limit, cap, measure, pending);
  // All values accepted by the pinned encoder, including its surrogate and
  // non-Unicode asymmetry. Each call follows a real ASCII prefix.
  for (uint32_t c = 0; c <= 0x200000; ++c) Compare({'A', c, 'Z', 0}, 4, 9, false);
  GuardPages();
  std::printf("WIDE_ASCII_CONTRACT_PASS checks=%llu\n", static_cast<unsigned long long>(checks));
}
